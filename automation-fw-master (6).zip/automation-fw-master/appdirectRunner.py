"""
Example command

    ('python appdirect_stub.py --tags='+tags+,'behave --tags=@'+tags+' -k --no-capture')
"""

import argparse
import multiprocessing

import os

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--tags', required=True, help="TC ID")
    parser.add_argument('--log', required=False, help="pass DEBUG if you want to see the messages to debug")
    parser.add_argument('--debug-logs', required=False,
                        help="loggers with DEBUG level (e.g. database,classes.consumer_data)")
    parser.add_argument('-r', required=False, help="pass Y if you want report to be created in a separate file")
    parser.add_argument('-j', required=False, help="if true asks for jira token", action=argparse.BooleanOptionalAction)


    args = parser.parse_args()
    tags = args.tags
    logging_level = args.log
    debug_logs = args.debug_logs
    r = args.r
    j = args.j

    print(args)

    if j is not None:
        token = input("insert your jira token please\n")
        os.environ.setdefault("JIRA_TOKEN", token)

    all_processes = ['python appdirect_stub.py']

    behave_process = 'PYTHONPATH=.:$PYTHONPATH behave --tags=@' + tags + ' -k --no-logcapture'
    if logging_level is not None:
        behave_process += ' --logging-level ' + logging_level
    if debug_logs is not None:
        behave_process += ' -D debug_logs=' + debug_logs
    if r is not None and 'Y' in r:
        behave_process += ' -f json.pretty_custom -o report_' + tags + '.json'
    behave_process += ' -f pretty_custom'

    all_processes.append(behave_process)


    def execute(process):
        print(process)
        os.system(f'{process}')

    process_pool = multiprocessing.Pool(processes=3)
    process_pool.map(execute, all_processes)
