#!/usr/bin/env python
"""
Generate pydantic models from a JSON Swagger 2.0 API definition

Notes:
  - this script can be called from generate_models.py (to generate all models),
    so there is no need to call it directly
  - when all API definitions are updated to Openapi 3 (instead
    of Swagger 2.0), we will not need this script anymore, as we could use
    datamodel-code-generator instead.

Usage:
  # Clone tmf-gateway-api repository
  $ git clone --depth=1 https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/tmf-gateway-api.git /tmp/tmf-gateway-api

  # Generate pydantic models
  $ ./generate_models_from_swagger2.py --input=/tmp/tmf-gateway-api/api/TMF641-ServiceOrdering-v4.1.0.swagger.json --output=tmf_api.py
"""
import argparse
import enum
import json
import os
import re
from typing import Optional

THIS_DIR = os.path.dirname(os.path.abspath(__file__))


class Element(enum.Enum):
    """Top level elements."""
    CLASS = "BaseModel"
    ENUM = "Enum"


def get_cli_arguments() -> argparse.Namespace:
    """Get command line arguments."""
    parser = argparse.ArgumentParser(
        description="Tool generating Pydantic models from a swagger 2.0 API definition")
    parser.add_argument('--input', required=True, help="Input file")
    parser.add_argument('--output', required=True, help="Output file")
    parser.add_argument('--custom-file-header', help="Output file header")
    parser.add_argument('--additional-imports', help="Additional imports in output file")
    args = parser.parse_args()
    return args


def main() -> None:
    args = get_cli_arguments()

    with open(args.input, "r") as f:
        data = json.load(f)

    assert data.get("swagger") == "2.0", "This tool was tested with Swagger 2.0 only"

    
    file_header = args.custom_file_header or ""
    gen = ModelGenerator()
    content = gen.generate_file_content(data, file_header, args.additional_imports)

    print(f"Save file: {args.output} (converted from {args.input})")
    with open(args.output, "w", encoding="utf8") as f:
        f.write(content)


class ModelGenerator:
    def __init__(self) -> None:
        self.referenced_types = set()
        self.all_elements = {}

    def generate_file_content(self, data: dict, file_header: str, additional_imports: str | None) -> str:
        """Generate code for all types."""
        all_lines = [
            file_header,
            "from __future__ import annotations",
            "",
            "from enum import Enum",
            "from typing import Any, List",
            "",
            "from pydantic import BaseModel, Field",
        ]
        if additional_imports:
            all_lines.append("")
            for module_path in additional_imports.split(","):
                path, name = module_path.rsplit(".", 1)
                all_lines.append(f"from {path} import {name}")

        for name, node in data["definitions"].items():
            self._process_element(name, node)

        # Ensure all types used/referenced have a definition
        if undefined_types := self.referenced_types - self.all_elements.keys() - {"Any"}:
            raise Exception(f"Some referenced types are not defined: {undefined_types}")

        for lines in self.all_elements.values():
            all_lines.extend(["", ""] + lines)

        all_lines.extend(["", "", "# Now that all types are defined, resolve forward references"])
        for type_name, lines in self.all_elements.items():
            if lines[0].endswith("(BaseModel):"):
                all_lines.append(f"{type_name}.model_rebuild()")

        return "\n".join(all_lines + ["\n"])

    def _process_element(self, element: str, node: dict) -> None:
        """Process one API top-level element (Class or Enum)."""
        if not node:
            return
        lines = []
        if description := node.get("description"):
            lines.extend(f'"""{description}"""'.splitlines())

        top_element_type = self._get_top_element_type(node)
        if top_element_type == Element.CLASS:
            # process the properties of this class
            required_properties = node.get("required", [])
            for property, property_node in node.get("properties").items():
                line = self._generate_code_for_property(
                    property,
                    py_type=self._get_property_python_type(property_node),
                    description=property_node.get("description"),
                    is_required=property in required_properties)
                lines.append(line)

        elif top_element_type == Element.ENUM:
            # process the values of this Enum
            for value in node["enum"]:
                key = value.upper().replace(" ", "_")
                lines.append(f'{key} = "{value}"')

        else:
            raise Exception(f"Node should be a top-level class/enum: {node=}")

        self.all_elements[element] = [f"class {element}({top_element_type.value}):"] \
            + ["    " + line for line in lines]

    def _get_top_element_type(self, node: dict) -> Optional[Element]:
        """Determine the type of top element (class/Enum)."""
        api_type = node.get("type")
        if api_type == "string" and "enum" in node:
            return Element.ENUM
        elif api_type == "object":
            return Element.CLASS
        return None

    def _get_property_python_type(self, node: dict) -> str:
        """Determine the corresponding python type name."""
        assert self._get_top_element_type(node) is None, \
            f"Node should be a property {node=}"

        api_type = node.get("type")
        if api_type == "array":
            items_type = self._get_property_python_type(node["items"])
            return f"List[{items_type}]"
        elif api_type == "string":
            return "str"
        elif api_type == "boolean":
            return "bool"
        elif api_type == "integer":
            return "int"
        elif not node:
            return "Any"
        elif api_type is None and (ref := node.get("$ref")):
            # referencing another class/enum
            element_name = ref.removeprefix("#/definitions/")
            self.referenced_types.add(element_name)
            return element_name
        raise NotImplementedError(f"Python typpe for {node=}")

    def _generate_code_for_property(
            self, property: str, py_type: str, description: Optional[str],
            is_required: bool) -> str:
        """Generate the line of code for 1 property."""
        assert isinstance(py_type, str), f"{property} should be a property (not top-level Element)"

        field_kwargs = {}
        comments = []

        if is_required:
            comments.append("(REQUIRED)")
        elif default_value := self._get_default_value(py_type):
            field_kwargs["default"] = default_value

        # Alias (for API property names that would be invalid python field names)
        if property.startswith("@"):
            field_kwargs["alias"] = f'"{property}"'
            property = re.sub(r"^@", "field_", property)

        parts = [f"{property}:", py_type]
        if field_kwargs:
            kwargs = ', '.join([f'{k}={v}' for k, v in field_kwargs.items()])
            parts.append(f"= Field({kwargs})")
        if description:
            comments.append(description)

        if comments:
            parts.extend([" #"] + comments)

        line = " ".join(parts)
        return line

    @staticmethod
    def _get_default_value(py_type: str) -> str:
        """Get default value based on the type.

        Properties not marked as required in API definition have a
        default value (for when they are missing from messages).
        """
        if py_type == "bool":
            default = "False"
        elif py_type == "int":
            default = "0"
        elif py_type.startswith("List"):
            default = "[]"
        elif py_type in ["Any", "str"]:
            default = "None"
        else:  # a Class
            default = "None"
        return default


if __name__ == '__main__':
    main()
