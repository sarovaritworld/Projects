#!/bin/bash

git submodule init
git submodule update
git submodule update --remote --checkout


if ! command -v ./protoc &> /dev/null; then
  echo "Error: protoc not found or not executable in the current directory."
  exit 1
fi

# Execute the protoc command
PROTO_DIR="schema-repository/protobuf"
OUTPUT_DIR="./"

if [ -d "$PROTO_DIR" ]; then
    ./protoc -I="$PROTO_DIR" --python_out="$OUTPUT_DIR" "$PROTO_DIR"/*.proto
    echo "Protobuf files compiled successfully."
else
    echo "Error: Directory $PROTO_DIR does not exist."
    exit 1
fi

# -------------------------------
# How to use this script:
# -------------------------------
# 1. Make sure you have 'protoc' installed and available in the current directory.
#    You can download it from: https://github.com/protocolbuffers/protobuf/releases
#
# 2. Run this script from the root of your project:
#       ./scripts/update_submodule_and_protobuf.sh
#
# 3. The generated Python files will appear in the current directory.
