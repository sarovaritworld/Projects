# UNITY Automation Framework

## Links

More details can be found on the [Test Automation Framework Guidelines](https://confluence.tools.aws.vodafone.com/display/UCP/Test+Automation+Framework).
[Test Automation Best Practices](https://confluence.tools.aws.vodafone.com/display/UCP/Mastering+Automation+Guild+%3A+Best+Practices+for+Effective+Test+Development)
