#!/bin/bash

# Whether to use behavex
USE_BEHAVEX=1


if [ $ENVIRONMENT_NAME == "Unity-Middleware-DEV" ]; then
  SUITE="regression"

else
  SUITE="regression_staging"
fi
echo "Executing SUITE: $SUITE"


if [ "$USE_BEHAVEX" == "1" ]; then
  testing_tools/scripts/behavex/automation_fw_run_tests.sh -t $SUITE -d -e
  exit 0
fi


export PYTHONPATH=.:$PYTHONPATH
rm -f report_*.{json,log,html} rerun_failing.features

# Initial run
TAGS=$SUITE
python appdirect_stub.py &
behave features/ --tags=$TAGS \
  -k --no-capture \
  -f json.pretty_custom -o report_$TAGS.json \
  -f pretty_custom --junit
python PrintFailures.py --tags=$TAGS
python testing_tools/scripts/report_analyzer.py update --input-json-file report_$TAGS.json
python testing_tools/scripts/defect_mapper.py --input-json-file report_$TAGS.json --prepend-defects-to-errors
python send_report_to_lab/send_report_to_lab.py --input-file=report_$TAGS.json --tags=regression
python SendEmailToTeam.py --tags=$TAGS
python report_generator.py --input_json_file report_$TAGS.json --output_html_file report_$TAGS.html

# Rerun
if test -s "rerun_failing.features"; then
  TAGS=rerun_$SUITE
  python appdirect_stub.py &
  behave @rerun_failing.features \
    -k --no-capture \
    -f json.pretty_custom -o report_$TAGS.json \
    -f pretty_custom --junit
  python PrintFailures.py --tags=$TAGS
  python testing_tools/scripts/report_analyzer.py update --input-json-file report_$TAGS.json
  python testing_tools/scripts/defect_mapper.py --input-json-file report_$TAGS.json --prepend-defects-to-errors
  python send_report_to_lab/send_report_to_lab.py --input-file=report_$TAGS.json --tags=rerun_regression
  python SendEmailToTeam.py --tags=$TAGS
  python SendMessageToTeams.py --tags=$TAGS
  python report_generator.py --input_json_file report_$TAGS.json --output_html_file report_$TAGS.html
fi
