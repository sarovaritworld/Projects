"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : RingCentral Gateway
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/ringcentral-gateway/-/blob/master/openapi.yml
  Commit         : 379ebf61  (on 2025-05-20)
  Commit title   : docs(https://jira.tools.aws.vodafone.com.mcas.ms/browse/UN-41194): add key licenses to examples

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import AwareDatetime, BaseModel, Field, RootModel

from .utils import base_configuration


class Status(str, Enum):
    """
    Account status
    """

    INITIAL = "Initial"
    UNCONFIRMED = "Unconfirmed"
    CONFIRMED = "Confirmed"
    DISABLED = "Disabled"


class ContactInfo(BaseModel):
    """
    Address linked to the customer
    """

    id: str | None = Field(default=None, examples=["1092062004"])
    firstName: str | None = Field(default=None, examples=["John"])
    lastName: str | None = Field(default=None, examples=["Pitt"])
    contactPhone: str | None = Field(default=None, examples=["+441234567890"])
    email: str | None = Field(default=None, examples=["name@example.com"])
    extensionNumber: str | None = Field(default=None, examples=["301"])


class ErrorItem(BaseModel):
    timestamp: AwareDatetime | None = None
    status: float | None = None
    error: str | None = None
    path: str | None = None


class Brand(BaseModel):
    id: str | None = Field(default=None, examples=["7010"])
    name: str | None = Field(
        default=None, examples=["Vodafone Business UC with RingCentral"]
    )


class ServicePlan(BaseModel):
    id: str | None = Field(default=None, examples=["5899"])
    name: str | None = Field(default=None, examples=["RBS_VODAFONE_RCO"])


class ContractedCountry(BaseModel):
    id: str | None = Field(default=None, examples=["224"])


class Package(BaseModel):
    id: str | None = Field(default=None, examples=["1126"])
    version: str | None = Field(default=None, examples=["1"])


class ServiceInfo(BaseModel):
    brand: Brand | None = None
    servicePlan: ServicePlan | None = None
    contractedCountry: ContractedCountry | None = None
    package: Package | None = None


class AdditionalData(BaseModel):
    """
    A list of additional characteristics that characterize this service (ServiceCharacteristic [*])
    """

    billingAccountNumber: str | None = None
    billingServiceReference: str | None = None
    opportunityId: str | None = None
    maxExtensionLength: int | None = Field(default=None, examples=[5])


class CompanyAddress(BaseModel):
    """
    Address linked to the customer
    """

    street: str | None = Field(default=None, examples=["The Connection"])
    city: str | None = Field(default=None, examples=["Newbury"])
    state: str | None = Field(default=None, examples=["NY"])
    zip: str | None = Field(default=None, examples=["RG14 2FN"])
    country: str | None = Field(default=None, examples=["GB"])


class License(BaseModel):
    skuId: str | None = Field(default=None, examples=["LC_ALN_38"])
    """
    The SKU ID of the license
    """
    quantity: int | None = Field(default=None, examples=[5])
    """
    The quantity of licenses
    """


class RingCXAccount(BaseModel):
    accountId: str | None = Field(default=None, examples=["7863871106"])
    """
    RingCX account ID
    """
    opportunityId: str | None = Field(default=None, examples=["ibn8Yb34"])
    """
    Opportunity identifier
    """
    licenses: List[License] | None = None
    """
    The RCX account's licenses
    """


class License1(BaseModel):
    skuId: str = Field(..., examples=["LC_ALN_38"])
    """
    The SKU ID of the license
    """
    unassignedQuantity: int = Field(..., examples=[5])
    """
    The quantity of unassigned licenses
    """
    assignedQuantity: int = Field(..., examples=[2])
    """
    The quantity of assigned licenses
    """


class Licenses(RootModel[List[License1]]):
    """
    RingCentral Account Licenses
    """

    root: List[License1]
    """
    RingCentral Account Licenses
    """


class AccountEntity(BaseModel):
    """
    RingCentral Account entity
    """

    ucasAccountId: str = Field(..., examples=["7863871106"])
    """
    RingCentral ID account
    """
    vodafoneId: str = Field(..., examples=["3245256"])
    """
    Customer Vodafone ID
    """
    market: str = Field(..., examples=["VFUK"])
    """
    Market to which the customer belongs
    """
    mainNumber: str = Field(..., examples=["+441234567890"])
    """
    The main number associated to the account
    """
    status: Status = Field(..., examples=["Confirmed"])
    """
    Account status
    """
    profile: str | None = Field(default=None, examples=["Office Premium"])
    """
    Name of the service plan
    """
    accountActivatedOn: AwareDatetime | None = Field(
        default=None, examples=["2024-01-22T06:15:56Z"]
    )
    """
    The timestamp of account creation
    """
    accountDisabledOn: AwareDatetime | None = Field(
        default=None, examples=["2024-02-22T06:15:56Z"]
    )
    """
    Date until which an account will get deleted. The default value is 30 days since the current date. Required if status is equal to "Disabled" (RingCentral v1 API)

    """
    localAccountId: str | None = Field(default=None, examples=["11"])
    """
    External account ID second element splitted in _
    """
    externalAccountId: str = Field(..., examples=["VFDE_11"])
    """
    Full external account ID
    """
    serviceInfo: ServiceInfo
    companyName: str = Field(..., examples=["Core Lab Testing"])
    """
    Customer name
    """
    companyAddress: CompanyAddress
    contactInfo: ContactInfo
    """
    Address linked to the customer
    """
    additionalData: AdditionalData | None = None
