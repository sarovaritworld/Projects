"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : TMF Service Inventory Gateway API
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/tmf-svc-inventory-gw-api/-/blob/master/openapi.yaml
  Commit         : e2b9e270  (on 2025-05-23)
  Commit title   : docs(https://jira.tools.aws.vodafone.com/browse/UN-42648): add unity account licenses service sample in openapi spec

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from typing import List

from pydantic import BaseModel, Field

from .utils import base_configuration


class RelatedParty(BaseModel):
    """
    Related Entity reference. A related party defines party or party role linked to a specific entity.
    """

    id: str
    """
    unique identifier
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str = Field(..., alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """
    role: str | None = None
    """
    Role
    """
    marketCode: str | None = None
    """
    Market code
    """
    vodafoneAccountId: str | None = None
    """
    Vodafone Account ID
    """


class GeographicalAddress(BaseModel):
    """
    A place defines a GeographicalAddress of the HQ
    """

    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible
    """
    role: str
    streetName: str | None = None
    """
    Street Name
    """
    city: str | None = None
    """
    City
    """
    stateOrProvince: str | None = None
    """
    State or province
    """
    postcode: str | None = None
    """
    Postcode
    """
    country: str | None = None
    """
    Country
    """


class Error(BaseModel):
    """
    Used when an API throws an Error, typically with a HTTP error response-code (3xx, 4xx, 5xx)
    """

    code: str
    """
    Application relevant detail, defined in the API or a common list.
    """
    reason: str
    """
    Explanation of the reason for the error which can be shown to a client user.
    """
    message: str | None = None
    """
    More details and corrective actions related to the error which can be shown to a client user.
    """


class TenantInfo(BaseModel):
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    isvId: str | None = None
    """
    RingCentral account ID
    """
    isvTenantStatus: str | None = None
    """
    Account status
    """
    name: str | None = None
    """
    Company name
    """
    profile: str | None = None
    """
    Name of the service plan
    """
    currency: str | None = None
    """
    Currency of the current account
    """
    mainNumber: str | None = None
    """
    MainNumber of the current account
    """
    accountActivatedOn: str | None = None
    """
    The timestamp of account creation
    """
    accountDisabledOn: str | None = None
    """
    Date until which an account will get deleted. The default value is 30 days since the current date. Required if status is equal to "Disabled" (RingCentral v1 API)

    """
    localAccountId: str | None = None
    """
    External account ID second element split by _
    """
    externalAccountId: str | None = None
    """
    Full external account ID
    """
    billingAccountNumber: str | None = None
    billingServiceReference: str | None = None
    opportunityId: str | None = None


class TenantAdminInfo(BaseModel):
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    id: str | None = None
    firstName: str | None = None
    lastName: str | None = None
    email: str | None = None
    phoneNumber: str | None = None
    extensionNumber: str | None = None


class TenantConfig(BaseModel):
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    maxExtensionLength: str | None = None


class CAC(BaseModel):
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    marginIn: int | None = None
    marginOut: int | None = None
    marginAll: int | None = None
    burstMarginIn: int | None = None
    burstMarginOut: int | None = None
    burstMarginAll: int | None = None


class ServiceRefOrValue(BaseModel):
    """
    Describes a given characteristic of an object or entity
    """

    href: str | None = Field(
        default=None,
        examples=["/tmf-api/serviceInventory/v4/service/unity-rcx-tenant-VFUK-VF123"],
    )
    id: str | None = Field(default=None, examples=["unity-rcx-tenant-VFUK-VF123"])
    serviceType: str | None = Field(default=None, examples=["ucc.unity.rcx.tenant"])
    field_type: str | None = Field(default=None, alias="@type", examples=["ServiceRef"])
    field_referredType: str | None = Field(
        default=None, alias="@referredType", examples=["Service"]
    )


class RCXTenantInfo(BaseModel):
    """
    RCX Tenant info details
    """

    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    isvId: str | None = None
    """
    RCX account ID
    """
    isvStatus: str | None = None
    """
    Account status
    """
    subAccountsName: str | None = None
    partnerOpportunityId: str | None = None
    isvCreationTime: str | None = None


class License(BaseModel):
    skuId: str | None = None
    assignedQuantity: int | None = None


class RCXLicenses(BaseModel):
    """
    RCX Tenant Licenses info details
    """

    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    licenses: List[License] | None = None
    """
    RCX account licenses
    """


class License1(BaseModel):
    skuId: str | None = None
    assignedQuantity: int | None = None
    unassignedQuantity: int | None = None


class RingCentralLicenses(BaseModel):
    """
    RingCentral account licenses info details
    """

    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    licenses: List[License1] | None = None
    """
    RingCentral account licenses
    """


class ServiceCharacteristicItem(BaseModel):
    name: str | None = None
    """
    Name of the characteristic
    """
    valueType: str | None = None
    """
    Data type of the value of the characteristic
    """
    value: (
        TenantAdminInfo
        | TenantInfo
        | TenantConfig
        | CAC
        | RCXTenantInfo
        | RCXLicenses
        | RingCentralLicenses
        | None
    ) = None
    """
    Value of the characteristic
    """


class ServiceRelationship(BaseModel):
    """
    Describes links with other service(s) in the inventory.
    """

    relationshipType: str | None = None
    service: ServiceRefOrValue | None = None


class Service(BaseModel):
    """
    Service is a base class for defining the Service hierarchy. All Services are characterized as either being possibly visible and usable by a Customer or not. This gives rise to the two subclasses of Service: CustomerFacingService and ResourceFacingService.
    """

    id: str | None = None
    """
    Unique identifier of the service
    """
    href: str | None = None
    """
    Reference of the service
    """
    description: str | None = None
    """
    Free-text description of the service
    """
    name: str | None = None
    """
    Name of the service
    """
    serviceType: str | None = None
    """
    Business type of the service
    """
    place: List[GeographicalAddress] | None = None
    """
    A list of places (Place [*]). Used to define a place useful for the service (for example a geographical place whre the service is installed)
    """
    relatedParty: List[RelatedParty] | None = Field(
        default=None,
        examples=[
            [
                {
                    "id": "MarketInfo",
                    "@type": "RelatedParty",
                    "@referredType": "RelatedPartyChannelInfo",
                    "role": "channel",
                    "marketCode": "VFUK",
                    "vodafoneAccountId": 12345,
                }
            ]
        ],
    )
    """
    A list of related party references (RelatedParty [*]). A related party defines party or party role linked to a specific entity
    """
    serviceCharacteristic: List[ServiceCharacteristicItem] | None = None
    serviceRelationship: List[ServiceRelationship] | None = None
