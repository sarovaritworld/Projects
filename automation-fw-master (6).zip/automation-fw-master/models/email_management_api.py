"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : Email Management API
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/email-management-api/-/blob/master/openapi.yaml
  Commit         : 4065406c  (on 2021-07-15)
  Commit title   : fix: remove email subject length limit

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel, EmailStr, Field

from .utils import base_configuration


class Type(str, Enum):
    """
    Content type i.e. plain text or html encoded content
    """

    TEXT_PLAIN = "text/plain"
    TEXT_HTML = "text/html"


class Content(BaseModel):
    """
    Email message content
    """

    value: str
    """
    Content data e.g. Hello World
    """
    type: Type
    """
    Content type i.e. plain text or html encoded content
    """


class Person(BaseModel):
    """
    Message actor i.e. sender or recipient
    """

    email: EmailStr
    """
    Actor email address e.g. john.doe@gmail.com
    """
    name: str | None = None
    """
    Actor reference name e.g. John Doe
    """


class Problem(BaseModel):
    """
    Unauthorised operation problem response
    """

    type: str | None = None
    """
    URL to a page with more details regarding the problem
    """
    title: str
    """
    Status code description e.g. Unauthorized
    """
    detail: str | None = None
    """
    Human-readable description of the problem
    """
    instance: str | None = None
    """
    URI that describes where the problem occurred e.g. /test/path/caused/problem?log=false
    """
    status: int
    """
    HTTP status code
    """


class Format(str, Enum):
    """
    data file format as an IANA MIME-type
    """

    APPLICATION_JSON = "application/json"
    APPLICATION_PDF = "application/pdf"
    APPLICATION_XML = "application/xml"
    APPLICATION_ZIP = "application/zip"
    AUDIO_MPEG = "audio/mpeg"
    IMAGE_GIF = "image/gif"
    IMAGE_WEBP = "image/webp"
    IMAGE_JPEG = "image/jpeg"
    IMAGE_PNG = "image/png"
    MULTIPART_FORM_DATA = "multipart/form-data"
    TEXT_CSV = "text/csv"
    TEXT_HTML = "text/html"
    TEXT_PLAIN = "text/plain"
    TEXT_XML = "text/xml"


class FileAttachment(BaseModel):
    """
    File attachment information. Content is base64
    """

    data: str
    """
    base64 encoded file object data
    """
    name: str
    """
    Reference name
    """
    format: Format = Field(..., examples=["text/csv"])
    """
    data file format as an IANA MIME-type
    """


class KeyValuePairObject(BaseModel):
    """
    A JSON object representing a list of key-value pairs
    """

    key: str
    value: str


class Message(BaseModel):
    from_: Person = Field(..., alias="from")
    to: List[Person] = Field(..., min_length=1)
    """
    Primary recipient
    """
    cc: List[Person] | None = None
    """
    Carbon copies i.e. additional recipients
    """
    bcc: List[Person] | None = None
    """
    Blind carbon copies i.e. hidden recipients
    """
    subject: str | None = None
    """
    Title
    """
    header: List[KeyValuePairObject] | None = None
    content: List[Content]
    """
    Message content
    """
    attachment: List[FileAttachment] | None = None
    """
    List of attached files
    """
