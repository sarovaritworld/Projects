"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : ID Mapper API
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/id-mapper-api/-/blob/master/openapi.yaml
  Commit         : ac8c1061  (on 2025-04-21)
  Commit title   : docs(https://jira.tools.aws.vodafone.com/browse/UN-41859): Correct ItsmProvisioning in MSOC and TPM customer response

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List

from pydantic import BaseModel, Field, RootModel, constr

from .utils import base_configuration


class MarketEnum(str, Enum):
    """
    Market to which the customer or the account belongs to
    """

    MNC = "MNC"
    VFUK = "VFUK"
    VFDE = "VFDE"
    VFPT = "VFPT"
    VFES = "VFES"
    VFCZ = "VFCZ"
    VFIE = "VFIE"
    VFAL = "VFAL"
    VFGR = "VFGR"
    VFRO = "VFRO"
    VFIT = "VFIT"


class CustomerEntity(BaseModel):
    """
    Vodafone Operating Company (Op Co) entity
    """

    ringcentral_id: str
    """
    Customer RingCentral ID
    """
    vodafone_id: str
    """
    Vodafone ID
    """
    uuid: str | None = None
    """
    Universally Unique Identifier
    """
    name: str | None = None
    """
    OpCo name
    """
    market: MarketEnum


class MsocCustomerEntity(BaseModel):
    """
    Msoc Customer Operating Company Entity
    """

    msoc_bgid: str
    """
    Msoc Customer BGID
    """
    vodafone_id: str
    """
    Vodafone ID
    """
    name: str
    """
    OpCo name
    """
    market: MarketEnum


class BillingIdentifier(BaseModel):
    """
    Set of billing identifiers for MSOC accounts
    """

    service_identifier: str | None = Field(default=None, examples=["SVC0001"])
    customer_reference: str | None = Field(default=None, examples=["CUS0001"])


class Address(BaseModel):
    """
    Address of the company
    """

    street: str | None = Field(default=None, examples=["The Connection"])
    city: str | None = Field(default=None, examples=["Newbury"])
    zip: str | None = Field(default=None, examples=["RG14 2FN"])
    country: str | None = Field(default=None, examples=["GB"])


class MsocContact(BaseModel):
    """
    Contact details
    """

    first_name: str | None = Field(default=None, examples=["Peter"])
    last_name: str | None = Field(default=None, examples=["Pan"])
    email: str | None = Field(default=None, examples=["test-email@vodafone.com"])
    phone_number: str | None = Field(default=None, examples=[18002025091])


class ItsmProvisioning(BaseModel):
    """
    ITSM Provisioning details for an MSOC or TPM customer service
    """

    enable_provisioning: bool | None = Field(default=None, examples=[True])
    """
    Indicates if the customer service should be provisioned in ITSM
    """
    contract_start_date: str | None = Field(default=None, examples=["2024-04-18"])
    """
    Contract start date for the customer service
    """
    contract_end_date: str | None = Field(default=None, examples=["2099-12-31"])
    """
    Contract end date for the customer service
    """
    local_market_service_id: str | None = Field(default=None, examples=[12345])
    """
    An optional service ID provided by local markets
    """
    link_service_to_fully_onboarded_customer: bool | None = Field(
        default=None, examples=[True]
    )
    """
    Indicates if the service should be linked to a fully onboarded customer in ITSM
    """


class UserRequest(BaseModel):
    """
    User request Body
    """

    ringcentral_user_id: constr(pattern=r"^[a-zA-Z0-9-_]+$")
    """
    Customer RingCentral user ID
    """
    vodafone_user_id: constr(pattern=r"^[a-zA-Z0-9._@-]+$")
    """
    Vodafone user ID
    """


class UserResponse(BaseModel):
    """
    The details of a User entity
    """

    market: MarketEnum | None = None
    vodafone_account_id: str | None = None
    """
    The Vodafone internal account identifier of the User's parent Vodafone account.
    """
    ringcentral_account_id: str | None = None
    """
    The RingCentral ID of the User's parent RingCentral account.
    """
    ringcentral_user_id: str
    """
    The RingCentral User ID created under the RingCentral account.
    """
    vodafone_user_id: str
    """
    Vodafone user ID created under the Vodafone account.
    """


class VodafoneAccountId(RootModel[str]):
    root: str = Field(..., examples=[7797239476], title="Vodafone Account ID")
    """
    The Vodafone internal account identifier.
    """


class UnityAccountsList(RootModel[List[CustomerEntity]]):
    """
    A list of Unity account information objects
    """

    root: List[CustomerEntity] = Field(..., title="Unity Accounts List")
    """
    A list of Unity account information objects
    """


class Paging(BaseModel):
    page: Any | None = Field(default=None, examples=[1])
    """
    The current page returned in the API response
    """
    totalPages: Any | None = Field(default=None, examples=[1])
    """
    The total number of pages returned in the API response
    """
    perPage: Any | None = Field(default=None, examples=[100])
    """
    The number of elements per page returned in the API response
    """
    totalElements: Any | None = Field(default=None, examples=[1])
    """
    The total number of elements returned in the API response
    """


class TpmCustomerEntity(BaseModel):
    """
    Tpm Customer Operating Company Entity
    """

    bgid: str
    """
    TPM service identifier for the customer
    """
    vodafone_id: str
    """
    Vodafone ID
    """
    name: str
    """
    Customer name
    """
    market: MarketEnum
    market_country_code: str
    """
    Tpm customer market country code
    """
    ms_teams_tenant_id: str
    """
    Tpm customer ms teams tenant id
    """
    itsm_provisioning: ItsmProvisioning | None = None


class MsocCustomerEntityExtended(MsocCustomerEntity):
    """
    Msoc Customer Operating Company Entity extended with more info
    """

    ms_teams_tenant_id: str | None = Field(default=None, examples=["bb44-2222-ddd-66"])
    """
    Microsoft Teams tenant ID
    """
    hq_address: Address | None = None
    contact: MsocContact | None = None
    consent_countries: List[str] | None = Field(
        default=None, examples=[["GB", "DE", "ES", "PT", "IT"]]
    )
    customer_domains: List[str] | None = Field(
        default=None, examples=[["Domain1", "Domain2"]]
    )
    billing_identifiers: Dict[str, BillingIdentifier] | None = Field(
        default=None,
        examples=[
            [{"GB": {"service_identifier": "SVC0001", "customer_reference": "CUS0001"}}]
        ],
    )
    """
    Dictionary where the KEY is the Country Code ISO3166 and value is the set of billing account identifiers
    """
    itsm_provisioning: ItsmProvisioning | None = None
    cac_ids: List[str] | None = Field(default=None, examples=[["CAC216", "44232"]])


class ListUnityAccountsResponse(BaseModel):
    records: UnityAccountsList | None = None
    paging: Paging | None = None
