"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : TMF Gateway API Schemas
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/tmf-gateway-api/-/blob/master/api/TMF641-ServiceOrdering-v4.1.0.swagger.json
  Commit         : 0d6a0446  (on 2022-05-09)
  Commit title   : fix: UPUA-4510 - Reverted code changes for patch document to swagger

Generated with script: scripts/models/generate_models.py
"""
from __future__ import annotations

from enum import Enum
from typing import Any, List

from pydantic import BaseModel, Field

from .utils import base_configuration


class Addressable(BaseModel):
    """Base schema for adressable entities"""
    id: str = Field(default=None)  # unique identifier
    href: str = Field(default=None)  # Hyperlink reference


class AppointmentRef(BaseModel):
    """Refers an appointment, such as a Customer presentation or internal meeting or site visit"""
    id: str  # (REQUIRED) The identifier of the referred appointment
    href: str = Field(default=None)  # The reference of the appointment
    description: str = Field(default=None)  # An explanatory text regarding the appointment made with a party
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation


class CancelOrder(BaseModel):
    """A Order cancel is a type of task which  can  be used to place a request to cancel an order"""
    id: str = Field(default=None)  # id of the cancellation request (this is not an order id)
    href: str = Field(default=None)  # Hyperlink to access the cancellation request
    cancellationReason: str = Field(default=None)  # Reason why the order is cancelled.
    effectiveCancellationDate: str = Field(default=None)  # Date when the order is cancelled.
    requestedCancellationDate: str = Field(default=None)  # Date when the submitter wants the order to be cancelled
    state: TaskStateType = Field(default=None)  # Tracks the lifecycle status of the cancellation request, such as Acknowledged, Rejected, InProgress, Pending and so on.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class CancelServiceOrder(BaseModel):
    """Request for cancellation an existing Service order"""
    id: str = Field(default=None)  # unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    cancellationReason: str = Field(default=None)  # Reason why the order is cancelled.
    completionMessage: str = Field(default=None)  # an optional message describing the completion of the task if it is done as expected or it is denied for a reason (like order in an state of PoNR).
    effectiveCancellationDate: str = Field(default=None)  # Date when the order is cancelled.
    requestedCancellationDate: str = Field(default=None)  # Date when the submitter wants the order to be cancelled
    errorMessage: ErrorMessage = Field(default=None)  # the error(s) cause the termination of cancelServiceOrder (in TerminatedWithError state)
    serviceOrder: ServiceOrderRef = Field(default=None)
    state: TaskStateType = Field(default=None)  # Tracks the lifecycle status of the cancellation request, such as Acknowledged, Rejected, InProgress, Pending and so on.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class CancelServiceOrder_Create(BaseModel):
    """Request for cancellation an existing Service order
    Skipped properties: id,href,state,effectiveCancellationDate,completionMessage,errorMessage"""
    cancellationReason: str = Field(default=None)  # Reason why the order is cancelled.
    requestedCancellationDate: str = Field(default=None)  # Date when the submitter wants the order to be cancelled
    serviceOrder: ServiceOrderRef  # (REQUIRED)
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class Characteristic(BaseModel):
    """Describes a given characteristic of an object or entity through a name/value pair."""
    id: str = Field(default=None)  # Unique identifier of the characteristic
    name: str  # (REQUIRED) Name of the characteristic
    valueType: str = Field(default=None)  # Data type of the value of the characteristic
    characteristicRelationship: List[CharacteristicRelationship] = Field(default=[])
    value: Any  # (REQUIRED) The value of the characteristic
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class CharacteristicRelationship(BaseModel):
    """Another Characteristic that is related to the current Characteristic;"""
    id: str = Field(default=None)  # Unique identifier of the characteristic
    href: str = Field(default=None)  # Hyperlink reference
    relationshipType: str = Field(default=None)  # The type of relationship
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ConstraintRef(BaseModel):
    """Constraint reference. The Constraint resource represents a policy/rule applied to an entity or entity spec."""
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related entity.
    version: str = Field(default=None)  # constraint version
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class Entity(BaseModel):
    """Base entity schema for use in TMForum Open-APIs"""
    id: str = Field(default=None)  # unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class EntityRef(BaseModel):
    """Entity reference schema to be use for all entityRef class."""
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related entity.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class EntityValue(BaseModel):
    """Base entity value  schema for use in TMForum Open-APIs"""
    id: str = Field(default=None)  # Unique identifier of a related entity.
    href: str = Field(default=None)  # Reference of the related entity.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ErrorMessage(BaseModel):
    """represents an Error"""
    code: str = Field(default=None)  # error code
    message: str = Field(default=None)  # More details and corrective actions related to the error
    reason: str = Field(default=None)  # Explanation of the reason for the error
    referenceError: str = Field(default=None)  # URI of documentation describing the error
    status: str = Field(default=None)  # error code extension like sys-ABC-2001
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class Extensible(BaseModel):
    """Base Extensible schema for use in TMForum Open-APIs"""
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ExternalReference(BaseModel):
    """External reference of the individual or reference in other system"""
    id: str = Field(default=None)  # unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    externalReferenceType: str = Field(default=None)  # Type of the external reference
    name: str  # (REQUIRED) External reference name
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class Feature(BaseModel):
    """Configuration feature."""
    id: str = Field(default=None)  # Unique identifier of the feature.
    isBundle: bool = Field(default=False)  # True if this is a feature group. Default is false.
    isEnabled: bool = Field(default=False)  # True if this feature is enabled. Default is true.
    name: str  # (REQUIRED) This is the name for the feature.
    constraint: List[ConstraintRef] = Field(default=[])  # This is a list of feature constraints.
    featureCharacteristic: List[Characteristic]  # (REQUIRED) This is a list of Characteristics for a particular feature.
    featureRelationship: List[FeatureRelationship] = Field(default=[])


class FeatureRelationship(BaseModel):
    """Configuration feature"""
    id: str = Field(default=None)  # Unique identifier of the target feature.
    name: str  # (REQUIRED) This is the name of the target feature.
    relationshipType: str  # (REQUIRED) This is the type of the feature relationship.
    validFor: TimePeriod = Field(default=None)  # The period for which this feature relationship is valid.


class JeopardyAlert(BaseModel):
    """A JeopardyAlert represents a predicted exception during a process that may cause a risk to complete successfully the process."""
    id: str = Field(default=None)  # identifier of the JeopardyAlert
    alertDate: str = Field(default=None)  # A date time( DateTime). The date that the alert issued
    exception: str = Field(default=None)  #  The exception associated with this jeopardy alert
    jeopardyType: str = Field(default=None)  # A string represents the type of jeopardy/risk like Normal, Hazard, Critical, ...
    message: str = Field(default=None)  # A string represents the message of the alert
    name: str = Field(default=None)  # A string used to give a name to the jeopardy alert
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class Milestone(BaseModel):
    """Milestone represents an action or event marking a significant change or stage in a process like an order process."""
    id: str = Field(default=None)  # identifier of the Milestone
    description: str = Field(default=None)  # free-text description of the Milestone
    message: str = Field(default=None)  # A string represents the message of the milestone
    milestoneDate: str = Field(default=None)  # A date time( DateTime). The date that the milestone happens
    name: str = Field(default=None)  # A string used to give a name to the milestone
    status: str = Field(default=None)  # The milestone status
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class Note(BaseModel):
    """Extra information about a given entity"""
    id: str = Field(default=None)  # Identifier of the note within its containing entity
    author: str = Field(default=None)  # Author of the note
    date: str = Field(default=None)  # Date of the note
    text: str  # (REQUIRED) Text of the note
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class OrderItemActionType(Enum):
    """action to be performed on the product"""
    ADD = "add"
    MODIFY = "modify"
    DELETE = "delete"
    NOCHANGE = "noChange"


class Place(BaseModel):
    """Place reference. Place defines the places where the products are sold or delivered."""
    id: str = Field(default=None)  # Unique identifier of the place
    href: str = Field(default=None)  # Unique reference of the place
    name: str = Field(default=None)  # A user-friendly name for the place, such as [Paris Store], [London Store], [Main Home]
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class PlaceRef(BaseModel):
    """Place reference. PlaceRef defines the placeRefs where the products are sold or delivered."""
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related entity.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class RelatedEntityRefOrValue(BaseModel):
    """A reference to an entity, where the type of the entity is not known in advance. A related entity defines a entity described by reference or by value linked to a specific entity. The polymorphic attributes @type, @schemaLocation & @referredType are related to the Entity and not the RelatedEntityRefOrValue class itself"""
    id: str = Field(default=None)  # Unique identifier of a related entity.
    href: str = Field(default=None)  # Reference of the related entity.
    name: str = Field(default=None)  # Name of the related entity.
    role: str  # (REQUIRED)
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class RelatedParty(BaseModel):
    """Related Party reference. A related party defines party or party role linked to a specific entity."""
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related entity.
    role: str = Field(default=None)  # Role played by the related party
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(alias="@type")  # (REQUIRED) When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(alias="@referredType")  # (REQUIRED) The actual type of the target instance when needed for disambiguation.


class RelatedPlaceRefOrValue(BaseModel):
    """Related Entity reference. A related place defines a place described by reference or by value linked to a specific entity. The polymorphic attributes @type, @schemaLocation & @referredType are related to the place entity and not the RelatedPlaceRefOrValue class itself"""
    id: str = Field(default=None)  # Unique identifier of the place
    href: str = Field(default=None)  # Unique reference of the place
    name: str = Field(default=None)  # A user-friendly name for the place, such as [Paris Store], [London Store], [Main Home]
    role: str  # (REQUIRED)
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class RelatedServiceOrderItem(BaseModel):
    """RelatedServiceOrderItem (a ServiceOrder item) .The service order item which triggered service creation/change/termination."""
    id: str = Field(default=None)  # unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    itemId: str = Field(default=None)  # Identifier of the order item where the service was managed
    role: str = Field(default=None)  # role of the service order item for this service
    serviceOrderHref: str = Field(default=None)  # Reference of the related entity.
    serviceOrderId: str = Field(default=None)  # Unique identifier of a related entity.
    itemAction: OrderItemActionType = Field(default=None)  # Action of the order item for this service
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class ResourceRef(BaseModel):
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related entity.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class Service(BaseModel):
    """Service is a base class for defining the Service hierarchy. All Services are characterized as either being possibly visible and usable by a Customer or not. This gives rise to the two subclasses of Service: CustomerFacingService and ResourceFacingService."""
    id: str = Field(default=None)  # Unique identifier of the service
    href: str = Field(default=None)  # Reference of the service
    category: str = Field(default=None)  # Is it a customer facing or resource facing service
    description: str = Field(default=None)  # Free-text description of the service
    endDate: str = Field(default=None)  # Date when the service ends
    hasStarted: bool = Field(default=False)  # If TRUE, this Service has already been started
    isBundle: bool = Field(default=False)  # If true, the service is a ServiceBundle which regroup a service hierachy. If false, the service is a 'atomic' service (hierachy leaf).
    isServiceEnabled: bool = Field(default=False)  # If FALSE and hasStarted is FALSE, this particular Service has NOT been enabled for use - if FALSE and hasStarted is TRUE then the service has failed 
    isStateful: bool = Field(default=False)  # If TRUE, this Service can be changed without affecting any other services
    name: str = Field(default=None)  # Name of the service
    serviceDate: str = Field(default=None)  # Date when the service was created (whatever its status).
    serviceType: str = Field(default=None)  # Business type of the service
    startDate: str = Field(default=None)  # Date when the service starts
    startMode: str = Field(default=None)  # This attribute is an enumerated integer that indicates how the Service is started, such as: 0: Unknown; 1: Automatically by the managed environment; 2: Automatically by the owning device; 3: Manually by the Provider of the Service; 4: Manually by a Customer of the Provider; 5: Any of the above
    feature: List[Feature] = Field(default=[])  # A list of feature associated with this service 
    note: List[Note] = Field(default=[])  # A list of notes made on this service
    place: List[RelatedPlaceRefOrValue] = Field(default=[])  # A list of places (Place [*]). Used to define a place useful for the service (for example a geographical place whre the service is installed)
    relatedEntity: List[RelatedEntityRefOrValue] = Field(default=[])  # A list of related  entity in relationship with this service 
    relatedParty: List[RelatedParty] = Field(default=[])  # A list of related party references (RelatedParty [*]). A related party defines party or party role linked to a specific entity
    serviceCharacteristic: List[Characteristic] = Field(default=[])  # A list of characteristics that characterize this service (ServiceCharacteristic [*]) 
    serviceOrderItem: List[RelatedServiceOrderItem] = Field(default=[])  # A list of service order items related to this service
    serviceRelationship: List[ServiceRelationship] = Field(default=[])  # A list of service relationships (ServiceRelationship [*]). Describes links with other service(s) in the inventory.
    serviceSpecification: ServiceSpecificationRef = Field(default=None)  # The specification from which this service was instantiated
    state: ServiceStateType = Field(default=None)  # The life cycle state of the service, such as designed, reserved, active, etc...
    supportingResource: List[ResourceRef] = Field(default=[])  # A list of supporting resources (SupportingResource [*]).Note: only Service of type RFS can be associated with Resources
    supportingService: List[ServiceRefOrValue] = Field(default=[])  # A list of supporting services (SupportingService [*]). A collection of services that support this service (bundling, link CFS to RFS)
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrder(BaseModel):
    id: str = Field(default=None)  # ID created on repository side
    href: str = Field(default=None)  # Hyperlink to access the order
    cancellationDate: str = Field(default=None)  # Date when the order is cancelled. This is used when order is cancelled. 
    cancellationReason: str = Field(default=None)  # Reason why the order is cancelled. This is used when order is cancelled. 
    category: str = Field(default=None)  # Used to categorize the order, useful for the OM system, such as: Broadband, TVOption
    completionDate: str = Field(default=None)  # Effective delivery date amended by the provider
    description: str = Field(default=None)  # A free-text description of the service order
    expectedCompletionDate: str = Field(default=None)  # Expected delivery date amended by the provider
    externalId: str = Field(default=None)  # ID given by the consumer to facilitate searches
    notificationContact: str = Field(default=None)  # Contact attached to the order to send back information regarding this order
    orderDate: str = Field(default=None)
    priority: str = Field(default=None)  # Can be used by consumers to prioritize orders in a Service Order Management system
    requestedCompletionDate: str = Field(default=None)  # Requested delivery date from the requestors perspective
    requestedStartDate: str = Field(default=None)  # Order start date wished by the requestor
    startDate: str = Field(default=None)  # Date when the order was started for processing
    errorMessage: List[ServiceOrderErrorMessage] = Field(default=[])  # the error(s) cause an order status change
    externalReference: List[ExternalReference] = Field(default=[])
    jeopardyAlert: List[ServiceOrderJeopardyAlert] = Field(default=[])  # A list of jeopardy alerts related to this order
    milestone: List[ServiceOrderMilestone] = Field(default=[])  # A list of milestones related to this order
    note: List[Note] = Field(default=[])  # Extra-information about the order; e.g. useful to add extra delivery information that could be useful for a human process
    orderRelationship: List[ServiceOrderRelationship] = Field(default=[])  # A list of service orders related to this order (e.g. prerequisite, dependent on)
    relatedParty: List[RelatedParty] = Field(default=[])  # A list of parties which are involved in this order and the role they are playing
    serviceOrderItem: List[ServiceOrderItem] = Field(default=[])  # A list of service order items to be processed by this order
    state: ServiceOrderStateType = Field(default=None)  # State of the order: described in the state-machine diagram
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrder_Create(BaseModel):
    """
    Skipped properties: id,href,orderDate,completionDate,expectedCompletionDate,startDate,state,jeopardyAlert,errorMessage,milestone"""
    cancellationDate: str = Field(default=None)  # Date when the order is cancelled. This is used when order is cancelled. 
    cancellationReason: str = Field(default=None)  # Reason why the order is cancelled. This is used when order is cancelled. 
    category: str = Field(default=None)  # Used to categorize the order, useful for the OM system, such as: Broadband, TVOption
    description: str = Field(default=None)  # A free-text description of the service order
    externalId: str = Field(default=None)  # ID given by the consumer to facilitate searches
    notificationContact: str = Field(default=None)  # Contact attached to the order to send back information regarding this order
    priority: str = Field(default=None)  # Can be used by consumers to prioritize orders in a Service Order Management system
    requestedCompletionDate: str = Field(default=None)  # Requested delivery date from the requestors perspective
    requestedStartDate: str = Field(default=None)  # Order start date wished by the requestor
    externalReference: List[ExternalReference] = Field(default=[])
    note: List[Note] = Field(default=[])  # Extra-information about the order; e.g. useful to add extra delivery information that could be useful for a human process
    orderRelationship: List[ServiceOrderRelationship] = Field(default=[])  # A list of service orders related to this order (e.g. prerequisite, dependent on)
    relatedParty: List[RelatedParty] = Field(default=[])  # A list of parties which are involved in this order and the role they are playing
    serviceOrderItem: List[ServiceOrderItem]  # (REQUIRED) A list of service order items to be processed by this order
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrder_Update(BaseModel):
    """
    Skipped properties: id,href,orderDate,jeopardyAlert,errorMessage,milestone,@baseType,@schemaLocation,@type,cancellationDate,cancellationReason,category,completionDate,startDate"""
    description: str = Field(default=None)  # A free-text description of the service order
    expectedCompletionDate: str = Field(default=None)  # Expected delivery date amended by the provider
    externalId: str = Field(default=None)  # ID given by the consumer to facilitate searches
    notificationContact: str = Field(default=None)  # Contact attached to the order to send back information regarding this order
    priority: str = Field(default=None)  # Can be used by consumers to prioritize orders in a Service Order Management system
    requestedCompletionDate: str = Field(default=None)  # Requested delivery date from the requestors perspective
    requestedStartDate: str = Field(default=None)  # Order start date wished by the requestor
    externalReference: List[ExternalReference] = Field(default=[])
    note: List[Note] = Field(default=[])  # Extra-information about the order; e.g. useful to add extra delivery information that could be useful for a human process
    orderRelationship: List[ServiceOrderRelationship] = Field(default=[])  # A list of service orders related to this order (e.g. prerequisite, dependent on)
    relatedParty: List[RelatedParty] = Field(default=[])  # A list of parties which are involved in this order and the role they are playing
    serviceOrderItem: List[ServiceOrderItem] = Field(default=[])  # A list of service order items to be processed by this order
    state: ServiceOrderStateType = Field(default=None)  # State of the order: described in the state-machine diagram


class ServiceOrderErrorMessage(BaseModel):
    """A ServiceOrderErrorMessage represents an error that causes a status change in a service order."""
    code: str = Field(default=None)  # error code
    message: str = Field(default=None)  # More details and corrective actions related to the error
    reason: str = Field(default=None)  # Explanation of the reason for the error
    referenceError: str = Field(default=None)  # URI of documentation describing the error
    status: str = Field(default=None)  # error code extension like sys-ABC-2001
    timestamp: str = Field(default=None)  # Date when the error happened
    serviceOrderItem: List[ServiceOrderItemRef] = Field(default=[])  # A list of order item references corresponded to this error
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrderItem(BaseModel):
    id: str  # (REQUIRED) Identifier of the individual line item
    quantity: int = Field(default=0)  # Quantity ordered
    action: OrderItemActionType  # (REQUIRED) The action to be carried out on the Service. Can be: add, modify, delete, noChange
    appointment: AppointmentRef = Field(default=None)  # An appointment that was set up with a related party for this order item
    errorMessage: List[ServiceOrderItemErrorMessage] = Field(default=[])  # the error(s) cause an order item status change
    service: ServiceRefOrValue  # (REQUIRED) The Service to be acted on by the order item
    serviceOrderItem: List[ServiceOrderItem] = Field(default=[])  # A list of order items embedded to this order item
    serviceOrderItemRelationship: List[ServiceOrderItemRelationship] = Field(default=[])  # A list of order items related to this order item
    state: ServiceOrderItemStateType = Field(default=None)  # State of the order item: described in the state machine diagram. This is the requested state.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrderItemErrorMessage(BaseModel):
    """AServiceOrderItemErrorMessage represents an error that causes a status change in a service order item."""
    code: str = Field(default=None)  # error code
    message: str = Field(default=None)  # More details and corrective actions related to the error
    reason: str = Field(default=None)  # Explanation of the reason for the error
    referenceError: str = Field(default=None)  # URI of documentation describing the error
    status: str = Field(default=None)  # error code extension like sys-ABC-2001
    timestamp: str = Field(default=None)  # Date when the error happened
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrderItemRef(BaseModel):
    itemId: str = Field(default=None)  # Identifier of the line item
    serviceOrderHref: str = Field(default=None)  # Link to the order to which this item belongs to
    serviceOrderId: str = Field(default=None)  # Identifier of the order that this item belongs to
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class ServiceOrderItemRelationship(BaseModel):
    """Linked service order item to the one containing this attribute"""
    relationshipType: str = Field(default=None)  # The type of related order item, can be: dependency if the order item needs to be not started until another order item is complete
    orderItem: ServiceOrderItemRef = Field(default=None)  # A service order item in relationship with this order item
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrderItemStateType(Enum):
    """Possible values for the state of the order item"""
    ACKNOWLEDGED = "acknowledged"
    REJECTED = "rejected"
    PENDING = "pending"
    HELD = "held"
    INPROGRESS = "inProgress"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    FAILED = "failed"
    ASSESSINGCANCELLATION = "assessingCancellation"
    PENDINGCANCELLATION = "pendingCancellation"
    PARTIAL = "partial"


class ServiceOrderJeopardyAlert(BaseModel):
    """A ServiceOrderJeopardyAlert represents a predicted exception during a service order processing that would brings risk to complete successfully the ordetr."""
    id: str = Field(default=None)  # identifier of the JeopardyAlert
    alertDate: str = Field(default=None)  # A date time( DateTime). The date that the alert issued
    exception: str = Field(default=None)  #  The exception associated with this jeopardy alert
    jeopardyType: str = Field(default=None)  # A string represents the type of jeopardy/risk like Normal, Hazard, Critical, ...
    message: str = Field(default=None)  # A string represents the message of the alert
    name: str = Field(default=None)  # A string used to give a name to the jeopardy alert
    serviceOrderItem: List[ServiceOrderItemRef] = Field(default=[])  # A list of order item references corresponded to this alert
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrderMilestone(BaseModel):
    """ServiceOrderMilestone represents an action or event marking a significant change or stage in processing of a service order."""
    id: str = Field(default=None)  # identifier of the Milestone
    description: str = Field(default=None)  # free-text description of the Milestone
    message: str = Field(default=None)  # A string represents the message of the milestone
    milestoneDate: str = Field(default=None)  # A date time( DateTime). The date that the milestone happens
    name: str = Field(default=None)  # A string used to give a name to the milestone
    status: str = Field(default=None)  # The milestone status
    serviceOrderItem: List[ServiceOrderItemRef] = Field(default=[])  # A list of order item references corresponded to this milestone
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceOrderRef(BaseModel):
    """Service Order reference. Useful to understand the which was the Service order through which the service was instantiated in the service inventory"""
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related service order
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class ServiceOrderRelationship(BaseModel):
    """Linked service order to the one containing this attribute"""
    id: str  # (REQUIRED) The id of the related order
    href: str = Field(default=None)  # A hyperlink to the related order
    relationshipType: str  # (REQUIRED) The type of related order, such as: [dependency] if the order needs to be [not started] until another order item is complete (a service order in this case) or [cross-ref] to keep track of the source order (a productOrder)
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The entity type of the related order


class ServiceOrderStateType(Enum):
    """Possible values for the state of the order"""
    ACKNOWLEDGED = "acknowledged"
    REJECTED = "rejected"
    PENDING = "pending"
    HELD = "held"
    INPROGRESS = "inProgress"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"
    ASSESSINGCANCELLATION = "assessingCancellation"
    PENDINGCANCELLATION = "pendingCancellation"


class ServiceRef(BaseModel):
    """Service reference, for when Service is used by other entities"""
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related entity.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class ServiceRefOrValue(BaseModel):
    """A Service to be created defined by value or existing defined by reference. The polymorphic attributes @type, @schemaLocation & @referredType are related to the Service entity and not the RelatedServiceRefOrValue class itself"""
    id: str = Field(default=None)  # Unique identifier of the service
    href: str = Field(default=None)  # Reference of the service
    category: str = Field(default=None)  # Is it a customer facing or resource facing service
    description: str = Field(default=None)  # Free-text description of the service
    endDate: str = Field(default=None)  # Date when the service ends
    hasStarted: bool = Field(default=False)  # If TRUE, this Service has already been started
    isBundle: bool = Field(default=False)  # If true, the service is a ServiceBundle which regroup a service hierachy. If false, the service is a 'atomic' service (hierachy leaf).
    isServiceEnabled: bool = Field(default=False)  # If FALSE and hasStarted is FALSE, this particular Service has NOT been enabled for use - if FALSE and hasStarted is TRUE then the service has failed 
    isStateful: bool = Field(default=False)  # If TRUE, this Service can be changed without affecting any other services
    name: str = Field(default=None)  # Name of the service
    serviceDate: str = Field(default=None)  # Date when the service was created (whatever its status).
    serviceType: str = Field(default=None)  # Business type of the service
    startDate: str = Field(default=None)  # Date when the service starts
    startMode: str = Field(default=None)  # This attribute is an enumerated integer that indicates how the Service is started, such as: 0: Unknown; 1: Automatically by the managed environment; 2: Automatically by the owning device; 3: Manually by the Provider of the Service; 4: Manually by a Customer of the Provider; 5: Any of the above
    feature: List[Feature] = Field(default=[])  # A list of feature associated with this service 
    note: List[Note] = Field(default=[])  # A list of notes made on this service
    place: List[RelatedPlaceRefOrValue] = Field(default=[])  # A list of places (Place [*]). Used to define a place useful for the service (for example a geographical place whre the service is installed)
    relatedEntity: List[RelatedEntityRefOrValue] = Field(default=[])  # A list of related  entity in relationship with this service 
    relatedParty: List[RelatedParty] = Field(default=[])  # A list of related party references (RelatedParty [*]). A related party defines party or party role linked to a specific entity
    serviceCharacteristic: List[Characteristic] = Field(default=[])  # A list of characteristics that characterize this service (ServiceCharacteristic [*]) 
    serviceOrderItem: List[RelatedServiceOrderItem] = Field(default=[])  # A list of service order items related to this service
    serviceRelationship: List[ServiceRelationship] = Field(default=[])  # A list of service relationships (ServiceRelationship [*]). Describes links with other service(s) in the inventory.
    serviceSpecification: ServiceSpecificationRef = Field(default=None)  # The specification from which this service was instantiated
    state: ServiceStateType = Field(default=None)  # The life cycle state of the service, such as designed, reserved, active, etc...
    supportingResource: List[ResourceRef] = Field(default=[])  # A list of supporting resources (SupportingResource [*]).Note: only Service of type RFS can be associated with Resources
    supportingService: List[ServiceRefOrValue] = Field(default=[])  # A list of supporting services (SupportingService [*]). A collection of services that support this service (bundling, link CFS to RFS)
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class ServiceRelationship(BaseModel):
    id: str = Field(default=None)  # unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    relationshipType: str  # (REQUIRED)
    service: ServiceRefOrValue = Field(default=None)
    serviceRelationshipCharacteristic: List[Characteristic] = Field(default=[])
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name


class ServiceSpecificationRef(BaseModel):
    """Service specification reference: ServiceSpecification(s) required to realize a ProductSpecification."""
    id: str  # (REQUIRED) unique identifier
    href: str = Field(default=None)  # Hyperlink reference
    name: str = Field(default=None)  # Name of the related entity.
    version: str = Field(default=None)  # Service specification version
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class Extensible name
    field_referredType: str = Field(default=None, alias="@referredType")  # The actual type of the target instance when needed for disambiguation.


class ServiceStateType(Enum):
    """Valid values for the lifecycle state of the service"""
    FEASIBILITYCHECKED = "feasibilityChecked"
    DESIGNED = "designed"
    RESERVED = "reserved"
    INACTIVE = "inactive"
    ACTIVE = "active"
    TERMINATED = "terminated"


class TaskStateType(Enum):
    """Possible values for the state of a task"""
    ACCEPTED = "accepted"
    TERMINATEDWITHERROR = "terminatedWithError"
    INPROGRESS = "inProgress"
    DONE = "done"


class TimePeriod(BaseModel):
    """A period of time, either as a deadline (endDateTime only) a startDateTime only, or both"""
    endDateTime: str = Field(default=None)  # End of the time period, using IETC-RFC-3339 format
    startDateTime: str = Field(default=None)  # Start of the time period, using IETC-RFC-3339 format


class EventSubscription(BaseModel):
    """Sets the communication endpoint address the service instance must use to deliver notification information"""
    id: str  # (REQUIRED) Id of the listener
    callback: str  # (REQUIRED) The callback being registered.
    query: str = Field(default=None)  # additional data to be passed


class EventSubscriptionInput(BaseModel):
    """Sets the communication endpoint address the service instance must use to deliver notification information"""
    callback: str  # (REQUIRED) The callback being registered.
    query: str = Field(default=None)  # additional data to be passed


class ServiceOrderCreateEvent(BaseModel):
    """The notification data structure"""
    event: ServiceOrderCreateEventPayload = Field(default=None)  # The event payload linked to the involved resource object
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.


class ServiceOrderCreateEventPayload(BaseModel):
    """The event data structure"""
    serviceOrder: ServiceOrder = Field(default=None)  # The involved resource data for the event


class ServiceOrderAttributeValueChangeEvent(BaseModel):
    """The notification data structure"""
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.
    fieldPath: str = Field(default=None)  # The path identifying the object field concerned by this notification.
    event: ServiceOrderAttributeValueChangeEventPayload = Field(default=None)  # The event payload linked to the involved resource object


class ServiceOrderAttributeValueChangeEventPayload(BaseModel):
    """The event data structure"""
    serviceOrder: ServiceOrder = Field(default=None)  # The involved resource data for the event


class ServiceOrderStateChangeEvent(BaseModel):
    """The notification data structure"""
    event: ServiceOrderStateChangeEventPayload = Field(default=None)  # The event payload linked to the involved resource object
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.


class ServiceOrderStateChangeEventPayload(BaseModel):
    """The event data structure"""
    serviceOrder: ServiceOrder = Field(default=None)  # The involved resource data for the event


class ServiceOrderDeleteEvent(BaseModel):
    """The notification data structure"""
    event: ServiceOrderDeleteEventPayload = Field(default=None)  # The event payload linked to the involved resource object
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.


class ServiceOrderDeleteEventPayload(BaseModel):
    """The event data structure"""
    serviceOrder: ServiceOrder = Field(default=None)  # The involved resource data for the event


class ServiceOrderInformationRequiredEvent(BaseModel):
    """The notification data structure"""
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.
    fieldPath: str = Field(default=None)  # The path identifying the object field concerned by this notification.
    event: ServiceOrderInformationRequiredEventPayload = Field(default=None)  # The event payload linked to the involved resource object


class ServiceOrderInformationRequiredEventPayload(BaseModel):
    """The event data structure"""
    serviceOrder: ServiceOrder = Field(default=None)  # The involved resource data for the event


class ServiceOrderMilestoneEvent(BaseModel):
    """The notification data structure"""
    event: ServiceOrderMilestoneEventPayload = Field(default=None)  # The event payload linked to the involved resource object
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.


class ServiceOrderMilestoneEventPayload(BaseModel):
    """The event data structure"""
    serviceOrder: ServiceOrder = Field(default=None)  # The involved resource data for the event


class ServiceOrderJeopardyEvent(BaseModel):
    """The notification data structure"""
    event: ServiceOrderJeopardyEventPayload = Field(default=None)  # The event payload linked to the involved resource object
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.


class ServiceOrderJeopardyEventPayload(BaseModel):
    """The event data structure"""
    serviceOrder: ServiceOrder = Field(default=None)  # The involved resource data for the event


class CancelServiceOrderCreateEvent(BaseModel):
    """The notification data structure"""
    event: CancelServiceOrderCreateEventPayload = Field(default=None)  # The event payload linked to the involved resource object
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.


class CancelServiceOrderCreateEventPayload(BaseModel):
    """The event data structure"""
    cancelServiceOrder: CancelServiceOrder = Field(default=None)  # The involved resource data for the event


class CancelServiceOrderStateChangeEvent(BaseModel):
    """The notification data structure"""
    event: CancelServiceOrderStateChangeEventPayload = Field(default=None)  # The event payload linked to the involved resource object
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.


class CancelServiceOrderStateChangeEventPayload(BaseModel):
    """The event data structure"""
    cancelServiceOrder: CancelServiceOrder = Field(default=None)  # The involved resource data for the event


class CancelServiceOrderInformationRequiredEvent(BaseModel):
    """The notification data structure"""
    eventId: str = Field(default=None)  # The identifier of the notification.
    eventTime: str = Field(default=None)  # Time of the event occurrence.
    eventType: str = Field(default=None)  # The type of the notification.
    correlationId: str = Field(default=None)  # The correlation id for this event.
    domain: str = Field(default=None)  # The domain of the event.
    title: str = Field(default=None)  # The title of the event.
    description: str = Field(default=None)  # An explnatory of the event.
    priority: str = Field(default=None)  # A priority.
    timeOcurred: str = Field(default=None)  # The time the event occured.
    fieldPath: str = Field(default=None)  # The path identifying the object field concerned by this notification.
    event: CancelServiceOrderInformationRequiredEventPayload = Field(default=None)  # The event payload linked to the involved resource object


class CancelServiceOrderInformationRequiredEventPayload(BaseModel):
    """The event data structure"""
    cancelServiceOrder: CancelServiceOrder = Field(default=None)  # The involved resource data for the event


class Error(BaseModel):
    """Used when an API throws an Error, typically with a HTTP error response-code (3xx, 4xx, 5xx)"""
    code: str  # (REQUIRED) Application relevant detail, defined in the API or a common list.
    reason: str  # (REQUIRED) Explanation of the reason for the error which can be shown to a client user.
    message: str = Field(default=None)  # More details and corrective actions related to the error which can be shown to a client user.
    status: str = Field(default=None)  # HTTP Error code extension
    referenceError: str = Field(default=None)  # URI of documentation describing the error.
    field_baseType: str = Field(default=None, alias="@baseType")  # When sub-classing, this defines the super-class.
    field_schemaLocation: str = Field(default=None, alias="@schemaLocation")  # A URI to a JSON-Schema file that defines additional attributes and relationships
    field_type: str = Field(default=None, alias="@type")  # When sub-classing, this defines the sub-class entity name.


# Now that all types are defined, resolve forward references
Addressable.model_rebuild()
AppointmentRef.model_rebuild()
CancelOrder.model_rebuild()
CancelServiceOrder.model_rebuild()
CancelServiceOrder_Create.model_rebuild()
Characteristic.model_rebuild()
CharacteristicRelationship.model_rebuild()
ConstraintRef.model_rebuild()
Entity.model_rebuild()
EntityRef.model_rebuild()
EntityValue.model_rebuild()
ErrorMessage.model_rebuild()
Extensible.model_rebuild()
ExternalReference.model_rebuild()
Feature.model_rebuild()
FeatureRelationship.model_rebuild()
JeopardyAlert.model_rebuild()
Milestone.model_rebuild()
Note.model_rebuild()
Place.model_rebuild()
PlaceRef.model_rebuild()
RelatedEntityRefOrValue.model_rebuild()
RelatedParty.model_rebuild()
RelatedPlaceRefOrValue.model_rebuild()
RelatedServiceOrderItem.model_rebuild()
ResourceRef.model_rebuild()
Service.model_rebuild()
ServiceOrder.model_rebuild()
ServiceOrder_Create.model_rebuild()
ServiceOrder_Update.model_rebuild()
ServiceOrderErrorMessage.model_rebuild()
ServiceOrderItem.model_rebuild()
ServiceOrderItemErrorMessage.model_rebuild()
ServiceOrderItemRef.model_rebuild()
ServiceOrderItemRelationship.model_rebuild()
ServiceOrderJeopardyAlert.model_rebuild()
ServiceOrderMilestone.model_rebuild()
ServiceOrderRef.model_rebuild()
ServiceOrderRelationship.model_rebuild()
ServiceRef.model_rebuild()
ServiceRefOrValue.model_rebuild()
ServiceRelationship.model_rebuild()
ServiceSpecificationRef.model_rebuild()
TimePeriod.model_rebuild()
EventSubscription.model_rebuild()
EventSubscriptionInput.model_rebuild()
ServiceOrderCreateEvent.model_rebuild()
ServiceOrderCreateEventPayload.model_rebuild()
ServiceOrderAttributeValueChangeEvent.model_rebuild()
ServiceOrderAttributeValueChangeEventPayload.model_rebuild()
ServiceOrderStateChangeEvent.model_rebuild()
ServiceOrderStateChangeEventPayload.model_rebuild()
ServiceOrderDeleteEvent.model_rebuild()
ServiceOrderDeleteEventPayload.model_rebuild()
ServiceOrderInformationRequiredEvent.model_rebuild()
ServiceOrderInformationRequiredEventPayload.model_rebuild()
ServiceOrderMilestoneEvent.model_rebuild()
ServiceOrderMilestoneEventPayload.model_rebuild()
ServiceOrderJeopardyEvent.model_rebuild()
ServiceOrderJeopardyEventPayload.model_rebuild()
CancelServiceOrderCreateEvent.model_rebuild()
CancelServiceOrderCreateEventPayload.model_rebuild()
CancelServiceOrderStateChangeEvent.model_rebuild()
CancelServiceOrderStateChangeEventPayload.model_rebuild()
CancelServiceOrderInformationRequiredEvent.model_rebuild()
CancelServiceOrderInformationRequiredEventPayload.model_rebuild()
Error.model_rebuild()

