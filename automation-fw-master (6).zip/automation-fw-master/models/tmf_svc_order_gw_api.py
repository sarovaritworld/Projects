"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : TMF Service Order Gateway API
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/tmf-svc-order-gw-api/-/blob/master/openapi.yaml
  Commit         : 84089ec1  (on 2025-05-02)
  Commit title   : docs(https://jira.tools.aws.vodafone.com/browse/UN-42089): Add defaultPolicyAction field

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import List, Literal

from pydantic import AwareDatetime, BaseModel, Field, RootModel, constr

from .utils import base_configuration


class AnyDef(BaseModel):
    """
    A generic object for any definition
    """


class AppointmentRef(BaseModel):
    id: str | None = None
    href: str | None = None
    description: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class Entity(BaseModel):
    id: str | None = None
    href: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str = Field(..., alias="@type")


class CharacteristicRelationship(BaseModel):
    id: str | None = None
    href: str | None = None
    relationshipType: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class ConstraintRef(BaseModel):
    id: str | None = None
    href: str | None = None
    name: str | None = None
    version: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class ExternalReference(BaseModel):
    id: str | None = None
    href: str | None = None
    externalReferenceType: str | None = None
    name: str
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class ErrorResponse(BaseModel):
    code: str | None = None
    reason: str | None = None
    message: str | None = None


class Note(BaseModel):
    id: str | None = None
    author: str | None = None
    date: AwareDatetime | None = None
    text: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class RelatedEntityRefOrValue(BaseModel):
    id: str | None = None
    href: str | None = None
    name: str | None = None
    role: str
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class RelatedParty(BaseModel):
    id: str
    href: str | None = None
    name: str | None = None
    role: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str = Field(..., alias="@type")
    field_referredType: str = Field(..., alias="@referredType")


class RelatedPlaceRefOrValue(BaseModel):
    id: str | None = None
    href: str | None = None
    name: str | None = None
    role: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class ItemAction(str, Enum):
    ADD = "add"
    MODIFY = "modify"
    DELETE = "delete"
    NO_CHANGE = "noChange"


class RelatedServiceOrderItem(BaseModel):
    id: str | None = None
    href: str | None = None
    itemId: str | None = None
    role: str | None = None
    serviceOrderHref: str | None = None
    serviceOrderId: str | None = None
    itemAction: ItemAction | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class State(str, Enum):
    ACKNOWLEDGED = "acknowledged"
    REJECTED = "rejected"
    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"
    CANCELLED = "cancelled"


class ServiceOrderItemRef(BaseModel):
    itemId: str
    serviceOrderHref: str | None = None
    serviceOrderId: str | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class ServiceOrderItemRelationship(BaseModel):
    relationshipType: str | None = None
    orderItem: ServiceOrderItemRef | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class ServiceOrderJeopardyAlert(BaseModel):
    id: str | None = None
    alertDate: AwareDatetime | None = None
    exception: str | None = None
    jeopardyType: str | None = None
    message: str | None = None
    name: str | None = None
    serviceOrderItem: List[ServiceOrderItemRef] | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class ServiceOrderMilestone(BaseModel):
    id: str | None = None
    description: str | None = None
    message: str | None = None
    milestoneDate: AwareDatetime | None = None
    name: str | None = None
    status: str | None = None
    serviceOrderItem: List[ServiceOrderItemRef] | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class ServiceOrderRelationship(BaseModel):
    id: str
    href: str | None = None
    relationshipType: str
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class ServiceSpecificationRef(ConstraintRef):
    pass


class TimePeriod(BaseModel):
    endDateTime: AwareDatetime | None = None
    startDateTime: AwareDatetime | None = None


class MarketCode(str, Enum):
    VFUK = "VFUK"
    VFDE = "VFDE"
    VFES = "VFES"
    VFPT = "VFPT"
    VFCZ = "VFCZ"
    VFIE = "VFIE"
    VFAL = "VFAL"
    VFGR = "VFGR"
    VFRO = "VFRO"
    VFIT = "VFIT"
    MNC = "MNC"


class UccRelatedPartyChannelInfo(RelatedParty):
    countryCode: constr(min_length=2, max_length=2)
    marketCode: MarketCode
    orderSystem: str | None = None
    field_referredType: str = Field(..., alias="@referredType")
    field_type: str = Field(..., alias="@type")
    id: str


class RegisterListener(BaseModel):
    id: str | None = None
    callback: str
    query: str | None = None


class JsonPatch(BaseModel):
    pass


class Code(str, Enum):
    UNSUPPORTED_OPERATION = "UNSUPPORTED_OPERATION"
    UNAUTHORIZED_ACCESS = "UNAUTHORIZED_ACCESS"
    UNEXPECTED_ERROR = "UNEXPECTED_ERROR"
    INVALID_REQUEST = "INVALID_REQUEST"
    INVALID_SERVICE_ORDER = "INVALID_SERVICE_ORDER"
    DATA_NOT_FOUND = "DATA_NOT_FOUND"


class ErrorResponseModel(BaseModel):
    code: Code | None = None
    reason: str | None = None
    message: str | None = None


class UccItsmProvisioning(Entity):
    enableProvisioning: bool
    contractStartDate: AwareDatetime
    contractEndDate: AwareDatetime
    localMarketServiceId: str | None = None
    linkServiceToFullyOnboardedCustomer: bool | None = None


class DefaultPolicyAction(str, Enum):
    """
    Default policy action for all traffic if does not match any geoLocations or IP rule
    """

    ALLOW = "ALLOW"
    DENY = "DENY"


class UccTenantPolicies(Entity):
    enabled: bool
    defaultPolicyAction: DefaultPolicyAction | None = None
    """
    Default policy action for all traffic if does not match any geoLocations or IP rule
    """
    geoLocations: List[str] | None = None
    """
    ISO 3166-1 Alpha 2 country codes
    """
    ips: List[str] | None = None
    """
    IP addresses, ranges or CIDR blocks
    """


class UccMsocCacConfiguration(Entity):
    cacId: str
    marginIn: int | None = None
    marginOut: int | None = None
    marginAll: int | None = None
    burstMarginIn: int | None = None
    burstMarginOut: int | None = None
    burstMarginAll: int | None = None


class UccMsocCustomerBillingInfo(Entity):
    serviceIdentifier: str
    customerReferenceNumber: str


class UccMsocCustomerContact(Entity):
    firstName: str
    lastName: str
    email: str
    phoneNumber: str | None = None


class UccMsocCustomerInfo(Entity):
    name: str
    tenantId: str
    consentCountries: List[str]
    customerDomains: List[str]


class UccNumberRange(BaseModel):
    from_: str | None = Field(default=None, alias="from")
    to: str | None = None


class UccTenantAdminInfo(Entity):
    firstName: str
    lastName: str
    email: str
    phoneNumber: str | None = None
    extension: int | None = None


class UccTenantConfig(Entity):
    idpEntityId: str | None = None
    maxExtensionLength: int | None = None


class UccTenantFlowSettings(Entity):
    activateImmediately: bool | None = None
    sendWelcomeEmail: bool | None = None
    sendConfirmationEmail: bool | None = None


class UccTenantInfo(Entity):
    profile: str | None = None
    currency: str | None = None
    name: str | None = None
    mainNumber: str | None = None
    faxNumber: str | None = None
    carrierId: str | None = None
    billingAccountNumber: str | None = None
    billingServiceReference: str | None = None
    opportunityId: str | None = None
    podLocation: str | None = None


class ActivationStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"


class UccTpmCustomerInfo(Entity):
    name: str
    tenantId: str


class Provider(str, Enum):
    VFUK = "VFUK"
    VFDE = "VFDE"


class UccTenantPoolType(str, Enum):
    FIXED = "Fixed"
    MOBILE = "Mobile"
    FMC = "FMC"
    PRESENTATION = "Presentation"


class ErrorMessage(BaseModel):
    code: str | None = None
    message: str | None = None
    reason: str | None = None
    referenceError: str | None = None
    status: str | None = None
    timestamp: AwareDatetime | None = None
    serviceOrderItem: List[ServiceOrderItemRef] | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class FeatureRelationship(BaseModel):
    id: str | None = None
    name: str
    relationshipType: str
    validFor: TimePeriod | None = None


class GeographicAddress(RelatedPlaceRefOrValue):
    city: str | None = None
    country: str | None = None
    locality: str | None = None
    postcode: str | None = None
    stateOrProvince: str | None = None
    streetName: str | None = None
    streetNr: str | None = None
    streetNrLast: str | None = None
    streetNrLastSuffix: str | None = None
    streetNrSuffix: str | None = None
    streetSuffix: str | None = None
    streetType: str | None = None


class UccMsocNumber(Entity):
    poolType: UccTenantPoolType
    usageType: str | None = None
    capability: str | None = None
    emergencyAddressLocationId: str | None = None
    carrierId: str | None = None
    cacId: str | None = None


class UccMsocNumberPool(UccMsocNumber):
    pool: List[str]


class UccMsocNumberPoolRange(UccMsocNumber):
    poolRange: List[UccNumberRange]


class UccUnityNumber(Entity):
    poolType: UccTenantPoolType
    siteId: str | None = None
    carrierId: str | None = None
    activationStatus: ActivationStatus | None = None


class UccTenantPool(UccUnityNumber):
    pool: List[str]


class UccTenantPoolRange(UccUnityNumber):
    poolRange: List[UccNumberRange]


class UccTpmNumber(Entity):
    poolType: UccTenantPoolType
    country: str | None = None
    """
    ISO 3166-1 Alpha 2 country codes
    """
    provider: Provider | None = None


class UccTpmNumberPool(UccTpmNumber):
    pool: List[str]


class UccTpmNumberPoolRange(UccTpmNumber):
    poolRange: List[UccNumberRange]


class EntityHierarchyRef(
    RootModel[
        UccItsmProvisioning
        | UccMsocCustomerContact
        | UccMsocCacConfiguration
        | UccMsocCustomerBillingInfo
        | UccMsocCustomerInfo
        | UccMsocNumberPool
        | UccMsocNumberPoolRange
        | UccTenantAdminInfo
        | UccTenantConfig
        | UccTenantFlowSettings
        | UccTenantInfo
        | UccTenantPool
        | UccTenantPoolRange
        | UccTpmCustomerInfo
        | UccTpmNumberPool
        | UccTpmNumberPoolRange
        | UccTenantPolicies
    ]
):
    root: (
        UccItsmProvisioning
        | UccMsocCustomerContact
        | UccMsocCacConfiguration
        | UccMsocCustomerBillingInfo
        | UccMsocCustomerInfo
        | UccMsocNumberPool
        | UccMsocNumberPoolRange
        | UccTenantAdminInfo
        | UccTenantConfig
        | UccTenantFlowSettings
        | UccTenantInfo
        | UccTenantPool
        | UccTenantPoolRange
        | UccTpmCustomerInfo
        | UccTpmNumberPool
        | UccTpmNumberPoolRange
        | UccTenantPolicies
    )


class Characteristic(BaseModel):
    id: str | None = None
    name: str
    valueType: str
    characteristicRelationship: List[CharacteristicRelationship] | None = None
    value: EntityHierarchyRef | str | bool | int | List = Field(
        ..., discriminator="valueType"
    )


class Feature(BaseModel):
    id: str | None = None
    isBundle: bool | None = None
    isEnabled: bool | None = None
    name: str
    constraint: List[ConstraintRef] | None = None
    featureCharacteristic: List[Characteristic]
    featureRelationship: List[FeatureRelationship] | None = None


class ResourceRefOrValue(BaseModel):
    id: str
    href: str | None = None
    name: str | None = None
    category: str | None = None
    description: str | None = None
    endOperatingDate: AwareDatetime | None = None
    resourceCharacteristic: List[Characteristic] | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class ServiceOrdersList(RootModel[List[ServiceOrder]]):
    """
    A list of Service Orders
    """

    root: List[ServiceOrder] = Field(..., title="Service Orders List")
    """
    A list of Service Orders
    """


class ServiceOrder(BaseModel):
    id: str | None = None
    href: str | None = None
    cancellationDate: AwareDatetime | None = None
    cancellationReason: str | None = None
    category: str | None = None
    completionDate: AwareDatetime | None = None
    description: str | None = None
    expectedCompletionDate: AwareDatetime | None = None
    externalId: str | None = None
    notificationContact: str | None = None
    orderDate: AwareDatetime | None = None
    priority: str | None = None
    requestedCompletionDate: AwareDatetime | None = None
    requestedStartDate: AwareDatetime | None = None
    startDate: AwareDatetime | None = None
    errorMessage: List[ErrorMessage] | None = None
    externalReference: List[ExternalReference] | None = None
    jeopardyAlert: List[ServiceOrderJeopardyAlert] | None = None
    milestone: List[ServiceOrderMilestone] | None = None
    note: List[Note] | None = None
    orderRelationship: List[ServiceOrderRelationship] | None = None
    relatedParty: List[RelatedParty | UccRelatedPartyChannelInfo] | None = None
    serviceOrderItem: List[ServiceOrderItem]
    state: State | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


class ServiceOrderItem(BaseModel):
    id: str
    quantity: int | None = None
    action: ItemAction
    appointment: AppointmentRef | None = None
    errorMessage: List[ErrorMessage] | None = None
    service: ServiceRefOrValue
    serviceOrderItem: List[ServiceOrderItem] | None = None
    serviceOrderItemRelationship: List[ServiceOrderItemRelationship] | None = None
    state: State | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: constr(pattern=r"^ServiceOrderItem$") | None = Field(
        default=None, alias="@type"
    )


class ServiceRefOrValue(BaseModel):
    id: str | None = None
    href: str | None = None
    category: str | None = None
    description: str | None = None
    endDate: AwareDatetime | None = None
    hasStarted: bool | None = None
    isBundle: bool | None = None
    isServiceEnabled: bool | None = None
    isStateful: bool | None = None
    name: str | None = None
    serviceDate: AwareDatetime | None = None
    serviceType: str | None = None
    startDate: AwareDatetime | None = None
    startMode: str | None = None
    feature: List[Feature] | None = None
    note: List[Note] | None = None
    place: List[RelatedPlaceRefOrValue | GeographicAddress] | None = None
    relatedEntity: List[RelatedEntityRefOrValue] | None = None
    relatedParty: List[RelatedParty | UccRelatedPartyChannelInfo] | None = None
    serviceCharacteristic: List[Characteristic] | None = None
    serviceOrderItem: List[RelatedServiceOrderItem] | None = None
    serviceRelationship: List[ServiceRelationship] | None = None
    serviceSpecification: ServiceSpecificationRef | None = None
    state: State | None = None
    supportingResource: List[ResourceRefOrValue] | None = None
    supportingService: List[ServiceRefOrValue] | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")
    field_referredType: str | None = Field(default=None, alias="@referredType")


class ServiceRelationship(BaseModel):
    id: str | None = None
    href: str | None = None
    relationshipType: str
    service: ServiceRefOrValue | None = None
    serviceRelationshipCharacteristic: List[Characteristic] | None = None
    field_baseType: str | None = Field(default=None, alias="@baseType")
    field_schemaLocation: str | None = Field(default=None, alias="@schemaLocation")
    field_type: str | None = Field(default=None, alias="@type")


ServiceOrdersList.model_rebuild()
ServiceOrder.model_rebuild()
ServiceOrderItem.model_rebuild()
ServiceRefOrValue.model_rebuild()
