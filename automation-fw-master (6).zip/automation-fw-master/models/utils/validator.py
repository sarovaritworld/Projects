"""
Validator for pydantic models
"""
import logging
from typing import TypeVar, Type

from pydantic import ValidationError, BaseModel

logger = logging.getLogger(__name__)
T = TypeVar("T", bound=BaseModel)


def validate_model(data: dict, model_class: Type[T]) -> T:
    """Validate schema and instantiate model."""

    try:
        instance = model_class(**data)
    except ValidationError:
        model_name = model_class.__name__
        # Keep exception message brief for GCP results, but log full error
        logger.exception(f"Failed schema validation for '{model_name}': {data}")
        raise Exception(f"Failed schema validation for '{model_name}'")

    return instance


def model_to_json(model: BaseModel) -> str:
    return model.model_dump_json(exclude_unset=True)
