"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : CRF Gateway
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/crf-gateway/-/blob/master/openapi.yaml
  Commit         : c71b4f6b  (on 2024-09-11)
  Commit title   : chore(https://jira.tools.aws.vodafone.com/browse/UN-34235): Fix OpenAPI spec according to latest DEP documentation changes

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import AnyUrl, AwareDatetime, BaseModel, Field, RootModel

from .utils import base_configuration


class ResourceCharacteristic(BaseModel):
    """
    Describes a given characteristic of an object or entity through a name/value pair.
    """

    name: str
    """
    Name of the characteristic
    """
    value: bool
    field_type: str = Field(..., alias="@type")
    """
    Type of the characteristic
    """


class CharacteristicRelationship(BaseModel):
    """
    Another Characteristic that is related to the current Characteristic
    """

    marginIn: int | None = None
    marginOut: int | None = None
    marginAll: int | None = None
    burstMarginIn: int | None = None
    burstMarginOut: int | None = None
    burstMarginAll: int | None = None


class TMF652RelatedParty(BaseModel):
    """
    Related Entity reference. A related party defines party or party role linked to a specific entity.
    """

    id: str
    """
    Unique identifier of a related entity.
    """
    name: str
    """
    Name of the related entity.
    """
    externalPstnProvider: str | None = None
    """
    Identifier of any external PSTN provider associated with the given Market. Only used for Market related party objects.
    """
    field_referredType: str = Field(..., alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """
    field_type: str = Field(..., alias="@type")
    """
    Type of the related party
    """


class MarketRelatedParty(TMF652RelatedParty):
    externalPstnProvider: str


class RelatedPlaceRefOrValue(BaseModel):
    """
    Related Entity reference. A related place defines a place described by reference or by value linked to a specific entity. The polymorphic attributes @type, @schemaLocation & @referredType are related to the place entity and not the RelatedPlaceRefOrValue class itself
    """

    role: str = Field(..., examples=["Resource Location Value"])
    countryCode: str | None = Field(default=None, examples=["GB"])
    stateOrProvince: str | None = Field(default=None, examples=["Berkshire"])
    city: str | None = Field(default=None, examples=["Newbury"])
    postCode: str | None = Field(default=None, examples=["RG14 2FN"])
    streetName: str | None = Field(
        default=None, examples=["Vodafone House, The Connection"]
    )
    streetNr: str | None = Field(default=None, examples=["1"])


class Action(str, Enum):
    """
    Can be "add" | "modify" | "no_change" | "delete"
    """

    ADD = "add"
    MODIFY = "modify"
    NO_CHANGE = "no_change"
    DELETE = "delete"


class ResourceRelationshipItem(BaseModel):
    id: str | None = Field(default=None, examples=["447534889125"])
    """
    id of the related resource.
    """


class ResourceRelationship(RootModel[List[ResourceRelationshipItem]]):
    root: List[ResourceRelationshipItem]


class EventSubscription(BaseModel):
    """
    Sets the communication endpoint address the service instance must use to deliver notification information
    """

    id: str
    """
    Id of the listener
    """
    callback: str
    """
    The callback being registered.
    """
    query: str | None = None
    """
    additional data to be passed
    """


class EventSubscriptionInput(BaseModel):
    """
    Sets the communication endpoint address the service instance must use to deliver notification information
    """

    callback: str
    """
    The callback being registered.
    """
    query: str | None = None
    """
    additional data to be passed
    """


class ResourceCacInfo(BaseModel):
    """
    Item which contains all CAC information
    """

    marginIn: int | None = Field(default=None, examples=[1])
    marginOut: int | None = Field(default=None, examples=[2])
    marginAll: int | None = Field(default=None, examples=[1])
    burstMarginIn: int | None = Field(default=None, examples=[2])
    burstMarginOut: int | None = Field(default=None, examples=[3])
    burstMarginAll: int | None = Field(default=None, examples=[2])
    enabled: bool | None = Field(default=None, examples=[True])


class Error(BaseModel):
    """
    Used when an API throws an Error, typically with a HTTP error response-code (3xx, 4xx, 5xx)
    """

    code: str
    """
    Application relevant detail, defined in the API or a common list.
    """
    reason: str
    """
    Explanation of the reason for the error which can be shown to a client user.
    """
    message: str | None = None
    """
    More details and corrective actions related to the error which can be shown to a client user.
    """
    status: str | None = None
    """
    HTTP Error code extension
    """
    referenceError: AnyUrl | None = None
    """
    URI of documentation describing the error.
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class.
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class entity name.
    """


class Action1(str, Enum):
    """
    The action of the service order item
    """

    ADD = "add"
    DELETE = "delete"


class Service(BaseModel):
    name: str | None = Field(default=None, examples=["Microsoft Teams Phone Mobile"])
    """
    The service name
    """
    serviceType: str | None = Field(default=None, examples=["dep.tpm"])
    """
    The service type
    """


class ErrorMessage(BaseModel):
    """
    An error message added as part of the processing of the service order item.
    """

    code: str | None = Field(default=None, examples=[400])
    """
    The error code
    """
    message: str | None = Field(default=None, examples=["Bad request"])
    """
    More details and corrective actions related to the error
    """
    reason: str | None = Field(
        default=None, examples=["Microsoft rejected action for tenant with ID '12345'"]
    )
    """
    Explanation of the reason for the error
    """
    timestamp: AwareDatetime | None = Field(
        default=None, examples=["2023-12-06 13:31:15"]
    )
    """
    Date when the error happened
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    The sub-class Extensible name
    """


class ServiceCharacteristic(BaseModel):
    """
    A service characteristic of the current service order item
    """

    name: str | None = Field(default=None, examples=["dep.numbers.mobile"])
    """
    The name of the service characteristic
    """
    valueType: str | None = Field(default=None, examples=["array"])
    """
    Data type of the value of the characteristic
    """
    field_baseType: str | None = Field(
        default=None, alias="@baseType", examples=["Characteristic"]
    )
    """
    When sub-classing, this defines the super-class
    """
    value: List[str] | None = Field(
        default=None, examples=[["447785123101", "447785123110:447785123119"]]
    )


class TMF641RelatedParty(BaseModel):
    """
    A related party object related to a service order item
    """

    id: str | None = Field(
        default=None, examples=["dba616e8-db45-410e-98d1-6619b0ed4868"]
    )
    """
    Unique identifier of a Microsoft Tenant ID
    """
    field_type: str | None = Field(
        default=None, alias="@type", examples=["dep.microsoft.tenant"]
    )
    """
    When sub-classing, this defines the sub-class Extensible name.
    """
    field_referredType: str | None = Field(
        default=None, alias="@referredType", examples=["dep.microsoft.tenant"]
    )
    """
    The actual type of the target instance when needed for disambiguation
    """
    field_baseType: str | None = Field(
        default=None, alias="@baseType", examples=["RelatedParty"]
    )
    """
    When sub-classing, this defines the super-class
    """
    name: str | None = Field(default=None, examples=["Vodafone TPM POC"])
    """
    Name of the related party
    """
    marketCustomerId: str | None = Field(default=None, examples=["MTPM-cf14f313"])
    """
    Local market ID for this customer, also referred to as BGID
    """
    marketCode: str | None = Field(default=None, examples=["MNC"])
    """
    ISO 2 letter country codes as per ISO_3166-1_alpha-2
    """
    countryCode: str | None = Field(default=None, examples=["UK"])
    """
    ISO 2 letter country codes as per ISO_3166-1_alpha-2
    """


class ServiceOrderState(str, Enum):
    """
    The state of a service order or service order item
    """

    ACKNOWLEDGED = "acknowledged"
    REJECTED = "rejected"
    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"


class ConfigResourceCharacteristic(ResourceCharacteristic):
    characteristicRelationship: List[CharacteristicRelationship] | None = None


class ResourceRefOrValue(BaseModel):
    """
    Resource is an abstract entity that describes the common set of attributes shared by all concrete resources. The polymorphic attributes @type, @schemaLocation & @referredType are related to the Resource entity and not the related ResourceRefOrValue class itself
    """

    id: str = Field(..., examples=["447534889125"])
    """
    Identifier of an instance of the resource. Required to be unique within the resource type.  Used in URIs as the identifier for specific instances of a type.
    """
    href: str = Field(..., examples=["tel:+447534889125"])
    """
    The URI for the object itself.
    """
    place: RelatedPlaceRefOrValue | None = None
    resourceCharacteristic: (
        List[ResourceCharacteristic | ConfigResourceCharacteristic] | None
    ) = Field(
        default=None,
        examples=[
            [
                {"name": "Service", "value": "UNITY", "@type": "Service"},
                {"name": "Range", "value": 1, "@type": "Range"},
                {"name": "HEC Groups ID", "value": "HQ", "@type": "HEC Groups ID"},
                {
                    "name": "Market Configuration",
                    "value": True,
                    "@type": "Configuration",
                    "characteristicRelationship": [
                        {
                            "marginIn": 10,
                            "marginOut": 0,
                            "marginAll": 0,
                            "burstMarginIn": 30,
                            "burstMarginOut": 0,
                            "burstMarginAll": 0,
                        }
                    ],
                },
            ]
        ],
    )
    resourceRelationship: ResourceRelationship | None = None
    relatedParty: List[RelatedPlaceRefOrValue | MarketRelatedParty] | None = Field(
        default=None,
        examples=[
            [
                {
                    "id": "VFUK",
                    "name": "Market",
                    "externalPstnProvider": "VCS-TATA",
                    "@type": "Market",
                    "@referredType": "Market",
                },
                {
                    "id": "RingCentral",
                    "name": "Partner",
                    "@type": "Partner",
                    "@referredType": "Partner",
                },
                {
                    "id": "1SF222321",
                    "name": "Mercedes-Benz AG",
                    "@type": "Customer",
                    "@referredType": "Customer",
                },
            ]
        ],
    )


class ResourceCacInfoResponse(BaseModel):
    """
    Response returned by our get number information endpoint
    """

    id: str | None = Field(default=None, examples=["4183213758"])
    number: str | None = Field(default=None, examples=["+4183213758"])
    service: str | None = Field(default=None, examples=["UNITY"])
    market: str | None = Field(default=None, examples=["UK"])
    customer: str | None = Field(default=None, examples=["31546478"])
    cacInfo: ResourceCacInfo | None = None


class ServiceOrderItem(BaseModel):
    """
    A service order item entity
    """

    id: str | None = Field(
        default=None, examples=["ee07d500-65cd-46cd-9f8f-22ad32f05278"]
    )
    """
    The service order item ID
    """
    action: Action1 | None = Field(default=None, examples=["add"])
    """
    The action of the service order item
    """
    state: ServiceOrderState | None = None
    errorMessage: List[ErrorMessage] | None = None
    service: Service | None = None
    serviceCharacteristic: List[ServiceCharacteristic] | None = None
    relatedParty: List[TMF641RelatedParty] | None = None


class ResourceOrderItem(BaseModel):
    """
    An identified part of the order. A resource order is decomposed into one or more order items.
    """

    id: str | None = Field(default=None, examples=["01"])
    """
    Identifier of the line item (generally it is a sequence number 01, 02, 03, ...)
    """
    action: Action | None = None
    """
    Can be "add" | "modify" | "no_change" | "delete"
    """
    resource: ResourceRefOrValue | None = None


class ServiceOrder(BaseModel):
    """
    A service order entity
    """

    id: str | None = Field(
        default=None, examples=["68c558a8-f6e3-454f-b869-0620b3de3447"]
    )
    """
    Service order ID
    """
    state: ServiceOrderState | None = Field(default=None, examples=["inProgress"])
    serviceOrderItem: List[ServiceOrderItem] | None = None


class ResourceOrder(BaseModel):
    """
    A Resource Order is a request to provision a set of Resources (logical and physical) triggered by the request to provision a Service through a Service Order
    """

    id: str | None = Field(
        default=None, examples=["123e4567-e89b-12d3-a456-426614174000"]
    )
    """
    Identifier of an instance of the Resource Order. Required to be unique within the resource type.  Used in URIs as the identifier for specific instances of a type.
    """
    orderDate: AwareDatetime | None = None
    """
    Date when the order was created
    """
    completionDate: AwareDatetime | None = None
    """
    Date when the order was created
    """
    priority: int | None = Field(default=None, examples=[0])
    """
    A way that can be used by consumers to prioritize orders in OM system (from 0 to 4 : 0 is the highest priority, and 4 the lowest)
    """
    state: str | None = Field(default=None, examples=["acknowledged"])
    """
    The life cycle state of the resource.
    """
    orderItem: List[ResourceOrderItem] | None = None


class ResourceOrderStateChangeEventPayload(BaseModel):
    """
    The event data structure
    """

    resourceOrder: ResourceOrder | None = None
    """
    The involved resource data for the event
    """


class ResourceOrderInformationRequiredEventPayload(
    ResourceOrderStateChangeEventPayload
):
    """
    The event data structure
    """


class ServiceOrderNotification(BaseModel):
    """
    A notification received from the DEP TMF641 API
    """

    eventId: str | None = Field(
        default=None, examples=["af7b5cd8-64b5-4498-999e-95cd01f15ed6"]
    )
    """
    The event ID of the notification
    """
    eventTime: AwareDatetime | None = Field(
        default=None, examples=["2023-12-06 13:31:15"]
    )
    """
    Date when the notification was sent
    """
    correlationId: str | None = Field(
        default=None, examples=["6f638919-1e26-41cb-92a8-6676743feca2"]
    )
    """
    The correlation ID of the notification
    """
    eventType: str | None = Field(
        default=None, examples=["ServiceOrderStateChangeEvent"]
    )
    """
    The type of notification sent
    """
    event: ServiceOrder | None = None
    """
    The content of the notification
    """


class ResourceOrderStateChangeEvent(BaseModel):
    """
    The notification data structure
    """

    id: str | None = None
    """
    Identifier of the Process flow
    """
    href: str | None = None
    """
    Reference of the ProcessFlow
    """
    eventId: str | None = None
    """
    The identifier of the notification.
    """
    eventTime: AwareDatetime | None = None
    """
    Time of the event occurrence.
    """
    eventType: str | None = None
    """
    The type of the notification.
    """
    correlationId: str | None = None
    """
    The correlation id for this event.
    """
    domain: str | None = None
    """
    The domain of the event.
    """
    title: str | None = None
    """
    The title of the event.
    """
    description: str | None = None
    """
    An explnatory of the event.
    """
    priority: str | None = None
    """
    A priority.
    """
    timeOcurred: AwareDatetime | None = None
    """
    The time the event occured.
    """
    event: ResourceOrderStateChangeEventPayload | None = None
    """
    The event payload linked to the involved resource object
    """


class ResourceOrderInformationRequiredEvent(BaseModel):
    """
    The notification data structure
    """

    eventId: str | None = None
    """
    The identifier of the notification.
    """
    eventTime: AwareDatetime | None = None
    """
    Time of the event occurrence.
    """
    eventType: str | None = None
    """
    The type of the notification.
    """
    correlationId: str | None = None
    """
    The correlation id for this event.
    """
    domain: str | None = None
    """
    The domain of the event.
    """
    title: str | None = None
    """
    The title of the event.
    """
    description: str | None = None
    """
    An explnatory of the event.
    """
    priority: str | None = None
    """
    A priority.
    """
    timeOcurred: AwareDatetime | None = None
    """
    The time the event occured.
    """
    fieldPath: str | None = None
    """
    The path identifying the object field concerned by this notification.
    """
    event: ResourceOrderInformationRequiredEventPayload | None = None
    """
    The event payload linked to the involved resource object
    """
