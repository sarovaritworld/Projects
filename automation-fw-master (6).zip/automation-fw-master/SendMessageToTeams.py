import argparse
import os

from testing_tools.scripts.report.tools_classes.report import Report

THIS_DIR = os.path.dirname(os.path.abspath(__file__))


def get_cli_arguments() -> argparse.Namespace:
    """Get command line arguments."""
    parser = argparse.ArgumentParser(description='Generate nightly report from JSON file')
    parser.add_argument('--tags', help="TC ID")
    parser.add_argument('--input-file', help="Input JSON report file")
    args = parser.parse_args()
    assert args.tags or args.input_file, "Required: --tags or --input-file"
    return args


if __name__ == '__main__':
    args = get_cli_arguments()
    report_file = args.input_file or os.path.join(THIS_DIR, "report_" + args.tags + ".json")
    print(report_file)
    Report(report_file=report_file).create(dry_run=False)


