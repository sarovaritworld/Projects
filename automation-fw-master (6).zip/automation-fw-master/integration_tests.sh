#!/bin/bash

SUITE=$1
if [ $ENVIRONMENT_NAME == "Unity-Middleware-DEV" ]; then
  EXTRA_TAGS="-wip"
else
  EXTRA_TAGS="-wip_staging"
fi
echo "Executing SUITE: $SUITE"

export PYTHONPATH=.:$PYTHONPATH
rm -f report_*.{json,log,html} rerun_failing.features

# Initial run
TAGS=$SUITE
python appdirect_stub.py &
behave features/ --tags=$TAGS --tags=$EXTRA_TAGS \
  -k --no-capture \
  -f json.pretty_simple_custom -o report_$TAGS.json \
  -f pretty_custom --junit
python PrintFailures.py --tags=$TAGS
python send_report_to_lab/send_report_to_lab.py --input-file=report_$TAGS.json --tags=$TAGS
python report_generator.py --input_json_file report_$TAGS.json --output_html_file report_$TAGS.html

# Rerun
if test -s "rerun_failing.features"; then
  TAGS=rerun_failing_$SUITE
  python appdirect_stub.py &
  behave @rerun_failing.features \
    -k --no-capture \
    -f json.pretty_custom -o report_full_$TAGS.json \
    -f json.pretty_simple_custom -o report_$TAGS.json \
    -f pretty_custom --junit
  # on rerun: print 1 line error summary only, but send full error log to Datalake
  python PrintFailures.py --tags=$TAGS
  python send_report_to_lab/send_report_to_lab.py --input-file=report_$TAGS.json --tags=$TAGS
  python report_generator.py --input_json_file report_$TAGS.json --output_html_file report_$TAGS.html
fi

# On error: fail the current CI pipeline
if test -s "rerun_failing.features"; then
  echo "Test failing after rerun"
  exit 1
fi
