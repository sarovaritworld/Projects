import argparse
import os

from classes import sendemail

THIS_DIR = os.path.dirname(os.path.abspath(__file__))


def get_cli_arguments() -> argparse.Namespace:
    """Get command line arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--tags', help="TC ID")
    parser.add_argument('--input-file', help="Input JSON report file")
    args = parser.parse_args()
    assert args.tags or args.input_file, "Required: --tags or --input-file"
    return args


if __name__ == '__main__':
    args = get_cli_arguments()
    report_file = args.input_file or os.path.join(THIS_DIR, "report_" + args.tags + ".json")
    sendemail.send_nigthly_reports_email(report_file)
