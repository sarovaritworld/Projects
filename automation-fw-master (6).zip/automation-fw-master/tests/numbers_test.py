# Unit tests for functions in classes/numbers.py
from classes import numbers
from classes import asserts

original_pool = [
    '+441171072901',
    '+441171073902',
    '+441171073903',
    '+441171073904',
    '+441171072905'
    '+441171072906'
]
mixin_pool = [
    '+441171072911',
    '+441171073912',
    '+441171073913',
    '+441171073914',
    '+441171072915'
    '+441171072916'
]


def test_mix_numbers_mixin_only():
    final_pool = numbers.mix_numbers(original_pool, "VFUK", mixin_pool, False)
    original_pool_size = len(original_pool)
    final_pool_size = len(final_pool)
    asserts.equals(original_pool_size, final_pool_size, "Length of pool")

    expected_mixin_count = len(original_pool) // 2
    expected_original_numbers_count = original_pool_size - expected_mixin_count

    actual_mixin_count = len([number for number in final_pool if number in mixin_pool])
    actual_original_numbers_count = len([number for number in final_pool if number in original_pool])
    
    asserts.equals(actual_mixin_count, expected_mixin_count, "Mixin Count")
    asserts.equals(actual_original_numbers_count, expected_original_numbers_count, "Original numbers Count")


def test_mix_numbers_new_numbers_only():
    final_pool = numbers.mix_numbers(original_pool, "VFUK", None, True)
    original_pool_size = len(original_pool)
    final_pool_size = len(final_pool)
    asserts.equals(original_pool_size, final_pool_size, "Length of pool")

    expected_new_numbers_count = len(original_pool) // 2
    expected_original_numbers_count = original_pool_size - expected_new_numbers_count

    actual_new_numbers_count = len([number for number in final_pool if number not in original_pool])
    actual_original_numbers_count = len([number for number in final_pool if number in original_pool])

    asserts.equals(actual_new_numbers_count, expected_new_numbers_count, "New Numbers Count")
    asserts.equals(actual_original_numbers_count, expected_original_numbers_count, "Original numbers Count")


def test_mix_numbers_mixin_and_new_numbers():
    final_pool = numbers.mix_numbers(original_pool, "VFUK", mixin_pool, True)
    original_pool_size = len(original_pool)
    final_pool_size = len(final_pool)
    asserts.equals(original_pool_size, final_pool_size, "Length of pool")

    expected_new_numbers_count = len(original_pool) // 3
    expected_mixin_numbers_count = len(original_pool) // 3
    expected_original_numbers_count = original_pool_size - (expected_new_numbers_count + expected_mixin_numbers_count)

    actual_new_numbers_count = len([number for number in final_pool
                                    if (number not in original_pool and number not in mixin_pool)])
    actual_mixin_numbers_count = len([number for number in final_pool if number in mixin_pool])
    actual_original_numbers_count = len([number for number in final_pool if number in original_pool])

    asserts.equals(actual_new_numbers_count, expected_new_numbers_count, "New Numbers Count")
    asserts.equals(actual_mixin_numbers_count, expected_mixin_numbers_count, "Mixin Numbers Count")
    asserts.equals(actual_original_numbers_count, expected_original_numbers_count, "Original numbers Count")
