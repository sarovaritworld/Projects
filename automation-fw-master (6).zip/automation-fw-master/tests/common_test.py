import copy

import pytest

from classes import common

data = {
    "key": "value",
    "dict": {
        "inner_key": "inner_value",
        "inner_key_2": {"inner_value_2": "inner_value_3"}
    },
    "list": ["item", "item_2"],
    "list_of_dict": [
        {"inner_dict_key": {"inner_dict_value": "test"}},
        {"inner_dict_key_2": {"inner_dict_value": "innest_value", "other_key": "other_value"}}
    ],
    "externalReference": [
        {
            "name": "MARKET_ACCOUNT_ID",
            "id": "88558780937"
        },
        {
            "name": "ORDER_REFERENCE",
            "id": "OPCO5555"
        }
    ],
    "serviceOrderItem": [
        {
            "service": {
                "serviceCharacteristic": [
                    {
                        "name": "TenantInfo",
                        "valueType": "object",
                        "value": {
                            "@type": "UccTenantInfo",
                            "name": "Test_Automation",
                            "mainNumber": "+441155325630",
                            "billingAccountNumber": "OPCO2222",
                            "billingServiceReference": "OPCO3333",
                            "opportunityId": "OPCO4444"
                        }
                    },
                    {
                        "name": "TenantAdminInfo",
                        "valueType": "object",
                        "value": {
                            "@type": "UccTenantAdminInfo",
                            "firstName": "Something",
                            "lastName": "New",
                            "email": "automation27092022054204@automation-fw-1.com",
                            "phoneNumber": "+441155327632"
                        }
                    }
                ]
            }
        },
    ],
}


@pytest.mark.parametrize("field", ['key',
                                   'dict.inner_key',
                                   'list.[1]',
                                   'list_of_dict.[0].inner_dict_key',
                                   'unknown_path',
                                   'unknown_path.nested',
                                   '$.list_of_dict[?(@..inner_dict_value=="innest_value")].other_key',
                                   ])
def test_create_key(field):
    new_value = 'updated_value'
    data_copy = copy.deepcopy(data)
    common.create_or_update_key(data_copy, field, new_value)
    print(data_copy)
    assert common.find_first_value(data_copy, field) == new_value

@pytest.mark.parametrize("field", ['unknown_path.[0]',
                                   'unknown_path.[0].nested_dict'])
def test_create_key_fail(field):
    """ list cannot be handled """
    new_value = 'updated_value'
    data_copy = copy.deepcopy(data)
    try:
        common.create_or_update_key(data_copy, field, new_value)
    except KeyError:
        print("Value was not created")
    else:
        assert common.find_first_value(data_copy, field) == {}, "value is missing"


@pytest.mark.parametrize(
    "path_expr,expected_value",
    [
        ("$.serviceOrderItem[*].service.serviceCharacteristic[?(@.name=='TenantAdminInfo')].value.phoneNumber", "+441155327632"),
        ("$.externalReference[?(@.name=='MARKET_ACCOUNT_ID')].id", "88558780937"),
        ("$.field_that_is_missing", None),
    ])
def test_get_field_with_field_present(path_expr, expected_value):
    value = common.get_field(data, path_expr)
    assert value == expected_value, "using get_field"


def test_validate_message_with_valid_data():
    validation_set = {
        "$..serviceCharacteristic[?(@.name=='TenantInfo')].value.billingAccountNumber": "OPCO2222",
        "$..serviceCharacteristic[?(@.name=='TenantAdminInfo')].value.phoneNumber": "+441155327632",
        "$.externalReference[?(@.name=='MARKET_ACCOUNT_ID')].id": "88558780937",
        "$.field_that_is_missing": None,
        "$.key": "value",
    }
    common.validate_message(data, validation_set)


def test_validate_message_with_wrong_value():
    validation_set = {
        "$.key": "wrong_value",
    }
    with pytest.raises(AssertionError):
        common.validate_message(data, validation_set)
