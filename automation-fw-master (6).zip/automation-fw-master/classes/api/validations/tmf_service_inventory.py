"""
Validations for TMF Service Inventory API responses.
"""

from classes.domain.account import UnityAccount
from models.tmf_svc_inventory_gw_api import License1, Service

from common_python.parser.data_parser import Parser

def assert_common_service_schema(service_obj, account, service_type, id_prefix, name_prefix, description):
    """
        Assert that the service object matches the common service schema for the given account and service type.

        :param service_obj: The service object to validate.
        :param account: The UnityAccount instance containing market and customer info.
        :param service_type: The expected service type string.
        :param id_prefix: The prefix for the service id. e.g. unity-licenses
        :param name_prefix: The prefix for the service name.
        :param description: The expected description of the service.
        """
    market = account.market_code
    customer_id = account.op_co_customer_id
    assert service_obj["id"] == f"{id_prefix}-{market}-{customer_id}"
    assert service_obj["href"] == f"/tmf-api/serviceInventory/v4/service/{id_prefix}-{market}-{customer_id}"
    assert service_obj["description"] == description
    assert service_obj["name"] == f"{name_prefix} {market}-{customer_id}"
    assert service_obj["serviceType"] == service_type

def assert_related_party(service_obj, account):
    """
    Assert that the relatedParty field in the service object matches the expected values for the given account.

    :param service_obj: The service object (list of dicts) to validate.
    :param account: The UnityAccount instance containing market and customer info.
    """
    assert service_obj[0]["relatedParty"] is not None, "relatedParty should not be None"
    related_party = service_obj[0]["relatedParty"][0]
    assert len(related_party) > 0, "relatedParty should not be empty"
    assert related_party['id'] == "MarketInfo", "relatedParty id should be MarketInfo"
    assert related_party['@type'] == "RelatedParty", "relatedParty type should be RelatedParty"
    assert related_party['@referredType'] == "RelatedPartyChannelInfo", "relatedParty referredType should be RelatedPartyChannelInfo"
    assert related_party['role'] == "channel", "relatedParty role should be channel"
    assert related_party['marketCode'] == account.market_code, "relatedParty marketCode should match account market_code"
    assert related_party['vodafoneAccount'] == account.op_co_customer_id, "relatedParty vodafoneAccount should match account op_co_customer_id"

def validate_ringcentral_licenses_response(response_data, account: UnityAccount, expect_licenses=True):
    """
    https://confluence.tools.aws.vodafone.com/spaces/UCP/pages/457344817/TMF638+-+API+Definition#TMF638APIDefinition-Responsedatamapping.1
    :param response_data:
    :param account:
    :param expect_licenses:
    :return:
    """
    assert isinstance(response_data, list), "Response should be a list"
    assert len(response_data) == 1, "Should return one response object"
    assert len(response_data[0]) > 0, "Response data should not be empty"
    Service.model_validate(response_data[0])

    license_obj = response_data[0]
    assert_common_service_schema(
        license_obj,
        account,
        "ucc.unity.licenses",
        "unity-licenses",
        "VBUC Licenses",
        "VBUC licenses"
    )

    assert_related_party(license_obj, account)

    assert "serviceCharacteristic" in license_obj, "Missing serviceCharacteristic"
    assert len(license_obj["serviceCharacteristic"]) == 1, "serviceCharacteristic should be one item for licenses"
    service_characteristic = license_obj["serviceCharacteristic"][0]
    assert "RingcentralLicenses" in service_characteristic["name"], "Missing RingcentralLicenses in serviceCharacteristic"

    rc_licenses = Parser(license_obj).find_first(
        '$.serviceCharacteristic[?(@.name=="RingcentralLicenses")].value[*].licenses'
    )
    for lic in rc_licenses:
        if expect_licenses:
            if "licenses" in lic and lic["licenses"]:
                # Validate each license item using License1 model
                for l in lic["licenses"]:
                    License1.model_validate(l)
            else:
                assert lic["licenses"] == []