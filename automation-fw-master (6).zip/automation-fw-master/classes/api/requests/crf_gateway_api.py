"""
CRF Gateway API: Get phone number details form NGIN

User Story:
    https://jira.tools.aws.vodafone.com/browse/UN-19561

API Documentation:
    https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/crf-gateway/-/blob/master/openapi.yaml?ref_type=heads
    https://confluence.tools.aws.vodafone.com/pages/viewpage.action?spaceKey=UCP&title=CRF+Provisioning+LLD#CRFProvisioningLLD-NGIN-GetAccountInformation
"""

import logging
from dataclasses import dataclass

from common_python import api_requests

logger = logging.getLogger(__name__)
BASE_URL = "http://crf-gateway/crf-gateway/v1"


@dataclass
class Client:
    """
    Client interacting with CRF Gateway API.
    """
    token: api_requests.AuthType = api_requests.AuthType.VALID
    numbers_endpoint = "/numbers"

    def get_numbers(self, phone_number) -> api_requests.Response:
        """
        GET the phone number details (CAC info) from NGIN
        Mandatory parameter is phone number
        """
        phone_number = phone_number.replace("+", "")   # remove the + prefix from isd
        logging.info(f"Calling crf_gateway_numbers API to get details for phone number: {phone_number}")
        numbers_url = f"{BASE_URL}{self.numbers_endpoint}/{phone_number}"
        return api_requests.get(url=numbers_url, token=self.token, timeout=60)
