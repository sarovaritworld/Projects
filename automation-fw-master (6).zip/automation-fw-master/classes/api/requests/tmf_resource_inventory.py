"""
Client for TMF Resource Inventory Gateway API.

API documentation:
    https://confluence.tools.aws.vodafone.com/display/UCP/Authentication+with+AWS+Cognito#AuthenticationwithAWSCognito-TMF639ResourceInventoryAPI
    https://confluence.tools.aws.vodafone.com/pages/viewpage.action?pageId=671601293
"""
import logging
from dataclasses import dataclass

from common_python import api_requests

logger = logging.getLogger(__name__)
BASE_URL = "http://tmf-rsc-inventory-gw-api/tmf/tmf-api/resourceInventoryManagement/v4"


@dataclass
class Client:
    """Client interacting with TMF Resource Inventory Gateway API."""
    token: api_requests.AuthType = api_requests.AuthType.VALID

    def get_resource_by_id(self, resource_id):
        """Get request retrieves resources by resource_id"""
        return api_requests.get(url=self._url_resource(resource_id), token=self.token)

    @staticmethod
    def _url_resource(resource_id: str) -> str:
        return f"{BASE_URL}/resource/{resource_id}"
