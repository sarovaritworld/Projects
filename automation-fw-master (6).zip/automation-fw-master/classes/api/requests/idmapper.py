"""
Client for IDMapper API.

API documentation:
    https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/id-mapper-api/-/blob/master/openapi.yaml
"""
import logging
import os
from dataclasses import dataclass
from http import HTTPStatus
from typing import Optional

from classes import read_xmldata, polling
from classes.delay import Timeout
from common_python import api_requests

IDMAPPER_API_SERVER = os.environ.get("IDMAPPER_API_SERVER")
BASE_URL = f"http://{IDMAPPER_API_SERVER}/id-mapper"
logger = logging.getLogger(__name__)


@dataclass
class Client:
    """Client interacting with IDMapper API."""
    vodafone_id: Optional[str] = None
    market_code: str = "VFUK"
    token: api_requests.AuthType | str = api_requests.AuthType.VALID

    def get_account(self, ringcentral_id: Optional[str] = None) -> "AccountInfo":
        """Get account information.

        :param ringcentral_id: (Optional) ringcentral ID
        :return: account information
        """
        if ringcentral_id is not None:
            # Use endpoint with ringcentral_id as argument
            url = self._url_vfid(ringcentral_id)
        elif self.vodafone_id is not None:
            # Use endpoint with vodafone_id as argument
            url = self._url_rcid()
        else:
            raise Exception("Fetching account requires RCID or VFID")
        response = api_requests.get(url, token=self.token)
        return AccountInfo(response)

    def get_user(self, vodafone_user_id: str) -> api_requests.Response:
        """Retrieves a User entity and its parent account."""
        url = self._url_user(vodafone_user_id)
        return api_requests.get(url, token=self.token)

    def delete_user(self, vodafone_user_id: str) -> api_requests.Response:
        """Delete a User entity."""
        url = self._url_user(vodafone_user_id)
        return api_requests.delete(url, token=self.token)

    def create_user(self, payload: dict) -> api_requests.Response:
        """Add a new user to an existing account."""
        url = self._url_users()

        response = polling.wait_until(
            lambda: api_requests.post(url, json=payload, token=self.token),
            "IDMapper can access vodafone_id",
            stop_when=lambda response: response.status_code != 404,
            timeout=Timeout.create_account,
            raises=False)  # on timeout, return the last response (even if 404)
        return response

    def get_msoc_account(self, query_params: dict) -> api_requests.Response:
        """MSOC Customer Mapping."""
        return api_requests.get(self._url_msoc(), params=query_params, token=self.token)

    def get_unity_accounts(self, query_params: dict = None) -> api_requests.Response:
        """Unity Accounts."""
        return api_requests.get(self._url_unity_account(), params=query_params, token=self.token)

    def get_tpm_customer(self, query_params: dict = None) -> api_requests.Response:
        """tpm Accounts."""
        return api_requests.get(self._url_tpm_customer(), params=query_params, token=self.token)

    @staticmethod
    def create_user_default_payload() -> dict:
        return read_xmldata.read_jsonfile("create_sub_account")

    def _url_users(self) -> str:
        return f"{BASE_URL}/v1/ucc/id/mapper/markets/{self.market_code}/vfid/{self.vodafone_id}/users"

    def _url_user(self, vodafone_user_id: str) -> str:
        return f"{BASE_URL}/v1/ucc/id/mapper/markets/{self.market_code}/vfid/{self.vodafone_id}/users/{vodafone_user_id}"

    def _url_vfid(self, ringcentral_id) -> str:
        return f"{BASE_URL}/v1/ucc/id/mapper/rcid/{ringcentral_id}/vfid"

    def _url_rcid(self) -> str:
        return f"{BASE_URL}/v1/ucc/id/mapper/markets/{self.market_code}/vfid/{self.vodafone_id}/rcid"
    
    def _url_msoc(self) -> str:
        return f"{BASE_URL}/id-mapper/v1/ucc/msoc-account"

    def _url_unity_account(self) -> str:
        return f"{BASE_URL}/id-mapper/v1/ucc/unity-account"

    def _url_tpm_customer(self) -> str:
        return f"{BASE_URL}/id-mapper/v1/ucc/tpm-customer"


class AccountInfo:
    """Parse response of get_account."""
    def __init__(self, response: api_requests.Response) -> None:
        self.response = response
        self.exists = response.ok
        if not response.ok and self.response.status_code != HTTPStatus.NOT_FOUND:
            logger.info(f"IDMAPPER Response: {self.response.status_code}")

    def ringcentral_id(self) -> Optional[str]:
        if not self.response.ok:
            return None
        return self.response.json()["ringcentral_id"]
