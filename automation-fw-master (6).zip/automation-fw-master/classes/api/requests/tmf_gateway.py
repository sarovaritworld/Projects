"""
Client for TMF Service Order Gateway API.

API documentation:
https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/tmf-svc-order-gw-api/-/blob/master/openapi.yaml
"""
import logging
from dataclasses import dataclass

from classes import utils
from common_python import api_requests

logger = logging.getLogger(__name__)

BASE_URL = "http://tmf-svc-order-gw-api/tmf/tmf-api/serviceOrdering/v4"
SERVICE_ORDER_URL = BASE_URL + '/serviceOrder'
CANCEL_SERVICE_ORDER_URL = BASE_URL + '/cancelServiceOrder'
HUB_URL = BASE_URL + '/hub'


@dataclass
class Client:
    """Client interacting with TMF Service Order Gateway API."""

    token: api_requests.AuthType | str = api_requests.AuthType.VALID

    def create_service_order(self, payload):
        """Post request to create service order"""
        logging.info('Sending Service order')
        logging.info(utils.to_json(data=payload))
        return api_requests.post(SERVICE_ORDER_URL, json=payload, token=self.token)

    def get_service_order_by_id(self, service_order_id='628357cf767d2124cc0b60c3'):
        """Get request retrieves Service Order by id"""
        return api_requests.get(f'{SERVICE_ORDER_URL}/{service_order_id}', token=self.token)

    def get_service_order(self):
        """List service orders"""
        pass

    def patch_service_order(self, service_order_id):
        """Update/patch service order"""
        pass

    def register_listener(self):
        """Creates a listener"""
        pass

    def deregister_listener(self):
        """Deregisters a listener"""
        pass
