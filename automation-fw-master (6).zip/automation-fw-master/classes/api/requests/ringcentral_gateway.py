"""
Client for RingCentral Gateway API.

API documentation:
    https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/ringcentral-gateway/-/blob/master/openapi.yml
"""
import logging
from dataclasses import dataclass

from common_python import api_requests
from common_python.stub_accounts.stub_accounts import StubAccounts

BASE_URL = "http://ringcentral-gateway/ringcentral-gateway/v1"
logger = logging.getLogger(__name__)
stub_accounts = StubAccounts()


class AccountIdIsNotProvidedException(Exception):
    pass


@dataclass
class Client:
    """Client interacting with RingCentral Gateway API."""
    token: api_requests.AuthType | str = api_requests.AuthType.VALID

    def get_account_info(
            self, ucas_account_id: str | None,
            params: dict | None = None) -> api_requests.Response:
        """Get account information.

        :param ucas_account_id:  ringcentral ID
        :return: account information from RingCentral resources
        """
        if ucas_account_id is None:
            raise AccountIdIsNotProvidedException('ucas_account_id should be provided')
        url = self._url_account_info(ucas_account_id)
        return api_requests.get(url, token=self.token, params=params)

    def request_to_invalid_path(self) -> api_requests.Response:
        """Making request to invalid path"""
        url = self._url_wrong()
        return api_requests.get(url, token=self.token)

    def _url_account_info(self, ucas_account_id) -> str:
        return f"{BASE_URL}/accounts/{ucas_account_id}"

    def _url_wrong(self) -> str:
        return f"{BASE_URL}/invalid_url"


td_ringcentral_id = {
    "blank": " ",
    "valid": "995298744",
    "Account_does_not_exist_in_RC": "995757138",
    "NOK_Bad_Request": "990095274",
    "No_ResponseFromRC": "992061420",
    "negative_rc_id": "123456789",
    "ok_nok_rc_id": "999611007",
    "non_existing_number": "992925066",
    "Server_Not_Found": "997513445",
    "Bad_Request": "993612852",
    "retry_pass_too_many_requests": "991699020934144",
    "retry_fail_too_many_requests": "991699021079225",
    "retry_pass_internal_server_error": "991699021159059",
    "retry_fail_internal_server_error": "991699021008044",
    "request_pass_on_third_time_too_many_requests": "991701349550081",
    "request_pass_on_third_time_internal_server_error": "991701349020570",
    "Bad_Gateway": "991923415",
    "RC_Timeout": "991710931241820",
    "CRF_TIMEOUT_ACCOUNT": "SAVECAC382172201",
    "previously_added_main_number": stub_accounts.rc.previously_added_main_number
}
RCID_SAVE_DB_PREFIX = "333"
VFID_SAVE_DB_PREFIX = "SAVE"
VFID_SAVE_CAC_PREFIX = "SAVECAC"
VFID_RETRY_PASS_PREFIX = "SAVECAC_RTY_PASS_"
VFID_RETRY_FAIL_PREFIX = "SAVECAC_RTY_FAIL_"
VFID_NO_MAIN_NUMBER = "SAVE675899286"