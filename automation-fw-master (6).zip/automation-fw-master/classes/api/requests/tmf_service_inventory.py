"""
Client for TMF Service Inventory Gateway API.

API documentation:
    https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/tmf-svc-inventory-gw-api/-/blob/master/openapi.yaml
    https://confluence.tools.aws.vodafone.com/display/UCP/TMF638+-+API+Definition#TMF638APIDefinition-Endpointsandmethods
"""
import logging
from dataclasses import dataclass

from common_python import api_requests

logger = logging.getLogger(__name__)
BASE_URL = "http://tmf-svc-inventory-gw-api/tmf/tmf-api/serviceInventory/v4"


@dataclass
class Client:
    """Client interacting with TMF Service Inventory Gateway API."""
    token: api_requests.AuthType = api_requests.AuthType.VALID

    def get_services(self, **params) -> api_requests.Response:
        """Get all service entities.

        For positive tests, the 3 parameters are mandatory: market, vodafoneAccountId, serviceType
        """
        logging.info(f"Calling tmf_service_inventory API to get services with parameters: {params}")
        return api_requests.get(
            url=self._url_services(), params=params, token=self.token,
            timeout=3*60)  # allow extra timeout as SI needs time to make multiple API calls (with possible retries)

    def get_service(self, id: str, **params) -> api_requests.Response:
        """Get a service entity.

        For positive tests, there are no parameters defined.
        """
        return api_requests.get(url=self._url_service(id), params=params, token=self.token)

    @staticmethod
    def _url_services() -> str:
        return f"{BASE_URL}/service"

    @staticmethod
    def _url_service(id: str) -> str:
        return f"{BASE_URL}/service/{id}"
