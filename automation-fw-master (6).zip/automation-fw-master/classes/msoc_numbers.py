import logging

from classes import numbers, payload, read_xmldata

logger = logging.getLogger(__name__)


def msoc_number_check(item: dict, action) -> bool:
    return item['service']['serviceType'] == 'ucc.msoc.numbers' and item['action'] == action


def item_is_add_msoc_number(item: dict) -> bool:
    return msoc_number_check(item, action='add')


def item_is_delete_msoc_number(item: dict) -> bool:
    return msoc_number_check(item, action='delete')


def has_delete_msoc_numbers(payload):
    for item in payload['serviceOrderItem']:
        if msoc_number_check(item, action='delete'):
            return True
    return False


def has_add_msoc_numbers(payload):
    for item in payload['serviceOrderItem']:
        if msoc_number_check(item, action='add'):
            return True
    return False


def add_remove_msoc_numbers(context, action, quantity, pool_type, order_type=None, carrier_id=None):
    context.msoc_service_order_type = order_type
    if order_type == "separate" and hasattr(context, "payload"):
        context.payload['serviceOrderItem'].clear()

    _payload = payload.append_item_to_payload(context, action + '_msoc_numbers', action)
    if pool_type == "pool":
        context.msoc_number_type = "msocPool"
    else:
        context.msoc_number_type = "msocPoolRange"
    logging.info(f'{_payload=}')
    context.action = action
    context.quantity = quantity
    context.pool_type = pool_type
    number_item = payload.get_last_item(_payload)
    if not hasattr(context, 'added_numbers'):
        context.added_numbers = []

    context.index = _payload['serviceOrderItem'].index(number_item)

    if 'delete' in action:
        _payload['serviceOrderItem'].clear()
        _payload['serviceOrderItem'].append(number_item)
        context.index = _payload['serviceOrderItem'].index(number_item)
        _payload = payload.refresh_ids(_payload)

        if pool_type == "pool_range":
            _payload["serviceOrderItem"][context.index]['service']['supportingResource'][0]['resourceCharacteristic'][
                0]['value']['@type'] = 'UccMsocNumberPoolRange'
            from_range_number = context.from_range_number if len(
                context.added_numbers) > 0 else numbers.generate_phone_number(context.market_code)
            to_range_number = read_xmldata.add_range_number(from_range_number, quantity)

            _payload["serviceOrderItem"][context.index]['service']['supportingResource'][0]['resourceCharacteristic'][
                0]['value']['poolRange'] = [{"from": from_range_number, "to": to_range_number}]

        else:
            context.number_pool_list = numbers.generate_pool(quantity, context.market_code) if len(
                context.added_numbers) < 1 else context.added_numbers
            _payload["serviceOrderItem"][context.index]['service']['supportingResource'][0]['resourceCharacteristic'][
                0]['value']['pool'] = context.number_pool_list
    else:
        if 'pool_range' in pool_type:
            context.from_range_number = numbers.generate_phone_number(context.market_code)
            context.to_range_number = read_xmldata.add_range_number(context.from_range_number, quantity)
            context.number_pool_list = context.E164_FwPoolList = numbers.get_pool_range(context.from_range_number,
                                                                                        context.to_range_number)
            _payload["serviceOrderItem"][context.index]["@type"] = 'ServiceOrderItem'
            _payload["serviceOrderItem"][context.index]['service']['supportingResource'][0]['resourceCharacteristic'][
                0][
                'value']['@type'] = 'UccMsocNumberPoolRange'
            _payload["serviceOrderItem"][context.index]['service']['supportingResource'][0]['resourceCharacteristic'][
                0][
                'value'].update({'poolRange': [{"from": context.from_range_number, "to": context.to_range_number}]})
        else:
            context.number_pool_list = context.pool = numbers.generate_pool(quantity, context.market_code)
            _payload["serviceOrderItem"][context.index]['service']['supportingResource'][0]['resourceCharacteristic'][
                0]['value'].update({'pool': context.number_pool_list})

        context.added_numbers = context.number_pool_list
        _payload['serviceOrderItem'][context.index] = number_item
        context.payload = payload.refresh_ids(_payload)

        context.usage_type = \
            _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["resourceCharacteristic"][
                0][
                "value"]["usageType"]
        context.capability = \
            _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["resourceCharacteristic"][
                0][
                "value"]["capability"]
        context.emergency_address_location_id = \
            _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["resourceCharacteristic"][
                0][
                "value"]["emergencyAddressLocationId"]

        if carrier_id is not None:
            if carrier_id == 'default':
                del context.payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0][
                    "resourceCharacteristic"][0]["value"]["carrierId"]
            else:
                context.carrier_id = \
                    context.payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0][
                        "resourceCharacteristic"][0]["value"]["carrierId"] = carrier_id

    context.id = _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["id"]
    context.service_order_item_category = \
        _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["category"]
    context.name = \
        _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["resourceCharacteristic"][0][
            "name"]
    context.value_type = \
        _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["resourceCharacteristic"][0][
            "valueType"]
    context.resource_type = \
        _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["resourceCharacteristic"][0][
            "value"]["@type"]
    context.pool_type = \
        _payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0]["resourceCharacteristic"][0][
            "value"]["poolType"]

    if context.payload['category'] != 'MSOC':
        context.category = context.payload['category'] = 'MSOC'

    return context.payload


def update_msoc_customer_context(context):
    context.category = context.msoc_account.category
    context.market_code = context.msoc_account.market_code
    # Added below condition to use same op_co_customer_id for multiple markets
    if not hasattr(context, 'op_co_customer_id'):
        context.op_co_customer_id = context.msoc_account.op_co_customer_id
    else:
        context.msoc_account.op_co_customer_id = context.payload['externalReference'][0][
            'id'] = context.op_co_customer_id

    # MSOC Customer fields
    index, item = payload.get_item_by_type(context.payload, 'ucc.msoc.customer')
    context.customer_name = payload.companyName

    context.ms_teams_tenant_id = context.msoc_account.tenant_id
    context.consent_countries = context.msoc_account.consent_countries
    context.customer_domains = context.msoc_account.customer_domains
    context.first_name = context.msoc_account.contact.first_name
    context.last_name = context.msoc_account.contact.last_name
    context.msoc_email = context.email = context.msoc_account.contact.email
    context.city = context.msoc_account.place.city
    context.postcode = context.msoc_account.place.postcode
    context.country_code = context.msoc_account.place.country_code
    context.hq_street_full = context.msoc_account.place.hq_street_full

    context.customer_reference_number = context.msoc_account.billing_info.customer_reference_number
    context.service_identifier = context.msoc_account.billing_info.service_identifier


def update_msoc_numbers_context(context, is_dep_validation=False):
    '''
    This method updates the variable in the context
    Parameters:
        is_dep_validation (str): Flag is used DEP validation feature where we just want to re-use the same numbers for second request
    '''
    # MSOC Add DDIs fields
    context.usage_type = context.requested_numbers.usage_type
    context.capability = context.requested_numbers.capability
    context.emergency_address_location_id = context.requested_numbers.emergency_address_location_id
    if hasattr(context, "number_pool_list") and is_dep_validation:
        # If number_pool_list is in context then the numbers have been added previously
        context.requested_numbers.pool = context.number_pool_list
        msoc_number_item_id = payload.get_items_by_type(context.payload, 'ucc.msoc.numbers')
        msoc_number_item_id[0]['service']['supportingResource'][0]['resourceCharacteristic'][0][
            'value']['pool'] = context.number_pool_list
    else:
        context.number_pool_list = context.requested_numbers.pool
