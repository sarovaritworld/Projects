import logging
import time
from typing import Callable, Optional, TypeVar


logger = logging.getLogger(__name__)
T = TypeVar("T")


class TimeoutError(Exception):
    """Exception raised when wait_until times out."""


def wait_until(
        fct: Callable[[], T],
        description: str,
        timeout: float = 60,
        period: float = 2,
        raises: bool = True,
        stop_when: Callable[[T], bool] = bool,
        exc_msg: Optional[str] = None,
) -> T:
    """Retry calling a function until it returns a truthy value.

    If no `default` is passed, will raise a TimeoutError Exception on timeout.

    :param fct: function to call
    :param description: for timeout message
    :param timeout: timeout in seconds
    :param period: sleep between attempts
    :param raises: (optional) on timeout, whether to raise an exception or return the last value
    :param stop_when: (optional) function to determine when to stop waiting
    :param exc_msg: (optional) message for the TimeoutError
    :returns: the truthy value returned by `fct`

    Examples:
        To wait until a file exists:

        >>> wait_until(
                lambda: os.path.exists(file_path),
                "File with notification payload")

        To wait until a DB document exists with a final status:
        
        >>> document = wait_until(
                lambda: get_document_from_db(),
                presence_of_doc_with_final_status,
                stop_when: lambda doc: doc is not None and doc["status"] != "PENDING",
                "DB document with a final status")
    """
    start_time = time.time()
    end_time = start_time + timeout
    while True:
        value = fct()
        if stop_when(value):
            logger.info(
                f"Found '{description}' (in {time.time() - start_time:.1f}s"
                f" out of {timeout}s timeout)")
            return value
        logger.debug(f"'{description}' not found yet (after {time.time() - start_time:.1f}s)")
        if time.time() > end_time:
            break
        time.sleep(period)

    logger.info(f"After {timeout}s timeout, '{description}' is still not present\n    Value on timeout: {value}")
    if raises:
        # log the full timing info, but keep the exception message generic
        # so we can group similar errors on GCP Results Dashboard
        logger.error(f"Timeout waiting {timeout:.0f}s for '{description}'")
        raise TimeoutError(exc_msg or f"Timeout waiting {timeout:.0f}s for '{description}'")
    return value
