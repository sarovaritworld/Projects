import logging

from classes import payload, read_xmldata, common
from classes.payload_generators.TMF import patch_generator


def generate_patch(level, item_to_change, status, index):
    update_type = 'update_service_order'
    if status == 'failed':
        update_type = 'update_service_order_with_error'
    patch_payload = patch_generator.create_payload_for_patch(update_type, item_to_change)
    patch_payload[0]["path"] = payload.assign_path('state_path', index)
    if level == 'service_order_item':
        patch_payload[1]["path"] = payload.assign_path('item_note', index)

        if status == 'failed':
            patch_payload[2]['path'] = payload.assign_path('error_path', index)
    elif level == 'service_characteristics':
        new_payload = read_xmldata.read_jsonfile("add_characteristics_patch")[0]
        new_payload["path"] = payload.assign_path("serviceCharacteristic_patch", index)
        new_payload["value"]["value"] = common.gen_contact(8)
        patch_payload[1]["path"] = payload.assign_path('item_note', index)
        patch_payload.append(new_payload)

    # status
    patch_payload[0]['value'] = status
    logging.debug(f'patch_payload {patch_payload}')
    return patch_payload


def generate_complex_patch(patch_payload, level, item_to_change, status, index):
    patch_payload.append(generate_patch(level, item_to_change, status, index)[0])
    logging.debug(f'patch_payload {patch_payload}')

    return patch_payload


def additional_patch(action, order_id, index):
    patch_payload = read_xmldata.read_jsonfile("add_characteristics_patch")
    patch_payload[0]["path"] = payload.assign_path("serviceCharacteristic_patch", index)
    patch_payload[0]["value"]["value"] = order_id
    if action == "replace":
        patch_payload[0]["op"] = action
        patch_payload[0]["path"] = payload.assign_path("replace_patch", index)
    elif action == "add_new_value":
        patch_payload[0]["path"] = payload.assign_path("new_value_patch", index)
        patch_payload[0]["value"] = {"another_device": 1234}
    elif action == "incorrect_path":
        patch_payload[0]["path"] = "/serviceOrderItem/0/service/serviceCharacteristic/4"
    elif action == "add_additional":
        patch_payload[0]["path"] = payload.assign_path("serviceCharacteristic_patch", index)
        patch_payload[0]["value"]["name"] = "TenantInfo"
    logging.info(f"patch payload: {patch_payload}")
    return patch_payload
