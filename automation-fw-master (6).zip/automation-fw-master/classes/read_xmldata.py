import base64
import csv
import json
import logging
import os
import random
import socket
import string
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from json import JSONDecodeError
import uuid

from classes.delay import Delay

logger = logging.getLogger(__name__)


###################################################################################################################################
# This function reads the data from the xml file                                                                                  #
# Required parameter : 3 : tagname , filename , root of that tagname                                                              #
###################################################################################################################################
def readxml(data, filename, rootname):
    """
This function reads the data from the xml file
    :param data: tagname
    :param filename: name of xml file, like test_inputdata
    :param rootname: name of the root
    :return:
    """
    filepath = "./testdata/" + filename + ".xml"
    datatree = ET.parse(filepath)
    dataroot = datatree.getroot()
    for c in dataroot.findall(rootname):
        return c.find(data).text
    raise Exception(f"XML file {filepath} has no element {rootname}/{data}")


UK_TELEPHONE_CODE = readxml("UK_ISD_CODE", "test_inputdata", "num_prov")
NUMBER_OF_DIGIT = readxml("NUMBER_OF_DIGIT", "test_inputdata", "num_prov")


###################################################################################################################################
# This function generates phone number dynamically                                                                                #
###################################################################################################################################
def gen_phone():
    first = str(random.randint(100, 999))
    second = str(random.randint(1, 888)).zfill(3)
    last = (str(random.randint(1, 9998)).zfill(4))
    while last in ['1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888']:
        last = (str(random.randint(1, 9998)).zfill(4))
    return '+{}{}{}'.format(first, second, last)


###################################################################################################################################
# This function generates Email ID dynamically                                                                                    #
###################################################################################################################################
def gen_email():
    domain = socket.gethostname()[:15]
    currenttime = datetime.now()
    dt_string = currenttime.strftime("%d%m%Y%H%M%S")
    email = "automation" + dt_string + f"@{domain}.com"
    return email


###################################################################################################################################
# This function generates reference code dynamically                                                                              #
###################################################################################################################################
def gen_refer_code():
    first = "ORC"
    second = str(random.randint(111111, 999999)).zfill(3)
    return '{}{}'.format(first, second)


###################################################################################################################################
# This function reads the data from the json file                                                                                 #
# Required parameter : 1 : filename                                                                                               #
###################################################################################################################################
def read_jsonfile(filename: str, filepath: str = "./testdata/JSON_Payload/") -> dict:
    """
    Reads the data from a JSON file and convert it to a python dict
    @param filename:
    @param filepath: optional path to override default path
    @return: JSON data read a dict
    """
    filename = filename.replace("'", "")
    filename = filename.replace('"', "")
    if not filename.endswith(".json"):
        filename += ".json"
    filename = os.path.join(filepath, filename)

    try:
        with open(filename, "r") as jsonfile:
            json_data = json.load(jsonfile)
        return json_data
    except FileNotFoundError:
        logger.error(f"file {filename} does not exist")
        raise
    except JSONDecodeError:
        logger.error(f"Invalid JSON format in json file")
        raise


def read_dump_with_jsonfile(filename):
    filepath = "./testdata/JSON_Payload/" + filename + ".json"
    with open(filepath) as json_file:
        data = json.load(json_file)
    print("Request payload: {}".format(json.dumps(data, indent=3)))
    request_json = json.dumps(data)
    return request_json


###################################################################################################################################
# This function reads the data from the csv file                                                                                 #
# Required parameter : 1 : filename                                                                                               #
###################################################################################################################################
def readcsvfile(filename):
    file = open("./testdata/attachement/" + filename, "r")
    filecontent = csv.DictReader(file)
    # print("CSV Data:", filecontent)
    return filecontent


###################################################################################################################################
# This function reads the data into base64value                                                                                   #
# Required parameter : 1 : filename                                                                                               #
###################################################################################################################################
def convertintoBase64(filename, path='./testdata/attachement/'):
    filename = path + filename
    file = open(filename, "rb")
    file_content = file.read()
    encoded = base64.b64encode(file_content)
    base64file = encoded.decode('utf-8')
    return base64file


###################################################################################################################################
# This function is used to generate UUID                                                                                           #
###################################################################################################################################
def gen_uuid():
    actual_uuid = str(uuid.uuid1())
    return actual_uuid


###################################################################################################################################
# This function is used to generate OPCO ID                                                                                        #
###################################################################################################################################
def gen_opco(context=None, marketplace=None):
    if marketplace == "TMF":
        opco_id = "88" + gen_contact(9)
    else:
        opco_id = "77" + gen_contact(9)
    if context is not None:
        context.op_co_customer_id = opco_id
        logging.info(f"{context.op_co_customer_id=}")
    return opco_id


def generate_msoc_tenantid():
    tenant_id = "MS-" + gen_contact(8)
    return tenant_id


###################################################################################################################################
# This function is used to generate RC ID                                                                                        #
###################################################################################################################################
def gen_RCID():
    RCID = str(random.randint(111111111, 999999999))
    return RCID


def randomdigitnumber(lower, higher):
    number = str(random.randint(lower, higher))
    return number


###################################################################################################################################
# This function is used to generate contact number                                                                                 #
###################################################################################################################################
def gen_contact(digit):
    wait_to_connect(Delay.short)
    current_time = str(datetime.now()).replace(" ", "").replace("-", "").replace(":", "").replace(".", "")
    # Condition to support invalid number generation
    if int(digit) > 10:
        return current_time[0:int(digit)]
    # Condition to generate OPCO ID
    if int(digit) > 9:
        final_number = current_time[5:8] + current_time[9:]
        return final_number[0:int(digit)]
    final_number = current_time[5:8] + current_time[12:]
    return str(final_number[0:int(digit)])


# TODO: refactor that so method from numbers.get_end_range_number is used
def add_range_number(start_number, end_number):
    return "+" + str(int(start_number) + int(end_number) - 1)


def gen_contact_batch():
    contact_num = str(random.randint(11111, 44444))
    return contact_num


def gen_contact_batch_end():
    contact_num = str(random.randint(55555, 99999))
    return contact_num


##########################################################################
# This Function is used to write data in XML                              #
##########################################################################
def update_xml(tag_name, new_value):
    file = "./testdata/test_inputdata.xml"
    tree = ET.ElementTree(file=file)
    root = tree.getroot()
    for tag in root.iter(tag_name):
        tag.text = new_value
    tree = ET.ElementTree(root)
    with open(file=file, mode="wb") as fileupdate:
        tree.write(fileupdate)
    # print("XML Updated successfully")


############################################################################
# This Function is used to wait sometimes                                  #
############################################################################
def wait_to_connect(time_slice):
    time.sleep(int(time_slice))


def write_jsonfile(filename: str, data: dict, filepath: str = "./testdata/JSON_Payload/"):
    """
    Writes a dict object to a JSON file
    @param filename: name of json file
    @param data: a python dict
    @param filepath: optional filepath with default location ./testdata/JSON_Payload/
    """
    if not filename.endswith(".json"):
        filename += ".json"
    filename = os.path.join(filepath, filename)
    with open(filename, "w") as file:
        json.dump(data, file, indent=2)


def add_bulk_number_response(lastRange, E164_List):
    listObj = []
    x = {"bulkItemSuccessful": True, "id": "1162821000", "phoneNumber": 1}
    for i in range(0, lastRange):
        sjson1 = int(x["id"])
        sjson1 += 1
        sjson1 = str(sjson1)
        x["id"] = sjson1
        # x["phoneNumber"] = "<% post." + str(i) + " %>"
        x["phoneNumber"] = E164_List[i]
        y = x.copy()
        listObj.append(y)
        # Verify updated list
        # print("List values ", listObj)
    final_response_obj = json.dumps(listObj)
    return final_response_obj


def delete_bulk_number_response(lastRange, E164_List):
    listObj = []
    x = {"bulkItemSuccessful": True, "phoneNumber": 1}
    for i in range(0, lastRange):
        x["phoneNumber"] = E164_List[i]
        y = x.copy()
        listObj.append(y)
        # Verify updated list
        # print("List values ", listObj)
    final_response_obj = json.dumps(listObj)
    return final_response_obj


def add_bulk_number_response_NOK(lastRange, E164_List):
    logging.info(f'lastRange >>> {lastRange}')
    logging.info(f'E164_List >>> {E164_List}')
    response_data = {"records": []}
    NOK_Add_Number = readxml("NOK_Add_Number_1", "RC_inputdata", "RC_errors")
    for x in range(0, lastRange):
        response_data['records'].append({
            "bulkItemSuccessful": False,
            "phoneNumber": E164_List[x],
            "bulkItemErrors": [
                {
                    "errorCode": "PRT-102",
                    "message": NOK_Add_Number
                }
            ]
        })
    final_response_obj = json.dumps(response_data)
    logging.info(f'final_response_obj >>> {final_response_obj}')
    return final_response_obj


def add_bulk_number_request_10(range_value, E164_List):
    request_body = ''
    request_template = r'\{\s*"phoneNumber"\s*:\s*"(\+[0-9]+)"\s*,\s*"usageType"\s*:\s*"Inventory"\s*\}'
    for i in range(1, range_value + 1):
        request_body += request_template if i == range_value else request_template + r'\s*,\s*'
    return r'^\{"records"\s*:\s*\[\{"phoneNumber"\s*:\s*"\+4432399[0-9]{5}".*'


def add_bulk_number_request_5(range_value, E164_List):
    request_body = ''
    request_template = r'\{\s*"phoneNumber"\s*:\s*"(\+[0-9]+)"\s*,\s*"usageType"\s*:\s*"Inventory"\s*\}'
    for i in range(1, range_value + 1):
        request_body += request_template if i == range_value else request_template + r'\s*,\s*'
    return r'^\{"records"\s*:\s*\[\{"phoneNumber"\s*:\s*"\+4479378[0-9]{5}".*'


def delete_bulk_number_request_10(range_value, E164_List):
    request_body = ''
    request_template = r'\{\s*"phoneNumber"\s*:\s*"(\+[0-9]+)"\s*\}'
    for i in range(1, range_value + 1):
        request_body += request_template if i == range_value else request_template + r'\s*,\s*'
    return r'^\{"records"\s*:\s*\[\{"phoneNumber"\s*:\s*"\+4432399[0-9]{5}".*'


def delete_bulk_number_request_5(range_value, E164_List):
    request_body = ''
    request_template = r'\{\s*"phoneNumber"\s*:\s*"(\+[0-9]+)"\s*\}'
    for i in range(1, range_value + 1):
        request_body += request_template if i == range_value else request_template + r'\s*,\s*'
    return r'^\{"records"\s*:\s*\[\{"phoneNumber"\s*:\s*"\+4479378[0-9]{5}".*'
    # return r'^\{"records"\s*:\s*\[\{"phoneNumber"\s*:\s*"\"" + E164_List[0] + "\".*'


def add_bulk_number_response_5(lastRange, E164_List):
    listObj = []
    x = {"bulkItemSuccessful": True, "id": "1162821000", "phoneNumber": 1}
    for i in range(0, lastRange):
        sjson1 = int(x["id"])
        sjson1 += 1
        sjson1 = str(sjson1)
        x["id"] = sjson1
        # x["phoneNumber"] = "<% post." + str(i) + " %>"
        x["phoneNumber"] = E164_List[i]
        y = x.copy()
        listObj.append(y)
        # Verify updated list
        # print("List values ", listObj)
    final_response_obj = json.dumps(listObj)
    return final_response_obj


def delete_bulk_number_response_5(lastRange, E164_List):
    listObj = []
    x = {"bulkItemSuccessful": True, "phoneNumber": 1}
    for i in range(0, lastRange):
        x["phoneNumber"] = E164_List[i]
        y = x.copy()
        listObj.append(y)
        # Verify updated list
        # print("List values ", listObj)
    final_response_obj = json.dumps(listObj)
    return final_response_obj


###############################################################################################################
# This Function is used to generate test data for Create Account Scenario                                     #
###############################################################################################################
def generatedatainitialorder():
    email_id = gen_email()
    update_xml("email_id", email_id)
    print(email_id)
    contact_number = UK_TELEPHONE_CODE + gen_contact(NUMBER_OF_DIGIT)
    update_xml("appdirect_contactnumber", contact_number)
    print(contact_number)
    opco_crm_customer_id = gen_opco(marketplace="Appdirect")
    update_xml("appdirect_opco_crm_customer_id", opco_crm_customer_id)
    print(opco_crm_customer_id)
    uuid = gen_uuid()
    update_xml("uuid", uuid)
    subscriptionId_uuid = gen_uuid()
    update_xml("subscriptionId_uuid", subscriptionId_uuid)
    company_uuid = gen_uuid()
    update_xml("company_uuid", company_uuid)


###############################################################################################################
# This Function is used to generate test data for Various duplicate event regarding error handling Scenario   #
###############################################################################################################
def generate_testdata_for_duplicate_event(field_name, field_value):
    subscriptionId_uuid = gen_uuid()
    update_xml("subscriptionId_uuid", subscriptionId_uuid)
    if field_name == "OpCo CRM Customer Id" and field_value == "duplicate":

        email_id = gen_email()
        update_xml("email_id", email_id)
        print(email_id)
        contact_number = UK_TELEPHONE_CODE + gen_contact(NUMBER_OF_DIGIT)
        update_xml("appdirect_contactnumber", contact_number)
        print(contact_number)
        company_uuid = gen_uuid()
        update_xml("company_uuid", company_uuid)
    elif field_name == "Customer Admin Email" and field_value == "duplicate":

        contact_number = UK_TELEPHONE_CODE + gen_contact(NUMBER_OF_DIGIT)
        update_xml("appdirect_contactnumber", contact_number)
        print(contact_number)
        opco_crm_customer_id = gen_opco(marketplace="Appdirect")
        update_xml("appdirect_opco_crm_customer_id", opco_crm_customer_id)
        print(opco_crm_customer_id)
        company_uuid = gen_uuid()
        update_xml("company_uuid", company_uuid)
    elif field_name == "Customer Contact Number" and field_value == "duplicate":
        email_id = gen_email()
        update_xml("email_id", email_id)
        print(email_id)
        opco_crm_customer_id = gen_opco(marketplace="Appdirect")
        update_xml("appdirect_opco_crm_customer_id", opco_crm_customer_id)
        print(opco_crm_customer_id)
        company_uuid = gen_uuid()
        update_xml("company_uuid", company_uuid)
    elif field_name == "company EventID" or field_name == "MarketPlace_account_ID" and field_value == "duplicate":
        email_id = gen_email()
        update_xml("email_id", email_id)
        print(email_id)
        contact_number = UK_TELEPHONE_CODE + gen_contact(NUMBER_OF_DIGIT)
        update_xml("appdirect_contactnumber", contact_number)
        print(contact_number)
        opco_crm_customer_id = gen_opco(marketplace="Appdirect")
        update_xml("appdirect_opco_crm_customer_id", opco_crm_customer_id)
        print(opco_crm_customer_id)
    else:
        assert 1 == 0, "Invalid field name = {}... ".format(field_name)


def generatedatachangelicense():
    global eventID_uuid_changeLicense
    marketplace_eventID_changeLicense = gen_uuid()
    update_xml("marketplace_eventID_changeLicense", marketplace_eventID_changeLicense)

    uuidchangeLicense = gen_uuid()
    update_xml("uuidchangeLicense", uuidchangeLicense)


def rename_csv_file(originalfilename, uuid):
    currenttime = datetime.now()
    dt_string = currenttime.strftime("%Y%m%d")
    newfilename = dt_string + "_" + uuid + ".csv"
    print("newfilename -> ", newfilename)
    os.rename(r'./testdata/attachement/' + originalfilename, r'./testdata/attachement/' + newfilename)
    print("renamed the file")
    return newfilename


def rename_csv_file_without_date(originalfilename, newfilename):
    currenttime = datetime.now()
    print("originalfilename -> ", originalfilename)
    print("newfilename -> ", newfilename)
    os.rename(r'./testdata/attachement/' + originalfilename, r'./testdata/attachement/' + newfilename)
    print("renamed the file")
    return newfilename


def delete_file(filename):
    os.remove('./testdata/attachement/' + filename)
    print("File Removed! > ", filename)
    print(" ")


def get_current_datetime(format_type="%Y-%m-%dT%H:%M:%SZ"):
    """
    It generates current datetime with default time format like this "%Y-%m-%dT%H:%M:%SZ"
    :param format_type:
    :return dt_string:
    """
    now = datetime.now()
    dt_string = now.strftime(format_type)
    return dt_string


def get_current_date(format_type="%Y-%m-%d") -> str:
    """
    It generates current date with default time format like this "%Y-%m-%d"
    :param format_type:
    :return dt_string:
    """
    return datetime.now().strftime(format_type)


def get_days_before_now(days=1) -> str:
    """
Generates current date minus days your desire. Default is 1
    :param days:
    :return: date string
    """
    return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")


def get_days_after_now(days=1) -> str:
    """
Generates current date plus days your desire. Default is 1
    :param days:
    :return: date string
    """
    return (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")


def vf_rc_user_id_generator(size=13):
    """
    Generates a string of size 'size' made of numbers and uppercase and lowercase English letters

    :param size: size of the string (13 by default)
    :return: random string
    """
    return ''.join(random.SystemRandom().choice(string.digits + string.ascii_letters + "@.-") for _ in range(size))


def invalid_vf_rc_user_id_generator(size=13):
    """
    Generates a  random string of size 'size' made of symbols considered punctuation marks and
    all characters considered whitespace, which includes the characters space, tab, linefeed, return, formfeed, and
    vertical tab.

    :param size: size of the string (13 by default)
    :return: random string
    """
    return ''.join(random.SystemRandom().choice(string.whitespace + string.punctuation) for _ in range(size))


def read_file(filename, path=None):
    if path is None:
        path = "./testdata/attachement/"
    with open(path + filename, "r") as file:
        file_content = file.read()
    return file_content


def write_file(filename, msg, path=None):
    if path is None:
        path = "./testdata/attachement/"
    with open(path + filename, "w") as file:
        file.write(msg)


def empty_file(filename, path=None):
    if path is None:
        path = "./testdata/attachement/"
    with open(path + filename, "w"):
        pass
