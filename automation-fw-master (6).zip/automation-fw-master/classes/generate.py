from rstr import xeger


def string_by_regex(regex_pattern: str) -> str:
    """
        Generates a random string that matches the given regular expression pattern.
        The pattern must be a valid regular expression that can be parsed by Python's `re` module
    """
    return xeger(regex_pattern)