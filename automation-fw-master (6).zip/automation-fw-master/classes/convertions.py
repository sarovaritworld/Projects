from datetime import datetime


def format_date_to_iso(date_string: str) -> str:
    """
    Converts a date string from 'YYYY-MM-DD' format to ISO 8601 format ('YYYY-MM-DDTHH:MM:SSZ').
    param:
        date_string (str): The input date string in 'YYYY-MM-DD' format.
    Returns:
        str: The formatted date string in ISO 8601 format ('YYYY-MM-DDTHH:MM:SSZ').
    """
    return datetime.strptime(date_string, "%Y-%m-%d").strftime("%Y-%m-%dT%H:%M:%SZ")
