import logging
from typing import List

from classes import asserts, polling, s3_bucket
from classes.common import config

logger = logging.getLogger(__name__)


def get_domain():
    domain_name = "@unity.connectedcomms.click"
    if config.is_staging_env:
        domain_name = "@test.ucc-stg.vodafone.com"
    return domain_name


def validate_email(context, mail):
    """
    This function validates email fetched from S3 bucket
    @param context: behave context
    @param mail: object fetched from S3 bucket
    """
    if hasattr(context, "Content_Field_Value"):
        content = ""
        for part in mail.iter_parts():
            content_type = part.get_content_type()
            content_disposition = part.get_content_disposition()
            if content_type in ("text/plain", "text/html", "multipart/msgbody") and not content_disposition:
                if part.is_multipart():
                    for value in part.walk():
                        if value.get_content_type() in ("text/plain", "text/html"):
                            content = value.get_content()
                            break
                else:
                    content = part.get_content()
                logger.info(f"content {content}")
                logger.info(f"PART {part}")
        logger.info(f"Actual: {content}")
        logger.info(f"Expected: {context.Content_Field_Value}")
        asserts.equals(content, context.Content_Field_Value, "Content field value")
    if hasattr(context, "Attachment_Field_format"):
        file_name = ""
        file_type = ""
        for part in mail.iter_parts():
            content_disposition = part.get_content_disposition()
            if content_disposition and 'attachment' in content_disposition:
                file_name = part.get_filename()
                file_type = part.get_content_type()
                break
        asserts.equals(file_name, context.attachment_field_value, "File name")
        asserts.equals(file_type, context.Attachment_Field_format, "File type")
    if hasattr(context, "From_Field_Value"):
        asserts.in_list(context.From_Field_Value, mail["From"], "From value")
    if hasattr(context, "To_Field_Value"):
        asserts.in_list(context.To_Field_Value, mail["To"], "To value")
    if hasattr(context, "CC_Field_Value"):
        asserts.in_list(context.CC_Field_Value, mail["CC"], "CC value")


def get_expected_attachment_data(context, number_type: str, action: str) -> List[List]:
    """
    Prepare expected email attachment list
    @param context:
    @param number_type:
    @param action:
    @return: expected list of rows
    """
    action_map = {
        "add": "A",
        "delete": "D"
    }
    expected_list = []
    match number_type:
        case "mandatory_numbers":
            for number in context.E164_List:
                expected_row = [context.RC_ID, action_map[action], number, "", "M", "", "OK", "", "OK"]
                expected_list.append(expected_row)
        case "pool" | "pool_range":
            for number in context.number_fwpool_list:
                expected_row = [context.RC_ID, action_map[action], number, "", "", "", "OK", "", "OK"]
                expected_list.append(expected_row)
        case "all":
            expected_list.append(
                [context.RC_ID, action_map[action], context.main_number_add, "", "M", "", "OK", "", "OK"])
            expected_list.append(
                [context.RC_ID, action_map[action], context.admin_number_add, "", "A", "", "OK", "", "OK"])
            for number in context.E164_FwPoolList:
                expected_row = [context.RC_ID, action_map[action] + "F", number, "", "", "", "OK", "", ""]
                expected_list.append(expected_row)
            for number in context.number_pool_list:
                expected_row = [context.RC_ID, action_map[action], number, "", "", "", "OK", "", "OK"]
                expected_list.append(expected_row)
        case "pool and pool_range":
            for number in context.number_fwpool_list:
                expected_row = [context.RC_ID, action_map[action], number, "", "", "", "OK", "", "OK"]
                expected_list.append(expected_row)
            for number in context.pool:
                expected_row = [context.RC_ID, action_map[action], number, "", "", "", "OK", "", "OK"]
                expected_list.append(expected_row)
        case _:
            logger.error(f"{number_type=} not supported")
            raise NotImplementedError(f"Getting email attachment data for {number_type=} not supported yet")
    return expected_list


def get_email_search_property(context) -> str | None:
    """
    Gets the search property to search the email in s3 bucket
    @param context:
    @return:
    """
    search_properties_in_order = [
        "op_co_customer_id",
        "status_get_response_num_pool_uuid"
    ]

    for search_property in search_properties_in_order:
        logger.debug(f"Looking for {search_property=} in context")
        if hasattr(context, search_property):
            return getattr(context, search_property)

    raise Exception("Possible search properties are not found in context")


def get_attachment_data(msgs):
    attachment_data = []
    actual_data = []
    file_name = ""
    for email_data in msgs:
        for part in email_data.iter_parts():
            content_disposition = part.get_content_disposition()
            if content_disposition and 'attachment' in content_disposition:
                file_name = part.get_filename()
                file_data = part.get_content()
                attachment_data = file_data.split("\n")[1:]
                break

        for row in attachment_data:
            attributes = row.split(",")
            if len(attributes) > 1:
                # Date and Time is not being validated so making it empty string
                attributes[5] = ""
                for x in range(len(attributes)):
                    attributes[x] = attributes[x].replace('\r', '')
                logging.info(attributes)
                actual_data.append(attributes)

    return actual_data, file_name


def get_email(search_property: str, search_in: str = 'Subject'):
    """
    Retrieve an email from an S3 bucket based on a specified search property.
    @param:
        search_property (str): The property to search for in the email
        search_in (str): The part of the email to search in
    @returns: The first email that matches the search criteria.
    """
    received_email = polling.wait_until(lambda: s3_bucket.get_email(search_property, 1, search_in),
                                        f"Email for {search_property}", period=5, timeout=120,
                                        stop_when=lambda x: len(x) > 0)
    return received_email[0]
