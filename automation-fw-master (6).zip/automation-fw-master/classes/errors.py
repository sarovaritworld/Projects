from datetime import datetime


class ErrorCodes:
    INVALID_REQUEST = "INVALID_REQUEST"
    SERVICE_PROVIDER_ERROR = "SERVICE_PROVIDER_ERROR"
    SYSTEM_ERROR = "SYSTEM_ERROR"
    INVALID_MESSAGE = "INVALID_MESSAGE"
    ACCOUNT_NOT_FOUND = "ACCOUNT_NOT_FOUND"
    UNKNOWN_ERROR = "UNKNOWN_ERROR"
    ACCOUNT_ALREADY_EXISTS = "ACCOUNT_ALREADY_EXISTS"
    COUNTRY_BILLING_ALREADY_EXISTS = "COUNTRY_BILLING_ALREADY_EXISTS"
    TENANT_ID_ALREADY_IN_USE = "TENANT_ID_ALREADY_IN_USE"
    LOCAL_MARKET_SERVICE_ID_ALREADY_EXISTS = "LOCAL_MARKET_SERVICE_ID_ALREADY_EXISTS"
    CUSTOMER_CAC_LIMIT_EXCEEDED = "CUSTOMER_CAC_LIMIT_EXCEEDED"
    INVALID_ACCOUNT_FIELD = "INVALID_ACCOUNT_FIELD"
    INVALID_PRIMARY_CONTACT_NUMBER = "INVALID_PRIMARY_CONTACT_NUMBER"
    INVALID_IDP_ENTITY_ID = "INVALID_IDP_ENTITY_ID"
    INVALID_LICENSE_SKU_ID = "INVALID_LICENSE_SKU_ID"
    LICENSE_ORDER_EXCEEDS_LIMIT = "LICENSE_ORDER_EXCEEDS_LIMIT"
    INSUFFICIENT_LICENSES = "INSUFFICIENT_LICENSES"
    TEL_NUMBER_CONFLICTING_USAGE_TYPE = "TEL_NUMBER_CONFLICTING_USAGE_TYPE"
    TEL_NUMBER_ALREADY_IN_USE = "TEL_NUMBER_ALREADY_IN_USE"
    TEL_NUMBER_PROVISIONING_ERROR = "TEL_NUMBER_PROVISIONING_ERROR"
    TEL_NUMBER_DEPROVISIONING_ERROR = "TEL_NUMBER_DEPROVISIONING_ERROR"
    TEL_NUMBER_CANNOT_BE_REMOVED = "TEL_NUMBER_CANNOT_BE_REMOVED"
    EXTENSION_OUT_OF_RANGE = "EXTENSION_OUT_OF_RANGE"
    EXTENSION_RESERVED = "EXTENSION_RESERVED"
    EXTENSION_ALREADY_IN_USE = "EXTENSION_ALREADY_IN_USE"
    CUSTOMER_MAPPING_ALREADY_EXISTS = "TEL_NUMBER_ALREADY_PROVISIONED"
    INVALID_TASK_FORMAT = "INVALID_TENANT_ID"
    MISSING_MARKET_CONFIGURATIONS = "INVALID_MARKET"
    TEL_NUMBER_ALREADY_EXISTS = "TEL_NUMBER_ALREADY_PROVISIONED"
    INCORRECT_ARGUMENTS = "INVALID_TENANT_ID"
    TEL_NUMBER_NOT_VALID = "INVALID_TEL_NUMBER"
    CUSTOMER_MAPPING_NOT_OWNED_BY_CUSTOMER = "TEL_NUMBER_CANNOT_BE_REMOVED"
    CUSTOMER_MAPPING_NOT_FOUND = "TEL_NUMBER_NOT_PROVISIONED"


class MiddlewareErrors:
    """
    Base class for Scenario to Error Code and Message mapping
    Inherit this class for specific set of scenarios and just
    override class variable _error_dict
    or update it: if you need scenario -> Error mapping from base class

    Example:
    class XyzErrorCodes(MiddlewareErrors):
        _error_dict = {
            "Scenario1": {
                "code": "SOME_CODE_1",
                "message": "some error message"
            },
            "Scenario2": {
                "code": "SOME_CODE_2",
                "message": "some other error message"
            }
        }
    OR:
    class ABCErrorCodes(MiddlewareErrors):
        _error_dict.update({
            "Scenario1": {
                "code": "SOME_CODE_1",
                "message": "some error message"
            },
            "Scenario2": {
                "code": "SOME_CODE_2",
                "message": "some other error message"
            }
        })
    """
    _error_dict = {}

    @classmethod
    def error_code(cls, scenario: str):
        try:
            return cls._error_dict[scenario]["code"]
        except KeyError:
            raise NotImplementedError(f"No error found for {scenario=}")

    @classmethod
    def error_message(cls, scenario: str):
        try:
            return cls._error_dict[scenario]["message"]
        except KeyError:
            raise NotImplementedError(f"No error found for {scenario=}")

    @classmethod
    def is_error_present(cls, scenario: str):
        return scenario in cls._error_dict


class OrderManagementErrorCodes(MiddlewareErrors):
    # key(scenario): {error_code, error_message}
    _error_dict = {
        "existing_customer_id": {
            "code": ErrorCodes.ACCOUNT_ALREADY_EXISTS,
            "message": "Op Co Account has already been on-boarded: VFUK/88207144555"
        },
        "blank_country": {
            "code": ErrorCodes.INVALID_MESSAGE,
            "message": "The event message contains missing or incorrect data: [Company Location Country] must not be empty"
        },
        "blank_op_co_name": {
            "code": ErrorCodes.INVALID_MESSAGE,
            "message": "The event message contains missing or incorrect data: [OpCo Name] must not be empty"
        },
        "blank_op_co_customer_id": {
            "code": ErrorCodes.INVALID_MESSAGE,
            "message": "The event message contains missing or incorrect data: [OpCo Customer Id] must not be empty"
        }
    }


class SetExtensionErrorCodes(MiddlewareErrors):
    """
    Error code and message with set_extension during create unity account
    """
    _error_dict = {
        "UNKNOWN_ERROR": {
            "code": ErrorCodes.UNKNOWN_ERROR,
            "message": "InvalidParameter Parameter [extension_number] value is invalid."
        },
        "SYSTEM_ERROR": {
            "code": ErrorCodes.SERVICE_PROVIDER_ERROR,
            "message": "CMN-201 Internal Server Error"
        },
        "EXTENSION_ALREADY_IN_USE": {
            "code": ErrorCodes.EXTENSION_ALREADY_IN_USE,
            "message": "Extension number is already in use on the account"
        },
        "EXTENSION_RESERVED": {
            "code": ErrorCodes.EXTENSION_RESERVED,
            "message": "Extension number is reserved: 100"
        },
        "EXTENSION_OUT_OF_RANGE": {
            "code": ErrorCodes.EXTENSION_OUT_OF_RANGE,
            "message": "Extension number is out of range allowed on account"
        }
    }


class CRFErrorCodes(MiddlewareErrors):
    CRF_ERROR = "Error occurred while processing the CRF request"
    _error_dict = {
        "CRF_error": {
            "code": ErrorCodes.SERVICE_PROVIDER_ERROR,
            "message": "One or more numbers could not be deleted in CRF"
        },
        "CRF_RC_no_account": {
            "code": ErrorCodes.SYSTEM_ERROR,
            "message": CRF_ERROR
        },
        "RingCentral": {
            "code": ErrorCodes.SYSTEM_ERROR,
            "message": CRF_ERROR
        },
        "CRF_Bad_Request_add_pool": {
            "code": ErrorCodes.SERVICE_PROVIDER_ERROR,
            "message": CRF_ERROR
        },
        "id_mapper_invalid": {
            "code": ErrorCodes.ACCOUNT_NOT_FOUND,
            "message": "Customer has not been onboarded"
        },
        "non_existing_account": {
            "code": ErrorCodes.ACCOUNT_NOT_FOUND,
            "message": "Customer has not been onboarded"
        },
        "blank_pool": {
            "code": ErrorCodes.INVALID_MESSAGE,
            "message": "Validation of the CRF order failed: [Fields: "
                       "pool and pool_range. One of these fields should have at least one element]"
        },
        "blank_vodafone_id": {
            "code": ErrorCodes.INVALID_MESSAGE,
            "message": "Validation of the CRF order failed: [Field: "
                       "op_co_details.op_co_customer_id is mandatory but is empty]"
        },
        "CRF_number_Bad_Request": {
            "code": ErrorCodes.SERVICE_PROVIDER_ERROR,
            "message": CRF_ERROR
        },
        "CRF_Bad_Response": {
            "code": ErrorCodes.SERVICE_PROVIDER_ERROR,
            "message": CRF_ERROR
        },
        "failed_dep_response": {
            "code": ErrorCodes.SERVICE_PROVIDER_ERROR,
            "message": "Error occurred while processing the TPM request"
        }
    }


class DEPNoteErrors:
    @classmethod
    def get_dep_error(cls, scenario: str, numbers: list = None):
        if numbers:
            numbers = ",".join(numbers).replace('+', '')
        timestamp = datetime.now().isoformat()
        error_dict = {
            "TEL_NUMBER_ALREADY_EXISTS": {
                "reason": f"Number(s): {numbers} already exist.",
                "code": "TEL_NUMBER_ALREADY_EXISTS",
                "message": f"ServiceOrderItem with error TEL_NUMBER_ALREADY_EXISTS: Number(s): {numbers} already exist.",
                "timestamp": timestamp
            },
            "INVALID_TASK_FORMAT": {
                "reason": "invalid Microsoft Tenant ID.",
                "code": "INVALID_TASK_FORMAT",
                "message": "invalid Microsoft Tenant ID.",
                "timestamp": timestamp
            },
            "CUSTOMER_MAPPING_ALREADY_EXISTS": {
                "reason": "Customer data already in service inventory",
                "code": "CUSTOMER_MAPPING_ALREADY_EXISTS",
                "message": numbers,
                "timestamp": timestamp
            },
            "MISSING_MARKET_CONFIGURATIONS": {
                "reason": "Missing or invalid market specification in the request",
                "code": "MISSING_MARKET_CONFIGURATIONS",
                "message": "Missing or invalid market specification in the request",
                "timestamp": timestamp
            },
            "INCORRECT_ARGUMENTS": {
                "reason": "Microsoft operation failed due to missing arguments.",
                "code": "INCORRECT_ARGUMENTS",
                "message": "Microsoft operation failed due to missing arguments.",
                "timestamp": timestamp
            },
            "TEL_NUMBER_NOT_VALID": {
                "reason": "Telephone number format is not valid.",
                "code": "TEL_NUMBER_NOT_VALID",
                "message": "Telephone number format is not valid.",
                "timestamp": timestamp
            },
            "CUSTOMER_MAPPING_NOT_OWNED_BY_CUSTOMER": {
                "reason": "The phone number(s) are not associated with the provided customer.",
                "code": "CUSTOMER_MAPPING_NOT_OWNED_BY_CUSTOMER",
                "message": "The phone number(s) are not associated with the provided customer.",
                "timestamp": timestamp
            },
            "CUSTOMER_MAPPING_NOT_FOUND": {
                "reason": "DEP mapping of market, market account iD, Microsoft Tenant ID and phone number doesn't exist.",
                "code": "CUSTOMER_MAPPING_NOT_FOUND",
                "message": "DEP mapping of market, market account iD, Microsoft Tenant ID and phone number doesn't exist.",
                "timestamp": timestamp
            },
            "FAILED_SERVICE_ORDER": {
                "reason": "Failed to provision numbers",
                "code": "FAILED_SERVICE_ORDER",
                "message": "Failed to provision numbers",
                "timestamp": timestamp

            }
        }
        return [error_dict.get(scenario, {})]


class RCErrorType:

    RC_CLIENT_ERROR_CODE = "INVALID_REQUEST"
    RC_SYSTEM_ERROR_CODE = "SERVICE_PROVIDER_ERROR"
    RC_UNKNOWN_ERROR = "UNKNOWN_ERROR"
    RC_INVALID_MESSAGE_CODE = "INVALID_MESSAGE"


    error_message = {
        "resource_not_found": "Resource for parameter is not found",
        "Bad_Request": "CMN-400 Bad Request",
        "internal_server_error": "CMN-500 Internal Server Error",
        "presentation_server_error": "CMN-500 Server Not Found",
        "too_many_requests": "CMN-429 Too Many Requests",
        "pool_NOK": "Phone number could not be provisioned in RingCentral",
        "pool_NOK_Inventory": "Phone number could not be provisioned in RingCentral",
        "different_account": "Phone number is already in use but does not exist in the customer inventory",
        "Server_Not_Found": "CMN-500 Server Not Found",
        "all_NOK": "Phone number could not be provisioned in RingCentral",
        "invalid_phone_number": "errorCode:TEL-116, message:Invalid phone number",
        "pool_all_NOK": "Phone number could not be provisioned in RingCentral",
        "invalid_primary_contact": "The primary contact phone number cannot be a RingCentral phone number",
        "invalid_external_id": "CMN-101 Parameter [externalAccountId] value is invalid.",
        "failed_create_account": "ACT-123 Parameter [status] is invalid. Can't create account in [Disabled] status.",
        "System_Error_Bad_Request": "ACT-201 license with usage type cannot be reassigned.",
        "add_license_server_error": "CMN-500 Server Not Found",
        "max_license_limit": "The order size exceeds RingCentral limits",
        "invalid_sku_id": "The license SKU ID is not valid: *",
        "add_license_bad_request": "ACT-201 license with usage type cannot be reassigned.",
        "blank_sku_id": "Validation of event has failed: [[order.sku_id] is null or empty]",
        "zero_quantity": "Validation of event has failed: [[order.quantity] must be 1 or more]",
        "failed_create_policy": "APM-101 Maximum number of GeoIP access policies reached for the account.",
        "failed_add_rule": "APM-106 Rule with same condition already exists.",
        "failed_enable_policy": "APM-104 Cannot update active access policy.",
        "Get_Licenses_Bad_Request": "ACT-201 Bad Request",
        "Get_Licenses_Server_Error": "CMN-500 Internal Server Error",
        "invalid_sso_id": "The value of idpEntityId is not valid in RingCentral",
        "main_number_exists_in_rc_diff_usage": "Phone number is already in use with an incompatible usage type: Presentation",
        "different_usage_type": "Phone number is already in use with an incompatible usage type: *",
        "main_number_exists_in_rc": "Phone number is already in use but does not exist in the customer inventory",
        "pool_different_usage": "Cannot delete phone number with usage type DigitalLine"
    }
    different_account = "different_account"
    pool_all_NOK = "pool_all_NOK"
    all_NOK = "all_NOK"
    pool_NOK_Inventory = "pool_NOK_Inventory"
    pool_OK_NOK = "pool_OK_NOK"
    success = "success"
    inventory = "inventory"
    presentation = "presentation"
    incompatible_usage_type = "incompatible_usage_type"
    number_in_use = "number_in_use"
    pool_NOK = "pool_NOK"
    internal_server_error = "internal_server_error"
    presentation_server_error = "presentation_server_error"
    too_many_requests = "too_many_requests"
    bad_request = "Bad_Request"
    same_account_inventory = "same_account_inventory"
    same_account_presentation = "same_account_presentation"
    same_account_partial_inventory = "same_account_partial_inventory"
    same_account_partial_presentation = "same_account_partial_presentation"
    server_not_found = 'Server_Not_Found'
    invalid_phone_number = "invalid_phone_number"
    JWT_retry = "JWT_retry"
    main_number_exists_in_rc = "main_number_exists_in_rc"
    main_number_exists_in_rc_diff_usage = "main_number_exists_in_rc_diff_usage"

    @classmethod
    def get_error_message(cls, error_type: str) -> str:
        return cls.error_message[error_type]

    @classmethod
    def get_system_error(cls):
        return cls.RC_SYSTEM_ERROR_CODE

    @classmethod
    def get_client_error(cls):
        return cls.RC_CLIENT_ERROR_CODE


class NMErrorType:
    """This class contains all the error message aligned with Number Management API"""
    error_message = {
        "account_not_found": {"numbersConfirmation.errorMessage": "Account could not be found",
                              "numbersConfirmation.state": 'FAILED_PROVISIONING'}
    }

    @classmethod
    def get_error_data(cls, error_type) -> dict:
        """this method returns the associated error message aligned with error_type to send for NM API"""
        return cls.error_message[error_type]


class DEPErrors:
    INVALID_REQUEST = "INVALID_REQUEST"

    error_message = {
        "CUSTOMER_MAPPING_NOT_OWNED_BY_CUSTOMER": "Phone numbers are provisioned for a different customer",
        "CUSTOMER_MAPPING_NOT_FOUND": "Phone numbers are not provisioned",
        "TEL_NUMBER_NOT_VALID": "Phone numbers are not valid",
        "INVALID_TASK_FORMAT": "Invalid Microsoft Tenant ID",
        "INCORRECT_ARGUMENTS": "Invalid Microsoft Tenant ID",
        "MISSING_MARKET_CONFIGURATIONS": "Provisioning phone numbers is not supported for market",
        "CUSTOMER_MAPPING_ALREADY_EXISTS": "Cannot add numbers that have already been added",
        "TEL_NUMBER_ALREADY_EXISTS": "Cannot add numbers that have already been added",
        "FAILED_SERVICE_ORDER": "FAILED_SERVICE_ORDER: Failed to provision numbers: Failed to provision numbers"
    }

    @classmethod
    def get_error_message(cls, error_type: str) -> str:
        return cls.error_message.get(error_type, "Unknown error type")

    @classmethod
    def get_error_code(cls):
        return cls.INVALID_REQUEST

    @classmethod
    def is_error_present(cls, error_type: str) -> bool:
        return error_type in cls.error_message


GLOBAL_ERROR = "Error occurred while processing the TPM request"
CRF_ERROR = "Error occurred while processing the CRF request"

ACCOUNT_NOT_FOUND = 'ACCOUNT_NOT_FOUND'
