import ipaddress
import logging

import pycountry

logger = logging.getLogger(__name__)

from dataclasses import dataclass

from classes import read_xmldata, numbers
from classes.data_factory import countries_data_manager
import random


@dataclass
class Policies:
    enabled: bool | None = None
    geo_locations: list | None = None
    ips: list | None = None

    @staticmethod
    def get_country_codes(quantity):
        # Get all ISO 3166-1 Alpha-2 country codes
        country_codes = [country.alpha_2 for country in pycountry.countries]

        # Shuffle the list to ensure randomness
        random.shuffle(country_codes)
        logger.info(country_codes)
        logger.info(quantity)
        # Return the requested amount of country codes
        return country_codes[:int(quantity)]

    @staticmethod
    def generate_ip_addresses(quantity):
        ip_list = []
        for _ in range(int(quantity)):
            # Generate a random IP address
            ip = ipaddress.IPv4Address(random.randint(0, (1 << 32) - 1))
            ip_list.append(str(ip))
        return ip_list


@dataclass
class Contact:
    first_name: str = "Fred"
    last_name: str = "Flintstone"
    email: str = None
    extension: int | bool | None = None

    def __post_init__(self):
        self.email = read_xmldata.gen_email()

    def set_extension_number(self, extension: int = None):
        """
        Save extension number
        Generate 3 to 5 digits length number if not supplied
        """
        self.extension = extension if extension is not None else random.randint(100, 99999)


class Place:
    postcode: str
    country_code: str = None
    city: str
    hq_street_full: str
    street_nr: str = '1'
    street_name: str = '1,Oak Street'

    def __init__(self, market_code):
        self.postcode = countries_data_manager.get_postcode(market_code)
        self.city = countries_data_manager.get_city(market_code)
        self.country_code = countries_data_manager.get_country_code(market_code)
        self.hq_street_full = f'{self.street_nr} {self.street_name}'


class RelatedParty:
    country_code: str

    def __init__(self, market_code):
        self.country_code = countries_data_manager.get_country_code(market_code)


@dataclass
class BillingInfo:
    service_identifier: str = None
    customer_reference_number: str = None

    def __post_init__(self):
        if self.service_identifier is None:
            self.service_identifier = "SERV-" + read_xmldata.gen_contact(6)
        if self.customer_reference_number is None:
            self.customer_reference_number = "REF-" + read_xmldata.gen_contact(6)


@dataclass
class ItsmProvisioning:
    enable_provisioning: bool = True
    contract_start_date: str = None
    contract_end_date: str = None
    local_market_service_id: str = None
    link_service_to_fully_onboarded_customer: bool | None = None

    def __post_init__(self):
        if self.contract_start_date is None:
            self.contract_start_date = read_xmldata.get_current_date()
        if self.contract_end_date is None:
            self.contract_end_date = "2100-12-31"


@dataclass
class AccountOrderItem:
    """ Common account information for all categories"""
    market_code: str = 'VFUK'
    op_co_customer_id: str | None = None
    currency: str | None = None
    mobile: str | None = None
    main_number: str | None = None
    fax_number: str | None = None
    admin_number: str | None = None
    external_id: str | None = None
    activate_immediately: bool | None = True
    send_welcome_email: bool | None = True
    send_confirmation_email: bool | None = True
    name: str = 'Test_Automation'
    product_type: str = 'FULL_STACK_STANDARD'
    contact: Contact = None
    related_party: RelatedParty = None

    def __post_init__(self):
        self.currency = countries_data_manager.get_currency(self.market_code)
        self.mobile = numbers.generate_phone_number(self.market_code)
        self.main_number = numbers.generate_phone_number(self.market_code)
        self.fax_number = numbers.generate_phone_number(self.market_code)
        self.admin_number = numbers.generate_phone_number(self.market_code)
        if self.op_co_customer_id is None:
            self.op_co_customer_id = read_xmldata.gen_opco(marketplace='TMF')
        if self.related_party is None:
            self.related_party = RelatedParty(self.market_code)

        logger.debug(f'account generated {self}')

        if self.contact is None:
            self.contact = Contact()


@dataclass
class UnityAccount(AccountOrderItem):
    """Unity Account information.

    Contains the information required for validation.
    """
    category: str = 'unity'
    ucas_provider: str = 'RINGCENTRAL'
    billing_account_number: str = 'billingAccountNumber222'
    billing_service_reference: str = 'billingServiceReference333'
    opportunity_id: str = 'opportunityId444'
    place: Place = None
    pod_location: str | None = None
    policies: Policies = None
    idp_entity_id: str | None = None

    def __post_init__(self):
        super().__post_init__()
        if self.place is None:
            self.place = Place(self.market_code)


@dataclass
class MSOCAccount(AccountOrderItem):
    category: str = 'msoc'
    # name: str = 'Test Automation MSOC Customer' - TODO: where to generate this field
    tenant_id: str | None = None
    bgid: str | None = None
    customer_domains: list | None = None
    consent_countries: list | None = None
    billing_info: BillingInfo = None
    itsm_provisioning: ItsmProvisioning = None
    place: Place = None

    def __post_init__(self):
        super().__post_init__()
        if self.place is None:
            self.place = Place(self.market_code)
        if self.tenant_id is None:
            self.tenant_id = read_xmldata.generate_msoc_tenantid()
        if self.consent_countries is None:
            self.consent_countries = [self.place.country_code]
        if self.customer_domains is None:
            self.customer_domains = ["vodafone.com"]

    @staticmethod
    def from_msoc_customer_document(customer_doc: dict):
        """
        Factory method to create MSCOAccount object from MsocCustomer Database document
        DO NOT UPDATE context in the factory method, separation of concern.
        :param customer_doc: MsocCustomer Database document
        :return: MSOCAccount
        """
        market_code = customer_doc["market"]
        country_code = countries_data_manager.get_country_code(market_code)
        billing_info_object = BillingInfo()
        if "countryBillingInformation" in customer_doc:
            billing_info_object.service_identifier = customer_doc['countryBillingInformation'][country_code][
                'serviceIdentifier']
            billing_info_object.customer_reference_number = customer_doc['countryBillingInformation'][
                country_code]['customerReferenceNumber']

        # create an object for MSOCAccount with existing info and save to the context to be used with new approach
        msoc_account = MSOCAccount(
            market_code=market_code,
            tenant_id=customer_doc["msTeamsTenantId"],
            bgid=customer_doc["bgid"],
            billing_info=billing_info_object,
            op_co_customer_id=customer_doc['vodafoneId']
        )
        return msoc_account


@dataclass
class TPMAccount(AccountOrderItem):
    category: str = 'tpm'
    tenant_id: str | None = None
    bgid: str | None = None
    itsm_provisioning: ItsmProvisioning = None

    def __post_init__(self):
        super().__post_init__()
        if self.tenant_id is None:
            self.tenant_id = read_xmldata.gen_uuid()

    @staticmethod
    def from_tpm_customer_document(customer_doc: dict):
        """
        Factory method to create TPMAccount object from TpmCustomer Database document
        DO NOT UPDATE context in the factory method, separation of concern.
        :param customer_doc: TpmCustomer Database document
        :return: TPMAccount
        """
        market_code = customer_doc["market"]

        # create an object for TPMAccount with existing info and save to the context to be used with new approach
        tpm_account = TPMAccount(
            op_co_customer_id=customer_doc['vodafoneId'],
            tenant_id=customer_doc['msTeamsTenantId'],
            bgid=customer_doc['bgid'],
            market_code=market_code,
            name=customer_doc['name']
        )
        return tpm_account
