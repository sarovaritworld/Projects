import csv
import json
import logging
import os
import time
import uuid
from datetime import datetime

import toml

from classes import read_xmldata, common, polling
from common_python import api_requests


def get_filename(numpool_uuid, rows_list):
    """
                Function generates a filename with timestamp and provided uuid

                :param numpool_uuid: numpool_uuid
                :param rows_list: This includes all the rows which needs to written into file
                :return: original_filename
                """
    current_date = datetime.now()
    dt_string = current_date.strftime("%Y%m%d")
    original_filename = dt_string + "_" + numpool_uuid + ".csv"
    logging.info(f"csv file name sent as attachment : {original_filename}")
    filepath = './testdata/attachement/' + original_filename
    with open(filepath, 'w', newline='') as csvfile:
        fieldnames = ['RingCentralUUID', 'Action', 'E164', 'Extension', 'Type', 'Date', 'Status', 'Message']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows_list)
    return original_filename


def gen_csv_row(rc_id, action_value, e164, extension, my_type, curr_date, status, msg):
    """
            Function generates a dictionary with provided values

            :param rc_id: It's RingCentralUUID
            :param action_value: Action value
            :param e164: e164 value
            :param extension: extension value
            :param my_type: type value
            :param curr_date: current date value
            :param status: status value
            :param msg: message value
            :return: dictionary
            """
    my_dict = dict()
    my_dict['RingCentralUUID'] = rc_id
    my_dict['Action'] = action_value
    my_dict['E164'] = e164
    my_dict['Extension'] = extension
    my_dict['Type'] = my_type
    my_dict['Date'] = curr_date
    my_dict['Status'] = status
    my_dict['Message'] = msg
    return my_dict


def send_nigthly_reports_email(file):
    reports_config = toml.load("pyproject.toml")["tool"]["automation_fw"]["reports"]
    emails = reports_config['mail_list']

    api_requests.auth_handler.set_jwt_server_auth(common.config.jwt_server_auth)
    server_ip = common.config.EMAIL_SENDER_SERVER
    url = "http://" + server_ip + read_xmldata.readxml("mailserver_url", "test_inputdata", "email_mgnt")
    access_token = api_requests.AuthType.VALID
    uuid_no = str(uuid.uuid1())
    header = {
        'Authorization': access_token,
        'X-Request-ID': uuid_no,
        'Content-Type': "application/json"
    }

    for recipient in emails:
        mail_payload = generate_mail_payload(file, recipient)

        def send():
            max_retries = 3
            for attempt in (1, max_retries + 1):
                try:
                    post_response = api_requests.post(url=url, data=json.dumps(mail_payload), headers=header)
                    return post_response
                except Exception as e:
                    logging.error(f"Got exception while sending report to{recipient}:{e}")
                    if attempt < max_retries:
                        wait = 2
                        logging.info(f"Attempt {attempt} failed. Retrying in {wait} seconds...")
                        time.sleep(wait)
                    else:
                        logging.info("Max retries reached. Operation failed.")
                        return None

        result = polling.wait_until(send, 'Email is send')
        print(result.content)


def generate_mail_payload(file, to):
    mailpayload = read_xmldata.read_jsonfile('postReq_UPUA_73_16')
    mailpayload['to'][0]['email'] = to
    mailpayload['to'][0]['name'] = to
    mailpayload['from']['email'] = 'uccunitymw@gmail.com'
    if common.config.is_staging_env:
        mailpayload['from']['email'] = 'nightly@ucc-stg.vodafone.com'
    mailpayload['from']['name'] = 'SendReportToTeam'
    attachdata = read_xmldata.convertintoBase64(file, path='')
    mailpayload['attachment'][0]['data'] = attachdata
    mailpayload['attachment'][0]['name'] = os.path.basename(file)
    mailpayload['attachment'][0]['format'] = 'application/json'
    mailpayload['content'][0]['value'] = 'This is nightly run results for: ' + os.environ.get("ENVIRONMENT_NAME", "")
    mailpayload['content'][0]['type'] = 'text/plain'
    mailpayload['subject'] = 'Nightly run results'
    return mailpayload
