import logging

from classes import asserts, database, polling

CAC_ID_PREFIX = "TestCac"


def validate_order_of_operations(service_order_id):
    operations = {"ADD_CAC_TO_MSOC_CUSTOMER": 1, "APPLY_CAC_CONFIGURATION": 2}
    for k, v in operations.items():
        document = database.get_service_order_operation(service_order_id, k)
        logging.info(f'{document=}')
        asserts.equals(document["order"], v, 'order of operations')


def validate_cac_id_in_idmapper_db(customer_id, cac_id):
    document = polling.wait_until(
        lambda: database.get_msoc_document_by_customer_id(customer_id),
        f"ID mapper document for {customer_id=} contains {cac_id=}",
        stop_when=lambda doc: doc is not None and cac_id in doc["cacId"])
    logging.debug(f'ID mapper document CAC IDs: {document["cacId"]}')
    logging.info(f'Validated that ID mapper document contains {cac_id=}')


def validate_state_of_operations(service_order_id, operation, expected_state):
    database.get_service_order_operation(service_order_id, operation, expected_state)
    logging.info(f'Validated that {operation=} is in state {expected_state}')



def remove_fields_for_add_cac(payload, fields_to_remove):
    for item in payload.get('serviceOrderItem', []):
        service = item.get('service', {})
        for characteristic in service.get('serviceCharacteristic', []):
            if characteristic.get('name') == 'MsocCacConfiguration':
                value = characteristic.get('value', {})
                for field in fields_to_remove:
                    value.pop(field, None)

