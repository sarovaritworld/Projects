import json
import logging
import os

from confluent_kafka import KafkaException
from confluent_kafka import Producer
from confluent_kafka import SerializingProducer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.protobuf import ProtobufSerializer
from confluent_kafka.serialization import StringSerializer

import event_pb2
from classes import data as dt
from .topics import Topic, Kafka

schema_registry = "http://cp-schema-registry-sasl:8081"
security_protocol = os.environ.get('AUTOMATION_FW_KAFKA_SECURITY_PROTOCOL')


def send_data(data, topic):
    kafka_servers = Kafka.hostname
    logging.info(f'send_data  [topic: {topic}], data: {json.dumps(data, indent=3)}')
    topic = Topic(topic)

    full_topic_name = Kafka.get_kafka_full_topic_name(topic=topic.name)
    if topic.is_protobuf:
        logging.info("It's a protobuf message")
        message = dt.convert_to_protobuf(data)

        schema_registry_client = SchemaRegistryClient({'url': schema_registry})

        protobuf_serializer = ProtobufSerializer(event_pb2.Event,
                                                 schema_registry_client,
                                                 {'use.deprecated.format': False})

        producer = SerializingProducer(Kafka.add_properties({'bootstrap.servers': kafka_servers,
                                                             'security.protocol': security_protocol,
                                                             'key.serializer': StringSerializer('utf_8'),
                                                             'value.serializer': protobuf_serializer}))
    else:
        message = json.dumps(data).encode("utf-8")
        producer = Producer(Kafka.add_properties({
            'bootstrap.servers': kafka_servers,
            'security.protocol': security_protocol
        }))

    key = "TestAutomation"

    try:
        logging.info(f"sending topic {topic}")
        producer.produce(topic=full_topic_name, key=key, value=message)
        producer.flush()
        print("Message Sent Successfully!!!!!!!!!!!!!!!!!!!")
        return True
    except BufferError as err:
        print(f'Unable to send message {err=}')
        raise
    except KafkaException as err:
        print(f'Unable to send message {err=}')
        raise
