import json
import logging
import os
import time
from collections import namedtuple
from copy import copy
from typing import List, Optional

from confluent_kafka import (Consumer, DeserializingConsumer, TIMESTAMP_NOT_AVAILABLE, TopicPartition)
from confluent_kafka.schema_registry.protobuf import ProtobufDeserializer
from confluent_kafka.serialization import StringDeserializer

import event_pb2
from classes import common, data
from classes import data_files
from classes import polling
from classes.delay import Delay
from classes.utils import to_json
from .topics import Kafka, KafkaTopics, Topic
from .utils import get_search_field

num_messages = 10
security_protocol = os.environ.get('AUTOMATION_FW_KAFKA_SECURITY_PROTOCOL')
automationfw_consumer_group = 'automation-fw-adhoc'
logger = logging.getLogger(__name__)
_last_fetched_offsets = {}
_multi_messages_found = []

Message = namedtuple("Message", "value timestamp_ms")


def received_data(
        topic_name: str, search_value: str,
        multi_msg_min_count: int | None = None,
        timeout: Optional[float] = None,
        timeout_tag: Optional[str] = None,
        raises: bool = True) -> dict | list | None:
    """Get a message matching the required criteria on a topic.

    When a message is not found:
      - if `raises=True`, will raise a TimeoutError
      - if `raises=False`, will return None

    Examples:
        If a message is expected (and we want to end the test on missing message):
        >>> message = received_data(topic_name, search_value)
        No need to check `message` (a TimeoutError would have been raised if it was not found)
    
        If a message should NOT be present, you can use `raises=False` to return None
        >>> message = received_data(topic_name, search_value, raises=False)
        >>> assert message is None, "Message should NOT be present"
    
    :param topic_name: Kafka topic
    :param multi_msg_min_count: Minimum number of messages for multi-messages
    :param search_value: Kafka search_value
    :param timeout: (optional) timeout value in seconds
    :param timeout_tag: (optional) tag helping to determine the timeout
    :param raises: (optional) on timeout, whether to raise an exception or return None
    :return: message or None
    """
    if multi_msg_min_count is None:
        multi_msg_min_count = 1  # default: stop polling as soon as we find 1 message
    topic = Topic(topic_name)

    def presence_of_message() -> dict | list | None:
        """Check for presence of a specific Kafka message."""
        try:
            message = _find_message(topic_name, search_value, multi_msg_min_count)
        except Exception as err:
            if raises:
                logger.info(f'    Message still not present... ({type(err)} {err})')
            message = None
        return message

    assert search_value, f"Search value for {topic_name} is empty. Please check context variables"

    # Determine the timeout
    if timeout is None:
        if timeout_tag is None:
            if common.config.is_staging_env and (topic_name.startswith('ringcentral_respond') or
                                                 topic_name.startswith('snowgateway_event')):
                timeout_tag = "kafka_timer_staging"
            elif topic_name == 'crfgateway_event_cacconfiguration_applied':
                timeout_tag = "kafka_cac_timer_staging" if common.config.is_staging_env else "kafka_buffer_timer"
            else:
                timeout_tag = "kafka_timer"

        # Increase the timeout from tag as safety margin
        # Note: this will increase the testing time when no message is
        # received, so do not add too much margin.
        timeout = 2 * data_files.read_config("common.yml", f"timeouts.{timeout_tag}")

    logger.info(
        f"Start searching for a message with topic '{topic_name}' and value '{search_value}'"
        f" with {timeout:.1f}s timeout (based on '{timeout_tag}')")

    # For multiple messages, we cannot determine whether a message is the
    # last one. So we wait until all messages are expected to be present
    if topic.is_multiple:
        time.sleep(Delay.consumer_data)

    # New search: there is no message found or offset fetched yet
    _multi_messages_found.clear()
    _last_fetched_offsets.clear()

    # On timeout, use a general exception message (without search_value/UUID)
    # so we can group similar errors on GCP Results Dashboard
    exc_msg = f"Timeout waiting for 'kafka message {topic_name}'"
    message = polling.wait_until(
        presence_of_message, f"kafka message {topic_name} and {search_value}",
        timeout=timeout, raises=raises, exc_msg=exc_msg)
    return message


def _find_message(topic_name, search_value, multi_msg_min_count):
    topic = KafkaTopics.get(topic_name)
    recent_messages = _get_recent_messages_from_topic(Kafka.hostname, topic)
    # recent_messages are sorted oldest first. Search starting newest first
    # NB: for multi-messages, messages will be returned sorted by timestamp
    for message in reversed(recent_messages):
        if topic.is_protobuf:
            message_as_json = data.convert_to_json(message.value, topic.convert_to_camel_case)
            format = 'protobuf'
        else:
            message_as_json = message.value.decode("utf-8")
            format = 'json'

        try:
            message_object: dict = json.loads(message_as_json)
        except json.decoder.JSONDecodeError as err:
            logger.error(f'Invalid JSON for message {err}')
            raise

        # get keys in which we are looking for value; each topic has its keys
        fields_to_check = KafkaTopics.get(topic_name).search_list
        logger.debug(f'message is in {format}. {fields_to_check=}')

        matching_message = _match_message_any_path(search_value, message_object)
        # matching_message = _match_message(message_object, fields_to_check, search_value)
        if (
                matching_message
                and fields_to_check is not None
                and not _match_message(message_object, fields_to_check, search_value)
        ):
            logger.warning(
                f"Message with {topic_name=} did not match with any of search_list={fields_to_check}"
                f" but matched with another path. Fix (or remove) topics.{topic_name}.search_list"
                " in topic_properties.json")

        if matching_message is None:
            continue
        elif message.timestamp_ms is not None:
            seconds_before_start = \
                common.config.scenario_start_time - (message.timestamp_ms / 1000.0)
            if seconds_before_start > 0:
                logger.info(
                    "Discarding matching message from a previous test, dating"
                    f" {seconds_before_start:.1f} sec before the start of the"
                    f" current scenario:\n{matching_message}")
                continue

        logger.info(f"FOUND A MATCH for topic {topic_name} ({format}):\n{to_json(matching_message)}")
        if topic.is_multiple:
            _multi_messages_found.append(matching_message)
        else:
            return matching_message

    if len(_multi_messages_found) >= multi_msg_min_count:
        logger.info(f'Found a multi-message made of {len(_multi_messages_found)} messages')
        _multi_messages_found.sort(key=lambda message: message['header']['timestamp'])
        return _multi_messages_found
    logger.debug(f"Kafka messages received: {len(_multi_messages_found)} / {multi_msg_min_count}")
    return None


def _match_message_any_path(value, message_object):
    """
Takes a value and checks if the value is present in any key in the message
    :param value:
    :param message_object:
    :return:
    """
    return message_object if common.is_value_present(value, message_object) else None


def _match_message(message_object, fields_to_check, value_to_match):
    """
    Checks if a message matches the specified criteria
    :param message_object: The JSON object representing the message data
    :param fields_to_check: An array of fields to check in the JSON object
    :param value_to_match: The value to look for in the fields
    :return: message_object if match found; None if not found
    """
    for field in fields_to_check:
        # logger.debug(f'Checking field {field}')
        field_value = common.get_field(message_object, field)
        logger.debug(f'field_value {field_value}')
        if field_value == value_to_match:
            return message_object

    # No match
    return None

#Get the last n messages from each partition of a topic
def _get_recent_messages_from_topic(kafka_brokers, topic: Topic) -> List[Message]:
    logger.info(f'_get_recent_messages_from_topic: [{topic.name=}]')

    messages = []
    logger.debug(topic.is_protobuf)
    if topic.is_protobuf:

        protobuf_deserializer = ProtobufDeserializer(event_pb2.Event,
                                                     {'use.deprecated.format': False})
        string_deserializer = StringDeserializer('utf_8')

        consumer = DeserializingConsumer(Kafka.add_properties({'bootstrap.servers': kafka_brokers,
                                                               'key.deserializer': string_deserializer,
                                                               'value.deserializer': protobuf_deserializer,
                                                               'group.id': automationfw_consumer_group,
                                                               'security.protocol': security_protocol
                                                               }))
    else:
        consumer = Consumer(Kafka.add_properties({'bootstrap.servers': kafka_brokers,
                                                  'auto.offset.reset': 'latest',
                                                  'group.id': automationfw_consumer_group,
                                                  'security.protocol': security_protocol,
                                                  'enable.auto.commit': False
                                                  }))

    topic_name = Kafka.get_kafka_full_topic_name(topic=topic.name)

    try:
        topic_metadata = _find_topic(consumer, topic_name)
        for partition in topic_metadata.partitions:
            messages += _get_recent_messages_from_partition(consumer, topic_name, partition)

    except Exception as err:
        logger.warning(f'Failed to seek to get messages from topic, {err=}, {type(err)=}')

    finally:
        consumer.close()

    return messages


def _find_topic(consumer, topic_name):
    cluster_metadata = consumer.list_topics(topic_name)
    topic_metadata = cluster_metadata.topics.get(topic_name)

    if topic_metadata.error is not None:
        raise NameError(f'Failed to find topic {topic_name}: {topic_metadata.error.str()}')
    return topic_metadata


def _get_recent_messages_from_partition(consumer, topic_name, partition) -> List[Message]:
    logger.debug(f'Processing partition {partition} of topic {topic_name}')
    messages = []

    # Determine the start_offset (i.e. from which message we should start fetching)
    last_fetched_offset = _last_fetched_offsets.get(partition)
    if last_fetched_offset is None:
        # Start from the last n messages
        topic_partition = TopicPartition(topic=topic_name, partition=partition)
        low_offset, high_offset = consumer.get_watermark_offsets(topic_partition)
        start_offset = max(high_offset - num_messages, low_offset)
    else:
        # We already fetched messages up to last_fetched_offset
        start_offset = last_fetched_offset + 1

    logger.debug(f'In {partition=} and {topic_name=}, search all messages from {start_offset=}')
    topic_partition = TopicPartition(topic=topic_name, partition=partition, offset=start_offset)
    try:
        consumer.assign([topic_partition])

        while True:
            message = consumer.poll(timeout=1)

            if message is None:
                break

            if message.error():
                logger.warning(f'Consumer message error {message.error()}')
                break

            timestamp_type, timestamp_ms = message.timestamp()
            if timestamp_type == TIMESTAMP_NOT_AVAILABLE:
                logger.warning(f"Found a Kafka message without timestamp: {timestamp_type=}")
                timestamp_ms = None

            # logger.debug(f'Fetched the message with {partition=} and offset={message.offset()}')
            _last_fetched_offsets[partition] = message.offset()

            messages.append(Message(message.value(), timestamp_ms))

    except BaseException as err:
        logger.warning(
            f'Failed to seek to {TopicPartition(topic=topic_name, partition=partition, offset=start_offset)}, {err=}, {type(err)=}')

    finally:
        consumer.unassign()

    return messages


def get_messages(context, topic_name: str):
    logger.debug(f'getting messages for {topic_name=}')
    topic_search_field = get_search_field(context, topic_name)
    logger.debug(f'{topic_search_field=}')
    return received_data(topic_name, topic_search_field)
