import logging

import camel_converter

from classes import common
from .utils import to_messages

logger = logging.getLogger(__name__)


class KafkaMessagesFilter:

    def __init__(self, context=None):
        self._context = context

    def _search_by_key(self, field):
        filtered_messages = [
            msg for msg in to_messages(self._context.consumer_payload)
            if common.is_key_present(field, msg)]
        logger.info(f"Filtered messages containing key '{field}': {filtered_messages}")
        return filtered_messages

    def _search_by_value(self, field):
        filtered_messages = [
            msg for msg in to_messages(self._context.consumer_payload)
            if common.is_value_present(field, msg)]
        logger.info(f"Filtered messages containing key '{field}': {filtered_messages}")
        return filtered_messages

    def _search_by_partial_value(self, field):
        filtered_messages = [
            msg for msg in to_messages(self._context.consumer_payload)
            if common.is_partial_value_present(field, msg)]
        logger.info(f"Filtered messages containing key '{field}': {filtered_messages}")
        return filtered_messages

    def tmfmediator_create_addnumbers(self, number_type: str) -> list[dict]:
        number_type = camel_converter.to_camel(number_type)
        filtered_messages = self._search_by_key(number_type)
        return filtered_messages

    def tmfmediator_command_add_msoccountrybilling(self, marketplace_event_id: str):
        filtered_messages = self._search_by_partial_value(marketplace_event_id)
        return filtered_messages

    def tmfmediator_update_serviceorder(self, msg: str):
        filtered_messages = self._search_by_value(msg)
        return filtered_messages

