import logging

logger = logging.getLogger(__name__)

from .topics import KafkaTopics

crf_topics_add_number = ['numbermanagement_command_add_crfnumber',
                         'crfstub_process_resourceorder',
                         'crfgateway_event_crfnumber_added']


def get_search_field(context, topic):
    topic = topic.replace("'", "")
    search_property = KafkaTopics.get(topic).search_property
    match search_property:
        case 'email':
            return context.email
        case 'NumPool_UUID':
            return "RE: " + context.NumPool_UUID
        case _:
            return getattr(context, search_property)


def has_multiple_messages(consumer_payload):
    return isinstance(consumer_payload, list)


def to_messages(payload: list[dict] | dict | None) -> list[dict]:
    """Convert payload to a list of messages."""
    if payload is None:
        return []
    elif isinstance(payload, dict):
        return [payload]
    else:
        return payload

