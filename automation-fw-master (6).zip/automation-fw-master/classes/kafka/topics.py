import logging
import os

logger = logging.getLogger(__name__)

from classes import read_xmldata, data

properties = read_xmldata.read_jsonfile('topic_properties', 'classes/kafka')


class Kafka:
    """
    Class to communicate with kafka
    """
    datacenter_name = os.environ.get("KAFKA_DATACENTER_NAME")
    version = os.environ.get("KAFKA_VERSION")
    hostname = os.environ.get("KAFKA_HOSTNAME")

    @classmethod
    def get_kafka_full_topic_name(cls, topic) -> str:
        """
            Consumes a short topic name like "ordermanagement_command_create_initialorder" and concatenates it with
            _middelware_ and datacenter name and kafka version
            :param topic:
            :return: string like: "eu-west-1_middleware_ordermanagement_command_create_initialorder_1"
            """
        full_topic = cls.datacenter_name + "_middleware_" + topic + "_" + cls.version
        logger.debug(f"{full_topic=}")
        return full_topic

    @classmethod
    def add_properties(cls, kafka_properties) -> dict:
        if 'SASL' in kafka_properties['security.protocol']:
            kafka_properties['sasl.mechanism'] = os.environ.get('AUTOMATION_FW_KAFKA_SASL_MECHANISM')
            sasl_username, sasl_password = data.get_msk_credentials('msk.json')
            kafka_properties['sasl.username'] = sasl_username
            kafka_properties['sasl.password'] = sasl_password
            # properties['sasl.jaas.config'] = f'org.apache.kafka.common.security.scram.ScramLoginModule required username="{sasl_username}" password="{sasl_password}"; '
        return kafka_properties


class Topic:
    """
    Class, responsible to init any topic with defined in 'topic_properties.json' or with default values
    """

    def __init__(self, name):
        self.name = name

        self.convert_to_camel_case = properties['topics'][name].get('convert_to_camel_case',
                                                                    properties['default']['convert_to_camel_case'])
        self.search_list = properties['topics'][name].get('search_list', properties['default']['search_list'])
        self.search_property = properties['topics'][name].get('search_property',
                                                              properties['default']['search_property'])
        self.is_protobuf = properties['topics'][name].get('is_protobuf', properties['default']['is_protobuf'])
        self.is_multiple = properties['topics'][name].get('is_multiple', properties['default']['is_multiple'])
        self.event_type = properties['topics'][name].get('event_type', None)

    def __repr__(self):
        return str(self.name)


class KafkaTopics:
    """
    Class handles all topics, defined explicitly or automatically (based on topic_properties.json)

    Examples:
            In order to access topic in the IDE using dot, you need to declare it in the attributes list.

            >>> topic_name = Topic('topic_name')

            Then it will be accessible via KafkaTopics.topic_name
            with all properties:

            >>> KafkaTopics.topic_name.is_protobuf
    """

    @classmethod
    def get(cls, name) -> Topic:
        try:
            return cls.__getattribute__(cls, name)
        except AttributeError:
            return Topic(name)

    tmfgateway_process_serviceorder = Topic('tmfgateway_process_serviceorder')
    tmfgateway_update_serviceorder = Topic('tmfgateway_update_serviceorder')

    tmfmediator_command_create_initialorder = Topic('tmfmediator_command_create_initialorder')
    tmfmediator_create_addnumbers = Topic('tmfmediator_create_addnumbers')
    tmfmediator_create_msoc_addnumbers = Topic('tmfmediator_create_msoc_addnumbers')
    tmfmediator_create_deletenumbers = Topic('tmfmediator_create_deletenumbers')
    tmfmediator_create_jiraticket = Topic('tmfmediator_create_jiraticket')

    tmfmediator_update_serviceorder = Topic('tmfmediator_update_serviceorder')

    tmfmediator_command_set_ssoconfig = Topic('tmfmediator_command_set_ssoconfig')
    tmfmediator_command_set_accountserviceinfo = Topic('tmfmediator_command_set_accountserviceinfo')
    tmfmediator_command_create_msoccustomer = Topic('tmfmediator_command_create_msoccustomer')
    tmfmediator_command_create_snowcustomer = Topic('tmfmediator_command_create_snowcustomer')
    tmfmediator_command_delete_all_numbers = Topic('tmfmediator_command_delete_all_numbers')
    tmfmediator_command_delete_account = Topic('tmfmediator_command_delete_account')
    tmfmediator_command_add_msoccountrybilling = Topic('tmfmediator_command_add_msoccountrybilling')
    tmfmediator_command_add_msoccustomercac = Topic('tmfmediator_command_add_msoccustomercac')
    tmfmediator_command_apply_cacconfiguration = Topic('tmfmediator_command_apply_cacconfiguration')
    tmfmediator_command_create_tpmcustomer = Topic("tmfmediator_command_create_tpmcustomer")
    tmfmediator_command_send_tpmnotification = Topic("tmfmediator_command_send_tpmnotification")
    tmfmediator_command_set_emergencyaddress = Topic("tmfmediator_command_set_emergencyaddress")
    tmfmediator_command_delete_snowcustomer = Topic("tmfmediator_command_delete_snowcustomer")
    tmfmediator_command_add_unitylicense = Topic("tmfmediator_command_add_unitylicense")
    tmfmediator_command_delete_unitylicense = Topic("tmfmediator_command_delete_unitylicense")
    tmfmediator_command_change_unitylicense = Topic("tmfmediator_command_change_unitylicense")
    tmfmediator_command_set_policy_access = Topic("tmfmediator_command_set_policy_access")

    ordermanagement_command_create_initialorder = Topic('ordermanagement_command_create_initialorder')
    ordermanagement_event_order_completed = Topic('ordermanagement_event_order_completed')
    ordermanagement_event_account_created = Topic('ordermanagement_event_account_created')
    ordermanagement_command_update_accountstatus = Topic('ordermanagement_command_update_accountstatus')

    idmapper_event_msoccustomer_created = Topic('idmapper_event_msoccustomer_created')
    idmapper_event_msoccountrybilling_added = Topic('idmapper_event_msoccountrybilling_added')
    idmapper_event_account_deleted = Topic('idmapper_event_account_deleted')
    idmapper_event_tpmnotification_sent = Topic('idmapper_event_tpmnotification_sent')

    numbermanagement_command_add_numbers = Topic('numbermanagement_command_add_numbers')
    numbermanagement_command_add_crfnumber = Topic('numbermanagement_command_add_crfnumber')
    numbermanagement_respond_numbersadded = Topic('numbermanagement_respond_numbersadded')
    numbermanagement_event_numbers_deleted = Topic('numbermanagement_event_numbers_deleted')
    numbermanagement_command_delete_crfnumber = Topic('numbermanagement_command_delete_crfnumber')
    numbermanagement_command_update_numbers = Topic('numbermanagement_command_update_numbers')
    numbermanagement_command_delete_all_crf_numbers = Topic('numbermanagement_command_delete_all_crf_numbers')
    numbermanagement_event_all_numbers_deleted = Topic('numbermanagement_event_all_numbers_deleted')

    ringcentral_event_initialorder_created = Topic('ringcentral_event_initialorder_created')
    ringcentral_event_numbers_added = Topic('ringcentral_event_numbers_added')
    ringcentral_event_ssoconfig_updated = Topic('ringcentral_event_ssoconfig_updated')
    ringcentral_event_accountserviceinfo_updated = Topic('ringcentral_event_accountserviceinfo_updated')
    ringcentral_event_emergencyaddress_set = Topic('ringcentral_event_emergencyaddress_set')
    ringcentral_event_numbers_updated = Topic('ringcentral_event_numbers_updated')
    ringcentral_event_extension_set = Topic('ringcentral_event_extension_set')
    ringcentral_event_unitylicense_added = Topic('ringcentral_event_unitylicense_added')
    ringcentral_event_unitylicense_deleted = Topic('ringcentral_event_unitylicense_deleted')
    ringcentral_event_unitylicense_changed = Topic('ringcentral_event_unitylicense_changed')
    ringcentral_event_policy_access_set = Topic('ringcentral_event_policy_access_set')

    jiraticketmediator_respond_jiraticket = Topic('jiraticketmediator_respond_jiraticket')

    crfgateway_event_cacconfiguration_applied = Topic('crfgateway_event_cacconfiguration_applied')
    crfgateway_event_crfnumber_added = Topic('crfgateway_event_crfnumber_added')
    crfgateway_event_crfnumber_deleted = Topic('crfgateway_event_crfnumber_deleted')
    crfgateway_event_all_crf_numbers_deleted = Topic('crfgateway_event_all_crf_numbers_deleted')

    support_command_register_crf_tmf652_listener = Topic('support_command_register_crf_tmf652_listener')
    support_command_unregister_crf_tmf652_listener = Topic('support_command_unregister_crf_tmf652_listener')
    support_command_update_suspended_operation = Topic('support_command_update_suspended_operation')
    support_command_retry_tmf_notification = Topic('support_command_retry_tmf_notification')

    snowgateway_event_snowcustomer_created = Topic('snowgateway_event_snowcustomer_created')
    snowgateway_event_snowcustomer_deleted = Topic('snowgateway_event_snowcustomer_deleted')

    crfstub_process_resourceorder = Topic('crfstub_process_resourceorder')
    tmfmediator_command_set_extension = Topic('tmfmediator_command_set_extension')
