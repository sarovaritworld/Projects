from classes import numbers


def is_presentation(item):
    return True if numbers.get_numbers_pooltype(item).upper() == 'Presentation'.upper() else False


def is_inventory(item):
    return True if numbers.get_numbers_pooltype(item).upper() == 'Fixed'.upper() else False
