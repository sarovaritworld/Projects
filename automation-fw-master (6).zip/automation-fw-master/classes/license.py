from dataclasses import dataclass
from random import choice
from string import ascii_lowercase

from classes import common
from common_python.stub_accounts.stub_accounts import StubAccounts


@dataclass
class LicenseOrderItem:
    """ Holds information about service order item which orders license """
    quantity: int = 5
    id: str = "LC_DL-UNL_50"


@dataclass
class RCStubPreconfiguredLicenseCount:
    quantity: int = 5


def modify_licenses_addition_payload(payload, key, value):
    service_characteristics_path = "serviceCharacteristic.[0]"
    supporting_resource_path = "supportingResource.[0]"
    service_order_items_to_modify = payload["serviceOrderItem"][0]
    paths = {
        "name": f"{service_characteristics_path}.name",
        "value": f"{service_characteristics_path}.value",
        "valueType": f"{service_characteristics_path}.valueType",
        "supportingResource.id": f"{supporting_resource_path}.id",
        "multiple_supportingResource": "supportingResource",
        "supportingResource_sku_id_whiteSpaces": f"{supporting_resource_path}.id",
        "supportingResource_id_above_maxLength": f"{supporting_resource_path}.id",
        "invalid_SKU_ID": f"{supporting_resource_path}.id"
    }

    field = paths.get(key)
    value_to_use = ""
    match key:
        case "name" | "valueType":
            value_to_use = value

        case "value":
            match value:
                case "white_spaces":
                    value_to_use = "     "
                case "__NULL__":
                    value_to_use = ""
                case _:
                    value_to_use = float(value)

        case "supportingResource.id":
            value_to_use = value if value != "__NULL__" else ""

        case "multiple_supportingResource":
            supporting_resource_list = \
                service_order_items_to_modify["service"]["supportingResource"]
            additional_supporting_resource = {"id": value}
            supporting_resource_list.append(additional_supporting_resource)
            value_to_use = supporting_resource_list

        case "supportingResource_sku_id_whiteSpaces":
            value_to_use = "         "

        case "invalid_SKU_ID":
            value_to_use = value

        case "supportingResource_id_above_maxLength":
            value_to_use = ''.join(
                choice(ascii_lowercase) for _ in range(51))

        case _:
            raise NotImplementedError(f"validation for error {key} is not implemented yet")

    common.create_or_update_key(payload, f'$..{field}', value_to_use)


def get_test_failure_values(api, error):
    """
        Returns test failure values based on the API level and the provided error
        :param api, error
        :return: Ring Central id, Opco customer id (only for POST tests)
    """
    stub_accounts = StubAccounts()
    match (api, error):
        case ('Get_Licenses', 'Bad_Request'):
            return stub_accounts.rc.get_license_bad_request, None
        case ('Get_Licenses', 'Server_Error'):
            return stub_accounts.rc.get_license_server_error, None
        case ('Post_Licenses', 'Bad_Request'):
            return "995757138", "System_Error_Bad_Request"
        case ('Post_Licenses', 'Server_Error'):
            return "991923415", "Server_Not_found"
        case _:
            return None


def get_default_sku_id():
    """
    This function pick a sku ID up depending on the environment the tests are run

    @return: a default sku ID
    """
    return 'LC_DL-UNL_50' if common.config.is_dev_env else 'LC_ALN_38'


def get_modified_license_number(current_sku_id, initial_license_count, license_count):
    """
    This function calculates the number of licenses which has been modified (added or deleted)

    @param current_sku_id: sku ID depending on the environment we are running tests
    @param initial_license_count: initial number of licenses the account already has
    @param license_count: licenses number to be modified
    @return: the number of licenses which has been modified
    """
    return int(license_count) - initial_license_count if current_sku_id in get_default_sku_id() else int(license_count)


class AddLicenseMilestone:
    def __init__(self, quantity: str, sku_id: str):
        self.message = f"Added {quantity} licenses with SKU {sku_id} to the RINGCENTRAL account"
        self.description = "ADD_UNITY_LICENSE:COMPLETED"
        self.status = "COMPLETED"


class DeleteLicenseMilestone:
    def __init__(self, quantity: str, sku_id: str):
        self.message = f"Deleted {quantity} licenses with SKU {sku_id} from the RINGCENTRAL account"
        self.description = "DELETE_UNITY_LICENSE:COMPLETED"
        self.status = "COMPLETED"


class ModifyLicenseMilestone:
    def __init__(self, sku_id: str, licenses_added: int):
        if licenses_added > 0:
            self.message = f"Added {licenses_added} licenses with SKU {sku_id} to the RINGCENTRAL account"
        elif licenses_added < 0:
            self.message = f"Deleted {-1 * licenses_added} licenses with SKU {sku_id} from RINGCENTRAL account"
        else:
            self.message = f"RINGCENTRAL account has the requested number of licenses for SKU {sku_id} so no licenses added or removed"
        self.description = "CHANGE_UNITY_LICENSE:COMPLETED"
        self.status = "COMPLETED"
