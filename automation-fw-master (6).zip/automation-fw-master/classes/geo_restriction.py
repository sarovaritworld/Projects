class GeoRestrictionMilestone:
    def __init__(self):
        self.description: str = "SET_POLICY_ACCESS:COMPLETED"
        self.status: str = "COMPLETED"
        self.message: str = "Updated the RingCentral access policy"
