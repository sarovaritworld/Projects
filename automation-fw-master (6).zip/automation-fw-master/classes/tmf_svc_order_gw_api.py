import os

from classes import utils

SLO = os.getenv('UCC_TMF_SVC_ORDER_GW_SERVICE_ORDER_SLO_DURATION')
CRON_JOB_FREQUENCY_MINUTES = utils.cron_to_frequency(os.getenv('UCC_TMF_SVC_ORDER_GW_SERVICE_ORDER_SLO_CRONEXPRESSION'))
