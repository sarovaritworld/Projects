import logging

import phonenumbers
from jsonpath_ng import parse

from classes import asserts, common, payload, read_xmldata
from classes.data_factory import countries_data_manager
from classes.domain.numbers import PoolType
from classes.payload_generators import numbers
from classes.utils import to_json

logger = logging.getLogger(__name__)

negative_numbers = ["pool_all_NOK", "pool_OK_NOK", "pool_NOK_OK", "pool_Bad_Request", "pool_internal_server_error",
                    "pool_non_existing_account", "CRF_RC_no_account", "CRF_Bad_Request_add_pool",
                    "CRF_number_Bad_Request", "different_account", "same_account_partial_inventory",
                    "same_account_partial_presentation", "pool_different_usage"]

nonautomated_pooltype_list = ["Mobile", "FMC"]

topic_action_list = ("numbermanagement_command_add_numbers:Add", "numbermanagement_command_delete_numbers:Delete",
                     "ringcentral_event_numbers_added:Add", "ringcentral_event_numbers_deleted:Delete")

topic_action_range_list = (
    "numbermanagement_command_add_numbers:Add_Range", "numbermanagement_command_delete_numbers:Delete_Range",
    "ringcentral_event_numbers_added:Add_Range", "ringcentral_event_numbers_deleted:Delete_Range")

crf_negative_numbers = {"CRF_number_Bad_Request": "+12345678"}

add_number_errors = {
    "errorMessage1": "RingCentral provisioning failed:",
    "errorMessage2": "Phone number could not be provisioned in RingCentral",
    "incompatible_usage_type": "errorCode:ACT-152, message:Phone number is already in use with an incompatible usage type: ",
    "number_in_use": "errorCode:ACT-152, message:Phone number is already in use",
    "tpm_numbers_error_message": "TPM Provisioning failed: One or more numbers could not be added in TPM",
    "tpm_error_message_bad_request": "TPM Provisioning failed: Error occurred while processing the TPM request"
}

delete_number_errors = {
    "default": "TPM Deprovisioning failed: Error occurred while processing the TPM request",
    "partial_dep_notification": "TPM Deprovisioning failed: One or more numbers could not be deleted in CRF",
    "failed_dep_notification": "TPM Deprovisioning failed: Failed to delete all numbers from CRF"
}

invalid_number = read_xmldata.gen_contact(20)

duplicate_number_suffix = {"same_account_presentation": "22",
                           "different_account": "77",
                           "same_account_partial_presentation": "22",
                           "same_account_inventory": "55",
                           "same_account_partial_inventory": "44",
                           "same_account_inventory_usageType": "33",
                           "same_account_presentation_usageType": "22",
                           "Inventory": "11",
                           "MainCompanyNumber": "12",
                           "AdditionalCompanyNumber": "13",
                           "CompanyNumber": "14",
                           "DirectNumber": "15",
                           "PhoneLine": "16",
                           "CompanyFaxNumber": "17",
                           "ContactCenterNumber": "18",
                           "ConferencingNumber": "19",
                           "MeetingsNumber": "20",
                           "ForwardedNumber": "21",
                           "ForwardedCompanyNumber": "22",
                           "BusinessMobileNumber": "23"
                           }


def generate_pool(quantity: str | int, market_code: str, pool_type: PoolType = PoolType.Fixed):
    """
Generates pool of single numbers with requested quantity for market_code
    :param pool_type:
    :param quantity: can be passed as string
    :param market_code: ex: 'VFUK'
    :return:
    """
    logger.debug(f'generating {quantity} numbers for {market_code=} with {pool_type=}')
    pool = []
    quantity = int(quantity)
    while quantity > 0:
        pool_number = generate_phone_number(market_code, pool_type)
        pool.append(pool_number)
        quantity -= 1
    logger.debug(f'generated numbers: {pool}')
    return pool


def generate_phone_number(market_code: str = 'VFUK', pool_type: PoolType = PoolType.Fixed):
    """
Generates phone number based on requested market_code
    :param pool_type:
    :param market_code:
    :return:
    """
    isd_code = countries_data_manager.get_isd_code(market_code)
    area_code = countries_data_manager.get_area_code(market_code, pool_type)
    local_number_length = countries_data_manager.get_local_number_length(market_code)
    phone_number = isd_code + area_code + read_xmldata.gen_contact(local_number_length)
    assert phonenumbers.is_possible_number(phonenumbers.parse(phone_number)), \
        f"The {phone_number=} generated is invalid (in {market_code=})"
    return phone_number


def get_pool_range(from_range_number: str, to_range_number: str):
    """
Generates the pool between 2 numbers
    :param from_range_number:
    :param to_range_number:
    :return:
    """
    logger.debug(f'{from_range_number=}, {to_range_number=}')
    pool = [str(from_range_number)]
    while int(from_range_number) != int(to_range_number):
        from_range_number = int(from_range_number) + 1
        pool.append(f"+{from_range_number}")
    logger.debug(f'generated {pool=}')
    return pool


def get_end_range_number(start_number: str, quantity: str | int):
    """
Gets to_range_number based on start number and quantity: for pool_range
    :param start_number:
    :param quantity:
    :return:
    """
    return "+" + str(int(start_number) + int(quantity) - 1)


def generate_sequent_pool(quantity, market_code):
    start = generate_phone_number(market_code)
    pool = get_pool_range(start, get_end_range_number(start, quantity))
    return pool


def sorted_numbers(numbers):
    sorted_numbers = sorted(numbers, key=lambda x: int(x.replace("+", "").replace(" ", "")))
    return sorted_numbers


###

def append_resource_characteristic(number_item, item_index='1', resource_type=None, pool=None, pool_range_from=None,
                                   pool_range_to=None, pool_type="Fixed"):
    if resource_type is None:
        logger.error("Resource type is empty")
    resource = {
        "@baseType": "ResourceRef",
        "@type": "ResourceRefOrValue",
        "id": f"{item_index}.1",
        "category": "NumberPoolInventory",
        "resourceCharacteristic": [
            {
                "name": "TenantPool",
                "valueType": "object",
                "value": {
                    "@type": resource_type,
                    "poolType": pool_type,
                    "siteId": "HQ",
                }
            }
        ]
    }

    if resource_type in ('UccTenantPool', 'UccMsocNumberPool'):
        resource['resourceCharacteristic'][0]['value']['pool'] = pool
    elif resource_type in ('UccTenantPoolRange', 'UccMsocNumberPoolRange'):
        resource['resourceCharacteristic'][0]['value']['poolRange'] = [{"from": pool_range_from, "to": pool_range_to}]

    number_item['service']['supportingResource'].append(resource)
    logger.debug(number_item)
    return number_item


### generation of number item payload
def generate_invalid_numbers_payload(context, invalid_field, action):
    _payload = payload.append_item_to_payload(context, 'add_numbers', action)
    _payload = payload.refresh_ids(_payload)
    logger.debug(f'default _payload {_payload}')
    number_item = payload.get_last_item(_payload)
    index = _payload['serviceOrderItem'].index(number_item)
    logger.info(_payload)

    from_range_number = ""
    to_range_number = ""
    pool_number = ""
    number = read_xmldata.readxml("number_range", "tmf_testdata", "tmf_data")
    if 'number' in invalid_field:
        from_range_number = read_xmldata.gen_contact(number)
        to_range_number = read_xmldata.add_range_number(from_range_number, 5)
        number_item = append_resource_characteristic(number_item, index, resource_type='UccTenantPoolRange',
                                                     pool_range_from=from_range_number, pool_range_to=to_range_number)
    else:
        pool_number = read_xmldata.gen_contact(number)
        number_item = append_resource_characteristic(number_item, index, resource_type='UccTenantPool',
                                                     pool=pool_number)

    if invalid_field == 'duplicate_ids':
        ids_count = 2
        number_item = append_resource_characteristic(number_item, resource_type='UccTenantPool')
        index, item = payload.get_item_by_type(_payload, 'ucc.unity.numbers')
        for i in range(ids_count):
            item['service']['supportingResource'][i]['id'] = f'{index + 1}.1'
    elif invalid_field == 'empty_id_supporting_resource':
        number_item['service']['supportingResource'][0]['id'] = ''
    elif invalid_field == 'invalid_category':
        number_item['service']['supportingResource'][0]['category'] = 'notNumberPoolInventory!'
    elif invalid_field == 'duplicate_supporting_resource':
        number_item = append_resource_characteristic(number_item, resource_type='UccTenantPool')
    elif invalid_field == 'invalid_resource_name':
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['name'] = 'notEvenTenantPool!'
    elif invalid_field == 'invalid_resource_value_type':
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['valueType'] = 'not_object!'
    elif invalid_field == 'duplicate_resource_name':
        duplicate_resource_characteristic = {
            "name": "TenantPool",
            "valueType": "object",
            "value": {
                "@type": "UccTenantPool",
                "poolType": "Fixed",
                "siteId": "HQ",
                "pool": [
                    "+44" + pool_number
                ]
            }
        }
        number_item['service']['supportingResource'][0]['resourceCharacteristic'].append(
            duplicate_resource_characteristic)
    elif invalid_field == "invalid_pool":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['pool'] = [invalid_number]

    elif invalid_field == "invalid_from_number":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['poolRange'] = [
            {"from": invalid_number, "to": "+44" + to_range_number}]

    elif invalid_field == "invalid_to_number":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['poolRange'] = [
            {"from": "+44" + from_range_number, "to": invalid_number}]
    elif invalid_field == "to_before_from_number":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['poolRange'] = [
            {"from": "+44" + to_range_number, "to": "+44" + from_range_number}]

    elif invalid_field == "invalid_type_with_valid_number":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['@type'] = "NotUccTenants"
    elif invalid_field == "empty_pool_range_number":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['poolRange'] = []
    elif invalid_field == "empty_pool_num":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['pool'] = []
    elif invalid_field == "invalid_e164_pool_num":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['pool'] = [
            "44" + pool_number]
    elif invalid_field == "invalid_e164_pool_range_number":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['poolRange'] = [
            {"from": "44" + from_range_number, "to": "44" + to_range_number}]
    elif invalid_field == "invalid_pool_type":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['poolType'] = 'anything'
    elif invalid_field == "empty_site_id":
        number_item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['siteId'] = ''
    logger.debug(f'number_item {number_item}')
    logger.debug(f'_payload {_payload}')
    index = _payload['serviceOrderItem'].index(number_item)
    _payload['serviceOrderItem'][index] = number_item
    return _payload


def generate_numberitem_for_poolrange(context, pool_type, market_code, index, number_item, quantity,
                                      from_range_number=None):
    if from_range_number is None:
        from_range_number = generate_phone_number(market_code)
    to_range_number = read_xmldata.add_range_number(from_range_number, quantity)
    save_pool(context, from_range_number, to_range_number)
    number_item = append_resource_characteristic(number_item, index, resource_type='UccTenantPoolRange',
                                                 pool_range_from=from_range_number,
                                                 pool_range_to=to_range_number, pool_type=pool_type)
    return number_item


def generate_numbers_item(action, quantity='5', resource_type='pool', pool_type='Fixed', market_code='VFUK',
                          start_number=None):
    """
Generates numbers service order item (soi) with provided parameters:
Pass only one number, either start number to generate an end number for resource type Range,
OR to generate the whole list of numbers based of first number using the quantity.
    :param start_number:
    :param action:
    :param quantity:
    :param resource_type:
    :param pool_type:
    :param market_code:
    :return: generated service order item for numbers
    """
    logger.debug(f'{action=}, {quantity=}, {resource_type=}, {pool_type=}, {market_code=}, {start_number=}')
    number_item = read_xmldata.read_jsonfile(f"item_models/numbers")
    number_item['action'] = action
    if resource_type == 'pool_range':
        if not start_number:
            start_number = generate_phone_number(market_code)
        to_range_number = read_xmldata.add_range_number(start_number, quantity)
        number_item = append_resource_characteristic(number_item, resource_type='UccTenantPoolRange',
                                                     pool_range_from=start_number,
                                                     pool_range_to=to_range_number, pool_type=pool_type)
    else:
        if not start_number:
            pool = generate_sequent_pool(quantity, market_code)
        else:
            pool = get_pool_range(start_number, get_end_range_number(start_number, quantity))
        number_item = append_resource_characteristic(number_item, resource_type='UccTenantPool',
                                                     pool=pool, pool_type=pool_type)

    logger.debug(f'{number_item=}')
    return number_item


def save_pool(context, from_range_number, to_range_number):
    context.pool = get_pool_range(from_range_number, to_range_number)


#### manipulations with item, to be converted to number item class
def type_of_pool(item):
    return item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['@type']


def type_of_pool_str(item):
    if is_pool(item):
        return 'pool'
    if is_range(item):
        return 'pool_range'


def is_pool(item):
    category = get_category_by_service_type(item)
    if type_of_pool(item) == numbers.resource_type_list[category]["pool"]:
        return True
    return False


def is_range(item):
    category = get_category_by_service_type(item)
    if type_of_pool(item) == numbers.resource_type_list[category]["pool_range"]:
        return True
    return False


def is_multiple_range(item):
    if is_range(item) and \
            len(parse('$.service.supportingResource[0].resourceCharacteristic[0].value.poolRange').find(item)[
                    0].value) > 1:
        return True
    return False


def get_category_by_service_type(item):
    if 'ucc.msoc.numbers' in item['service']['serviceType']:
        return "MSOC"
    elif 'ucc.tpm.numbers' in item['service']['serviceType']:
        return "TPM"
    return "UNITY"


def get_pool(item):
    return item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['pool']


def get_main_number(item):
    return item['service']['serviceCharacteristic'][0]['value']['mainNumber']


def get_pool_range_from(item: dict) -> list:
    """
    Extracts the 'from' values from the pool ranges in the given item.

    :param item: order item.
    :return: A list of 'from' values if pool ranges exist, otherwise an empty list.
    """
    from_values = get_pool_range_values(item, 'from')
    return from_values


def get_pool_range_to(item: dict) -> list:
    """
    Extracts the 'to' values from the pool ranges in the given item.

    :param item: A dictionary containing service order details.
    :return: A list of 'to' values if pool ranges exist, otherwise an empty list.
    """
    to_values = get_pool_range_values(item, 'to')
    return to_values


def get_pool_range_values(item: dict, key: str) -> list:
    """
    Extracts the specified values from the pool ranges in the given item.
    If it is only one range, returns it's value
    Logs error if 'poolRange' not found

    :param item: A dictionary containing service order details.
    :param key: The key ('from' or 'to') to extract values for.
    :return: A list of specified values if pool ranges exist, otherwise an empty list.
    """
    pool_ranges = item['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['poolRange']
    if isinstance(pool_ranges, list):
        values = [pool.get(key) for pool in pool_ranges if key in pool]
        if len(values) == 1:
            return values[0]
        return values
    logger.error('Provided item does not contain any poolRange')
    logger.error(f'{to_json(item)}')
    return []


def get_start_number(number_item):
    resource_type = type_of_pool_str(number_item)
    if resource_type == 'pool':
        return get_pool(number_item)[0]
    elif resource_type == 'pool_range':
        return get_pool_range_from(number_item)


def get_all_numbers(item):
    logger.debug(item)
    if is_pool(item):
        return get_pool(item)
    elif is_multiple_range(item):
        range_numbers = []
        for ranges in parse('$.service.supportingResource[0].resourceCharacteristic[0].value.poolRange').find(item)[
            0].value:
            range_numbers.extend(get_pool_range(ranges['from'], ranges['to']))
        return range_numbers
    elif is_range(item):
        return get_pool_range(get_pool_range_from(item), get_pool_range_to(item))


def get_numbers_pooltype(item):
    return item["service"]["supportingResource"][0]["resourceCharacteristic"][0]["value"]["poolType"]


### manipulations with messages related to number item
def remove_main_number_from_consumer_payload(consumer_payload, main_number):
    """
removes main number from received messages for numbers validation
    :param consumer_payload:
    :param main_number:
    :return:
    """
    logger.info(f'removing main number: {main_number} item from received messages')
    logger.info(f'consumer_payload {consumer_payload}')
    for item in consumer_payload:
        try:
            if item['addNumbers']['mainNumber'] == main_number:
                consumer_payload.remove(item)
                logger.debug('main number item removed')
                return consumer_payload
        except KeyError:
            pass
        try:
            if item['phone_numbers']['phone_number_details'][0]['phone_number'] == main_number:
                consumer_payload.remove(item)
                logger.debug('main number item removed')
                return consumer_payload
        except KeyError:
            pass
    return consumer_payload


def get_numbers_from_message(message, include_error=False):
    numbers = []
    for number in message['phone_numbers']['phone_number_details']:
        if include_error is False and 'error' in number.keys() and len(number['error']) != 0:
            continue
        numbers.append(number['phone_number'])
    return numbers


def is_main_number_in_consumer_payload(consumer_payload):
    return any('mainNumber' in message['addNumbers'].keys() for message in consumer_payload)


def get_numbers_from_numbersConfirmation(message):
    numbers = []
    for number in message['numbersConfirmation']['data']:
        if 'error' in number.keys() and len(number['error']) != 0:
            continue
        numbers.append(number['e164'])
    return numbers


def get_message_with_main_number(consumer_messages):
    logger.info(f'{consumer_messages=}')
    for message in consumer_messages:
        logger.info(f'{message=}')
        if 'mainNumber' in message['addNumbers'].keys():
            return message


def fetch_and_validate_numbers(context, kafka_topic_name, expected_list):
    """
            Function fetch_and_validate_numbers: compare actual and expected values for numbers and prints a message, if assertion did not pass
            :param context: Global variable
            :param kafka_topic_name: This is name of kafka topic
            :param expected_list: This is list of expected numbers which will used to validate actual results
            """
    if isinstance(expected_list, dict):
        expected_list = expected_list.get("pool")
    logger.debug(f'{expected_list=}')
    logger.debug(' ')
    consumer_payload = context.consumer_payload
    for message in consumer_payload:
        if message["phone_numbers"]["phone_number_details"][0]["phone_number"] in expected_list:
            consumer_payload = message
            break
    try:
        if isinstance(consumer_payload, list):
            consumer_payload = consumer_payload[-1]
        ucas_account_id = consumer_payload["phone_numbers"]["ucas_account_id"]
        logger.debug(f"ucas_account_id :{ucas_account_id}")
        asserts.equals(len(consumer_payload["phone_numbers"]["phone_number_details"]), len(expected_list),
                       f"Number of Phone numbers")
        for i in range(len(expected_list)):
            phone_number = consumer_payload["phone_numbers"]["phone_number_details"][i]["phone_number"]
            logger.debug(f"phone_number {i}:{phone_number}")
            if phone_number not in expected_list:
                logger.error(f"Phone number {phone_number} not in expected list: {expected_list}")
                raise Exception("Phone number not in expected list")

    except (KeyError, IndexError):
        assert False, f"KeyError/IndexError for topic: {kafka_topic_name} : Please check the JSON payload"
    assert context.RC_ID == ucas_account_id, f"Ucas_account_id : {context.RC_ID} is not present in kafka topic {ucas_account_id}"


def validate_number_in_crf_request(_context):
    logger.info("Validating no duplicates are there")
    numbers_list = []
    if hasattr(_context, "pool"):
        numbers_list = _context.pool
    elif hasattr(_context, "E164_LookupValue"):
        numbers_list = _context.E164_LookupValue
    if len(numbers_list) > 0:
        if "pool" in _context.consumer_payload['crfNumberRequest']:
            actual_numbers = _context.consumer_payload['crfNumberRequest']["pool"]
        else:
            actual_numbers = []
            for range_ in _context.consumer_payload['crfNumberRequest']["poolRange"]:
                actual_numbers += get_pool_range(range_["from"], range_["to"])
        asserts.equals(len(actual_numbers),
                       len(numbers_list), "Pool without duplicate length")


## manipulations with whole service order and context
def remove_negative_numbers(context, expected_service_order_items):
    if hasattr(context, 'number_type') and context.number_type in negative_numbers:
        i, item = payload.get_item_by_type(context.payload, 'ucc.unity.numbers')
        expected_service_order_items.pop(i)


def get_numbers_list(soi):
    """
    Get numbers list of list.
    :param: soi
    :return: list of numbers
    """
    numbers_list = []
    MAX_NUM_LIMIT = int(read_xmldata.readxml("MAX_NUM_LIMIT", "test_inputdata", "num_prov"))

    for item in soi:
        number_set = get_all_numbers(item)
        numbers_list.extend(number_set)
        # chunks = [number_set[x:x + MAX_NUM_LIMIT] for x in range(0, len(number_set), MAX_NUM_LIMIT)]
        # for chunk in chunks:
        #     numbers_list.append(chunk)

    return numbers_list


def remove_add_number_item_by_pooltype(items, pooltype):
    for item in items:
        if (item["service"]["serviceType"] == "ucc.unity.numbers" or item["service"][
            "serviceType"] == "ucc.msoc.numbers") and get_numbers_pooltype(item) == pooltype and item[
            "action"] == "add":
            items.remove(item)
    return items


def get_number_item_by_pool_type(service_order_list, pool_type):
    logger.debug(f"pool_type is : {pool_type} , Items : {service_order_list}")
    for index, item in enumerate(service_order_list):
        logger.debug(f'{index=}, {item=}')
        if get_numbers_pooltype(item) == pool_type:
            return index, item
    return 0, None


def get_number_item_by_resource_type(items, resource_type):
    for index, item in enumerate(items):
        if type_of_pool_str(item) == resource_type:
            logger.info(f'{index=}, {item=}')
            return index, item
    logger.debug('number item is not found')
    return None, None


def save_numbers_to_context(context, variable_name, number_item):
    if not hasattr(context, variable_name):
        setattr(context, variable_name, [])
    resource_type = type_of_pool_str(number_item)
    # get generated numbers saved to the context
    if resource_type == 'pool':
        n = get_pool(number_item)
    elif resource_type == 'pool_range':
        n = get_pool_range_from(number_item)

    param = getattr(context, variable_name)
    if len(param) == 0:
        param = [n]
    else:
        param.append([n])

    setattr(context, variable_name, param)


def remove_unsupported_number_item_based_on_pool_type(expected_soi):
    expected_soi_final = expected_soi.copy()
    for item in expected_soi:
        if get_numbers_pooltype(item) in nonautomated_pooltype_list:
            expected_soi_final.remove(item)
    return expected_soi_final


def get_numbers_from_payload_based_on_pooltype(expected_order, action, number_type):
    pool_number = None
    for item in expected_order:
        if (payload.item_is_add_number(item) or payload.item_is_add_tpm_numbers(item)) and get_numbers_pooltype(
                item) == number_type and \
                item["action"] == action:
            pool_number = get_all_numbers(item)

    logger.debug(f'{pool_number=}')
    assert pool_number is not None, 'No Service Order Item'
    return pool_number


def get_service_order(number_type: str, _payload: dict | list[dict]) -> dict | None:
    """Get the first service orders."""
    if service_orders := get_service_orders(number_type, _payload):
        return service_orders[0]
    return None


def get_service_orders(number_type: str, _payload: dict | list[dict]) -> list[dict]:
    """Get all service orders."""
    if number_type == "mainNumber":
        service_orders = payload.get_items_by_type(_payload, 'ucc.unity.tenant')
    else:  # pool or pool_range
        service_orders = [
            item for item in payload.get_items_by_type(_payload, 'ucc.unity.numbers')
            if type_of_pool_str(item) == number_type]
    return service_orders


def get_all_numbers_expected(context):
    all_numbers_expected = []

    order_source = 'TMF'
    if hasattr(context, 'poolpayload'):
        order_source = 'NM'
    if order_source == 'TMF':
        # if main number is validated, now we have all messages
        # get all order items
        numbers_items = payload.get_items_by_type(context.payload, 'ucc.unity.numbers')
        # get all expected numbers
        all_numbers_expected = get_numbers_list(numbers_items)
        if hasattr(context, 'add_account_validated'):
            context.consumer_payload = remove_main_number_from_consumer_payload(context.consumer_payload,
                                                                                context.main_number)

    elif order_source == 'NM':
        all_numbers_expected = context.E164_List
    logger.debug(f'{all_numbers_expected=}')
    return all_numbers_expected


def get_all_numbers_actual(_payload):
    all_numbers_actual = []
    for message in _payload:
        nums = get_numbers_from_message(message)
        all_numbers_actual.extend(nums)

    logger.debug(f'{all_numbers_actual=}')
    return all_numbers_actual


def get_e164_numbers_from_order_item(order_item: dict) -> list[str]:
    """Get a sorted list of E164 numbers from an order item."""
    all_numbers: list[str] = []  # E164 numbers
    for characteristic in order_item["resource"]["resourceCharacteristic"]:
        if characteristic["name"] == "dep.numbers.geo":
            ranges = characteristic["value"]
            all_numbers.extend(dep_ranges_to_e164_numbers(ranges))
    return sorted(all_numbers)


def dep_ranges_to_e164_numbers(ranges: list[str]) -> list[str]:
    """Convert dep.numbers.geo ranges to E164 numbers.
    
    Each dep.numbers.geo range is a string, either:
      - a single number (without "+")
      - first and last numbers (without "+") sepatated by ":"
    e.g. 441234567890 is a range of 1 number, and 441234567890:441234567895 is
    a range of 6 numbers
    """
    all_numbers: list[str] = []  # E164 numbers

    for rg in ranges:
        if not ":" in rg:
            # single number
            all_numbers.append(e164(rg))
        else:
            logger.debug(f"Range: {rg}")
            try:
                rg_from, rg_to = rg.split(":")
            except ValueError:
                raise Exception(f"Invalid number range: {rg}") from None
            for num in range(int(rg_from), int(rg_to) + 1):
                all_numbers.append(e164(num))

    return sorted(all_numbers)


def e164(value: int | str) -> str:
    """Convert to E164."""
    return f"+{value}" if isinstance(value, int) else "+" + value.removeprefix("+")


def generate_pool_range(quantity, market_code, pool_type=PoolType.Fixed):
    from_number = generate_phone_number(market_code, pool_type)
    return {'from': from_number,
            'to': get_end_range_number(from_number, quantity)}


def update_numbers_order_with_several_ranges(payload: dict, from_number: str, to: str, market_code: str) -> tuple:
    """
Patches payload with additional range.
    :param payload: Service Order payload
    :param from_number: originally generated from number
    :param to: originally generated to number
    :param market_code: market code to generate the same pool. Might be used with different market_code to generate another code
    :return: updated payload and additional range
    """
    pool_range = generate_pool_range(5, market_code, pool_type=PoolType.Mobile)

    return common.create_or_update_key(payload,
                                       '$.serviceOrderItem.[*].service.supportingResource.[*].resourceCharacteristic.[0].value.poolRange',
                                       [pool_range, {'from': from_number, 'to': to}]), pool_range


def mix_numbers(original_pool: list[str],
                market_code: str,
                mixin_pool: list[str] = None,
                mix_new_numbers: bool = False) -> list[str]:
    """
    Replace some numbers from an original list of numbers with numbers from another list and(or) new numbers.
    Numbers will be mixed in roughly equal proportion.
    :param original_pool: Original List of number to which mixins will be ingested
    :param market_code: Market code will be used to generated new numbers if necessary, no validation done
    :param mixin_pool: list of numbers from which some numbers will be picked
    :param mix_new_numbers: True (new numbers will be generated and mixed) OR False;
    :return: List of mixed numbers
    """
    total_numbers_count = len(original_pool)
    new_numbers = generate_pool(total_numbers_count, market_code)
    if mixin_pool and mix_new_numbers:
        proportion = 3
    elif mixin_pool:
        proportion = 2
        new_numbers = []
    elif mix_new_numbers:
        proportion = 2
        mixin_pool = []
    else:
        return original_pool

    mixin_count = total_numbers_count // proportion
    same_numbers_count = total_numbers_count - ((proportion - 1) * mixin_count)
    original_pool = original_pool[:same_numbers_count] + mixin_pool[:mixin_count] + new_numbers[:mixin_count]

    return original_pool
