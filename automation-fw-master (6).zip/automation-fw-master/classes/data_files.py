"""
Data Files

The aim of those data files is to ensure we do not read data from
previous tests. Those data files will never write on source files
from the repo. Instead, they will be written to a temporary 
directory (making it easy to clean-up between test runs).
"""

import json
import logging
import os
from typing import Optional, Any

import yaml

from classes import polling, common

logger = logging.getLogger(__name__)

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
TEST_DATA_DIR = os.path.join(THIS_DIR, "..", "testdata")
PAYLOAD_DATA_DIR = os.path.join(TEST_DATA_DIR, "JSON_Payload")
# Directory to save content of modified files
TMP_DATA_DIR = os.path.join(THIS_DIR, "..", "test_run", "data_files")

FILE_CONFIG = {
    # Only data files with initial data, or requiring clearing between tests, need to be registered
    "OperationStatusEndNotification": {"clear_hook": "after_scenario"},
    #"session": {"clear_hook": "before_all", "initial_data_dir": TEST_DATA_DIR},
}


def read_config(file_path: str, field: Optional[str] = None) -> Any:
    """Read from a READ-ONLY config file.

    :param file_path: relative file path
    :param param: field (supports dotted path)
    :return: data previously saved (or initial data)
    """
    file_path_abs = os.path.join(TEST_DATA_DIR, file_path)
    logger.info(f"Read Data config file: {file_path_abs}")
    with open(file_path_abs, "r") as f:
        if file_path.endswith(".json"):
            data = json.load(f)
        else:
            data = yaml.safe_load(f)

    if field:
        data = common.get_field(data, field)
    logger.debug(f"Config file '{file_path}', {field=}: {json.dumps(data, sort_keys=True)}")
    return data


class DataFile:
    """Class handling one data file.

    Example without initial data:
        From behave:
        >>> df = DataFile("OperationStatusEndNotification")
        >>> data = df.read(timeout=60)  # wait until temporary file exists to read it

        From appdirect_stub:
        >>> df = DataFile("OperationStatusEndNotification")
        >>> df.write(data)  # Write data to temporary file

    Example with initial data:
        From appdirect_stub:
        >>> df = DataFile("AddonChangeLicense", initial_data_dir=PAYLOAD_DATA_DIR)
        >>> data = df.read()  # No temporary file exists: read initial data from ./testdata/JSON_Payload
        >>> modified_data = data | {"extra_key": "extra_value"}
        >>> df.write(modified_data)  # Write new data to temporary file
        >>> modified_data = df.read()  # new data from temporary file exists: reads temporary file
    """
    def __init__(
            self, name: str, ext: str = "json", initial_data_dir: Optional[str] = None,
            clear_hook: Optional[str] = None) -> None:
        """Constructor.

        :param name: file name without extension or path
        :param initial_data_dir: (optional) directory containing file for initial data
        :param clear_hook: when to clear the data
        """
        self.file = f"{name}.{ext}"
        self.clear_hook = clear_hook
        self._tmp_file_path = os.path.join(TMP_DATA_DIR, self.file)
        os.makedirs(TMP_DATA_DIR, exist_ok=True)

        if initial_data_dir:
            # Ensure the file with initial data exists
            self._initial_file_path = os.path.join(initial_data_dir, self.file)
            assert os.path.exists(self._initial_file_path), \
                f"Data file {self._initial_file_path} with initial data should exist"
        else:
            self._initial_file_path = None

    def exists(self) -> bool:
        """Check if data was previously written."""
        return os.path.exists(self._tmp_file_path)
    
    def clear(self) -> None:
        """Clear data previously written."""
        if os.path.exists(self._tmp_file_path):
            logger.info(f"Clear Data File: {self.file}")
            os.remove(self._tmp_file_path)

    def write(self, data: dict) -> None:
        """Write data.

        :param data: any data to save (that can be retrieved with read())
        """
        logger.info(f"Write Data File {self.file} with:\n{data}")
        with open(self._tmp_file_path, "w") as f:
            if self._tmp_file_path.endswith(".json"):
                json.dump(data, f, sort_keys=True, indent=2)
            else:
                yaml.dump(data, f, sort_keys=True, indent=2)

    def read(self, timeout: float = 60) -> dict:
        """Read data saved by this datafile.

        :param timeout: maximum time to wait if the file has not been written yet
        :return: data previously saved
        """
        if os.path.exists(self._tmp_file_path):
            # Use the data file (as it was written at least once before)
            file_path = self._tmp_file_path
        elif self._initial_file_path:
            # Use the file containing the inital data
            file_path = self._initial_file_path
        else:
            # Wait for another process to create the data file
            file_path = self._tmp_file_path
            polling.wait_until(
                lambda: os.path.exists(file_path),
                f"Data File {self.file}",
                timeout=timeout)

        logger.info(f"Read Data File: {file_path}")
        with open(file_path, "r") as f:
            if file_path.endswith(".json"):
                data = json.load(f)
            else:
                data = yaml.safe_load(f)

        return data


def clear_files_hook(hook_name: str) -> None:
    """Clear data files.

    :param hook_name: name of the caller hook
    """

    for data_file in _data_files_registry.values():
        if data_file.clear_hook == hook_name:
            data_file.clear()


def exists(name: str) -> bool:
    """Check whether a file exists (was written at least once).

    :param name: name of the data file
    """
    return _get_from_registry(name).exists()


def clear(name: str) -> None:
    """Clear a file (data previously written).

    :param name: name of the data file
    """
    _get_from_registry(name).clear()


def write(name: str, data: dict) -> None:
    """Write to a data file.

    :param name: name of the data file
    :param data: data to save (must be json serializable)
    """
    _get_from_registry(name).write(data)


def read(name: str, field: Optional[str] = None, timeout: float = 60) -> Any:
    """Read from a data file.

    :param name: name of the data file
    :param param: field (supports dotted path)
    :param timeout: maximum time to wait if the file has not been written yet
    :return: data previously saved (or initial data)
    """
    data = _get_from_registry(name).read(timeout=timeout)
    if field:
        data = common.get_field(data, field)
    logger.debug(f"Data file '{name}', {field=}: {json.dumps(data, sort_keys=True)}")
    return data


def _get_from_registry(name: str) -> DataFile:
    if name not in _data_files_registry:
        logger.info(f"Registered new DataFile '{name}'")
        kwargs = FILE_CONFIG.get(name, {})
        _data_files_registry[name] = DataFile(name, **kwargs)
    return _data_files_registry[name]


_data_files_registry: dict[str, DataFile] = {}  # store all instances created
