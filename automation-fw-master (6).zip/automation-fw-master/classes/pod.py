import logging

from kubernetes import client, config
from kubernetes.client import ApiException

from classes import common

NAMESPACE = common.config.namespace


def list_pods(ns):
    v1 = client.CoreV1Api()
    pods = v1.list_namespaced_pod(namespace=ns)
    if pods:
        return pods


def get_pod_ip(name):
    ip_value = []
    config.load_incluster_config()
    ret = list_pods(NAMESPACE)
    for i in ret.items:
        if i.metadata.name.lower().startswith(name) and i.status.phase.lower() == 'running':
            ip_value.append(i.status.pod_ip)
            logging.info(f"pod name:{i.metadata.name}, ip address:{i.status.pod_ip}")
    return ip_value


def read_logs(pod_name):
    try:
        api_responses = ""
        config.load_incluster_config()
        api_instance = client.CoreV1Api()
        pods = get_pod_names(api_instance, pod_name)
        if len(pods) < 1:
            raise NotImplementedError(f"Please Check if provided pod name {pod_name} is correct")
        for listed_pod in pods:
            api_responses += api_instance.read_namespaced_pod_log(name=listed_pod,
                                                                  namespace=NAMESPACE)
        return api_responses

    except ApiException as e:
        logging.error(str(e))
        raise


def get_pod_name(instance, pod_name):
    try:
        pod_list = instance.list_namespaced_pod(NAMESPACE)
        for pod in pod_list.items:
            if pod.metadata.name.startswith(pod_name):
                return pod.metadata.name
    except KeyError:
        raise f"Not Implemented for {pod_name} pod"


def get_pod_names(instance, pod_name_prefix):
    try:
        response = instance.list_namespaced_pod("middleware")
        pod_names = []
        for pod in response.items:
            if pod.metadata.name.startswith(pod_name_prefix):
                pod_names.append(pod.metadata.name)
        return pod_names
    except ApiException as e:
        logging.error(str(e))
        raise


def filter_logs(pod_name, condition):
    pod_logs = read_logs(pod_name).split('\n')
    logs = []
    for log in pod_logs:
        if condition in log:
            logs.append(log)
    return logs
