import logging

from classes import numbers, read_xmldata

logger = logging.getLogger(__name__)

resource_type_list = {
    "UNITY": {
        "pool": "UccTenantPool",
        "pool_range": "UccTenantPoolRange"
    },
    "MSOC": {
        "pool": "UccMsocNumberPool",
        "pool_range": "UccMsocNumberPoolRange"
    },
    "TPM": {
        "pool": "UccTpmNumberPool",
        "pool_range": "UccTpmNumberPoolRange"
    }
}


def generate_number_item(context, number_item, pool_type, quantity, category="UNITY"):
    resource_type = resource_type_list[category]["pool"]
    if 'pool_range' in pool_type:
        resource_type = resource_type_list[category]["pool_range"]

    if 'pool_range' in pool_type:
        from_range_number = numbers.generate_phone_number(context.market_code)
        to_range_number = read_xmldata.add_range_number(from_range_number, quantity)
        number_item = numbers.append_resource_characteristic(number_item, context.index,
                                                             resource_type=resource_type,
                                                             pool_range_from=from_range_number,
                                                             pool_range_to=to_range_number)

    else:
        context.number_pool_list = context.pool = numbers.generate_pool(quantity, context.market_code)
        number_item = numbers.append_resource_characteristic(number_item, context.index, resource_type=resource_type,
                                                             pool=context.number_pool_list)

    return number_item
