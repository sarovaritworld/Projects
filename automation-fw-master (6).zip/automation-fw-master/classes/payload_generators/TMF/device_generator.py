class DevicePayloadGenerator:
    def __init__(self):
        raise NotImplementedError
