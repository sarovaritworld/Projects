from classes.domain.account import MSOCAccount
from classes.payload_generators.TMF.payload_generator import PayloadGenerator, Action, ServiceOrderItemGenerator
from classes.payload_generators.TMF.service_characteristic_generator import \
    MsocCustomerBillingCountryServiceCharacteristicGenerator, MsocCustomerBillingInfoServiceCharacteristicGenerator


class CountryBillingGenerator(PayloadGenerator):
    category: str = 'msoc'
    service_type: str = 'country-billing'

    def __init__(self, account: MSOCAccount, action: Action, payload: dict = None):
        super().__init__(account, payload)
        country_billing_item = ServiceOrderItemGenerator(self.category, self.service_type)
        country_billing_item.set_action(action)
        country_billing_item.update_service_characteristic(
            MsocCustomerBillingCountryServiceCharacteristicGenerator(account).to_dict())
        country_billing_item.update_service_characteristic(
            MsocCustomerBillingInfoServiceCharacteristicGenerator(account).to_dict())

        self.country_billing_item = country_billing_item

        self.service_order_items.append(self.country_billing_item)
