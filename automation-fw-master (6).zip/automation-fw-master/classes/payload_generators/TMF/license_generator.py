from classes.domain.account import UnityAccount
from classes.license import LicenseOrderItem
from classes.payload_generators.TMF import Action, ServiceOrderItemGenerator
from classes.payload_generators.TMF.payload_generator import PayloadGenerator
from classes.payload_generators.TMF.service_characteristic_generator import UnityLicenseServiceCharacteristicGenerator


class LicensePayloadGenerator(PayloadGenerator):
    category: str = 'unity'
    service_type: str = 'license'
    action: Action
    payload: dict
    requested_licenses: LicenseOrderItem

    def __init__(self, account: UnityAccount, action: Action, requested_licenses: LicenseOrderItem,
                 payload: dict | None = None):
        super().__init__(account, payload)

        license_item = ServiceOrderItemGenerator(self.category, self.service_type)
        license_item.set_action(action)

        license_item.set_supporting_resource({'id': requested_licenses.id})
        license_item.update_service_characteristic(
            UnityLicenseServiceCharacteristicGenerator(requested_licenses).to_dict())

        self.license_item = license_item

        self.service_order_items.append(self.license_item)
