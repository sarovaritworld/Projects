import logging

from classes import read_xmldata
from classes.domain.account import AccountOrderItem, MSOCAccount, TPMAccount, UnityAccount
from classes.payload_generators.TMF.payload_generator import Action, PayloadGenerator, ServiceOrderItemGenerator
from classes.payload_generators.TMF.service_characteristic_generator import \
    ItsmProvisioningServiceCharacteristicGenerator, MsocCustomerContactServiceCharacteristicGenerator, \
    MsocCustomerInfoServiceCharacteristicGenerator, TpmCustomerInfoServiceCharacteristicGenerator, \
    UccTenantAdminInfoServiceCharacteristicGenerator, UccTenantFlowSettingsServiceCharacteristicGenerator, \
    UccTenantInfoServiceCharacteristicGenerator, UccTenantTenantPoliciesServiceCharacteristicGenerator, \
    UccTenantConfigServiceCharacteristicGenerator

logger = logging.getLogger(__name__)


class PlaceGenerator:
    def __init__(self, account: UnityAccount | MSOCAccount):
        place = read_xmldata.read_jsonfile("item_models/place")
        place["postcode"] = account.place.postcode
        place["country"] = account.place.country_code
        place["city"] = account.place.city
        place["streetNr"] = account.place.street_nr
        place["streetName"] = account.place.street_name
        self.place = place

    def to_dict(self) -> dict:
        return self.place


class AccountPayloadGenerator(PayloadGenerator):
    """ Generates the basic account request payload: fills market_code related fields and action
    If payload is passed, it will be added to the existing payload """
    service_type: str = None
    category: str = None

    def __init__(self, account: AccountOrderItem, action: Action, payload: dict | None = None):
        super().__init__(account, payload)
        self.account_item = None
        self.generate_account_item(account, action)

    def generate_account_item(self, account: AccountOrderItem, action: Action):
        account_item = ServiceOrderItemGenerator(self.category, self.service_type)
        account_item.set_action(action)
        self.account_item = account_item


class UnityAccountPayloadGenerator(AccountPayloadGenerator):
    """ Holds Unity specific properties and changes the payload with Unity specific fields """
    category = 'unity'
    service_type = 'tenant'

    def __init__(self, unity_account: UnityAccount, action: Action, payload=None):
        super().__init__(unity_account, action, payload)
        if action == Action.add:
            self._add_account_generator(unity_account)
        elif action == Action.modify:
            self._modify_account_generator(unity_account)
        self.service_order_items.append(self.account_item)

    def _add_account_generator(self, unity_account):
        self.account_item.set_place(PlaceGenerator(unity_account).to_dict())
        self.account_item.update_service_characteristic(
            UccTenantInfoServiceCharacteristicGenerator(unity_account).to_dict())
        self.account_item.update_service_characteristic(
            UccTenantAdminInfoServiceCharacteristicGenerator(unity_account).to_dict())
        self.account_item.update_service_characteristic(
            UccTenantFlowSettingsServiceCharacteristicGenerator(unity_account).to_dict())
        if unity_account.policies and unity_account.policies.enabled:
            self.account_item.update_service_characteristic(
                UccTenantTenantPoliciesServiceCharacteristicGenerator(unity_account).to_dict())

    def _modify_account_generator(self, unity_account):
        if unity_account.idp_entity_id is not None:
            self.account_item.update_service_characteristic(
                UccTenantConfigServiceCharacteristicGenerator(unity_account).to_dict())


class MSOCAccountPayloadGenerator(AccountPayloadGenerator):
    """ Holds MSOC specific properties and changes the payload with MSOC specific fields """

    category = 'msoc'
    service_type = 'customer'

    def __init__(self, msoc_account: MSOCAccount, action: Action, payload=None):
        super().__init__(msoc_account, action, payload)
        if 'delete' not in action:
            self.account_item.set_place(PlaceGenerator(msoc_account).to_dict())
            self.account_item.update_service_characteristic(
                MsocCustomerInfoServiceCharacteristicGenerator(msoc_account).to_dict())
            self.account_item.update_service_characteristic(
                MsocCustomerContactServiceCharacteristicGenerator(msoc_account).to_dict())
            if msoc_account.itsm_provisioning is not None:
                self.account_item.update_service_characteristic(
                    ItsmProvisioningServiceCharacteristicGenerator(msoc_account).to_dict())
        self.service_order_items.append(self.account_item)


class TPMAccountPayloadGenerator(AccountPayloadGenerator):
    category = 'tpm'
    service_type = 'customer'

    def __init__(self, tpm_account: TPMAccount, action: Action, payload=None):
        super().__init__(tpm_account, action, payload)
        if 'delete' not in action:
            self.account_item.update_service_characteristic(
                TpmCustomerInfoServiceCharacteristicGenerator(tpm_account).to_dict())
            if tpm_account.itsm_provisioning is not None:
                self.account_item.update_service_characteristic(
                    ItsmProvisioningServiceCharacteristicGenerator(tpm_account).to_dict())
        self.service_order_items.append(self.account_item)
