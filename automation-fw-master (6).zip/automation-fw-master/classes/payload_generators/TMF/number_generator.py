import logging

from classes import numbers, read_xmldata
from classes.domain.account import AccountOrderItem
from classes.domain.numbers import NumbersOrderItem
from classes.payload_generators.TMF.payload_generator import Action, PayloadGenerator, ServiceOrderItemGenerator

logger = logging.getLogger(__name__)


class ResourceCharacteristicGenerator:
    def __init__(self, resource_characteristic, requested_numbers):
        resource_characteristic['value']['@type'] = requested_numbers.resource_type.value
        resource_characteristic['value']['poolType'] = requested_numbers.pool_type.name
        if requested_numbers.carrier_id:
            resource_characteristic['value']['carrierId'] = requested_numbers.carrier_id
        if requested_numbers.resource_type.is_pool():
            resource_characteristic['value']['pool'] = requested_numbers.pool
        elif requested_numbers.resource_type.is_range():
            resource_characteristic['value']['poolRange'] = [
                {"from": requested_numbers.from_range_number, "to": requested_numbers.to_range_number}]
            requested_numbers.pool = numbers.get_pool_range(requested_numbers.from_range_number,
                                                            requested_numbers.to_range_number)
        if getattr(requested_numbers, 'country', None) and getattr(requested_numbers, 'provider', None):
            resource_characteristic['value']['country'] = requested_numbers.country
            resource_characteristic['value']['provider'] = requested_numbers.provider
        self.resource_characteristic = resource_characteristic

    def to_dict(self):
        return self.resource_characteristic


class SupportingResourceGenerator:
    def __init__(self, resource_characteristic, requested_numbers):
        supporting_resource = read_xmldata.read_jsonfile("item_models/supportingResource")
        supporting_resource['resourceCharacteristic'].append(
            ResourceCharacteristicGenerator(resource_characteristic, requested_numbers).to_dict())
        self.supporting_resource = supporting_resource

    def to_dict(self):
        return self.supporting_resource


class NumbersPayloadGenerator(PayloadGenerator):
    """ Number Generator
    Generates a payload with number service order item and appends it to the payload
    Usage: you need to pass objects (<category>Account) and (NumbersOrderItem)

    Examples:
        >>> account = UnityAccount(op_co_customer_id=context.op_co_customer_id)

        >>> requested_numbers = UnityNumbers(quantity=5,
        >>>                                           resource_type=UnityResourceType.pool_range,
        >>>                                           pool_type=PoolType.Presentation)
        >>> context.payload = NumbersPayloadGenerator(account=account,
        >>>                                         requested_numbers=requested_numbers,
        >>>                                         action=Action.add,
        >>>                                         payload=context.payload).to_dict()
    """
    action: Action
    payload: dict
    resource_characteristic: dict
    service_type = 'numbers'
    requested_numbers: NumbersOrderItem

    def __init__(self, account: AccountOrderItem, requested_numbers: NumbersOrderItem, action: Action,
                 payload: dict | None = None):
        super().__init__(account, payload)
        self.resource_characteristic = read_xmldata.read_jsonfile(
            f"item_models/resourceCharacteristic/{account.category}")

        numbers_item = ServiceOrderItemGenerator(account.category, self.service_type)
        numbers_item.set_action(action)

        if getattr(requested_numbers, "provider", None) is not None:
            self.generate_numbers(requested_numbers.provider, requested_numbers)
        else:
            self.generate_numbers(account.market_code, requested_numbers)
        logger.info(f'{requested_numbers.pool=}')
        numbers_item.set_supporting_resource(
            SupportingResourceGenerator(self.resource_characteristic, requested_numbers).to_dict())
        self.numbers_item = numbers_item
        self.service_order_items.append(numbers_item)

    @staticmethod
    def generate_numbers(market_code: str,
                         requested_numbers: NumbersOrderItem):

        if requested_numbers.resource_type.is_range():
            if not requested_numbers.from_range_number:
                requested_numbers.from_range_number = numbers.generate_phone_number(market_code,
                                                                                    requested_numbers.pool_type)
            requested_numbers.to_range_number = numbers.get_end_range_number(
                requested_numbers.from_range_number,
                requested_numbers.quantity)
        elif requested_numbers.resource_type.is_pool() and not requested_numbers.pool:
            requested_numbers.pool = numbers.generate_pool(requested_numbers.quantity, market_code,
                                                           requested_numbers.pool_type)
