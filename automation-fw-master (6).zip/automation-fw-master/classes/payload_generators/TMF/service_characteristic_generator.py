from classes import read_xmldata
from classes.domain.account import MSOCAccount, TPMAccount, UnityAccount
from classes.license import LicenseOrderItem


class BaseServiceCharacteristicGenerator:
    service_characteristic_type = None

    def __init__(self, order_item: UnityAccount | MSOCAccount | TPMAccount | LicenseOrderItem):
        self.order_item = order_item
        self.service_characteristic = read_xmldata.read_jsonfile(
            f"item_models/serviceCharacteristic/{self.service_characteristic_type}")
        self.__update_value__()

    def __update_value__(self):
        # called in the every child method
        pass

    def to_dict(self):
        return self.service_characteristic


class UnityLicenseBaseServiceCharacteristicGenerator(BaseServiceCharacteristicGenerator):
    service_characteristic_type = None
    account: LicenseOrderItem

    def __init__(self, order_item: LicenseOrderItem):
        self.requested_licenses = order_item
        super().__init__(order_item)


class AccountBaseServiceCharacteristicGenerator(BaseServiceCharacteristicGenerator):
    service_characteristic_type = None
    account: UnityAccount | MSOCAccount | TPMAccount

    def __init__(self, order_item: UnityAccount | MSOCAccount | TPMAccount):
        self.account = order_item
        super().__init__(order_item)


class UnityBaseServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = None
    account: UnityAccount


class MSOCBaseServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = None
    account: MSOCAccount


class TpmBaseServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = None
    account: TPMAccount


class UccTenantInfoServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'UccTenantInfo'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "mainNumber": self.account.main_number,
            "faxNumber": self.account.fax_number,
            "profile": self.account.product_type,
            "currency": self.account.currency,
            "billingAccountNumber": self.account.billing_account_number,
            "billingServiceReference": self.account.billing_service_reference,
            "opportunityId": self.account.opportunity_id,
            "name": 'Test_Automation'
        })


class UccTenantAdminInfoServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'UccTenantAdminInfo'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "email": self.account.contact.email,
            "phoneNumber": self.account.mobile
        })
        if self.account.contact.extension:
            self.service_characteristic["value"].update({
                "extension": self.account.contact.extension
            })

class UccTenantFlowSettingsServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'UccTenantFlowSettings'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "activateImmediately": self.account.activate_immediately,
            "sendWelcomeEmail": self.account.send_welcome_email,
            "sendConfirmationEmail": self.account.send_confirmation_email
        })


class UccTenantTenantPoliciesServiceCharacteristicGenerator(UnityBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'UccTenantPolicies'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "@type": self.service_characteristic_type,
            "enabled": self.account.policies.enabled,
        })
        if self.account.policies.geo_locations:
            self.service_characteristic["value"].update({
                "geoLocations": self.account.policies.geo_locations
            })
        if self.account.policies.ips:
            self.service_characteristic["value"].update({
                "ips": self.account.policies.ips
            })


class UccTenantConfigServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'UccTenantConfig'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "@type": self.service_characteristic_type,
            "idpEntityId": self.account.idp_entity_id,
        })


class MsocCustomerInfoServiceCharacteristicGenerator(MSOCBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'MsocCustomerInfo'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "name": 'Test_Automation',
            "tenantId": self.account.tenant_id,
            "consentCountries": self.account.consent_countries,
            "customerDomains": self.account.customer_domains
        })


class MsocCustomerContactServiceCharacteristicGenerator(MSOCBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'MsocCustomerContact'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "email": self.account.contact.email
        })


class MsocCustomerBillingCountryServiceCharacteristicGenerator(MSOCBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'MsocCustomerBillingCountry'

    def __update_value__(self):
        self.service_characteristic["value"] = self.account.place.country_code


class MsocCustomerBillingInfoServiceCharacteristicGenerator(MSOCBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'MsocCustomerBillingInfo'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "serviceIdentifier": self.account.billing_info.service_identifier,
            "customerReferenceNumber": self.account.billing_info.customer_reference_number
        })


class ItsmProvisioningServiceCharacteristicGenerator(AccountBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'ItsmProvisioning'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "enableProvisioning": self.account.itsm_provisioning.enable_provisioning,
            "contractStartDate": self.account.itsm_provisioning.contract_start_date,
            "contractEndDate": self.account.itsm_provisioning.contract_end_date
        })
        if self.account.itsm_provisioning.local_market_service_id is not None:
            self.service_characteristic["value"].update({
                "localMarketServiceId": self.account.itsm_provisioning.local_market_service_id
            })
        if self.account.itsm_provisioning.link_service_to_fully_onboarded_customer is not None:
            self.service_characteristic["value"].update({
                "linkServiceToFullyOnboardedCustomer": self.account.itsm_provisioning.link_service_to_fully_onboarded_customer
            })


class TPMItsmProvisioningServiceCharacteristicGenerator(TpmBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'ItsmProvisioning'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "enableProvisioning": self.account.itsm_provisioning.enable_provisioning,
            "contractStartDate": self.account.itsm_provisioning.contract_start_date,
            "contractEndDate": self.account.itsm_provisioning.contract_end_date
        })


class TpmCustomerInfoServiceCharacteristicGenerator(TpmBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'TpmCustomerInfo'

    def __update_value__(self):
        self.service_characteristic["value"].update({
            "name": self.account.name,
            "tenantId": self.account.tenant_id,
        })


class UnityLicenseServiceCharacteristicGenerator(UnityLicenseBaseServiceCharacteristicGenerator):
    service_characteristic_type = 'UnityLicense'

    def __update_value__(self):
        self.service_characteristic["value"] = int(self.requested_licenses.quantity)
