import logging
from enum import StrEnum
from typing import Dict

from classes import read_xmldata, utils
from classes.domain.account import AccountOrderItem

logger = logging.getLogger(__name__)


class Action(StrEnum):
    add = 'add'
    delete = 'delete'
    modify = 'modify'

    def to_upper(self):
        return self.name.upper()


class ServiceOrderItemGenerator:
    def __init__(self, category: str, service_type: str):
        order_item = read_xmldata.read_jsonfile("item_models/order_item")
        order_item['service']['serviceType'] = self.compose_service_type(category, service_type)
        self.order_item = order_item

    def set_action(self, action: Action):
        self.order_item['action'] = action.name

    def set_place(self, place: dict):
        self.order_item['service']['place'] = [place]

    def update_service_characteristic(self, service_characteristic: dict):
        self.order_item['service'].setdefault('serviceCharacteristic', []).append(service_characteristic)

    def set_supporting_resource(self, supporting_resource: dict):
        self.order_item['service']['supportingResource'] = [supporting_resource]

    def to_dict(self) -> dict:
        return self.order_item

    @staticmethod
    def compose_service_type(category: str, service_type: str):
        """ Appends 'ucc' to the category and service type
        :param category: unity or msoc
        :param service_type: tenant, numbers
        :return: service type like 'ucc.msoc.numbers'
        """
        return f'ucc.{category}.{service_type}'


class BasicPayloadGenerator:
    def __init__(self, account: AccountOrderItem):
        payload = read_xmldata.read_jsonfile("item_models/order_base")
        payload['externalId'] = account.external_id = read_xmldata.gen_uuid()
        payload['category'] = account.category.upper()
        payload['requestedStartDate'] = read_xmldata.get_current_datetime("%Y-%m-%dT%H:%M:%SZ")
        self.payload = payload

    def to_dict(self):
        return self.payload


class RelatedPartyGenerator:
    def __init__(self, account: AccountOrderItem):
        related_party = read_xmldata.read_jsonfile("item_models/relatedParty")
        related_party["id"] = account.market_code
        related_party["marketCode"] = account.market_code
        related_party["countryCode"] = account.related_party.country_code
        self.related_party = related_party

    def to_dict(self):
        return self.related_party


class PayloadGenerator:
    """ Generates basic service order payload without any service order items
    to_dict() method parses the payload and refreshes all ids and subids for number items
    and prints the payload in formatted json in debug mode
    """
    payload: Dict
    account: AccountOrderItem
    service_order_items: list = []

    def __init__(self, account: AccountOrderItem, payload: dict | None):
        if payload is None:
            payload = BasicPayloadGenerator(account).to_dict()
            payload["relatedParty"].append(RelatedPartyGenerator(account).to_dict())
            payload["externalReference"][0]["id"] = account.op_co_customer_id

        self.payload = payload
        self.service_order_items = self.payload['serviceOrderItem']

    def to_dict(self):
        """
refreshes all ids in the payload, logs the payload in debug mode and prints it
        :return:
        """
        self.payload['serviceOrderItem'] = [item if isinstance(item, dict) else item.to_dict() for item in
                                            self.service_order_items]
        self.refresh_ids()
        logger.info(f'generated payload: {utils.to_json(self.payload)})')
        return self.payload

    def refresh_ids(self):
        """
    Takes payload with service orders and refreshes the ids, making them ordered.
    Special case for ucc.unity.numbers and ucc.msoc.numbers serviceType: it has x.y numeration
        """

        for i, item in enumerate(self.payload["serviceOrderItem"]):
            self.payload["serviceOrderItem"][i]["id"] = i + 1
            if 'numbers' in item["service"]["serviceType"]:
                for l, sub_item in enumerate(item["service"]["supportingResource"]):
                    sub_item["id"] = f"{i + 1}.{l + 1}"
        logger.debug('refreshed ids in the payload')
        logger.debug(utils.to_json(self.payload))
