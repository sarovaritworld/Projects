import json
import logging
import os
from typing import Dict

from bson import ObjectId
from bson import json_util

from classes import asserts, common, database, polling
from classes.data_factory import countries_data_manager
from classes.utils import to_json

logger = logging.getLogger(__name__)

DB_URL_MIDDLEWARE = os.environ.get("DB_URL_TMF_NOTIFICATION")
DB_SECRET_NAME_MIDDLEWARE = 'documentDb'
SECRET_FILE = 'tmfnotification.json'

tlsCAFile = '/etc/ssl/certs/rds-combined-ca-bundle.pem'
tls = True
retryWrites = False

from common_python.database import Database


def open_database(database: str, collection: str) -> Database:
    return Database(
        SECRET_FILE, DB_URL_MIDDLEWARE, database, collection)


# TODO: rename function
def create_db_connection(marketplace_event_id):
    with database.open_database('account-management', 'orders') as db:
        return db.get_first_document('marketplaceEventId', marketplace_event_id)


def get_shipping_records(marketplace_event_id):
    with database.open_database('account-management', 'shippingAddresses') as db:
        return db.get_first_document('marketplaceEventId', marketplace_event_id)


def get_uid_nummgnt(UUID):
    with database.open_database('number-management-api', 'InterstitialPool') as db:
        return db.get_first_document('opStatusUuid', UUID)


def get_notification_collection(search_field, search_value):
    with database.open_database('tmf-svc-order-gw-api', 'serviceorder_listener') as db:
        return db.get_documents(search_field, search_value)


def validate_service_inventory_request(tenant_id, country_code, fully_onboarded_customer=None,
                                       op_co_customer_id: str = None):
    with database.open_database('automation-fw', 'snow-gateway') as db:
        document = db.collection.find_one({'serviceCharacteristic.0.value': tenant_id})
        logger.info(f'snow document {document}')
        asserts.equals(common.get_field(document, 'headers.x-country-code'), country_code,
                       'country code from headers')
        if fully_onboarded_customer:
            asserts.equals(common.get_field(document, 'relatedParty.0.id'), op_co_customer_id,
                           'id field for fully onboarded customer')


def validate_service_inventory_request_for_tpm(bgid, lmsid, link_service_to_fully_onboarded_customer=None,
                                       op_co_customer_id: str = None):
    with database.open_database('automation-fw', 'snow-gateway') as db:
        document = db.collection.find_one({'serviceCharacteristic.1.value': bgid})
        logger.info(f'snow document {document}')
        asserts.equals(common.get_field(document, 'serviceCharacteristic.2.value'), lmsid,
                       'lmsid from service characteristic')
        if link_service_to_fully_onboarded_customer:
            asserts.equals(common.get_field(document, 'relatedParty.0.id'), op_co_customer_id,
                           'id field for fully onboarded customer')


def get_listener_document(subscription_id):
    objInstance = ObjectId(subscription_id)
    get_notification_collection('_id', objInstance)


def get_crf_document_by_marketplace_event(marketplace_event_id: str) -> dict | None:
    with open_database('crf-gateway', 'crf_requests') as db:
        return db.get_first_document('initialCrfRequest.clientReferences.marketplace_event_id', marketplace_event_id)


def get_crf_document(middleware_correlation_id):
    with open_database('crf-gateway', 'crf_requests') as db:
        return db.get_first_document('correlationId', middleware_correlation_id)


def get_crf_parent_requests_document(event_id):
    with open_database('crf-gateway', 'crf_parent_requests') as db:
        return db.get_first_document('eventId', event_id)


def get_crf_document_by_resource_id(resource_order_id):
    with open_database('crf-gateway', 'crf_requests') as db:
        return db.get_first_document('crfOrderInfo.order._id', resource_order_id)


def get_all_crf_documents(middleware_correlation_id):
    with open_database('crf-gateway', 'crf_requests') as db:
        return db.get_documents('correlationId', middleware_correlation_id)


def get_snow_gw_document(op_co_customer_id):
    with database.open_database('snow-gateway', 'snow_onboarding') as db:
        return db.get_first_document('vodafoneId', op_co_customer_id)


def get_all_callback_calls(crf_request_id):
    logging.info(f'{crf_request_id=}')
    with open_database('automation-fw', 'crf_callbacks') as db:
        callbacks_requests = db.get_documents('resource_id', crf_request_id)
        return callbacks_requests


def get_listener_status():
    status = False
    with open_database("crf-gateway", "crf_listeners") as db:
        document = db.get_first_document('active', True)
        if document:
            status = True
        return status


def get_operation_id_by_service_order_operation(operation, service_order_id):
    with database.open_database("tmf-mediator", "service_order_operation") as db:
        document = polling.wait_until(
            lambda: db.collection.find_one({"serviceOrderId": service_order_id, "operation": operation}),
            'tmf mediator document')
        return str(document['_id'])


def parse_json(raw_data):
    """
    Changes the DB returned json to pretty json format
    Please don't consider this for any operation on the DB output
    It changes the keys in the json. Use only for printing the output
    """
    json_data = json.loads(json_util.dumps(raw_data))
    return json.dumps(json_data, indent=3)


class UserNotFoundInIdMapper(Exception):
    pass


def get_rc_user_id(vodafone_user_id):
    logging.info(f"Searching users details filtering by vodafoneUserId: {vodafone_user_id}")
    with open_database('id-mapper-api', 'Users') as db:
        return db.get_first_document('vodafoneUserId', vodafone_user_id)


def get_unity_accounts_count(market):
    try:
        with database.open_database("id-mapper-api", "OperatingCompany") as db:
            query = {'market': market, 'isDeleted': {"$ne": True}}
            unity_accounts_count = db.collection.count_documents(query)
            logging.info(f"{unity_accounts_count=}")
            return unity_accounts_count
    except Exception:
        logging.error(f"Exception while getting the unity account by market")
        raise


def get_number_management_all_batches(rc_id):
    with database.open_database('number-management-api', 'InterstitialPool') as db:
        return db.get_documents('ringcentralId', rc_id)


def get_msoc_customer_documents(market_code, billing_info=None, with_cac=None) -> Dict | None:
    if billing_info:
        country_code = countries_data_manager.get_country_code(market_code)
        search_filter = {
            f"countryBillingInformation.{country_code}": {"$exists": True},
            'market': market_code
        }
    else:
        search_filter = {
            'name': 'Test Automation MSOC Customer',
            "countryBillingInformation": {"$exists": False},
            'market': market_code
        }

    if with_cac is not None:
        search_filter["cacId"] = {'$exists': with_cac}
    logging.info(f"ID mapper {search_filter=}")
    return get_msoc_account_document(search_filter)


def get_msoc_customer_with_vodafone_id(prefix):
    search_filter = {"vodafoneId": {"$regex": f"^{prefix}"}, 'cacId': {'$exists': True}}
    return get_msoc_account_document(search_filter)


def get_cac_configuration_request(cac_id, state, op_co_customer_id, margin_in=None) -> dict:
    query = {"cacId": cac_id, "opCoAccountId": op_co_customer_id, "state": state}
    if margin_in:
        query.update({"cacConfiguration.marginIn": int(margin_in)})
    with database.open_database('crf-gateway', 'cac_configuration_request') as db:
        logger.info(query)
        document = polling.wait_until(
            lambda: db.collection.find_one(query),
            f'cac_configuration_request document with {state=}',
        )
    logging.info(f"cac_configuration_request is in state {state}: {to_json(document)}")
    return document


def get_service_order_operation(service_order_id, operation, state: str | None = None, timeout=60) -> dict:
    query = {"serviceOrderId": service_order_id, "operation": operation}
    if state:
        query["state"] = state
    with database.open_database('tmf-mediator', 'service_order_operation') as db:
        document = polling.wait_until(
            lambda: db.collection.find_one(query),
            f"service_order_operation document for {operation=}" + (f" and {state=}" if state else ""),
            timeout=timeout)
    logging.info(f"service_order_operation is in state {document['state']}: {document}")
    return document


def get_service_order_operations(service_order_id) -> list:
    query = {"serviceOrderId": service_order_id}

    with database.open_database('tmf-mediator', 'service_order_operation') as db:
        documents = polling.wait_until(
            lambda: db.collection.find(query),
            "service_order_operation document")
        return list(documents)


def get_msoc_document_by_customer_id(customer_id):
    return get_msoc_account_document({"vodafoneId": customer_id})


def get_msoc_account_document(query) -> dict:
    """
    Get first matching MSOC Account from database
    :param query:
    :return:
    """
    with open_database("id-mapper-api", "MsocCustomer") as db:
        doc = db.collection.find_one(query)
    logging.info(f"ID mapper MSOC customer: {to_json(doc) if doc else None}")
    return doc


def get_tpm_account_documents(query) -> list:
    """
    Get a list of matching TPM Accounts from database
    :param query:
    :return:
    """
    with open_database("id-mapper-api", "TpmCustomer") as db:
        documents = list(db.collection.find(query))
    return documents


def get_tpm_account_document(query) -> dict:
    """
    Get first matching TPM Account from database
    :param query:
    :return:
    """
    with open_database("id-mapper-api", "TpmCustomer") as db:
        doc = db.collection.find_one(query)
    return doc


def get_unity_account_document(query) -> dict:
    """
    Get first matching UNITY Account from database
    :param query:
    :return:
    """
    with open_database("id-mapper-api", "OperatingCompany") as db:
        doc = db.collection.find_one(query)
    return doc


def get_service_order_with_start_date(service_order_id) -> dict:
    with open_database("tmf-svc-order-gw-api", "serviceorder") as db:
        logger.info(f"Querying Service order with {service_order_id}")
        document = polling.wait_until(lambda: db.collection.find_one(ObjectId(service_order_id)),
                                      'Service Order Document')
    if document['state'] == "IN_PROGRESS" and not document.get('startDate'):
        raise ValueError("StartDate must have a value when state is 'inProgress' ")
    logger.info(f"service_order is in state {document['state']}: {document}")
    return document


def get_any_msoc_customer_id(market: str = "VFUK") -> str:
    document = get_msoc_account_document({"market": market})
    return document["vodafoneId"]


def get_any_tpm_customer_id(market: str = "VFUK") -> str:
    document = get_tpm_account_document({"market": market})
    return document["vodafoneId"]


def get_any_unity_customer_id(market: str = "VFUK") -> str:
    document = get_unity_account_document({"market": market})
    return document["vodafoneId"]


def get_any_customer_id(category: str, market: str) -> str:
    """
    Finds any record in Database for respective customer type and market and returns vodafoneId
    :param category: UNITY, TPM or MSOC
    :param market: Market Code
    :return: Vodafone ID
    """
    match category:
        case "UNITY":
            return get_any_unity_customer_id(market)
        case "MSOC":
            return get_any_msoc_customer_id(market)
        case "TPM":
            return get_any_tpm_customer_id(market)
        case _:
            raise NotImplementedError(f"No handling for {category=}")


def validate_operation_not_exists(operation, service_order_id):
    with database.open_database("tmf-mediator", "service_order_operation") as db:
        document = db.collection.find_one({"serviceOrderId": service_order_id, "operation": operation})
        assert document is None, 'Found the document'
