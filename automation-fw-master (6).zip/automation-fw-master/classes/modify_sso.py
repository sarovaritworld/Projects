class ModifySSOMilestone:
    def __init__(self):
        self.description: str = "SET_SSO_CONFIG:COMPLETED"
        self.status: str = "COMPLETED"
        self.message: str = "SSO Configuration modified for RINGCENTRAL account"