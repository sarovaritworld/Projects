import logging

from classes import database, polling
from classes.utils import to_json
from models.tmf_gateway_api import Error, Milestone

logger = logging.getLogger(__name__)


class SNOWMilestone(Milestone):
    message: str = "Customer service created in SNOW"
    description: str = "SNOW_ONBOARDING:COMPLETED"
    status: str = 'COMPLETED'


class SNOWOffboardingMilestone(Milestone):
    def __init__(self, ucas_provider: str, op_co_customer_id: str, market_code: str):
        super().__init__(ucas_provider=ucas_provider, op_co_customer_id=op_co_customer_id, market_code=market_code)
        self.message = f"Ceased in SNOW the {ucas_provider} account {op_co_customer_id} in market {market_code}"
        self.description = "SNOW_OFFBOARDING:COMPLETED"
        self.status = 'COMPLETED'


class SNOWError(Error):
    code: str = "SERVICE_PROVIDER_ERROR"
    reason: str = "Failed to onboard the customer in SNOW"


class SNOWAPIError(Error):
    code: str = "SERVICE_PROVIDER_ERROR"
    reason: str = "SNOW API not available"


def check_snow_onboarding_state(state, op_co_customer_id):
    document = polling.wait_until(
        lambda: database.get_snow_gw_document(op_co_customer_id),
        'SNOW GW onboarding document',
        stop_when=lambda doc: not doc if state == 'DELETED' else doc and doc['state'] == state)
    logger.info(f"Validate the Document: {to_json(document)}")
