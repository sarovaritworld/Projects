import copy
import json
import logging
import random
from datetime import datetime
from typing import Any

from classes import cac, common, numbers, read_xmldata
from classes.data_factory import countries_data_manager
from classes.exceptions import NoSuchElementError
from classes.utils import to_json

logger = logging.getLogger(__name__)

# we can skip using xml data
companyName = read_xmldata.readxml("companyName", "appdirect_inputdata", "AppdirectUI")

# we put the same values into the original payload, so I don't think we should read them from file.
OPCO_BAN = read_xmldata.readxml("opco_billing_account_num", "appdirect_inputdata", "AppdirectUI")
OPCO_BSR = read_xmldata.readxml("opco_billing_ref", "appdirect_inputdata", "AppdirectUI")
OPCO_OR = read_xmldata.readxml("opco_order_reference_id", "appdirect_inputdata", "AppdirectUI")
OPCO_OI = read_xmldata.readxml("opco_opportunity_id", "appdirect_inputdata", "AppdirectUI")
firstName = read_xmldata.readxml("first_name", "appdirect_inputdata", "AppdirectUI")
lastName = read_xmldata.readxml("last_name", "appdirect_inputdata", "AppdirectUI")
streetNr = read_xmldata.readxml("streetNr", "appdirect_inputdata", "AppdirectUI")
streetName = read_xmldata.readxml("address_line_1", "appdirect_inputdata", "AppdirectUI")
# unpleasant workaround for backward compatibility
streetName_2 = read_xmldata.readxml("address_line_2", "appdirect_inputdata", "AppdirectUI")

role = read_xmldata.readxml("role", "appdirect_inputdata", "AppdirectUI")
service_order_item_id = read_xmldata.readxml("service_order_item_id", "appdirect_inputdata", "AppdirectUI")

customerName = read_xmldata.readxml("customerName", "appdirect_inputdata", "AppdirectUI")

sku_id = "LC_DL-UNL_50"

profile_package = {"FULL_STACK_ENTRY": {"GBP": "1136", "EUR": "1137"},
                   "FULL_STACK_STANDARD": {"GBP": "1118", "EUR": "1120"},
                   "FULL_STACK_PREMIUM": {"GBP": "1124", "EUR": "1126"},
                   "VOICE_ONLY_STANDARD": {"GBP": "1119", "EUR": "1121"},
                   "VOICE_ONLY_PREMIUM": {"GBP": "1125", "EUR": "1127"},
                   "OVERLAY_STANDARD": {"EUR": "1151005"},
                   "OVERLAY_PREMIUM": {"EUR": "1152005"}}

tenant_flow_settings = ('activateImmediately',
                        'sendWelcomeEmail',
                        'sendConfirmationEmail')


def get_last_id(payload):
    return len(payload["serviceOrderItem"])


def compose_service_order(context, item=None):
    if hasattr(context, "payload"):
        return context.payload
    else:
        _payload = read_xmldata.read_jsonfile("item_models/service_order")

        if not hasattr(context, 'external_id'):
            # generate randoms, related to organization
            context.external_id = read_xmldata.gen_uuid()
        _payload["externalId"] = context.external_id
        _payload["requestedStartDate"] = context.start_time = read_xmldata.get_current_datetime("%Y-%m-%dT%H:%M:%SZ")

        if not hasattr(context, "market_code"):
            logging.info(f"context doesn't have market_code saved, saving default value VFUK")
            context.market_code = "VFUK"
        context.country_code = countries_data_manager.get_country_code(context.market_code)
        context.postcode = countries_data_manager.get_postcode(context.market_code)
        context.city = countries_data_manager.get_city(context.market_code)

        _payload["relatedParty"][0]["id"] = context.market_code
        _payload["relatedParty"][0]["marketCode"] = context.market_code
        _payload["relatedParty"][0]["countryCode"] = context.country_code
        _payload["relatedParty"][0]["postcode"] = context.postcode
        _payload["relatedParty"][0]["city"] = context.city

        if not getattr(context, 'op_co_customer_id', None):
            if item == 'cats':
                context.op_co_customer_id = "RETRY_429_" + str(read_xmldata.gen_opco(marketplace="TMF"))
            elif item == 'bats':
                context.op_co_customer_id = "RETRY_500_" + str(read_xmldata.gen_opco(marketplace="TMF"))
            else:
                context.op_co_customer_id = read_xmldata.gen_opco(marketplace="TMF")

        _payload["externalReference"][0]["id"] = context.op_co_customer_id
        return _payload


def append_item_to_payload(context, item, action):
    """
Adds service order item to payload
    :param context: sending context in order to check if payload already has been created
    :param item: type of item to add
    :param action: action for item
    :return: payload with added item
    """
    # if there is no payload in the context, create a base one
    _payload = compose_service_order(context, item=item)

    # read json model
    item_json = read_xmldata.read_jsonfile(f"item_models/{item}")
    # calculate last id
    item_id = get_last_id(_payload)
    item_json["id"] = item_id + 1
    item_json["action"] = action
    # add model to payload
    _payload["serviceOrderItem"].append(item_json)

    # update context.service_order list
    context.service_order = _payload["serviceOrderItem"]

    return _payload


def get_item_by_type(payload, service_type):
    logging.info(f'{payload=}')
    logging.info(' ')
    # we can consume 2 different payloads now
    if type(payload) is dict and 'serviceOrderItem' in payload.keys():
        logging.debug('contains high level payload with serviceOrderItem')
        payload = payload['serviceOrderItem']
    for index, item in enumerate(payload):
        logging.debug(index, item)
        if item['service']['serviceType'] == service_type:
            logging.debug(f'item found: {item}, with index {index}')
            return index, item
    logging.debug(f'{service_type} is not found!')
    return 0, None


def get_item_by_type_and_action(payload, service_type, action):
    # we can consume 2 different payloads now
    if type(payload) is dict and 'serviceOrderItem' in payload.keys():
        logging.debug('contains high level payload with serviceOrderItem')
        payload = payload['serviceOrderItem']
    for item in payload:
        if item['service']['serviceType'] == service_type:
            if item['action'] == action:
                return item
    logging.debug(f'{service_type} and {action} is not found!')
    return None


def get_items_by_type(payload, service_type):
    """
Returns all items with requested type
    :param payload: Service order payload to consume
    :param service_type: like 'ucc.unity.tenant'
    :return:
    """
    if payload is None:
        raise TypeError('payload is None')
    logger.info(payload)
    if isinstance(payload, dict) and 'serviceOrderItem' in payload.keys():
        logging.debug('contains high level payload with serviceOrderItem')
        payload = payload['serviceOrderItem']
    items = []
    for item in payload:
        if item['service']['serviceType'] == service_type:
            items.append(item)
    logging.debug(f"found {len(items)} for requested type {service_type}")
    return items


def add_account(context, product_type, market_code, action="add"):
    # append json for account into the payload
    payload = append_item_to_payload(context, 'unity/tenant', action)
    logging.debug(payload)

    context.email = read_xmldata.gen_email()

    context.main_number = numbers.generate_phone_number(market_code)
    context.fax_number = numbers.generate_phone_number(market_code)
    context.mobile = numbers.generate_phone_number(market_code)

    context.product_type = product_type
    context.currency = countries_data_manager.get_currency(market_code)

    account_items = get_items_by_type(payload, 'ucc.unity.tenant')
    item_id = get_last_id(payload)
    account_item = account_items[-1]

    account_item["service"]["place"][0]["postcode"] = context.postcode
    account_item["service"]["place"][0]["country"] = context.country_code
    account_item["service"]["place"][0]["city"] = context.city

    # TenantInfo
    account_item["service"]["serviceCharacteristic"][0]["value"]["mainNumber"] = context.main_number
    account_item["service"]["serviceCharacteristic"][0]["value"]["faxNumber"] = context.fax_number
    account_item["service"]["serviceCharacteristic"][0]["value"]["profile"] = product_type
    account_item["service"]["serviceCharacteristic"][0]["value"]["name"] = companyName
    account_item["service"]["serviceCharacteristic"][0]["value"]["billingAccountNumber"] = "OPCO2222"
    account_item["service"]["serviceCharacteristic"][0]["value"]["billingServiceReference"] = "OPCO3333"
    account_item["service"]["serviceCharacteristic"][0]["value"]["opportunityId"] = "OPCO4444"
    account_item["service"]["serviceCharacteristic"][0]["value"]["currency"] = context.currency

    # TenantAdminInfo
    account_item["service"]["serviceCharacteristic"][1]["value"]["email"] = context.email
    account_item["service"]["serviceCharacteristic"][1]["value"]["phoneNumber"] = context.mobile

    payload['serviceOrderItem'][item_id - 1] = account_item

    return payload


# Add by service type functions are not applicable yet
def add_license(payload, licenses=None):
    item = 'license'
    # add default value as we don't need real data yet
    if licenses is None:
        append_item_to_payload(payload, item)
    else:
        for i, license in enumerate(licenses):
            # read model structure
            append_item_to_payload(payload, item)
            # index of new item equals to count
            payload["serviceOrderItem"][i - 1]["id"] = i
            payload["serviceOrderItem"][i - 1]["service"]["supportingResource"][0]["id"] = license["sku_id"]
            payload["serviceOrderItem"][i - 1]["service"]["serviceCharacteristic"][0]["value"] = license["quantity"]
    return payload


def add_device(payload, devices=None):
    item = 'device'
    if devices is None:
        append_item_to_payload(payload, item)


def refresh_ids(payload):
    """
Takes payload with service orders and refreshes the ids, making them ordered.
Special case for ucc.unity.numbers serviceType: it has x.y numeration
    :param payload: payload in json format
    :return: payload in json format
    """
    for i, item in enumerate(payload["serviceOrderItem"]):
        payload["serviceOrderItem"][i]["id"] = i + 1
        if item["service"]["serviceType"] == "ucc.unity.numbers":
            for l, sub_item in enumerate(item["service"]["supportingResource"]):
                sub_item["id"] = f"{i + 1}.{l + 1}"
    return payload


def item_is_add_account(item):
    if item['service']['serviceType'] == 'ucc.unity.tenant' and item['action'] == 'add':
        return True
    return False


def assign_path(xml_key, replace_value):
    path = read_xmldata.readxml(xml_key, "tmf_testdata", "tmf_data")
    path = path.replace('|', str(replace_value))
    return path


def has_initial_order(payload):
    index, tenant_item = get_item_by_type(payload, 'ucc.unity.tenant')
    if tenant_item is not None and tenant_item['action'] == 'add':
        return True
    return False


def has_add_number(payload):
    index, number_item = get_item_by_type(payload, 'ucc.unity.numbers')
    if number_item is not None and number_item['action'] == 'add':
        return True
    return False


def is_duplicate_account(_payload, item):
    if len(get_items_by_type(_payload, 'ucc.unity.tenant')) > 1:
        if item['id'] != '1':
            logging.debug("item is duplicate account")
            return True


def type_of_soi(item):
    return item['service']['serviceType']


def get_last_item(_payload):
    return _payload['serviceOrderItem'][-1]


def remove_add_account_item(payload):
    payload = copy.deepcopy(payload)
    for item in payload:
        if item_is_add_account(item):
            payload.remove(item)
            logging.debug('add account removed')
    return payload


def get_last_message(actual_soi):
    temp = actual_soi[-1]
    actual_soi = [temp]
    return actual_soi


def update_payload_nm_crf(_payload, op_co_customer_id):
    _payload["header"]["event_id"] = read_xmldata.gen_uuid()
    _payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    _payload["header"]["timestamp"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    _payload["crf_number_request"]["op_co_details"]["op_co_customer_id"] = op_co_customer_id
    _payload["crf_number_request"]["client_reference"]['marketplace_event_id'] = read_xmldata.gen_uuid()
    if op_co_customer_id == "CRF_number_Bad_Request":
        _payload["crf_number_request"]["pool"][0] = numbers.crf_negative_numbers[op_co_customer_id]


def update_payload_reg_crf_listener(_payload, temp):
    _payload["header"]["event_id"] = read_xmldata.gen_uuid()
    _payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    _payload["header"]["timestamp"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def update_account_id(payload, account_id):
    payload["externalReference"][0]["id"] = account_id


def supported_service(action, service):
    """
    Checks if service is supported in Middleware.
    If False, we do not need to create Jira ticket
    If True, Jira ticket should be created for BO Tool
    Args:
        action: service order item's action
        service: service order item's service: serviceType

    Returns:
    False, if not in supported list
    True, if in supported list
    """
    supported_services = {
        "ucc.unity.tenant": ["add"],
        "ucc.unity.numbers": ["add"]
    }
    if not common.config.is_crf_add_number_enabled:
        supported_services.pop('ucc.unity.tenant')
    if service in supported_services:
        if action in supported_services[service]:
            return True

    return False


def has_not_supported_service(payload):
    """
Checks if Service Order payload contains not supported service.
At 2023 January we support add account and add number completely
    :param payload: context.payload (or any other TMF payload)
    :return: True if contains not supported services (that means, flow will go to check jira tickets)
        False otherwise
    """
    logging.debug('payload')
    logging.debug(payload)
    for item in payload['serviceOrderItem']:
        logging.debug(f'checking {item["action"]}  {type_of_soi(item)}')
        if not supported_service(item['action'], type_of_soi(item)):
            logging.debug(f'{item["action"]}  {type_of_soi(item)} service is not supported ')
            return True

    return False


def jira_to_validate(context):
    """
Checks if we have should validate Jira
    :param context:
    :return:
    """
    if has_not_supported_service(context.payload):
        if contains_negative_number_scenario(context):
            return False
        return True
    return False


def contains_negative_number_scenario(context):
    if hasattr(context, 'number_type'):
        return context.number_type in numbers.negative_numbers


def jira_note_to_validate(item):
    """
Checks if we have to validate jira note for item
    :param item:
    :return:
    """
    return not supported_service(item['action'], type_of_soi(item))


def update_action(payload: dict, service_type: str, new_action: str) -> dict:
    """
    Update the 'action' field for a specific service type in the given payload.

    :param payload: The JSON payload containing service order items.
    :param service_type: The service type to search for.
    :param new_action: The new action value to set.
    :return: The updated JSON payload with the new action value.
    """
    return common.create_or_update_key(payload,
                                       f"$.serviceOrderItem[?(@.service.serviceType == '{service_type}')].action",
                                       new_action)


def get_action_item(item):
    return item['action']


def item_is_add_number(item):
    if item['service']['serviceType'] == 'ucc.unity.numbers' and item['action'] == 'add':
        return True
    return False


def item_is_delete_number(item):
    if item['service']['serviceType'] == 'ucc.unity.numbers' and item['action'] == 'delete':
        return True
    return False


def item_is_number(item):
    if item['service']['serviceType'] == 'ucc.unity.numbers':
        return True
    return False


def item_is_create_tpm_customer(item):
    return item['service']['serviceType'] == 'ucc.tpm.customer'


def item_is_add_tpm_numbers(item):
    return item['service']['serviceType'] == 'ucc.tpm.numbers' and item['action'] == 'add'


def item_is_delete_tpm_numbers(item):
    return item['service']['serviceType'] == 'ucc.tpm.numbers' and item['action'] == 'delete'


def update_number_for_crf_delete(payload, number):
    payload['serviceOrderItem'][0]['service']['supportingResource'][0]['resourceCharacteristic'][0]['value']['pool'][
        0] = number
    return payload


def update_payload_with_tenant_config(context, config, value=None):
    tenant_config = read_xmldata.read_jsonfile("item_models/tenant_config")
    context.service_order_item_id = "1"
    if "SSO" in config:
        context.idp_entity_id = "https://pt-test-auth.dep.vodafone.com/ons-idp/saml2/idp/metadata.php"
        if "SSO_NOK" in config:
            context.idp_entity_id = "http://invalid.com"
        elif "SSO_RETRY" in config:
            context.idp_entity_id = "http://retry" + read_xmldata.gen_contact(7) + ".com"
        elif "SSO_FAIL" in config:
            context.idp_entity_id = "http://failed" + read_xmldata.gen_contact(7) + ".com"
        if value is not None:
            context.idp_entity_id = value
        tenant_config["value"].update({"idpEntityId": context.idp_entity_id})
    if "Extension" in config:
        context.max_extension_length = random.Random().randint(5, 8)
        if "Extension_NOK" in config:
            context.payload["externalReference"][0][
                "id"] = context.op_co_customer_id = "MAX_EXT_FAIL_" + read_xmldata.gen_contact(5)
        elif "Extension_RETRY" in config:
            context.payload["externalReference"][0][
                "id"] = context.op_co_customer_id = "RETRY" + read_xmldata.gen_contact(7)
        if value is not None:
            context.max_extension_length = value
        tenant_config["value"].update({"maxExtensionLength": context.max_extension_length})
    context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"].append(tenant_config)


def create_msoc_account(context, action="add"):
    # append json for msoc create account into the payload
    payload = append_item_to_payload(context, 'msoc_create_account', action)
    logging.info(f'{payload=}')
    index = get_item_by_type(payload, "ucc.msoc.customer")[0]
    context.category = payload['category'] = 'MSOC'
    payload["serviceOrderItem"][index]["service"]["place"][0]["city"] = context.city
    payload["serviceOrderItem"][index]["service"]["place"][0]["postcode"] = context.postcode
    payload["serviceOrderItem"][index]["service"]["place"][0]["country"] = context.country_code
    # TenantInfo
    payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"][
        "name"] = context.customer_name = companyName
    if not hasattr(context, "ms_teams_tenant_id"):
        context.ms_teams_tenant_id = generate_msoc_tenantid()
    payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"][
        "tenantId"] = context.ms_teams_tenant_id

    # MSOC new fields
    context.consent_countries = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"][
        "consentCountries"] = [context.country_code]
    context.customer_domains = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"][
        "customerDomains"]
    context.first_name = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][1]["value"][
        "firstName"]
    context.last_name = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][1]["value"][
        "lastName"]
    context.msoc_email = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][1]["value"][
        "email"]

    context.hq_street_nr = common.get_field(payload, f'serviceOrderItem.{index}.service.place.0.streetNr')
    context.hq_street_name = common.get_field(payload, f'serviceOrderItem.{index}.service.place.0.streetName')
    context.hq_street_full = f'{context.hq_street_nr} {context.hq_street_name}'

    return payload


def get_item_to_change(item_to_change):
    if 'ucc.msoc.' in item_to_change:
        return item_to_change
    return f'ucc.unity.{item_to_change}'


def generate_msoc_tenantid():
    tenant_id = "MS-" + read_xmldata.gen_contact(8)
    return tenant_id


def is_msoc_customer(service_order_item: dict) -> bool:
    return service_order_item['service']['serviceType'] == 'ucc.msoc.customer'


def item_is_add_msoc_account(item: dict) -> bool:
    return is_msoc_customer(item) and item['action'] == 'add'


def item_is_delete_msoc_account(item: dict) -> bool:
    return is_msoc_customer(item) and item['action'] == 'delete'


def item_is_delete_tpm_account(item: dict) -> bool:
    return is_tpm_customer(item) and item['action'] == 'delete'


def item_is_add_msoc_country_biiling(item: dict) -> bool:
    return item['service']['serviceType'] == 'ucc.msoc.country-billing' and item['action'] == 'add'


def item_is_add_cac_configuration(item: dict) -> bool:
    return item['service']['serviceType'] == 'ucc.msoc.cac-configuration'


def item_is_add_unity_license(item):
    return item['service']['serviceType'] == 'ucc.unity.license' and item['action'] == 'add'


def item_is_delete_unity_license(item):
    return item['service']['serviceType'] == 'ucc.unity.license' and item['action'] == 'delete'


def item_is_modify_unity_license(item):
    return item['service']['serviceType'] == 'ucc.unity.license' and item['action'] == 'modify'


def check_country_code_vfuk(context):
    if context.country_code == "GB":
        return True
    return False


def prepare_account_payload(context: any, action: str, product_type: str, market_code: str) -> None:
    """
    Prepare create account payload and other required fields and save it to the context

    @param context: context object
    @param action: example 'add'
    @param product_type: example 'FULL_STACK_STANDARD'
    @param market_code: example 'VFUK'
    """
    context.product_type = product_type
    context.market_code = market_code
    context.action = action
    context.initial_license = 1

    context.payload = add_account(context, context.product_type, context.market_code, context.action)
    context.payload = refresh_ids(context.payload)
    context.opco_details_name = common.get_field(context.payload, "relatedParty.0.id")

    if market_code.startswith("MNC"):
        context.payload["relatedParty"][0].update({"id": "MNC", "marketCode": "MNC"})
        context.opco_details_name = common.get_field(context.payload, "relatedParty.0.id")
        context.market_code = common.get_field(context.payload, "relatedParty.0.marketCode")

    logger.debug("Complex SO Item payload:")
    logging.debug(json.dumps(context.payload, indent=3))


def update_payload_activate_immediately(context: Any, new_value: bool):
    index, account_item = get_item_by_type(context.payload, 'ucc.unity.tenant')
    account_item["service"]["serviceCharacteristic"][2]["value"]["activateImmediately"] = new_value
    context.payload["serviceOrderItem"][index] = account_item
    context.activate_immediately = new_value
    logging.info(f"Updated payload with activateImmediately = {new_value}, Updated Payload:\n{context.payload}")


def msoc_add_cac_configuration(context, action="add"):
    payload = append_item_to_payload(context, 'msoc_add_cac_configuration', action)
    context.category = payload['category'] = 'MSOC'
    context.action = action

    if action == "modify" or hasattr(context, "previously_added_numbers"):
        # use different margin values (than the default "add" CAC)
        payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"].update({
            "marginIn": 20,
            "marginOut": 20,
            "marginAll": 30,
            "burstMarginIn": 60,
            "burstMarginOut": 60,
            "burstMarginAll": 100,
        })
        logging.info(
            f'Modified payload MsocCacConfiguration characteristic: {to_json(payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"])}')

    index, item = get_item_by_type(payload, "ucc.msoc.cac-configuration")
    context.msoc_cac_configuration = payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["name"]
    if not hasattr(context, "cac_id"):
        context.cac_id = cac.CAC_ID_PREFIX + read_xmldata.gen_contact(10)
    payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"]["cacId"] = context.cac_id
    context.margin_in = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"]["marginIn"]
    context.margin_out = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"]["marginOut"]
    context.margin_all = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"]["marginAll"]
    context.burst_margin_in = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"][
        "burstMarginIn"]
    context.burst_margin_out = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"][
        "burstMarginOut"]
    context.burst_margin_all = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0]["value"][
        "burstMarginAll"]
    if hasattr(context, "op_co_customer_id"):
        payload["externalReference"][0]["id"] = context.op_co_customer_id
    return payload


def create_msoc_billing_identifiers(context, action="add"):
    # append json for msoc create billing identifiers in to the payload
    payload = append_item_to_payload(context, 'msoc_create_billing_identifiers', action)
    logging.debug(f'{payload=}')
    index = get_item_by_type(payload, "ucc.msoc.country-billing")[0]
    context.category = payload['category'] = 'MSOC'
    payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][0][
        "value"] = context.country = countries_data_manager.get_country_code(context.market_code)
    context.service_identifier = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][1][
        "value"]["serviceIdentifier"] = "SERV-" + read_xmldata.gen_contact(6)

    context.customer_reference_number = payload["serviceOrderItem"][index]["service"]["serviceCharacteristic"][1][
        "value"]["customerReferenceNumber"] = "REF-" + read_xmldata.gen_contact(6)

    return payload


def has_add_msoc_account(payload):
    for item in payload['serviceOrderItem']:
        if is_msoc_customer(item) and item['action'] == 'add':
            return True
    return False


def has_msoc_cac_configuration(payload):
    for item in payload['serviceOrderItem']:
        if item['service']['serviceType'] == 'ucc.msoc.cac-configuration':
            return True
    return False


def has_modify_msoc_cac_configuration(payload):
    for item in payload['serviceOrderItem']:
        if item['service']['serviceType'] == 'ucc.msoc.cac-configuration' and item['action'] == 'modify':
            return True
    return False


def has_cease_msoc_account(payload):
    for item in payload['serviceOrderItem']:
        if is_msoc_customer(item) and item['action'] == 'delete':
            return True
    return False


def has_cease_tpm_account(payload):
    for item in payload['serviceOrderItem']:
        if is_tpm_customer(item) and item['action'] == 'delete':
            return True
    return False


def is_tpm_customer(service_order_item: dict) -> bool:
    return service_order_item['service']['serviceType'] == 'ucc.tpm.customer'


def has_tpm_create_account(payload):
    for item in payload['serviceOrderItem']:
        if is_tpm_customer(item) and item['action'] == 'add':
            return True
    return False


def has_tpm_add_numbers(payload):
    for item in payload['serviceOrderItem']:
        if item['service']['serviceType'] == 'ucc.tpm.numbers':
            return True
    return False


def has_add_msoc_billing_identifers(payload):
    for item in payload['serviceOrderItem']:
        if item['service']['serviceType'] == 'ucc.msoc.country-billing' and item['action'] == 'add':
            return True
    return False


def has_unity_add_policy(context, payload) -> bool:
    return hasattr(context.payload, 'policies') and payload['serviceOrderItem'][0]['action'] == 'add'



def has_modify_sso_config(payload) -> bool:
    for item in payload['serviceOrderItem']:
        if item['service']['serviceType'] == 'ucc.unity.tenant' and item['action'] == 'modify':
            return True
    return False


def get_extension_number_from_service_order_item(service_order_item: dict) -> int | None:
    """
    Retrieve extension number from a Service Order Item payload
    :param service_order_item: Individual service order item
    :return: Extension Number if found or None
    """
    logger.debug(f"get_extension_number_from_service_order_item() {service_order_item=}")
    extension_path = "$.service.serviceCharacteristic[?(@.name=='TenantAdminInfo')].value.extension"
    extension_number = common.get_field(service_order_item, extension_path)
    logger.debug(f"{extension_number=}")
    return extension_number


def get_extension_number_from_service_order(service_order: dict) -> int | None:
    """
    Retrieve extension number from a Service Order payload
    :param service_order: Entire service order payload dict
    :return: Extension Number if found or None
    """
    logger.debug(f"get_extension_number_from_service_order() {service_order=}")
    extension_path = "$.serviceOrderItem[*].service.serviceCharacteristic[?(@.name=='TenantAdminInfo')].value.extension"
    extension_number = common.get_field(service_order, extension_path)
    logger.debug(f"{extension_number=}")
    return extension_number


def has_extension_number(service_order_item: dict):
    """
    Checks if the serviceOrderItem has extension field
    :param service_order_item: A service order item
    :return: True if found else False
    """
    return get_extension_number_from_service_order_item(service_order_item) is not None


class ServiceOrderPayload:
    """class accessing fields of a Service Order payload."""

    def __init__(self, payload: dict) -> None:
        self.payload = payload

    def get_external_reference(self, name: str) -> dict:
        """Get an external reference by name."""
        for ref in self.payload["externalReference"]:
            if ref["name"] == name:
                return ref
        raise NoSuchElementError(f"Payload does not contain an external reference with {name=}")

    def add_external_reference(self, ref: dict) -> None:
        """Add a new external reference."""
        self.payload["externalReference"].append(ref)

    def set_external_reference(self, name: str, value: str | None) -> None:
        """Set/update an external reference."""
        try:
            # try to modify an existing reference
            ref = self.get_external_reference(name)
            ref["id"] = value
        except NoSuchElementError:
            # create new reference
            ref = {"name": name, "id": value}
            self.add_external_reference(ref)

    def get_characteristic(self, name: str) -> dict:
        """Get a SOI service characteristic."""
        for soi in self.payload["serviceOrderItem"]:
            for characteristic in soi["service"]["serviceCharacteristic"]:
                if characteristic["name"] == name:
                    return characteristic
        raise NoSuchElementError(f"Payload does not contain a characteristic with {name=}")

    def get_resource_characteristic(self, name: str) -> dict:
        """Get a SOI resource characteristic."""
        for soi in self.payload["serviceOrderItem"]:
            for supportingresource in soi["service"]["supportingResource"]:
                for resourceCharacteristic in supportingresource['resourceCharacteristic']:
                    if resourceCharacteristic["name"] == name:
                        return resourceCharacteristic
        raise NoSuchElementError(f"Payload does not contain a resource characteristic with {name=}")

    def get_category(self):
        return self.payload['category']
