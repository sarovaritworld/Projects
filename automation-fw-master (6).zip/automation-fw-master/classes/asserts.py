"""Asserts module

Provides simple assert functions for different assertions.
In case of failure, asserts provide customized error message
"""
import logging
import random
import re
import string
from typing import Any

logger = logging.getLogger(__name__)


def equals(actual: Any, expected: Any, name: str) -> None:
    """Assert actual value is as expected.

    :param actual: actual value
    :param expected: expected value
    :param name: name to be printed in error message.
    """
    logging.debug(f"Validating: {name}")
    logging.debug(f"Actual value: {actual}")
    logging.debug(f"Expected value: {expected}")

    if actual != expected:
        # log the full error with values, but keep the exception message generic
        # so we can group similar errors on GCP Results Dashboard
        if str(actual) != str(expected):
            logger.error(f"'{name}' is \n'{actual}' but was expected to be \n'{expected}'")
            raise AssertionError(f"'{name}' is '{actual}' but expected to be '{expected}'")
        else:
            logger.error(f"'{name}' is '{actual}' as type {type(actual)} but"
                         f" was expected as type {type(expected)}")
            raise AssertionError(f"'{name}' is not of the expected type")


def field_equals(actual: Any, expected: Any, field_name: str) -> None:
    """Assert a field has the expected value.

    :param actual: any type of value
    :param expected: any type of value
    :param field_name: field name to be printed in error message.
    """
    equals(str(actual), str(expected), name=f"Field {field_name}")


def in_list(item: Any, expected_values: list, name: str, case_sensitive=True) -> None:
    """Assert an item is in the list of expected values.

    :param item: value
    :param expected_values: expected values
    :param name: name to be printed in error message.
    :param case_sensitive: preserve case of item
    """
    if not case_sensitive:
        item = item.lower()
    if item not in expected_values:
        logger.error(f"'{name}' is '{item}' which is not in the list of expected values: '{expected_values}'")
        raise AssertionError(f"'{name}' is not in the list of expected values")


def is_subset(item: Any, expected_values: list, name: str):
    """Assert an item is subset of expected list.

    :param item: value
    :param expected_values: expected values
    :param name: name to be printed in error message."""

    if set(item).issubset(set(expected_values)):
        logger.info(f"{item} is subset of {expected_values}")
    else:
        logger.error(f"'{name}' is '{item}' which is not in the list of expected values: '{expected_values}'")
        raise AssertionError(f"'{name}' is not in the list of expected values")


def is_valid_uuid(value: str, name: str) -> None:
    logging.debug(f"Validating that {name} is a valid UUID")
    # example of UUID: 34480482-a385-4e7f-81a7-902b2a9d2ead
    hexa = lambda size: "[0-9a-fA-F]{%i}" % size
    pattern = "-".join([hexa(8), hexa(4), hexa(4), hexa(4), hexa(12)])
    if not re.search(f"^{pattern}$", value):
        logger.error(f"{name} = '{value}' is not a valid UUID (shoud match {pattern})")
        raise AssertionError(f"{name} is not a valid UUID")


def validate_and_fix_ringcentral_user_id(rc_user_id, size=13):
    """Validate the given ringcentral_user_id against the pattern [a-zA-Z0-9\\-_]+

        :param rc_user_id: The ringcentral_user_id to be validated
        :param size: The size of the new user ID to be generated if the original is invalid. Default is 13"""

    valid_pattern = re.compile(r'^[a-zA-Z0-9\-_]+$')
    if valid_pattern.match(rc_user_id):
        return rc_user_id
    else:
        valid_rc_user_id = ''.join(
            random.SystemRandom().choice(string.digits + string.ascii_letters + "-_") for _ in range(size))
        return valid_rc_user_id
