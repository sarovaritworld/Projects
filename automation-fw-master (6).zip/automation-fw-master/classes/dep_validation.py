import time

from classes import common, account, numbers, asserts


def get_ok_nok_numbers(
        action: str,
        number_pool_list: list[str],
        same_numbers: list[str],
        different_numbers: list[str],
        cac_mismatch: bool) -> tuple[list[str], list[str]]:
    """
    Returns a tuple of 2 lists of OK numbers and NOK numbers
    :param action: add or delete
    :param number_pool_list: final pool of numbers to be sent in request
    :param same_numbers: numbers already added to same account
    :param different_numbers: numbers already added to a different account
    :param cac_mismatch: True or False
    :return: (ok_numbers, nok_numbers)
    """
    # Prepare numbers expected status for further validation
    ok_numbers = same_numbers
    nok_numbers = different_numbers
    if action == "add":
        if cac_mismatch:
            # For CAC Mismatch scenarios (only applicable in add), same number would be NOK numbers
            ok_numbers = []
            nok_numbers = same_numbers
    elif action == "delete":
        nok_numbers = []
        ok_numbers = number_pool_list
    else:
        raise NotImplementedError(f"Unsupported {action=}")
    return ok_numbers, nok_numbers


def get_expected_numbers_status(
        action: str,
        number_pool_list: list[str],
        same_numbers: list[str],
        different_numbers: list[str],
        cac_mismatch: bool) -> dict:
    """
    Prepare a dict of expected status for each number according to their group
    No entry is added for a number in pool_list if they don't belong to either group
    :param action: add or delete
    :param number_pool_list: Actual pool of numbers
    :param same_numbers: for which status would be NOK
    :param different_numbers: for which status would be OK
    :param cac_mismatch:
    :return: expected_numbers_status dict
    """
    ok_numbers, nok_numbers = get_ok_nok_numbers(
        action,
        number_pool_list,
        same_numbers,
        different_numbers,
        cac_mismatch
    )
    
    ok_status = {'status': 'OK', 'errorReason': 'NO_ERROR'}
    nok_status = {'status': 'NOK', 'errorReason': 'ALREADY_PROVISIONED_IN_CRF'}
    expected_numbers_status = {}
    for number in number_pool_list:
        if number in nok_numbers:
            expected_status = nok_status
        elif number in ok_numbers:
            expected_status = ok_status
        else:
            continue
        number = number.replace("+", "")
        expected_numbers_status.update({number: expected_status})
    return expected_numbers_status


def get_numbers_from_different_account(category: str, market_code: str, op_co_customer_id: str) -> list[str]:
    """
    Returns a list of numbers added to a different account from reusable account json
    :param category: UNITY or MSOC
    :param market_code: e.g. VFUK
    :param op_co_customer_id: numbers will be fetched from an account other than this
    :return: List of numbers
    """
    account_filter = {
        "environment": common.config.ENVIRONMENT,
        "market_code": market_code,
        "category": category
    }
    # Find numbers added to some different account from reusable account json
    different_numbers = account.get_numbers_added_to_account_except(
        account_filter,
        op_co_customer_id
    )
    if not different_numbers:
        raise NotImplementedError(
            f"No account with its numbers found in reusable_account.json, "
            f"for Environment={common.config.ENVIRONMENT}, "
            f"Please add at least one account with at least 5 numbers for DEP Validations scenarios"
        )
    return different_numbers


def get_numbers_for_scenario(
        numbers_status: str,
        account_status: str,
        original_numbers: list[str],
        different_numbers: list[str],
        market_code: str) -> list[str]:
    """
    Returns the list of numbers for enhanced DEP validation scenarios
    :param numbers_status:
    :param account_status:
    :param original_numbers:
    :param different_numbers:
    :param market_code:
    :return:
    """
    match numbers_status:
        case "provisioned":
            match account_status:
                case "same":
                    # same set of numbers which were added to the account in the context
                    # Nothing to refresh as same set of numbers to be sent in the request
                    pass
                case "different":
                    # set of numbers to which have been provisioned for a different account
                    original_numbers = different_numbers
                case "same_and_different":
                    # some existing numbers mixed with already provisioned numbers for different account
                    original_numbers = numbers.mix_numbers(
                        original_numbers,
                        market_code,
                        mixin_pool=different_numbers,
                        mix_new_numbers=False
                    )
        case "provisioned_and_new":
            match account_status:
                case "same":
                    original_numbers = numbers.mix_numbers(
                        original_numbers,
                        market_code,
                        mix_new_numbers=True
                    )
                case "different":
                    original_numbers = numbers.mix_numbers(
                        different_numbers,
                        market_code,
                        mix_new_numbers=True
                    )
                case "same_and_different":
                    original_numbers = numbers.mix_numbers(
                        original_numbers,
                        market_code,
                        mixin_pool=different_numbers,
                        mix_new_numbers=True
                    )
        case "new":
            # For delete scenarios, number that don't exist for any customer yet
            original_numbers = numbers.generate_pool(5, market_code)
        case _:
            raise NotImplementedError(f"No handling for {numbers_status=}")
    return original_numbers


def get_notification_scenario(action: str, numbers_status: str) -> str:
    """
    Returns notification scenario for given numbers status
    :param action: add OR delete
    :param numbers_status:
    :return:
    """
    notification_scenario = {
        "add": {
            "provisioned": "ALL_NUMBERS_PROVISIONED",
            "provisioned_and_new": "NUMBERS_PARTIALLY_PROVISIONED"
        },
        "delete": {
            "new": "ALL_NUMBERS_NOT_FOUND",
            "provisioned": "ALL_NUMBERS_NOT_FOUND"
        }
    }
    return notification_scenario[action][numbers_status]


def validate_crf_document(document: dict, expected_result: str, expected_numbers_status: dict) -> None:
    """
    Validate CRF Document for enhanced DEP validations
    :param document: crf_request document from DB
    :param expected_result: Expected value of isCrfRequestSuccessful
    :param expected_numbers_status: status of each number
    :return: None
    """
    is_crf_request_successful = (expected_result == "Successful")
    asserts.equals(document["isCrfRequestSuccessful"], is_crf_request_successful, "isCrfRequestSuccessful")
    actual_failed_numbers_dict = document["failedNumbers"]
    asserts.equals(actual_failed_numbers_dict, expected_numbers_status, "failedNumbers")
