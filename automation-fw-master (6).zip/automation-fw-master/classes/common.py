import logging
import os
import time
from dataclasses import dataclass

from jsonpath_ng.ext import parse

from classes import asserts, data, data_files, read_xmldata
from classes.kafka.utils import has_multiple_messages
from classes.utils import strtobool
from common_python.stub_accounts.stub_accounts import StubAccounts

logger = logging.getLogger(__name__)
stub_accounts = StubAccounts()


class PostInitCaller(type):
    def __call__(cls, *args, **kwargs):
        obj = type.__call__(cls, *args, **kwargs)
        obj.__post_init__()
        return obj


@dataclass
class Config:
    """General configuration and state."""
    feature_start_time: float = time.time()
    ENVIRONMENT: str = os.environ.get("ENVIRONMENT_NAME", "")
    EMAIL_SENDER_SERVER: str = os.environ.get("EMAIL_SENDER_SERVER", "")
    is_staging_env: bool = ENVIRONMENT == "Unity-Middleware-Staging"
    is_dev_env: bool = ENVIRONMENT == "Unity-Middleware-DEV"
    jwt_server_auth: str | None = None
    is_crf_add_number_enabled: bool = strtobool(os.environ.get("CRF_ADD_NUMBER_ENABLED", "False"))
    is_crf_delete_number_enabled: bool = strtobool(os.environ.get("CRF_DELETE_NUMBER_ENABLED", "False"))
    _appdirect_stub: dict | None = None
    UN_26216_workaround: bool = True  # to remove conditions when defect https://jira.tools.aws.vodafone.com/browse/UN-26216 is fixed

    def __post_init__(self):
        try:
            credentials = data.read_jwt_token_json_file()
            self.jwt_server_auth = 'Basic ' + data.convert_string_into_Base_64(credentials)
        except FileNotFoundError:
            pass  # not running in a POD
        self.namespace = 'middleware' if self.is_dev_env else 'middleware-test'

    @property
    def appdirect_stub(self) -> dict:
        if self._appdirect_stub is None:
            self._appdirect_stub = data_files.read("appdirect_stub_server")
        return self._appdirect_stub


config = Config()

event_per_topic_name = {
    "ringcentral_event_numbers_added": "NUMBER_ADDED",
    "ringcentral_event_numbers_deleted": "NUMBER_DELETED",
    "ringcentral_event_numbers_updated": "NUMBER_UPDATED"
}


def match_message(message_object, fields_to_check, value_to_match):
    """
    Checks if a message matches the specified criteria
    :param message_object: The JSON object representing the message data
    :param fields_to_check: An array of fields to check in the JSON object
    :param value_to_match: The value to look for in the fields
    :return: message_object if match found; None if not found
    """
    for field in fields_to_check:
        logging.info(f'Checking field {field}')
        field_value = get_field(message_object, field)
        logging.info(f'field_value {field_value}')
        if field_value == value_to_match:
            return message_object

    # No match
    return None


def get_field(message_object: dict | list, field: str):
    """
    Gets a field from a dict object
    :param message_object: The JSON object representing the message data
    :param field: The field to get in dot notation (e.g. account.ucas_account_id)
    :return:
    """
    # Check whether field is a jsonpath expression
    if field.startswith("$"):
        return find_first_value(message_object, field)

    field_parts = field.split('.')
    current_object = message_object

    # Iterate through the field, getting nested values
    for k, field_part in enumerate(field_parts):
        if isinstance(current_object, list):
            logging.debug("node is a list, converting to int")
            field_part = int(field_part)
        try:
            current_object = current_object[field_part]
        except KeyError:
            logging.info(
                f"The dict .{'.'.join(field_parts[:k])} = {current_object} has no key '{field_part}'."
                " Check your notation, the address can be wrong, like"
                " event_type instead of eventType")
            return None
        except IndexError:
            logging.info(
                f"The list .{'.'.join(field_parts[:k])} = {current_object} has no index {field_part}")
            return None

    return current_object


def update_test_attributes(context, values, payload):
    """
This function is not finished and tested yet
    :param context: context object (or any class object)
    :param values: list of values to update: "'marketplaceEventID': "header.eventId"
                key is an attribute name in the context
                value is the json path in dot notation
    :param payload: payload json value from anywhere (where from to get the data, if there is not attribute is the context
    :return:
    """
    for key, value in values.items():
        if not hasattr(context, key):
            logging.debug(f"Attribute '{key}' does not exist in the context")
            v = get_field(payload, value)
            if v is not None:
                logging.debug(f"Saving to the context: key: {key}, value: {v}")
                setattr(context, key, v)
                return True
        elif hasattr(context, key):
            logging.debug(f"Attribute '{key}' exists in the context")
            v = get_field(payload, value)
            if v is not None:
                logging.debug(f"Update the context: key: {key}, value: {v}")
                setattr(context, key, v)
                return True
    return False


def wait(node):
    time_slice = read_xmldata.readxml(node, "test_inputdata", "appdirectinput")
    read_xmldata.wait_to_connect(time_slice)


def validate_message(message: dict | list, validation_set: dict) -> None:
    """Validate a message/payload."""
    try:
        for field_name, expected in validation_set.items():
            if expected is False:
                asserts.field_equals(is_key_present(field_name, message), False, field_name)
                continue
            actual = get_field(message, field_name)
            if callable(expected):
                expected(actual, field_name)
            else:
                asserts.field_equals(actual, expected, field_name)
    except Exception:
        logging.error("Exception while validating the message")
        raise


def get_opco_customer_id_by_number_type(number_type):
    invalid_account_id = read_xmldata.gen_contact(8)
    number_type_customer_id = {
        'pool_OK_NOK': 'OK-NOK',
        'pool_NOK_OK': 'NOK-OK',
        'pool_all_NOK': 'all-NOK',
        'pool_Bad_Request': 'bad-request',
        'pool_internal_server_error': 'server-error',
        "CRF_Bad_Request": "BAD_" + invalid_account_id,
        "CRF_RC_no_account": "Account_does_not_exist_in_RC",
        "fail_main_number_in_RC": "MAIN_NUMBER_FAIL_" + invalid_account_id,
        "CRF_Bad_Request_add_pool": "CRF_number_Not_Found",
        "same_account_presentation": "same_account_presentation_de",
        "same_account_inventory": "same_account_inventory_de",
        "retry_pass_too_many_requests": "88103242460",
        "retry_fail_too_many_requests": "88103497973",
        "retry_pass_internal_server_error": "88103083542",
        "retry_fail_internal_server_error": "88103377673",
        "request_pass_on_third_time_internal_server_error": "88130379851",
        "request_pass_on_third_time_too_many_requests": "88130386412",
        "existing_msoc_account": "88311347029",
        "pool_different_usage": "DELFAIL123",
        "fail_provisioning_in_snow": "SNOW_fail_" + invalid_account_id,
        "pool_non_existing_account": invalid_account_id,
        "main_number_exists_in_rc": stub_accounts.rc.existing_main_number_account_prefix + invalid_account_id,
        "main_number_exists_in_rc_diff_usage": stub_accounts.rc.existing_main_number_different_usage_prefix + invalid_account_id
    }
    return number_type_customer_id[number_type]


def update_key(payload, field, field_value):
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key == field:
                payload[key] = field_value
            elif isinstance(value, (dict, list)):
                update_key(value, field, field_value)
    elif isinstance(payload, list):
        for item in payload:
            if isinstance(item, (dict, list)):
                update_key(item, field, field_value)


def skip_stub_actions(topic_name):
    if topic_name == 'crfstub_process_resourceorder' and config.is_staging_env:
        logging.info(f'{topic_name} does not exist on staging')
        return True
    return False


def create_or_update_key(payload, field, value):
    """
updates key with dot notation address
if not found, creates it
Examples:   ['key',
            'dict.inner_key',
            'list.[1]',
            'list_of_dict.[0].inner_dict_key']
Important! List indexes should be addressed with []
    :param payload: dict
    :param field: address in dot notation
    :param value: value to set
    :return:
    """
    try:
        findings = parse(field).find_or_create(payload)
    except KeyError:
        print('list not found')
        print(field)

    for finding in findings:
        finding.full_path.update_or_create(payload, value)
    return payload


def delete_key(payload, key):
    jsonpath_expr = parse(key)
    jsonpath_expr.filter(lambda d: True, payload)
    return payload


def find_first_value(payload, field):
    if findings := parse(field).find(payload):
        return findings[0].value
    return None


def check_value_in_payload(json_data, key, value):
    if isinstance(json_data, dict):
        if key in json_data and json_data[key] == value:
            return True
        for k, v in json_data.items():
            if check_value_in_payload(v, key, value):
                return True
    elif isinstance(json_data, list):
        for item in json_data:
            if check_value_in_payload(item, key, value):
                return True
    return False


def is_key_present(key, data):
    if isinstance(data, dict):
        if key in data.keys():
            return True
        for k, v in data.items():
            if is_key_present(key, v):
                return True
    elif isinstance(data, list):
        for item in data:
            if is_key_present(key, item):
                return True
    return False


def get_key(key, data):
    logger.debug(f'{data=}')
    if isinstance(data, dict):
        if key in data.keys():
            return data[key]
        for k, v in data.items():
            result = get_key(key, v)
            logger.debug(f'{result=}')
            if result is not None:
                return result
    elif isinstance(data, list):
        for item in data:
            result = get_key(key, item)
            logger.debug(f'{result=}')
            if result is not None:
                return result


def is_value_present(value, data):
    if isinstance(data, dict):
        if value in data.values():
            return True
        for k, v in data.items():
            if is_value_present(value, v):
                return True
    elif isinstance(data, list):
        for item in data:
            if is_value_present(value, item):
                return True
    if data == value:
        return True
    return False


def is_partial_value_present(value, data):
    if isinstance(data, dict):
        if value in data.values():
            return True
        for k, v in data.items():
            if is_partial_value_present(value, v):
                return True
    elif isinstance(data, list):
        for item in data:
            if is_partial_value_present(value, item):
                return True
    if value in data:
        return True
    return False


def find_item(items: list[dict], filter_dict: dict) -> dict | None:
    """
    Finds an item in a list of dicts based on filtering criteria.
    Please note, if more than one matching item is there,
    then it will return first matched item and stop searching.
    @param items:
    @param filter_dict: Filter criteria
    @return: First matched item or None
    """
    for item in items:
        # checks if filter_dict is a subset of the item
        if filter_dict.items() <= item.items():
            return item


def find_matching_items(items: list[dict], filter_dict: dict) -> list[dict] | None:
    """
    Finds all matching items in a list of dicts based on filtering criteria.
    @param items:
    @param filter_dict: Filter criteria
    @return: List of matching items OR None if no matching item found
    """
    matching_items: list[dict] = []
    for item in items:
        # checks if filter_dict is a subset of the item
        if filter_dict.items() <= item.items():
            matching_items.append(item)
    if len(matching_items) > 0:
        return matching_items


def find_item_and_update(items: list[dict], filter_dict: dict, updates: dict) -> bool:
    """
    Finds a matching item and update the value with 'updates' values.
    Only attributes will be updated which are in 'updates', rest of them will persist.
    @param items: List of items
    @param filter_dict: Filter criteria
    @param updates: New values
    @return: True if update was successful or False otherwise
    """
    matching_item = find_item(items, filter_dict)
    if matching_item:
        for key, value in updates.items():
            matching_item[key] = value
        logger.debug(f"Update successful, updated item = {matching_item}")
        return True
    logger.warning(f"No record found using the filter criteria {filter_dict}")
    return False


def update_middleware_correlation_id(context):
    """
Update middleware_correlation_id
Used in the case when we have done some actions in prerequisite (e.g. create account) but has not cleaned up data
Checks if middleware_correlation_id is different that saved in the context and updates it
If the same, does nothing
    :param context:
    :return:
    """
    payload = context.consumer_payload
    keys = ('middleware_correlation_id', 'middlewareCorrelationId')
    if has_multiple_messages(context.consumer_payload):
        payload = context.consumer_payload[0]
    for key in keys:
        middleware_correlation_id = get_key(key, payload)
        if middleware_correlation_id is not None:
            if hasattr(context,
                       'middleware_correlation_id') and context.middleware_correlation_id == middleware_correlation_id:
                logger.info('No changes in middleware_correlation_id')
                break
            else:
                context.middleware_correlation_id = middleware_correlation_id
                logger.info('middleware_correlation_id updated')
                break
    else:
        raise Exception("No middleware_correlation_id found in message")


def save_marketplace_event_id(context):
    """
    Save marketplace_event_id
    Used in the case when we have done some actions in prerequisite (e.g. create account) but has not cleaned up data
    Checks if marketplaceEventID is in the context; if not, assigns it
    If the same, does nothing
        :param context:
        :return:
        """
    payload = context.consumer_payload
    keys = ('marketplace_event_id', 'marketplaceEventId')
    if has_multiple_messages(context.consumer_payload):
        payload = context.consumer_payload[0]
    if hasattr(context, 'marketplaceEventID'):
        for key in keys:
            try:
                if context.marketplaceEventID == payload['order'][key]:
                    logger.info('No changes in marketplaceEventID')
            except KeyError:
                continue
        return
    for key in keys:
        try:
            context.marketplaceEventID = payload['order'][key]
        except KeyError:
            continue


def update_RC_ID(context):
    payload = context.consumer_payload
    if has_multiple_messages(context.consumer_payload):
        payload = context.consumer_payload[0]
    if hasattr(context, 'RC_ID'):
        if context.RC_ID == payload['completed_order']['account']['ucas_account_id']:
            logger.info('No changes in RC_ID')
            return
    context.RC_ID = payload['completed_order']['account']['ucas_account_id']


def update_ucas_provider(context):
    # only for RC for now
    if not hasattr(context, 'ucas_provider'):
        context.ucas_provider = 'RINGCENTRAL'


def get_module_name(filename: str) -> str:
    # Behaves overwrites the `__name__` to `builtins`
    # which makes it tricky to find the current module name for step files
    return filename.split("automation-fw/")[-1].replace(".py", "").replace("/", ".")
