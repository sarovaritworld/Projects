import logging
from typing import Dict, Union
from http import HTTPStatus


class StatusCodeValidator:

    @staticmethod
    def validate_status_code_response(current_code: Union[int, str], expected_code: Union[int, str]):
        """
        Compares the status code of an HTTP response to an expected value.

        Args:
            current_code: The value to be validated.
            expected_code: The expected value.
        """

        logging.info(f"Validating current status code {current_code} with expected status code {expected_code}")
        assert int(current_code) == int(expected_code), StatusCodeMismatch(current_code, expected_code)

    @staticmethod
    def receive_status_code_response(context, expected_code: str):
        current_code = int(context.postresponse_NumberPool.status_code)
        expected_code = int(expected_code)

        code_dict = {
            HTTPStatus.ACCEPTED.value: "Success",
            HTTPStatus.BAD_REQUEST.value: "Invalid customer pool data",
            HTTPStatus.UNAUTHORIZED.value: "Expired JWT token",
            HTTPStatus.FORBIDDEN.value: "Unrecognised market / customer ID",
            HTTPStatus.NOT_FOUND.value: "Missing or wrong parameters",
            HTTPStatus.INTERNAL_SERVER_ERROR.value: "Internal server error"
        }

        check_status_code_in_dict(expected_code, code_dict)

        if current_code == expected_code:
            logging.info(f"Status code: {current_code}, Status: {code_dict.get(current_code)}")
            if current_code == HTTPStatus.ACCEPTED.value:
                context.status_get_response_num_pool_uuid = context.postresponse_NumberPool.json()['uuid']
            return

        raise StatusCodeMismatch(current_code, expected_code)

    @staticmethod
    def receive_response_from_ring_central(context, expected_code: str):
        current_code = int(context.postresponse2.status_code)
        expected_code = int(expected_code)

        code_dict = {
            HTTPStatus.OK.value: "Success",
            HTTPStatus.ACCEPTED.value: "Order is Pending / Processing state",
            HTTPStatus.BAD_REQUEST.value: "Error state",
            HTTPStatus.NOT_FOUND.value: "Method not found",
            HTTPStatus.METHOD_NOT_ALLOWED.value: "Method not allowed",
        }

        check_status_code_in_dict(expected_code, code_dict)

        logging.info(f"Status code: {current_code}, Status: {code_dict.get(current_code)}")
        assert int(current_code) == int(expected_code), StatusCodeMismatch(current_code, expected_code)

    @staticmethod
    def reply_with_status_response_for_endpoint_to_test(current_code: str, expected_code: str):
        current_code = int(current_code)
        expected_code = int(expected_code)

        code_dict = {
            HTTPStatus.OK.value: "Ok",
            HTTPStatus.CREATED.value: "Created",
            HTTPStatus.NO_CONTENT.value: "User successfully deleted",
            HTTPStatus.BAD_REQUEST.value: "Bad request",
            HTTPStatus.UNAUTHORIZED.value: "Unauthorized",
            HTTPStatus.METHOD_NOT_ALLOWED.value: "Method not found",
            HTTPStatus.CONFLICT.value: "Conflict",

        }

        logging.info(f"Status code: {current_code}, Status: {code_dict.get(current_code)}")
        assert int(current_code) == int(expected_code), StatusCodeMismatch(current_code, expected_code)


def check_status_code_in_dict(expected_code: int, code_dict: Dict):
    if expected_code not in code_dict.keys():
        raise StatusCodeValidatorException(f"Expected value {expected_code} not found in code_dict")


class StatusCodeValidatorException(Exception):
    def __init__(self, message):
        super().__init__(message)


class StatusCodeMismatch(Exception):
    def __init__(self, current_code, expected_code):
        super().__init__(
            f"Status code mismatch, current status code: {current_code}, expected status code: {expected_code}")
