import pdb
from datetime import datetime
import json
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--input_json_file',
                    required=True,
                    help="Path of input json file. JSON file is output of Behave test run")
parser.add_argument('--output_html_file',
                    required=True,
                    help="Path of the output html file to be generated")

args = parser.parse_args()

input_file = args.input_json_file
output_html_path = args.output_html_file

now = datetime.now()
feature_count = 0
feature_failed_count = 0
feature_passed_count = 0
scenario_count = 0
scenario_failed_count = 0
scenario_passed_count = 0
elapsed_time = 0.0
all_rows = ""
feature_row_template = '''<div id="s1" class="suite">
    <div class="element-header" onclick="toggleSuite('s1')"> 
        <div class="element-header-left" title="Test AudioAnnouncement">         
            <span class="elapsed" title="Elapsed time"></span>         
            <span class="label {status_type}">Feature</span> 
            <span class="name">{fe_name}</span>       
        </div>
        <div class="element-header-right" onclick="stopPropagation(event)" title="">
            <a class="expand" title="Expand all" href="javascript:expandAll('s1')"></a>
            <a class="collapse" title="Collapse all" href="javascript:collapseAll('s1')"></a>
            <a class="link" title="Link to this feature" href="#s1" onclick="makeElementVisible('s1')"></a> 
        </div>
        <div class="element-header-toggle" title="Toggle visibility"></div>
    </div> 
    <div class="children populated" style="display: block;">      
        <table class="metadata"><tbody>
<tr><th>Name:</th><td>{fe_name}</td></tr>
<tr><th>Tags:</th><td>{fe_tags}</td></tr>
<tr><th>Start / End / Elapsed:</th><td></td></tr><tr><th>Status:</th><td><span class="label {status_type}">{fe_status}</span></td></tr>
</tbody></table> </div>

'''

scenario_row_template = '''
<div id="{src_count}" class="keyword"> 
<div class="element-header" onclick="toggleKeyword('{src_count}')">
    <div class="element-header-left" title="Set Library Search Order">
        <span class="elapsed" title="Elapsed time"></span>
        <span class="label {status_type}">Scenario {index}</span>
        <span></span>
        <span class="name">
        <span class="arg">Title : </span>
        <span class="arg">{sce_name}</span> </span>
    </div>
    <div class="element-header-right" onclick="stopPropagation(event)">
        <a class="expand" title="Expand all" href="javascript:expandAll('${src_count}')"></a>
        <a class="collapse" title="Collapse all" href="javascript:collapseAll('{src_count}')"></a>
        <a class="link" title="Link to this keyword" href="#{src_count}" onclick="makeElementVisible('{src_count}')"></a>
    </div>
    <div class="element-header-toggle" title="Toggle visibility"></div>
</div>
<div class="children populated" style="display: block;">       
    <table class="metadata keyword-metadata"><tbody>
	<tr><th>Elapsed: </th><td></td></tr>
	<tr><th>Tags:</th><td>{sce_tags}</td></tr>

	</tbody></table>  
'''

substepfirst_row_template = '''
<div class="element-header-left" title="Test AudioAnnouncement.Regression PI5 SP2 TC004">

    <table class="metadata keyword-metadata"><tbody><tr>
    <td width="60%"><span class="label {status_type}">Step</span>

    <span class="arg">{passed_steps}</span>	<span></span></td>
    <td><span class="label {status_type}">{sce_status}</span></td>
    <td><span class="elapsed" title="Elapsed time">{elapsed_time}</span></td></tr></tbody></table>

</div>
'''

substep_row_template = '''
<div class="element-header-left" title="Test AudioAnnouncement.Regression PI5 SP2 TC004">

    <table class="metadata keyword-metadata"><tbody><tr>
    <td width="60%"><span class="label {status_type}">Step</span>
    <span class="arg">{passed_steps}</span>	<span></span>	</td>
    <td><span class="label {status_type}">{sce_status}</span></td>
    <td><span class="elapsed" title="Elapsed time">{elapsed_time}</span></td></tr></tbody></table>
</div>
</div>
</div>
'''

error_row_template = '''
<div class="element-header-left" title="Test AudioAnnouncement.Regression PI5 SP2 TC004">         
    <span class="elapsed" title="Elapsed time"></span>
        <table class="metadata keyword-metadata"><tbody><tr>
        <td><span class="label fail">Step</span>
    <span class="arg">{step_name}</span></td></tr></tbody></table>
    <span class="arg">{err}</span>	
<span class="label fail">FAILED</span>
</div>
</div> 
</div>
</div>   
</div> 
</div>
</div>  
</div> 
</div>
'''
report_styles = """
<style>
body {
font-family: Helvetica, sans-serif;
}    
.table-summary {
width: 65em;
border-collapse: collapse;
empty-cells: show;
margin-bottom: 1em;
display: table;
box-sizing: border-box;
text-indent: initial;
border-spacing: 2px;
border-color: grey;
font-size: 12px;
}
.table-summary th {
background-color: #ddd;
padding: 0.2em 0.3em;
}
#s1, .suite > .children > .keyword {
margin-left: 0;
}
.suite, .test, .keyword {
margin-left: -0.2em;
}
.suite, .test, #errors {
border: 1px solid #ccc;
padding: 0.3em 0.2em;
margin: 0.2em 0;
}
.element-header:hover {
cursor: pointer;
background-color: #eee;
border-color: #ccc;
}
.element-header {
border: 1px solid transparent;
border-radius: 2px;
position: relative;
}
.element-header-left {
padding: 3px 80px 3px 20px;
}
.elapsed {
float: right;
color: #999;
padding-left: 1em;
}
.label.error, .label.fail {
background-color: #d9534f;
}
.label.error, .label.fail, .label.pass, .label.warn {
color: #fff !important;
font-weight: bold;
}
.label {
padding: 2px 5px;
font-size: 0.75em;
letter-spacing: 1px;
white-space: nowrap;
color: black;
background-color: #ddd;
border-radius: 3px;
}
.fail {
color: #f33 !important;
font-weight: bold;
}
.name {
font-weight: bold;
}
.element-header-right {
position: absolute;
right: 0;
top: 0;
padding: 3px;
cursor: default;
}
.element-header {
    border: 1px solid transparent;
    border-radius: 2px;
    position: relative;
}
.element-header:hover {
    cursor: pointer;
    background-color: #eee;
    border-color: #ccc;
}
.element-header-toggle {
    position: absolute;
    left: 3px;
    top: 5px;
    background-repeat: no-repeat;
    background-position: center;
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAGCAQAAABKxSfDAAAAAmJLR0QA/4ePzL8AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfeCR0JChSkZz20AAAAGklEQVQI12NgQAKMDKzInP8IDhOqMk4G7AAANQwBE427PYUAAAAASUVORK5CYII=);
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiIHZpZXdCb3g9IjAgMCA4IDgiPgogIDxwYXRoIGQ9Ik0wIDB2Mmg4di0yaC04eiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzKSIgLz4KPC9zdmc+), none;
    height: 10px;
    width: 10px;
    background-size: 6px 6px;
    border: 1px solid #ccc;
    border-radius: 2px;
}
.closed > .element-header-toggle {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAGCAQAAABKxSfDAAAAAmJLR0QA/4ePzL8AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfeCR0JCDHdVYtxAAAAM0lEQVQI103MMQqAMBQFwVHyITaB3P+W1sKzSBC3mW6hRFw0pUB5DvF1bu9FN0RM3X/wAk98CUnvFTakAAAAAElFTkSuQmCC);
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiIHZpZXdCb3g9IjAgMCA4IDgiPgogIDxwYXRoIGQ9Ik0zIDB2M2gtM3YyaDN2M2gydi0zaDN2LTJoLTN2LTNoLTJ6IiAvPgo8L3N2Zz4=), none;
}
.element-header:hover > .element-header-toggle {
    background-color: #ccc;
}
.element-header-right:hover ~ .element-header-toggle {
    background-color: transparent;
}
.element-header:hover > .element-header-toggle {
background-color: #ccc;
}
.element-header-toggle {
position: absolute;
left: 3px;
top: 5px;
background-repeat: no-repeat;
background-position: center;
background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAGCAQAAABKxSfDAAAAAmJLR0QA/4ePzL8AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfeCR0JChSkZz20AAAAGklEQVQI12NgQAKMDKzInP8IDhOqMk4G7AAANQwBE427PYUAAAAASUVORK5CYII=);
background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiIHZpZXdCb3g9IjAgMCA4IDgiPgogIDxwYXRoIGQ9Ik0wIDB2Mmg4di0yaC04eiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAzKSIgLz4KPC9zdmc+), none;
height: 10px;
width: 10px;
background-size: 6px 6px;
border: 1px solid #ccc;
border-radius: 2px;
}
.children {
display: none;
margin-left: 1.4em;
}
#errors, .messages, .metadata {
width: 100%;
border-spacing: 0;
}
table {
table-layout: fixed;
word-wrap: break-word;
empty-cells: show;
font-size: 1em;
}
.metadata th {
width: 3.3em;
text-align: left;
white-space: nowrap;
padding: 0;
}
th, td {
vertical-align: top;
}
.metadata td {
padding: 0.2em;
}
.element-header {
border: 1px solid transparent;
border-radius: 2px;
position: relative;
}
.keyword-metadata {
font-size: 0.9em;
}
.element-header-left {
padding: 0.2px 80px 3px 20px;
}
.suite table, th, td {
border: unset;
}
.label.pass {
background-color: #5cb85c;
}
.label.error, .label.fail, .label.pass, .label.warn {
color: #fff !important;
font-weight: bold;
}
.label.debug, .label.trace, .label.error, .label.keyword {
letter-spacing: 0;
} 
#errors, .messages, .metadata {
    width: 100%;
    border-spacing: 0;
}
.doc > * {
    margin: 0.7em 1em 0.1em 1em;
    padding: 0;
}
.doc > p, .doc > h1, .doc > h2, .doc > h3, .doc > h4 {
    margin: 0.7em 0 0.1em 0;
}
.doc > *:first-child {
    margin-top: 0.1em;
}
.doc table {
    border: 1px solid #ccc;
    background: transparent;
    border-collapse: collapse;
    empty-cells: show;
    font-size: 0.9em;
}
.doc table th, .doc table td {
    border: 1px solid #ccc;
    background: transparent;
    padding: 0.1em 0.3em;
    height: 1.2em;
}
.doc table th {
    text-align: center;
    letter-spacing: 0.1em;
}
.doc pre {
    font-size: 1.1em;
    letter-spacing: 0.05em;
    background: #f4f4f4;
}
.doc code {
    padding: 0 0.2em;
    letter-spacing: 0.05em;
    background: #eee;
}
.doc li {
    list-style-position: inside;
    list-style-type: square;
}
.doc img {
    border: 1px solid #ccc;
}
.doc hr {
    background: #ccc;
    height: 1px;
    border: 0;
}    
.parent-name {
    font-size: 0.7em;
    letter-spacing: -0.07em;
}
</style>
"""

report_javascript = """
    <script>
        function justalert(sc_name){
            var locator = 'tr.error_row[scenario_name="' + sc_name + '"]'
            var errRow = document.querySelector(locator)

            if ( errRow.style.display == "block") {
                errRow.style.display = "none";
            } else {
                errRow.style.display = "block";
            }
        }
    </script><script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script>
    function toggleSuite(suiteId) {
        toggleElement(suiteId, ['keyword', 'suite', 'test']);
    }
    function toggleTest(testId) {
        toggleElement(testId, ['keyword']);
    }
    function toggleKeyword(kwId) {
        toggleElement(kwId, ['keyword', 'message']);
    }
    function toggleElement(elementId, childrenNames) {
        var element = $('#' + elementId);
        var children = element.children('.children');
        children.toggle(100, '', function () {
            element.children('.element-header').toggleClass('closed');
        });
    }
    </script>
"""

# read the report json file
with open(input_file) as f:
    reports = json.load(f)


def calcuate_percent_passed():
    global scenario_failed_count
    global scenario_passed_count
    global scenario_count

    total_scenarios = scenario_failed_count + scenario_passed_count
    if total_scenarios != scenario_count:
        raise Exception("Number of total scenario count and failed + passed does not match.")
    try:
        pct_pass = round((scenario_passed_count / total_scenarios) * 100, 2)
    except ZeroDivisionError:
        pct_pass = 100

    return pct_pass


index = 0
substepindex = 0
totalelapsed_time = 0
elapsed_time = 0
for report in reports:
    passed_step = ""
    # verify each dictionary in the list is a feature
    _type = report['keyword']
    if _type == 'Feature':
        feature = report
    else:
        raise Exception("Unexpected top level keyword '{}'. Only expected 'Feature'".format(_type))

    # update the count of features passed/failed
    if feature['status'] == 'passed':
        feature_passed_count += 1
        feature_status_background = '#a5f1a5'
        status_type = 'pass'
    elif feature['status'] == 'failed':
        feature_failed_count += 1
        feature_status_background = '#ffaaaa'
        status_type = 'fail'
    else:
        raise Exception(
            "Unexpected status for feature. Expected 'passed' or 'failed' but found '{}'".format(feature['status']))

    # add the feature as one row in the html table
    all_rows = all_rows + feature_row_template.format(fe_name=feature['name'], fe_status=feature['status'].upper(),
                                                      fe_tags=feature['tags'],
                                                      feature_status_background=feature_status_background,
                                                      status_type=status_type)
    feature_count += 1
    scenarios = feature['elements']
    for s in scenarios:
        s_type = s['type']
        if s_type == 'scenario':
            scenario = s
        else:
            raise Exception(
                "Unexpected 'type' in list of elements for feature. Expected 'scenario' but found '{}'".format(s_type))

        scenario_name = scenario['name'].strip()
        if scenario['status'] == 'passed':
            scenario_passed_count += 1
            scenario_count += 1
            err_color = 'NA'
            UnderLine = 'NA'
            on_click = "justalert('{}')".format(scenario_name)
            sc_status_color = '#1c881c'
            sc_status_font_weight = 'none'
            status_type = 'pass'
        elif scenario['status'] == 'failed':
            scenario_failed_count += 1
            scenario_count += 1
            err_color = 'red'
            UnderLine = 'underline'
            on_click = "justalert('{}')".format(scenario_name)
            sc_status_color = 'red'
            sc_status_font_weight = 'bold'
            status_type = 'fail'
        else:
            raise Exception(
                "Unexpected 'status' for scenario. Expected 'passed' or 'failed'. Actual: {}. Scenario name: {}".format(
                    scenario['status'], scenario_name))
            # add the scenario row
        scr = "scr"
        index = index + 1
        src_count = scr + str(index)
        #print(src_count)
        steps = scenario['steps']
        #for step in steps:
            #if step['result']['status'] == 'passed':
                #print(step['result']['duration'])
                #totalelapsed_time = totalelapsed_time + step['result']['duration']
        #print(totalelapsed_time)
        all_rows = all_rows + scenario_row_template.format(on_click=on_click, sce_name=scenario_name,
                                                           sce_status=scenario['status'].upper(),
                                                           UnderLine=UnderLine,
                                                           err_color=err_color,
                                                           sce_tags=scenario['tags'],
                                                           sc_status_color=sc_status_color,
                                                           sc_status_font_weight=sc_status_font_weight,
                                                           status_type=status_type,
                                                           src_count=src_count,
                                                           index=index)
        if scenario['status'] == 'passed':
            steps = scenario['steps']
            substepcount = 0
            for step in steps:
                if step['result']['status'] == 'passed':
                    substepcount = substepcount + 1
                    totalelapsed_time = totalelapsed_time + step['result']['duration']
            #print("substep count", substepcount)
            for step in steps:
                try:
                    substepindex = substepindex + 1
                    if step['result']['status'] == 'passed':
                        status_type = 'pass'
                        title = str(step['keyword']) + " " + str(step['name'])
                        passed_step = passed_step + title
                        elapsed_time = step['result']['duration']
                        if substepindex == substepcount:
                            all_rows = all_rows + substep_row_template.format(on_click=on_click,
                                                                              passed_steps=passed_step.strip(),
                                                                              elapsed_time=elapsed_time,
                                                                              sce_status='</div>'.join(
                                                                                  step['result']['status'].upper()),
                                                                              sc_status_font_weight=sc_status_font_weight,
                                                                              status_type=status_type,
                                                                              substepindex=substepindex)
                            passed_step = " "

                        else:
                            all_rows = all_rows + substepfirst_row_template.format(on_click=on_click,
                                                                                   passed_steps=passed_step.strip(),
                                                                                   elapsed_time=elapsed_time,
                                                                                   sce_status=
                                                                                   step['result']['status'].upper(),
                                                                                   sc_status_font_weight=sc_status_font_weight,
                                                                                   status_type=status_type,
                                                                                   substepindex=substepindex)
                            passed_step = ""
                    else:
                        break
                except Exception as e:
                    print("Exception in steps:", e)
            #print("Final value", passed_step)
            substepindex = 0
        if scenario['status'] == 'failed':
            steps = scenario['steps']
            status_type = 'fail'
            for step in steps:

                try:
                    if step['result']['status'] == 'passed':
                        status_type = 'pass'
                        title = str(step['keyword']) + " " + str(step['name'])
                        passed_step = passed_step + title
                        elapsed_time = elapsed_time + step['result']['duration']
                        all_rows = all_rows + substep_row_template.format(on_click=on_click,
                                                                          passed_steps=passed_step.strip(),
                                                                          elapsed_time=elapsed_time,
                                                                          sce_status=step['result']['status'].upper(),
                                                                          sc_status_font_weight=sc_status_font_weight,
                                                                          status_type=status_type)
                        passed_step = ""

                    if step['result']['status'] == 'failed':
                        failed_step = step
                        status_type = 'fail'
                        all_rows = all_rows + error_row_template.format(sce_name=scenario_name,
                                                                        step_name=failed_step['keyword'] + ":" +
                                                                                  failed_step['name'] + "\n",
                                                                        now=now,
                                                                        err='<span>'.join(
                                                                            failed_step['result']['error_message']))
                        break
                except Exception as e:
                    print("Exception in steps:", e)
            # add the error detail row

# Build the report summary
percent_passed = calcuate_percent_passed()

report_html_template = f"""<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    {report_styles}
    <title>Unity Automation</title>
</head>
<body>
<div id="test_summary">
         <h1> Scenario Pass Rate: {percent_passed}% ({scenario_passed_count}/{(
        scenario_failed_count + scenario_passed_count)})</h1>
<table class="table-summary">
    <thead><th>DETAILS</th><th>TOTAL</th><th>PASSED</th><th>FAILED</th></thead>
    <tbody>
        <tr>
            <th>Features</th><td style="color:green"><center>{feature_count}</center></td>
            <td style="color:green"><center>{feature_passed_count}</center></td>
            <td style="color:red"><center>{feature_failed_count}</center></td>

        </tr>
        <tr>
            <th>Scenario</th>
            <td style="color:green"><center>{scenario_count}</center></td>
            <td style="color:green"><center>{scenario_passed_count}</center></td>
            <td style="color:red"><center>{scenario_failed_count}</center></td>

        </tr>
    </tbody>
</table>
</div>
<br>
<table>
    <thead></thead>
    <tbody>
    {all_rows}
</div>
</div>
    </tbody>
</table>

{report_javascript}
</body>
</html>"""

# reate the final report html
with open(output_html_path, 'w') as f:
    f.write(report_html_template)

# print("***************************")
# print("Feature count: {}".format(feature_count))
# print("feature_failed_count: {}".format(feature_failed_count))
# print("feature_passed_count: {}".format(feature_passed_count))
# print("scenario_count: {}".format(scenario_count))
# print("scenario_failed_count: {}".format(scenario_failed_count))
# print("scenario_failed_count: {}".format(scenario_failed_count))
# print("Output html: {}".format(output_html_path))
# print("***************************")
