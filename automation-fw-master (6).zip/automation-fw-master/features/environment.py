import logging
import os
import signal
import time

import psutil
from behave.fixture import fixture, use_fixture
from behave.formatter import pretty

from classes import common, data_files
from common_python import api_requests

logger = logging.getLogger(__name__)
ENVIRONMENT = os.environ.get("ENVIRONMENT_NAME")
THIS_DIR = os.path.dirname(os.path.abspath(__file__))


def to_be_skipped(context, effective_tags, skip_tags):
    # If any skip tags are passed in arguments like --tags wip or --tags descoped then it should not be skipped
    for or_tags in context.config.tags.ands:
        if any([skip_tag in or_tags for skip_tag in skip_tags]):
            return False

    # If any of the skip tags are in the effective tags, skip it (return True)
    return any([skip_tag in effective_tags for skip_tag in skip_tags])


def before_all(context):
    context.config.setup_logging()
    data_files.clear_files_hook("before_all")
    # Set JWT server auth allowing common_python to request JWTs
    api_requests.auth_handler.set_jwt_server_auth(common.config.jwt_server_auth)

    # Enable specific DEBUG logs. e.g.:
    #  $ behave -D debug_logs=classes.consumer_data,common_python.api_requests
    if logger_names := context.config.userdata.get("debug_logs"):
        for logger_name in logger_names.split(","):
            logging.info(f"Enable DEBUG logs for: '{logger_name}'")
            logging.getLogger(logger_name).setLevel(logging.DEBUG)

    # Discard debug logs of some external modules (keep INFO or higher)
    for logger_name in ["urllib3", "botocore", "boto3"]:
        logging.getLogger(logger_name).setLevel(logging.INFO)


def before_feature(context, feature):
    logger.info(f"=== Starting feature: {feature.filename}  {feature.name}")
    common.config.feature_start_time = time.time()


def before_scenario(context, scenario):
    # skip tests with tag @wip (unless CLI args include --tags=wip,<other_tags>)
    # Alternatively, behave (but not behavex) also support an extra argument --tags=-wip
    wip_tag = "wip_staging" if common.config.is_staging_env else "wip"
    descoped_tag = "descoped"
    skip_tags = [wip_tag, descoped_tag]

    if to_be_skipped(context, scenario.effective_tags, skip_tags):
        scenario.skip(reason=f"scenario is tagged @{wip_tag} or @{descoped_tag}")
        return

    context.e2e = False
    context.health_check_response = None
    data_files.clear_files_hook("before_scenario")
    if "no_JWT" not in context.tags:
        context.execute_steps('''
                    Given it contains a 'valid' JWT Token
                    ''')

    if "UPUA_3636" in context.tags:
        # in UPUA_3636 is invalid jwt scenario: it does not matter which id we pass
        context.service_order_id = "7890"
        context.subscription_id = "7890"

    if not hasattr(context, 'market_code'):
        context.market_code = 'VFUK'

    for tag in context.tags:
        if tag.startswith('customer:'):
            context.category = tag.split(':', 1)[1].upper()
            context.ucas_provider = context.category if context.category not in 'UNITY' else 'RINGCENTRAL'

    common.config.scenario_start_time = time.time()


def after_scenario(context, scenario):
    data_files.clear_files_hook("after_scenario")
    if hasattr(context, "subscription_exists"):
        logger.debug(f"deleting subscription {context.subscription_id}")
        context.execute_steps("""When user sends a request to 'unregister_events_subscription'
                                 Then user validates '204' response""")

    if scenario.status == 'failed':
        try:
            logger.debug(f"Scenario status is {scenario.status}")
            logger.debug(f"Service order id: {context.service_order_id}")
        except AttributeError:
            pass


def after_all(context):
    if os.getenv("KEEP_APPDIRECT_ALIVE") == "1":
        # behavex can launch multiple instances of behave, so the script that
        # stated appdirect stub should be in charge of terminating it
        pass
    elif data_files.exists("appdirect_stub_server"):
        pid = data_files.read("appdirect_stub_server")["pid"]
        data_files.clear("appdirect_stub_server")
        logging.info(f"Kill appdirect stub process: {pid}")
        if pid in psutil.pids():
            os.kill(pid, signal.SIGKILL)

    # Log this repo link + version (before the Failing scenarios summary)
    changelog_file = os.path.join(THIS_DIR, "..", "CHANGELOG.md")
    with open(changelog_file, "r") as f:
        first_line = f.readline().rstrip()
    logging.info(f"Tests repo and version: {first_line}")

    logger.info(f'Time of the run end: {time.time()}')


# TODO: implement Enum with all markets
def before_tag(context, tag):
    if tag == 'fixture.create_account':
        use_fixture(create_account, context)
    if tag == 'fixture.add_numbers':
        use_fixture(add_numbers, context)
    if tag.startswith("VF"):
        context.market_code = tag


@fixture
def create_account(context):
    logger.info('Account creation is requested using fixture')
    context.execute_steps(f"""
        Given new account is requested
    """)
    del context.payload


@fixture
def add_numbers(context):
    logger.info('Adding numbers is requested using fixture')
    context.execute_steps(f"""
                Given it contains a 'valid' JWT Token
                Given service order contains item to 'add' '15' numbers in resource type 'pool_range' and pool type 'Fixed'
                When customer sends an order to Middleware
        """)
    del context.payload
    del context.service_order


# Fix behave pretty formatter (reporting of step overwrites the last log lines)
pretty.up = lambda _: ""
