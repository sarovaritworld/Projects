import logging
import time
from pydoc import locate
from typing import Callable, cast

from behave import *
from jsonpath_ng.ext import parse

from classes import cac, common, database, numbers, payload, read_xmldata
from classes.api.requests import tmf_gateway
from classes.api.validations.api_response_validation import TMFServiceOrderGWValidationSet
from classes.common import validate_message
from classes.domain.account import MSOCAccount
from classes.kafka import producer_data
from classes.status_code_validator import StatusCodeValidator
from classes.utils import to_json
from features.steps import MSOCHandler, flowHandler, validationHandler
from features.steps.TMFHandler import request_is_sent_to_create_service_order
from features.steps.Validations import CACHandler

logger = logging.getLogger("CACHandler")


@given("service order is created for '{action}' CAC Configuration")
@given("service order is created for '{action}' CAC Configuration as '{order_type}' order")
@given("service order is created for '{action}' CAC Configuration that is '{cac_type}'")
@when("service order is created for '{action}' CAC Configuration that is '{cac_type}'")
def service_order_is_created_with_cac_configuration(context, action: str, cac_type: str = "different",
                                                    order_type='separate') -> None:
    if action == 'modify':
        context.modify_cac = True
    assert action in ["add", "modify"]
    assert cac_type in ["same_cac_id", "different", "added_for_number", "modify_fail"]

    reuse_cac_id = None
    if cac_type == "same_cac_id" and "cac_id" in context:
        reuse_cac_id = context.cac_id
        logger.debug(f"Reuse previous CAC ID: {reuse_cac_id}")
    elif cac_type == 'added_for_number':
        reuse_cac_id = context.number_cac_id
    elif cac_type == 'different':
        reuse_cac_id = cac.CAC_ID_PREFIX + read_xmldata.gen_contact(10)
    elif cac_type == 'modify_fail':
        reuse_cac_id = 'MOD5' + read_xmldata.gen_contact(8)

    # Generate new payload (with new random CAC ID)
    if "payload" in context and order_type == 'separate':
        del context.payload
    if hasattr(context, "margin_in"):
        context.previous_margin_in = context.margin_in
        context.previous_margin_out = context.margin_out
        context.previous_margin_all = context.margin_all
    context.payload = payload.msoc_add_cac_configuration(context, action)
    cac_characteristic = payload.ServiceOrderPayload(context.payload) \
        .get_characteristic(name="MsocCacConfiguration")

    if reuse_cac_id is not None:
        context.cac_id = cac_characteristic["value"]["cacId"] = reuse_cac_id
    if common.config.is_staging_env and hasattr(context, "number_pool_list"):
        time.sleep(20)


@given("CAC Configuration is updated with '{parameter}' as '{value}'")
def step_impl(context, parameter: str, value: str) -> None:
    context.cac_parameter_impaired = parameter

    # Get the parent dict containing the parameter to modify
    characteristic = payload.ServiceOrderPayload(context.payload) \
        .get_characteristic(name="MsocCacConfiguration")
    parent = characteristic if parameter in ("name", "valueType") else characteristic["value"]
    assert parameter in parent, f"No parameter {parameter} in {parent}"

    if value == "__MISSING__":
        parent.pop(parameter)
    elif value == "__NULL__":
        parent[parameter] = None
    elif ":" in value:
        type_as_str, value = value.split(":")
        type_as_object = cast(Callable, locate(type_as_str))
        parent[parameter] = type_as_object(value)
    else:
        parent[parameter] = value

    logging.info(f"Updated payload MsocCacConfiguration characteristic: {to_json(characteristic)}")
    logging.info(f"{context.payload}")


@given("CAC configuration has been applied")
def step_impl(context) -> None:
    service_order_is_created_with_cac_configuration(context, "add")
    request_is_sent_to_create_service_order(context)


@then("user validates '{expected_status:d}' response for CAC Configuration")
def validate_response_for_cac_configuration(context, expected_status: int) -> None:
    StatusCodeValidator.validate_status_code_response(context.response.status_code, expected_status)

    context.response_payload = context.response.json()
    context.service_order_id = context.response_payload.get('id')
    if context.service_order_id:
        context.marketplace_event_id = context.service_order_id + "/1"  # 1st service_order_item
    logger.info(f"Validate the response: {to_json(context.response_payload)}")
    validation_set = TMFServiceOrderGWValidationSet(context).endpoint_service_order_create(expected_status)
    logging.info(f"{validation_set=}")
    if not payload.has_modify_msoc_cac_configuration(context.payload):
        response_payload = context.response_payload
        keys_to_remove = ["burstMarginIn", "burstMarginOut", "burstMarginAll"]
        cac.remove_fields_for_add_cac(response_payload, keys_to_remove)
    else:
        response_payload = context.response_payload

    validate_message(response_payload, validation_set)


@given("CAC ID is updated with '{value}'")
def update_cac_id_add_msoc_numbers(context, value):
    index, item = payload.get_item_by_type(context.payload, "ucc.msoc.numbers")
    cac_value = value
    if value == "__NULL__":
        cac_value = None
    elif value == "blank":
        cac_value = ""
    elif ":" in value:
        type_as_str, value = value.split(":")
        type_as_object = cast(Callable, locate(type_as_str))
        cac_value = type_as_object(value)
    elif value == "valid_id":
        cac_value = context.number_cac_id = cac.CAC_ID_PREFIX + read_xmldata.gen_contact(10)
    elif value == "added_cac":
        cac_value = context.number_cac_id = context.cac_id

    if hasattr(context, 'modify_cac'):
        context.action = "modify"
    context.payload["serviceOrderItem"][index]["service"]["supportingResource"][0][
        "resourceCharacteristic"][0]['value']['cacId'] = cac_value
    logging.info(f"{context.payload}")


@given("kafka message for topic tmfmediator_command_add_msoccustomercac is sent with {parameter} as {value}")
def sent_kafka_to_tmfmediator_command_add_msoccustomercac(context, parameter, value):
    topic_name = "tmfmediator_command_add_msoccustomercac"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.marketplace_event_id = context.payload["msoc_customer_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    key_path = {"op_co_name": "msoc_customer_request.msoc_account.op_co_details.name",
                "op_co_customer_id": "msoc_customer_request.msoc_account.op_co_details.op_co_customer_id",
                "cac_id": "msoc_customer_request.msoc_account.cac_id"}

    if parameter not in key_path:
        raise NotImplementedError
    if value == "blank":
        value = ""
    parse(key_path[parameter]).update(context.payload, value)
    context.op_co_customer_id = (parse(key_path["op_co_customer_id"]).find(context.payload))[0].value
    context.market_code = (parse(key_path["op_co_name"]).find(context.payload))[0].value
    context.cac_id = (parse(key_path["cac_id"]).find(context.payload))[0].value
    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@given("kafka message for topic tmfmediator_command_apply_cacconfiguration is sent with {parameter} as {value}")
def send_kafka_to_tmfmediator_command_apply_cacconfiguration(context, parameter, value):
    topic_name = "tmfmediator_command_apply_cacconfiguration"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.marketplace_event_id = context.payload["cac_configuration_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    key_path = {"op_co_name": "cac_configuration_request.op_co_details.name",
                "op_co_customer_id": "cac_configuration_request.op_co_details.op_co_customer_id",
                "cac_id": "cac_configuration_request.cac_id",
                "cac_configuration": "cac_configuration_request.cac_configuration"}

    if parameter not in key_path:
        raise NotImplementedError
    if value == "blank":
        value = ""
    parse(key_path[parameter]).update(context.payload, value)
    if value == "missing":
        parse(key_path[parameter]).filter(lambda d: True, context.payload)
    else:
        context.op_co_customer_id = (parse(key_path["op_co_customer_id"]).find(context.payload))[0].value
        context.market_code = (parse(key_path["op_co_name"]).find(context.payload))[0].value
        context.cac_id = (parse(key_path["cac_id"]).find(context.payload))[0].value
        context.margin_in = context.payload["cac_configuration_request"]["cac_configuration"]["margin_in"]
        context.margin_out = context.payload["cac_configuration_request"]["cac_configuration"]["margin_out"]
        context.margin_all = context.payload["cac_configuration_request"]["cac_configuration"]["margin_all"]
        context.burst_margin_in = context.payload["cac_configuration_request"]["cac_configuration"]["burst_margin_in"]
        context.burst_margin_out = context.payload["cac_configuration_request"]["cac_configuration"]["burst_margin_out"]
        context.burst_margin_all = context.payload["cac_configuration_request"]["cac_configuration"]["burst_margin_all"]
    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@given("account already has CAC configuration added")
def create_account_with_cac_configuration(context):
    document = database.get_msoc_customer_documents("VFUK", billing_info="VFUK", with_cac=True)
    if document:
        MSOCHandler.update_context_from_msoc_customer_document(context, document)
        context.msoc_account = MSOCAccount.from_msoc_customer_document(document)
    else:
        MSOCHandler.process_msoc_create_account_for_market(context, "VFUK")
        service_order_is_created_with_cac_configuration(context, "add")
        context.existing_cac_id = context.cac_id
        context.response = tmf_gateway.Client().create_service_order(context.payload)
        validate_response_for_cac_configuration(context, expected_status=201)
        CACHandler.add_cac_to_msoc_customer(context)


@given("CAC configuration is processed in Middleware")
@given("CAC configuration is processed in Middleware for '{cac_type}' condition")
def cac_configuration_processed_in_middleware(context, cac_type='different'):
    if cac_type == 'modify_fail':
        context.fail_on_crf_req = True
    service_order_is_created_with_cac_configuration(context, "add", cac_type)
    context.existing_cac_id = context.cac_id
    context.response = tmf_gateway.Client().create_service_order(context.payload)
    validate_response_for_cac_configuration(context, expected_status=201)
    CACHandler.add_cac_to_msoc_customer(context)
    CACHandler.apply_cac_configuration_pending(context)


@When("Patch Configuration for same CAC ID is requested")
def patch_configuration_for_apply_cac_configuration(context):
    topic_name = "tmfmediator_command_apply_cacconfiguration"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.payload["cac_configuration_request"]["cac_id"] = context.cac_id
    context.payload["cac_configuration_request"]["op_co_details"]["name"] = context.market_code
    context.payload["cac_configuration_request"]["op_co_details"]["op_co_customer_id"] = context.op_co_customer_id
    context.margin_in = context.payload["cac_configuration_request"]["cac_configuration"]["margin_in"] = 20
    context.margin_out = context.payload["cac_configuration_request"]["cac_configuration"]["margin_out"] = 30
    context.margin_all = context.payload["cac_configuration_request"]["cac_configuration"]["margin_all"] = 40
    context.burst_margin_in = context.payload["cac_configuration_request"]["cac_configuration"]["burst_margin_in"] = 50
    context.burst_margin_out = context.payload["cac_configuration_request"]["cac_configuration"][
        "burst_margin_out"] = 60
    context.burst_margin_all = context.payload["cac_configuration_request"]["cac_configuration"][
        "burst_margin_all"] = 70
    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@given("{action} number is set to fail in crf immediately")
def set_add_number_to_fail_in_crf(context, action):
    prefix = "CAC500" if action == "add" else "RTRA"
    context.op_co_customer_id = context.payload['externalReference'][0]['id'] = prefix + read_xmldata.gen_contact(6)


@given("MSOC account with billing identifiers is created")
@given("MSOC account with billing identifiers is created to fail in '{action}' resource")
@given("MSOC account with billing identifiers is created for '{action}'")
def msoc_account_with_billing_created(context, action=None):
    MSOCHandler.create_payload_msoc_account(context, 'add', market_code="VFDE")
    MSOCHandler.create_payload_for_msoc_billing_identifiers(context, 'add')
    if action:
        set_add_number_to_fail_in_crf(context, action)
        context.fail_on_crf_req = True
    MSOCHandler.new_msoc_customer_onboarded(context)
    MSOCHandler.msoc_billing_request_processed(context)


@given("Add DDIs is processed with CAC ID")
@given("Add DDIs with '{pool_type}' is processed with CAC ID")
def add_number_processed_with_cac_id(context, pool_type='pool', cac_id='valid_id'):
    MSOCHandler.msoc_order_created_for_numbers(context, 'add', '5', pool_type, 'separate')
    item = payload.get_item_by_type_and_action(context.payload, 'ucc.msoc.numbers', "add")
    context.number_pool_list = numbers.get_pool(item)
    if hasattr(context, 'cac_id'):
        cac_id = "added_cac"
    update_cac_id_add_msoc_numbers(context, cac_id)
    flowHandler.customer_sends_an_order_to_middleware(context)
    MSOCHandler.validate_msoc_numbers_request(context, 'add')


@given("MSOC account is created with billing info, cac configuration and DDIs are added to it")
def msoc_account_created_with_billing_ddis_added(context):
    msoc_account_with_billing_created(context)
    cac_configuration_processed_in_middleware(context)
    add_number_processed_with_cac_id(context, cac_id='added_cac')
    context.previously_added_numbers = context.number_pool_list

@given("MSOC account is created with billing info, cac configuration and numbers are added into it")
def msoc_account_created_with_cac(context):
    context.cac_uplift = True
    msoc_account_created_with_billing_ddis_added(context)


@given("optional CAC configuration values are not set")
def optional_cac_configuration_values(context):
    context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"] = {
        "@type": "UccMsocCacConfiguration",
        "cacId": context.cac_id}
    context.margin_in = context.margin_out = context.margin_all = context.burst_margin_in = context.burst_margin_out = context.burst_margin_all = None


@then("CAC ID is stored in UC MW MSOC Customer inventory and SO is '{state}'")
def cac_id_stored(context, state):
    CACHandler.add_cac_to_msoc_customer_success(context)
    CACHandler.apply_cac_configuration_pending(context)
    validationHandler.validate_order_status(context, state)


@given("an MSOC account created and numbers are added with CAC configuration")
def add_numbers_to_msoc_account_with_cac(context, pool_type: str = "pool"):
    """
    Creates an MSOC account with cac info or reuse an existing account with cac info
    :param context:
    :param pool_type:
    :return:
    """
    create_account_with_cac_configuration(context)
    add_number_processed_with_cac_id(context, pool_type)
