import json
import logging

from behave import then

from classes import tmf, payload, numbers, common, milestone_validator, asserts, msoc_numbers, polling
from features.steps import TMFHandler


@then("the service order item '{item}' status is '{status}'")
def validate_service_order_status(context, item, status, customer='unity'):
    def get_service_order_state() -> str:
        TMFHandler.request_service_order_by_id(context)
        _, so_item = payload.get_item_by_type(context.response_payload, f'ucc.{customer}.{item}')
        state = so_item["state"]
        logging.info(f"Current service order state is '{state}'")
        return state

    polling.wait_until(
        get_service_order_state,
        f"Service order in state: {status}",
        stop_when=lambda state: state == status)


@then("Validate '{status}' RC ID in tenant info in serviceOrderItem")
def validate_rc_id_status_in_serviceorderitem(context, status):
    validation_set = {
        "serviceOrderItem.0.service.serviceCharacteristic.0.value.isvId": context.RC_ID,
        "serviceOrderItem.0.service.serviceCharacteristic.0.value.isvTenantStatus": "CONFIRMED" if status in (
            "completed", "inProgress") else "UNCONFIRMED",
    }
    for field_name, expected in validation_set.items():
        actual = common.get_field(context.response_payload, field_name)
        asserts.field_equals(actual, expected, field_name)


@then("service order status is '{expected_state}'")
def validate_order_status(context, expected_state: str):
    def get_service_order_state() -> str:
        context.execute_steps("""
            When user sends a request for 'get_service_order_by_id' to TMF Service Order Gateway Microservice
        """)
        state = context.response_payload["state"]
        logging.info(f"Current service order state is '{state}'")
        return state

    polling.wait_until(
        get_service_order_state,
        f"Service order in state: {expected_state}",
        stop_when=lambda state: state == expected_state)


@then("service order item is updated to '{status}' state")
def update_service_order_item_status(context, status):
    asserts.field_equals(context.response_payload['serviceOrderItem'][0]['state'], status, 'Service order item state')


@then("all milestones achieved for '{outcome}'")
def validate_milestones_achieved(context, outcome):
    context.milestones = tmf.get_milestones(context, outcome)

    if hasattr(context, 'patch_milestones'):
        context.milestones = context.milestones + context.patch_milestones

    logging.debug(f"expected milestones: {context.milestones}")
    milestone_validator.validate_milestones(context.milestones, context)


@then("error message is present for '{outcome}'")
def validate_error_message(context, outcome):
    # if you need to use this step in python files, please call the below function instead
    tmf.validate_error_message(context, outcome)


@then("notes updated for '{item}'")
def update_item_notes(context, item):
    logging.debug(f'validating note for {item}')
    item = json.loads(item)

    # we need to perform jira validation only for
    if payload.jira_note_to_validate(item):
        # removing note validation for jira for now
        pass

    if hasattr(context, 'patch_milestones'):
        for patch in context.patch_milestones:
            tmf.validate_patch_note(patch, item)
    # TODO: fix note validation
    # if payload.type_of_soi(item) == 'ucc.unity.numbers' and numbers.get_numbers_pooltype(item) in numbers.nonautomated_pooltype_list and payload.get_action_item(item) == "add":
    #     tmf.validate_jira_note(context, item)


@then("notes updated for add account '{outcome}'")
def update_add_account_notes(context, outcome):
    logging.debug('item is add account')
    if hasattr(context, 'create_account_milestones'):
        tmf.validate_unity_create_account_notes(context, context.response_payload, outcome)
    else:
        logging.debug('Process failed on creating account, pass')


@then("notes updated for add numbers '{outcome}'")
def update_add_numbers_notes(context, outcome):
    logging.debug('item is add numbers')
    if hasattr(context, 'add_numbers_milestones') and len(context.add_numbers_milestones) > 0:
        tmf.validate_add_numbers_notes(context, context.response_payload, outcome)
    else:
        logging.error('Process failed on adding numbers, pass')


# Then user validates status as 'completed' for 'Presentation' number item
@then("user validates status as '{status}' for '{pool_type}' number item")
def validate_status_for_number(context, status, pool_type):
    so_items = payload.get_items_by_type(context.response_payload, "ucc.unity.numbers")
    index, so_item = numbers.get_number_item_by_pool_type(so_items, pool_type)
    tmf.validate_service_order_status(so_item, status)


# Then user validates MSOC customer status as 'completed'
@then("user validates MSOC numbers status as '{status}'")
@then("user validates MSOC customer status as '{status}'")
def validates_msoc_customer_or_number_status(context, status):
    status_summary = tmf.get_status(status)
    logging.debug(f"validating status: {status_summary}")
    context.execute_steps(f"""
        Then service order status is '{status_summary}'
    """)
    logging.debug("Checking for MSOC Milestones")
    context.milestones = tmf.get_milestones(context, status)
    if hasattr(context, 'patch_milestones'):
        context.milestones = context.milestones + context.patch_milestones

    logging.debug(f"expected milestones: {context.milestones}")
    milestone_validator.validate_milestones(context.milestones, context)

    logging.debug("Checking for MSOC notes")

    if payload.has_add_msoc_account(context.payload):
        tmf.validate_msoc_create_account_notes(context, context.response_payload, status)

    if status in ['duplicate_opco_customer_id',
                  'duplicate_ms_teamns_tenant_id',
                  'failed_different_billing_info',
                  'failed_billing_info_not_set']:
        tmf.validate_error_message(context, status)

    if payload.has_add_msoc_billing_identifers(context.payload):
        tmf.validate_msoc_country_billing_notes(context, context.response_payload, status)

    if msoc_numbers.has_add_msoc_numbers(context.payload):
        tmf.validate_add_numbers_notes(context, context.response_payload, status)

    if msoc_numbers.has_delete_msoc_numbers(context.payload):
        tmf.validate_delete_numbers_notes(context, context.response_payload, status)
