from behave import *

from classes import read_xmldata
from classes.status_code_validator import StatusCodeValidator


def cleanup_payload(context):
    del context.payload
# Then user validates 'correct' license count in 'ringcentral_respond_changelicense' in Middleware
@then("user validates '{validation_type}' license count in '{topic_name}' in Middleware")
def validate_license_count_for_topic(context, validation_type, topic_name):
    if topic_name == "ringcentral_respond_changelicense":
        if validation_type == "correct":
            updated_No_of_lic = context.consumer_payload["license_changed"]["quantity_added"]
            total_no_of_lic = -(int(context.initial_license) - int(context.new_license))

            assert total_no_of_lic == updated_No_of_lic, "Change License quantity = {} does not match with {} ".format(
                updated_No_of_lic, total_no_of_lic)


# And user stores Account Location ID for 'First' master device
@then("user stores Account Location ID for '{device_type}' master device")
def store_account_location_id(context, device_type):
    if device_type == 'First':
        context.First_MW_location_id = context.accountLocationID
        context.First_subscriptionId_uuid = context.subscriptionId_uuid
        print("First_location_id = {} and First_subscriptionId_uuid = {}".format(context.First_MW_location_id,
                                                                                 context.First_subscriptionId_uuid))
        print("")
    elif device_type == 'Second':
        context.Second_MW_location_id = context.accountLocationID
        context.Second_subscriptionId_uuid = context.subscriptionId_uuid
        print("Second_location_id = {} and Second_subscriptionId_uuid = {}".format(context.Second_MW_location_id,
                                                                                   context.Second_subscriptionId_uuid))
        print("")
    else:
        assert 1 == 0, "Unable to retrieve Location ID"


# And validate user receives new RingCentralID
@then("validate user receives new RingCentralID")
def validate_new_rcid(context):
    try:
        context.RC_ID = context.consumer_payload["completed_order"]["account"]["ucas_account_id"]
        read_xmldata.update_xml("RC_ID", context.RC_ID)
    except KeyError:
        print("KeyError for topic: " + context.kafka_topic_name + " : Please check the keys in JSON")
    read_xmldata.update_xml("RC_ID", context.RC_ID)


# And user stores new license for first time
@then(u"user stores new license for first time")
def store_new_license_first_time(context):
    context.new_license1 = context.new_license
    print(" context.new_license1 -- > ", context.new_license1)
    print("")


# And user stores new license for second time
@then(u"user stores new license for second time")
def store_new_license_again(context):
    context.new_license2 = context.new_license
    print(" context.new_license2 -- > ", context.new_license2)
    print("")


# Then user validates 'not_implemented' response
@then("user validates '{status_code}' response")
def validate_status_response(context, status_code):
    StatusCodeValidator.validate_status_code_response(context.response.status_code, status_code)


# Then user validates the response with an empty array
@then("user validates the response with an empty array")
def validate_response_with_empty_array(context):
    data = context.response.json()
    assert isinstance(data, list) and not data, f"Response should be an empty list: {data}"

