"""
Steps to test the formatters.
"""
import logging

from behave import *

from classes import common

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


class CustomException(Exception):
    """A non-builtin exception.
    
    Note: Exception names are reported differently (i.e. with the full
    dotted path) compared to builtin exceptions.
    """


@then("nested '{number}' levels, fail with '{failure_type}'")
def step_impl(context, number, failure_type):
    """Test multiple failure types in nested steps."""
    logger.info(f"start nested step")
    n = int(number)
    if n > 0:
        context.execute_steps(f"""
            Then nested '{n-1}' levels, fail with '{failure_type}'
        """)
    elif failure_type == "assert with message":
        assert "actual" == "expected", "message describing assert failure"
    elif failure_type == "assert without message":
        assert "actual" == "expected"
    elif failure_type == "exception with message":
        raise CustomException("message describing exception")
    elif failure_type == "exception without message":
        raise CustomException
    elif failure_type == "builtin exception with message":
        raise ValueError("message describing exception")
    elif failure_type == "builtin exception without message":
        raise ValueError
    elif failure_type == "with explicit cause":
        logger.error("error occurred: this should be reported as failure cause")
        raise ValueError("this should NOT be reported as failure cause")
    else:
        raise NotImplementedError(f"{failure_type=}")
