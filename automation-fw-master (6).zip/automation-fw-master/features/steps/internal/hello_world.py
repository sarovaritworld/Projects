"""
Steps implementation the Hello world example.
"""
import logging

from behave import *

from classes import calc, common

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("we have the number '{number1}'")
def step_impl(context, number1: int):
    context.number1 = int(number1)

@when("the task is to '{task}' '{number2}'")
def step_impl(context, task, number2: int):
    if "add" in task:
        context.result = calc.add(context.number1, int(number2))
    if "subtract" in task:
        context.result = calc.subtract(context.number1, int(number2))

@then("the answer is '{result}'")
def step_impl(context, result: int):
    try:
        assert(context.result == int(result))
    except ArithmeticError:
        print("Result was " + str(context.result) + "but was expecting" + str(result))
    finally:
        print("Result was " + str(context.result) + " but was expecting " + str(result))

@then("validate the context state")
def step_impl(context):
    context.new_variable = 1

    # Display context layers, showing how properties are saved/cleared
    # per layer (testrun / feature / scenario)
    context._dump()

    # Properties that should be present
    assert "new_variable" in context, \
        "context should contain properties set in this step"
    assert "number1" in context, \
        "context should contain properties set in previous steps of this scenario"
    assert "health_check_response" in context, \
        "context should contain properties set for this scenario (in before_scenario())"
    assert "is_devenv" in context, \
        "context should contain properties set for this test run (in before_all())"
    
    # Properties that should have been cleared
    assert "result" not in context, \
        "context should NOT contain properties set in previous scenarios"
