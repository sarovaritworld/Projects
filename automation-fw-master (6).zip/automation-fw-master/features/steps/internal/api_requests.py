"""
Steps to test the API requests.
"""
import logging

from behave import *

from classes import common
from common_python import api_requests
from classes.status_code_validator import StatusCodeValidator

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("api_requests request data is prepared with method '{method}' and an invalid URL")
def step_impl(context, method: str):
    context.method = method
    context.kwargs = {"url": "https://www.invalid_url.aaaaaaa"}


@given("api_requests request data is prepared with method '{method}' and an URL for expected code '{expected_code:d}'")
def step_impl(context, expected_code: int, method: str):
    """A valid URL.
    
    See this testing API doc at https://httpbin.org/
    https://httpbin.org/status/<status> supports all HTTP methods, and
    will return a response code <status>
    """
    context.method = method
    context.kwargs = {"url": f"https://httpbin.org/status/{expected_code}"}
    if method == "POST":
        context.kwargs["data"] = {"one": 1, "two": 2}


@when("api_requests sends the request")
def step_impl(context):
    try:
        fct = getattr(api_requests, context.method.lower())
    except KeyError:
        raise NotImplementedError(f"{context.method=}")

    try:
        context.result = fct(**context.kwargs)
    except Exception as ex:
        context.result = ex


@when("any exception caught is raised")
def step_impl(context):
    if isinstance(context.result, Exception):
        raise context.result


@when("api_requests sends the request with content type '{content_type}'")
def step_impl(context, content_type: str):
    if content_type == "json":
        context.kwargs["json"] = context.kwargs.pop("data", None)
    elif content_type == "x-www-form-urlencoded":
        pass  # nothing to do: this is the default
    else:
        raise NotImplementedError(f"{content_type=}")
    context.execute_steps("""
        When api_requests sends the request
    """)


@then("api_requests should raise an exception")
def step_impl(context):
    assert isinstance(context.result, api_requests.APIRequestError), \
        "api_requests should raise an Exception"


@then("api_requests response code should be '{expected_code:d}'")
def step_impl(context, expected_code: int):
    logger.info(f"The expected code is: {expected_code}")
    assert isinstance(context.result, api_requests.Response), \
        "api_requests should return a response"
    StatusCodeValidator.validate_status_code_response(context.result.status_code, expected_code)


@then("api_requests should have sent the content using type '{content_type}'")
def step_impl(context, content_type: str):
    assert isinstance(context.result, api_requests.Response), \
        "api_requests should return a response"

    logger.info(f"Request body: {context.result.request.body}")
    logger.info(f"Request headers: {context.result.request.headers}")
    assert f"application/{content_type}" in context.result.request.headers["Content-Type"], \
        f"Content-Type should be {content_type}"
