import datetime
import logging

from behave import given, then

from classes import common, crf, numbers, operations, tmf
from classes.common import create_or_update_key
from classes.data_factory.countries_data_manager import get_different_market_code
from classes.domain.account import TPMAccount
from classes.domain.numbers import PoolType, TpmResourceType
from classes.kafka import KafkaTopics, consumer_data, topic_validator
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF import Action
from classes.payload_generators.TMF.number_generator import NumbersOrderItem, NumbersPayloadGenerator
from features.steps import CRFHandler, TMFHandler, TpmHandler
from features.steps.TMFHandler import retrieve_data_in_topic_with_error

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("TPM order is sent to add '{quantity}' numbers in '{resource_type}'")
def tpm_order_add_numbers(context, quantity, resource_type):
    if common.config.is_dev_env:
        TpmHandler.tpm_account_already_onboarded(context, 'VFUK')
    else:
        TpmHandler.tpm_account_created(context)  # prerequisite step in case env is Test or Staging
    TpmHandler.tpm_order_created_for_numbers(context, "add", quantity, resource_type, "separate")
    if common.config.is_staging_env:
        TMFHandler.request_is_sent_to_create_service_order(context)
        TpmHandler.tpm_numbers_successfully_provisioned(context)


@given("delete tpm '{resource_type}' numbers order is updated with '{field}' as '{value}'")
def update_tpm_delete_number_order(context, resource_type, field, value):
    context.tpm_account = TPMAccount(market_code=context.market_code)
    context.tpm_numbers = NumbersOrderItem(
        resource_type=TpmResourceType[resource_type],
        pool_type=PoolType.Mobile
    )
    logger.debug(context.tpm_numbers)
    context.payload = NumbersPayloadGenerator(context.tpm_account,
                                              context.tpm_numbers,
                                              Action('delete')
                                              ).to_dict()
    logger.debug(context.payload)
    rc_path = 'resourceCharacteristic.[0].'
    paths = {
        "null_id": "id",
        "null_category": "category",
        "null_resourceCharacteristic": "resourceCharacteristic",
        "invalid_resourceCharacteristic_name": f"{rc_path}.name",
        "invalid_resourceCharacteristic_valueType": f"{rc_path}.valueType",
        "invalid_resourceCharacteristic_type": f"{rc_path}.value.@type",
        "null_resourceCharacteristic_pool": f"{rc_path}.value.pool",
        "null_resourceCharacteristic_poolRange": f"{rc_path}.value.poolRange",
        "null_resourceCharacteristic_poolRange_from": f"{rc_path}.value.poolRange.[0].from",
        "resourceCharacteristic_poolRange_to": f"{rc_path}.value.poolRange.[0].to",
        "invalid_resourceCharacteristic_value_both_resource_types": f"{rc_path}.value",
        "invalid_poolType": f"{rc_path}.value.poolType"
    }
    field = paths.get(field)

    match value:
        case '__NULL__':
            value = ' '
        case 'another_country':
            value = numbers.generate_phone_number(get_different_market_code(context.market_code))
        case 'less_than_to':
            value = numbers.get_end_range_number(context.tpm_numbers.from_range_number, -2)
        case 'both_resource_types':
            value = {'pool': [context.tpm_numbers.pool],
                     'pool_range': {
                         'from': context.tpm_numbers.from_range_number,
                         'to': context.tpm_numbers.to_range_number
                     }}
    create_or_update_key(context.payload, f'$..supportingResource.[0].{field}', value)


@then("numbers have been successfully deleted")
def tpm_numbers_successfully_deleted(context):
    if 'additional_range' in context:
        context.additional_range_numbers = numbers.get_pool_range(
            context.additional_range['from'],
            context.additional_range['to'])
        # If not already added while validating add numbers
        unsaved_numbers = [number for number in context.additional_range_numbers
                           if number not in context.tpm_numbers.pool]
        context.tpm_numbers.pool = context.tpm_numbers.pool + unsaved_numbers
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    operations.validate_operations_order("ucc.tpm.numbers", "delete", context.service_order_id)
    TMFHandler.retrieve_and_validate(context, 'tmfmediator_create_deletenumbers')
    if 'additional_range' in context:
        retrieve_data_in_topic_with_error(context, KafkaTopics.numbermanagement_command_delete_crfnumber.name,
                                          'additional_range')
    else:
        TMFHandler.retrieve_and_validate(context, 'numbermanagement_command_delete_crfnumber')

    context.crf_request_id = crf.get_resource_order_id(context.middleware_correlation_id)
    TpmHandler.crf_processing_delete_numbers(context, "completed")
    TMFHandler.retrieve_and_validate(context, KafkaTopics.crfgateway_event_crfnumber_deleted.name)

    if 'additional_range' in context:
        retrieve_data_in_topic_with_error(context, KafkaTopics.numbermanagement_event_numbers_deleted.name,
                                          'additional_range')
    else:
        TMFHandler.retrieve_and_validate(context, KafkaTopics.numbermanagement_event_numbers_deleted.name)

    service_order = tmf.get_service_order(context.service_order_id)
    logger.info(service_order)

    TMFHandler.validate_final_state(context, 'completed')


@then("delete numbers have been failed with '{error_type}' and order is suspended")
def tpm_delete_numbers_failed(context, error_type):
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfmediator_create_deletenumbers.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.numbermanagement_command_delete_crfnumber.name)
    TpmHandler.delete_tpm_numbers_fails_crf(context, error_type)
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.numbermanagement_event_numbers_deleted.name)
    topic_validator.KafkaTopicValidator(context).numbermanagement_event_numbers_deleted(error_type=error_type,
                                                                                        state='FAILED_PROVISIONING')
    TMFHandler.validate_final_state(context, 'inProgress')


@then("numbers have been successfully deleted using DEP callback")
def tpm_numbers_deleted_using_dep_callback(context):
    context.scenario_start_time = datetime.datetime.now()
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfmediator_create_deletenumbers.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.numbermanagement_command_delete_crfnumber.name)
    context.crf_request_id = crf.get_resource_order_id(context.middleware_correlation_id)
    context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.crfstub_process_resourceorder.name)
    context.crf_stub_payload = context.consumer_payload
    TpmHandler.dep_notification_sent_with_status(context, 'inProgress')
    CRFHandler.notification_not_received(context)
    CRFHandler.crf_dep_called_for_status_time(context, 1)
    CRFHandler.validate_crf_request_state_db(context, 'completed')
    CRFHandler.set_field_to_value(context, 'isCrfRequestSuccessful', 'true')
    CRFHandler.set_last_timestamp_to_current(context)
    context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.crfgateway_event_crfnumber_deleted.name)
    KafkaTopicValidator(context).validate_topic(KafkaTopics.crfgateway_event_crfnumber_deleted.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.numbermanagement_event_numbers_deleted.name)
    service_order = tmf.get_service_order(context.service_order_id)
    logger.info(service_order)
    TMFHandler.validate_final_state(context, 'completed')
