import logging

from behave import given, then

from classes import common
from classes.api.validations.api_response_validation import TMFServiceOrderGWValidationSet
from classes.common import create_or_update_key, validate_message
from classes.kafka import KafkaTopics
from classes.status_code_validator import StatusCodeValidator
from classes.utils import to_json
from features.steps import TMFHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("user adds pod location '{pod_location}' in SO")
def user_adds_pod_location_in_so(context, pod_location: str):
    if pod_location == "blank":
        pod_location = ""
    context.pod_location = context.unity_account.pod_location = pod_location
    create_or_update_key(context.payload, "serviceOrderItem.[0].service.serviceCharacteristic.[0].value.podLocation",
                         pod_location)


@then("create unity account request is processed in Middleware with '{pod_location}'")
def create_unity_account_request_processed_in_middleware_with_pod_location(context, pod_location: str):
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfmediator_command_create_initialorder.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.ordermanagement_command_create_initialorder.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.ringcentral_event_initialorder_created.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.ordermanagement_event_account_created.name)


@then("user validates the error response for invalid pod location '{invalid_pod_location}' from TMF Service Order API "
      "Gateway")
def validate_response_payload_and_error(context, invalid_pod_location: str):
    context.invalid_pod_location = invalid_pod_location
    StatusCodeValidator.validate_status_code_response(context.response.status_code, 400)
    context.response_payload = context.response.json()
    logger.info(f"Validate the response: {to_json(context.response_payload)}")
    validation_set = TMFServiceOrderGWValidationSet(context).endpoint_service_order_create(400)
    validate_message(context.response_payload, validation_set)
