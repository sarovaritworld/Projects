import logging
import re

from behave import given, then, when
from jsonpath_ng import parse

from classes import account, asserts, common, crf, data_files, database, errors, numbers, operations, payload, polling, \
    read_xmldata, s3_bucket, tmf, tpm
from classes.api.validations.api_response_validation import TMFServiceOrderGWValidationSet
from classes.common import validate_message, create_or_update_key
from classes.data_factory import countries_data_manager
from classes.domain.account import TPMAccount, RelatedParty
from classes.domain.numbers import NumbersOrderItem, PoolType, TpmResourceType, TPMNumbers
from classes.kafka import KafkaTopics, consumer_data, producer_data, topic_validator
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF import Action
from classes.payload_generators.TMF.account_generator import TPMAccountPayloadGenerator
from classes.payload_generators.TMF.number_generator import NumbersPayloadGenerator
from classes.status_code_validator import StatusCodeValidator
from classes.tmf import get_status
from classes.utils import to_json
from common_python.stub_accounts.stub_accounts import StubAccounts
from features.steps import CRFHandler, TMFHandler, TPMSNOWHandler, TpmCallbackHandler, databaseHandler, idmapperHandler, \
    kafkaHandler, numbersHandler, validationHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


def validate_notification_email(context, mail, operation="add_number"):
    actual_mail_content = mail.get_body().get_content()
    logger.info(mail)
    tenant_id = context.existing_tpm_document["msTeamsTenantId"] if getattr(context, 'existing_tpm_document', False) \
        else context.tpm_account.tenant_id
    expected_mail = data_files.read_config("tpm_email_notification.yml", "email_notification")
    values_to_update = [("market_code", context.tpm_account.market_code),
                        ("op_co_customer_id", context.tpm_account.op_co_customer_id),
                        ("country_code", context.tpm_account.related_party.country_code),
                        ("name", context.tpm_account.name),
                        ("ms_teams_tenant_id", tenant_id), ("bgid", context.tpm_account.bgid)]
    if operation == "cease":
        values_to_update.append(("service", "account"))
        values_to_update.append(("added to", "removed from"))
    for value in values_to_update:
        logger.info(value)
        expected_mail = expected_mail.replace(*value)
    asserts.equals(re.sub(r"[\n\t\s]*", "", actual_mail_content), re.sub(r"[\n\t\s]*", "", expected_mail),
                   f"email content for TPM notification")


@given("service order is created for add a TPM customer")
def create_tpm_customer_service_order(context, market_code='VFDE', error_type=None, new_data_model_enable=None):
    market_code = 'VFUK' if common.config.is_staging_env else market_code
    op_co_customer_id = getattr(context, 'op_co_customer_id', None)

    if error_type is not None:
        stub_accounts = StubAccounts()
        if error_type == 'tpm_bad_request':
            op_co_customer_id = stub_accounts.dep.cease_tpm_customer_bad_request_prefix + read_xmldata.gen_opco(
                marketplace='TMF')
        else:
            op_co_customer_id = stub_accounts.dep.cease_tpm_customer_server_error_prefix + read_xmldata.gen_opco(
                marketplace='TMF')

    context.tpm_account = TPMAccount(market_code=market_code, op_co_customer_id=op_co_customer_id) \
        if not new_data_model_enable else TPMAccount(market_code=context.market_code,
                                                     op_co_customer_id=op_co_customer_id,
                                                     related_party=context.related_party)

    if common.config.is_staging_env:
        context.tpm_account.tenant_id = account.EXISTING_TPM_CUSTOMER['staging_tenant']
    context.market_code = context.tpm_account.market_code
    context.payload = TPMAccountPayloadGenerator(tpm_account=context.tpm_account, action=Action.add).to_dict()


@given("service order is created with '{invalid_field}' to add TPM account")
def create_tpm_customer_service_order_with_invalid_field(context, invalid_field: str) -> None:
    create_tpm_customer_service_order(context)
    tpm_characteristic = payload.ServiceOrderPayload(context.payload) \
        .get_characteristic(name="TpmCustomerInfo")
    related_party = context.payload['relatedParty'][0]
    context.invalid_tpm_data = 'tpm_customer'
    if invalid_field == 'blank_TpmCustomerInfo':
        tpm_characteristic['name'] = ''
    elif invalid_field == 'blank_customerID':
        context.invalid_tpm_data = 'customer_id'
        context.payload['externalReference'][0]['id'] = ''
    else:
        error_type, obj, field = invalid_field.split("_")
        if obj == 'TpmCustomer':
            characteristic = tpm_characteristic['value']
        elif obj == 'relatedParty':
            context.invalid_tpm_data = 'related_party'
            characteristic = related_party
        else:
            raise NotImplementedError

        if error_type == 'blank':
            characteristic[field] = ''
        elif error_type == 'long':
            characteristic[field] = account.LONG_NAME_ACCOUNT['company_name']
        elif error_type == 'invalid':
            values = {"marketCode": "VFGB", "tenantId": "tenant_id", "@type": "TpmCustomerInfo", "countryCode": "ABC"}
            assert field in values, "Parameter"
            characteristic[field] = values[field]
    logger.info(context.payload)


@then("TMF Service Order API Gateway sends the error response for '{expected_status:d}' for tpm customer")
def validated_error_response_for_tpm_customer(context, expected_status: int) -> None:
    StatusCodeValidator.validate_status_code_response(context.response.status_code, expected_status)

    context.response_payload = context.response.json()
    context.service_order_id = context.response_payload.get('id')
    logger.info(f"Validate the response: {to_json(context.response_payload)}")
    validation_set = TMFServiceOrderGWValidationSet(context).endpoint_service_order_create(expected_status)
    validate_message(context.response_payload, validation_set)


@then("a new TPM customer is successfully created in the Middleware")
def tpm_customer_created_in_middleware(context):
    if context.service_order_id:
        context.marketplace_event_id = context.service_order_id + "/1"  # 1st service_order_item
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    common.update_middleware_correlation_id(context)
    common.save_marketplace_event_id(context)

    operations.validate_operations_order('ucc.tpm.customer', 'add', context.service_order_id)
    # Validate 'tmfmediator_command_create_tpmcustomer' topic
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_create_tpmcustomer')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_create_tpmcustomer()

    # BGID is stored in database
    databaseHandler.bgid_stored_for_tpm_customer(context)

    if tpm.is_snow_onboarding(context):
        TPMSNOWHandler.validate_itsm_info_in_id_mapper_api(context)

    # Validate 'idmapper_event_tpmcustomer_created' topic
    data_validated_in_idmapper_event_tpmcustomer_created(context, parameter=None, value=None)
    if not (hasattr(context, "order_type") and context.order_type == "complex"):
        validate_service_order_tpm(context, 'completed')


@given("service order is created to add TPM account with an existing '{dupe_id}' id and same market")
@given("service order is created to add another TPM account with same '{dupe_id}' id but for {market}")
def create_service_order_with_existing_id(context, dupe_id, market="VFDE"):
    if not hasattr(context, "existing_tpm_document"):
        context.existing_tpm_document = database.get_tpm_account_document({
            "vodafoneId": context.tpm_account.op_co_customer_id, "market": context.tpm_account.market_code})
    context.dupe_id = f"duplicate_{dupe_id}"
    op_co_customer_id = context.existing_tpm_document["vodafoneId"] if dupe_id == 'customer' else None
    tenant_id = context.existing_tpm_document["msTeamsTenantId"] if dupe_id == 'tenant' else None
    context.tpm_account = TPMAccount(market_code=market, op_co_customer_id=op_co_customer_id,
                                     bgid=context.existing_tpm_document["bgid"],
                                     tenant_id=tenant_id)
    context.payload = TPMAccountPayloadGenerator(tpm_account=context.tpm_account, action=Action.add).to_dict()


@given("a TPM account is already onboarded for {market}")
def tpm_account_already_onboarded(context, market="VFDE"):
    context.existing_tpm_document = tpm.get_existing_tpm_account({"market": market})
    context.tpm_account = TPMAccount(market_code=market, op_co_customer_id=context.existing_tpm_document["vodafoneId"],
                                     bgid=context.existing_tpm_document["bgid"],
                                     tenant_id=context.existing_tpm_document["msTeamsTenantId"],
                                     name=context.existing_tpm_document["name"])

@given("Payload is created and sent to tmfmediator_command_create_tpmcustomer topic")
@given("kafka message for topic tmfmediator_command_create_tpmcustomer is sent with {parameter} as {value}")
def payload_created_sent_to_tmfmediator_command_create_tpmcustomer(context, parameter=None, value=None):
    context.tpm_account = TPMAccount(market_code='VFDE')
    topic_name = "tmfmediator_command_create_tpmcustomer"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.event_type = context.payload["header"]["event_type"]
    context.marketplace_event_id = context.payload["tpm_customer_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    key_path = {"op_co_name": "tpm_customer_request.tpm_customer.op_co_details.name",
                "op_co_customer_id": "tpm_customer_request.tpm_customer.op_co_details.op_co_customer_id",
                "country_code": "tpm_customer_request.tpm_customer.op_co_details.country_code",
                "long_name": "tpm_customer_request.tpm_customer.name",
                "tenant_id": "tpm_customer_request.tpm_customer.ms_teams_tenant_id"}

    if value == "blank":
        value = ""
        parse(key_path[parameter]).update(context.payload, value)
    elif value == "invalid":
        value = account.LONG_NAME_ACCOUNT['company_name']
        parse(key_path[parameter]).update(context.payload, value)
    elif value == "existing":
        value = account.EXISTING_TPM_CUSTOMER['account_number']
        parse(key_path["op_co_customer_id"]).update(context.payload, value)
        parse(key_path["tenant_id"]).update(context.payload, context.tpm_account.tenant_id)
    else:
        context.tpm_account = TPMAccount(market_code='VFDE')
        parse(key_path["op_co_customer_id"]).update(context.payload, context.tpm_account.op_co_customer_id)
        parse(key_path["op_co_name"]).update(context.payload, context.tpm_account.market_code)
        parse(key_path["tenant_id"]).update(context.payload, context.tpm_account.tenant_id)
        parse(key_path["country_code"]).update(context.payload, context.tpm_account.related_party.country_code)

    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@then("data is validated in idmapper_event_tpmcustomer_created topic")
@then("data is validated in idmapper_event_tpmcustomer_created for {parameter} and {value}")
def data_validated_in_idmapper_event_tpmcustomer_created(context, parameter=None, value=None):
    topic_name = 'idmapper_event_tpmcustomer_created'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    error_type = f"{parameter}_{value}" if parameter else None
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name, error_type=error_type)


@then("TPM customer is failed to create in Middleware")
def tpm_customer_processing_with_error(context):
    if context.service_order_id:
        context.marketplace_event_id = context.service_order_id + "/1"  # 1st service_order_item
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    common.update_middleware_correlation_id(context)
    common.save_marketplace_event_id(context)

    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_create_tpmcustomer')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_create_tpmcustomer()

    data_validated_in_idmapper_event_tpmcustomer_created(context, parameter='tenant_id', value='duplicate')


@given(
    "TPM Order is created for '{action}' '{quantity}' numbers in pool type '{resource_type}' as '{order_type}' order")
def tpm_order_created_for_numbers(context, action, quantity, resource_type, order_type=None, op_co_customer_id=None, number_provider=None, number_country=None ):
    if order_type == 'separate':
        context.payload = None
        if not hasattr(context, 'tpm_account'):
            context.tpm_account = TPMAccount(market_code='VFDE', op_co_customer_id=op_co_customer_id)

    action = Action(action)  # convert action string to Action enum
    match action:
        case Action.add:
            resource = "pool_range" if resource_type == "several_pool_ranges" else resource_type

            context.tpm_numbers = TPMNumbers(
                quantity=quantity,
                resource_type=TpmResourceType[resource],
                pool_type=PoolType.Mobile,
                provider=number_provider,
                country=number_country
            )
            logger.info(f"Generated new numbers to add: {context.tpm_numbers}")
        case Action.delete:

            logger.info(f"Numbers to delete (added in earlier step): {context.tpm_numbers}")

    generator = NumbersPayloadGenerator(context.tpm_account, context.tpm_numbers, action, context.payload)
    context.payload = generator.to_dict()
    if hasattr(context, "additional_range"):
        del context.additional_range
    if resource_type == "several_pool_ranges":
        resource_type = "pool_range"
        context.payload, context.additional_range = numbers.update_numbers_order_with_several_ranges(
            context.payload,
            context.tpm_numbers.from_range_number,
            context.tpm_numbers.to_range_number,
            context.market_code
        )
    context.pool_type = resource_type
    context.op_co_customer_id = context.tpm_account.op_co_customer_id
    context.order_type = order_type
    context.pool = context.tpm_numbers.pool
    logging.info(f"{action} TPM Numbers SO Item payload: ")
    logging.info(to_json(context.payload))


@given(
    "service order is created with '{invalid_field}' to '{action}' TPM numbers with pool type '{resource_type}' as '{"
    "order_type}' order")
def tpm_order_created_for_numbers_with_invalid_field(context, invalid_field: str, action, resource_type,
                                                     order_type) -> None:
    tpm_order_created_for_numbers(context, action, 5, resource_type, order_type)
    tpm_characteristic = payload.ServiceOrderPayload(context.payload) \
        .get_resource_characteristic(name="TpmPool")
    context.invalid_tpm_data = "tpm_number"

    match invalid_field:
        case "blank_resourceCharacteristic_name":
            tpm_characteristic["name"] = ""
        case "invalid_resourceCharacteristic_name":
            tpm_characteristic["name"] = "invalid"
        case "invalid_resourceCharacteristic_type":
            tpm_characteristic["value"]["@type"] = "UccMsocNumberPool"
        case "invalid_poolType":
            tpm_characteristic["value"]["poolType"] = "Fixed"
        case "invalid_numberFormat":
            tpm_characteristic["value"]["pool"] = ["491728081723"]
        case "numberRange":
            tpm_characteristic["value"]["pool"] = [{"from": "+491728080623", "to": "+491728080627"}]
        case "invalid_numberRange":
            tpm_characteristic["value"]["poolRange"] = [{"from": "+491728080627", "to": "+491728080623"}]
        case "long_numberRange":
            tpm_characteristic["value"]["poolRange"] = [{"from": "+491728090623", "to": "+491728192627"}]
        case "diffCountry_numberRange":
            tpm_characteristic["value"]["poolRange"] = [{"from": "+491729080623", "to": "+441729080627"}]
        case "invalidFrom_numberFormat":
            tpm_characteristic["value"]["poolRange"] = [{"from": "491729080623", "to": "+491728080627"}]
        case "blankFrom_number":
            tpm_characteristic["value"]["poolRange"] = [{"from": "", "to": "+491728080627"}]
        case "blankTo_number":
            tpm_characteristic["value"]["poolRange"] = [{"from": "+491728080627", "to": ""}]
        case "invalidTo_numberFormat":
            tpm_characteristic["value"]["poolRange"] = [{"from": "+491728080623", "to": "491728080627"}]
        case _:
            raise NotImplementedError(f"Not implemented for invalid field {invalid_field}")
    logger.info(context.payload)


@then("numbers have been successfully provisioned")
def tpm_numbers_successfully_provisioned(context):
    if getattr(context, "new_data_model_enable", False) and common.config.is_staging_env:
        tpm_customer_created_in_middleware(context)
    add_tpm_numbers(context, crf_state="completed")


@then("DEP fails to provision the TPM numbers")
def tpm_numbers_failed_provisioning(context):
    add_tpm_numbers(context, crf_state="failed")


@then("add numbers request is processed with '{state}' state")
def tpm_numbers_failed_provisioning(context, state):
    add_tpm_numbers(context, crf_state=state)


@then("TPM add number processed with {crf_state}")
@then("DEP fails to provision the TPM numbers with error {crf_state}")
def add_tpm_numbers(context, crf_state):
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    common.update_middleware_correlation_id(context)
    common.save_marketplace_event_id(context)
    operations.validate_operations_order('ucc.tpm.numbers', 'add', context.service_order_id)
    item = payload.get_item_by_type_and_action(context.payload, 'ucc.tpm.numbers', action=Action.add)
    if context.pool_type == "pool":
        context.added_numbers = numbers.get_pool(item)
    assert item is not None, 'No item found'

    if 'additional_range' in context:
        context.additional_range_numbers = numbers.get_pool_range(
            context.additional_range['from'],
            context.additional_range['to'])
        context.pool = context.tpm_numbers.pool = context.tpm_numbers.pool + context.additional_range_numbers

    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_create_addnumbers')
    if isinstance(context.consumer_payload, list):
        consumer_message = context.consumer_payload[-1]

    topic_validator.KafkaTopicValidator(context).tmfmediator_create_addnumbers(
        number_type=context.pool_type,
        item=item,
        consumer_message=consumer_message,
        category=context.category)
    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_command_add_crfnumber')
    topic_validator.KafkaTopicValidator(context).validate_topic("numbermanagement_command_add_crfnumber")

    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, "acknowledged")
    if common.config.is_dev_env:
        context.consumer_payload = consumer_data.get_messages(context, 'crfstub_process_resourceorder')
        topic_validator.KafkaTopicValidator(context).validate_topic(
            topic_name="crfstub_process_resourceorder",
            error_type=None,
            action="add",
            pool=context.tpm_numbers.pool,
            account_category="TPM"
        )
    if not hasattr(context, 'action'):
        context.action = "add"
    dep_notification_sent_with_status(context, "inProgress")
    if crf_state in ("CUSTOMER_MAPPING_ALREADY_EXISTS", "FAILED_SERVICE_ORDER"):
        error = errors.DEPNoteErrors.get_dep_error(crf_state, context.tpm_numbers.pool)
        dep_notification_sent_with_status(context, "failed", error)
    else:
        dep_notification_sent_with_status(context, crf_state)
        CRFHandler.validate_crf_request_state_db(context, crf_state)
    if crf_state == "completed":
        context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_crfnumber_added')
        KafkaTopicValidator(context).validate_topic('crfgateway_event_crfnumber_added')
        numbersHandler.retrieve_numbermanagement_respond_numbersadded_number_for_state(context,
                                                                                       number_type='Mobile',
                                                                                       state='COMPLETED_PROVISIONING')
    elif crf_state == "failed":
        CRFHandler.validate_crf_numbers_failed(context, "CRF_error")
        numbersHandler.retrieve_numbermanagement_respond_numbersadded_number_for_state(context, number_type=None,
                                                                                       state='FAILED_PROVISIONING')

    elif crf_state in ("CUSTOMER_MAPPING_ALREADY_EXISTS", "FAILED_SERVICE_ORDER"):
        CRFHandler.validate_crf_numbers_failed(context, crf_state)
        # numbersHandler.retrieve_numbermanagement_respond_numbersadded_number_for_state(context, error_type=crf_state,
        # state='FAILED_PROVISIONING')
        context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_respond_numbersadded')
        topic_validator.KafkaTopicValidator(context).validate_topic('numbermanagement_respond_numbersadded',
                                                                    error_type=crf_state,
                                                                    state='FAILED_PROVISIONING')


@then("Validate the SO status as '{status}' for TPM customer")
def validate_service_order_tpm(context, status):
    validationHandler.validate_order_status(context, status)
    validationHandler.validate_milestones_achieved(context, status)
    if hasattr(context, 'delete_tpm_customer_milestones'):
        return
    if status == 'completed':
        tmf.validate_bgid_in_service_order(context.response_payload, context.tpm_account.bgid)
    elif status == 'failed':
        status = f"{status}_{context.dupe_id}"
        tmf.validate_error_message(context, status)
    tmf.validate_tpm_create_customer_notes(context.response_payload, status, context.tpm_account.bgid)


@given("a new TPM Account is created")
def tpm_account_created(context):
    create_tpm_customer_service_order(context)
    TMFHandler.request_is_sent_to_create_service_order(context)
    tpm_customer_created_in_middleware(context)


@then("the ID Mapper returns the relevant information")
def validate_id_mapper_api_data(context):
    idmapperHandler.look_up_for_tpm_customer(context, "BGID")
    idmapperHandler.validate_response_and_account_information(context, 200)


@then("an email is sent to NAO")
@then("email is '{email_status}' to NAO")
def validate_email_notification_sent_to_nao(context, email_status="sent"):
    context.email_status = email_status
    # Validate data in 'tmfmediator_command_send_tpmnotification'
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_send_tpmnotification')
    topic_validator.KafkaTopicValidator(context).validate_topic("tmfmediator_command_send_tpmnotification")

    payload_validation_idmapper_event_tpmnotification(context, email_status=email_status)

    # find and validate the email content
    search_property = context.tpm_account.bgid
    mail = polling.wait_until(lambda: s3_bucket.get_email(search_property, search_in='body'),
                              f"Email for {search_property}", period=5, timeout=120,
                              stop_when=lambda x: len(x) > 0)
    asserts.equals(len(mail), 1, "Number of emails")
    if email_status == "sent":
        validate_notification_email(context, mail[0])


@when("DEP TMF641 notification is sent with status '{state}'")
def dep_notification_sent_with_status(context, state, notes=None):
    if common.config.is_staging_env:
        return
    context.notification = state
    context.crf_stub_payload = context.consumer_payload
    # here to send a notification for crf_notification to update to a state
    crf.send_notification(state, context.crf_stub_payload, notification_type='tmf641', notes=notes)


@then("TPM add number is {outcome}")
def tpm_add_number_suspended(context, outcome):
    kafkaHandler.validate_payload_not_present_in_topic(context, 'tmfmediator_command_send_tpmnotification')
    # Validate the SO status as 'inProgress'
    if outcome == 'suspended':
        outcome = "inProgress"
    validationHandler.validate_order_status(context, outcome)
    if outcome == "failed":
        tmf.validate_error_message(context, "CUSTOMER_MAPPING_ALREADY_EXISTS")


@then("Validate the SO for '{state}' state for add number")
def validate_service_order_tpm_add_number(context, state):
    if not getattr(context, 'existing_tpm_document', False) and getattr(context, 'new_data_model_enable', False):
        validate_email_notification_sent_to_nao(context)
    if payload.has_tpm_create_account(context.payload):
        validate_service_order_tpm(context, state)
    validationHandler.validate_order_status(context, state.split("_")[0])
    validationHandler.validate_milestones_achieved(context, state)
    if 'failed' in state:
        tmf.validate_error_message(context, state)
    is_snow_onboarding = "snow_onboarding" in context and context.snow_onboarding
    tmf.validate_tpm_add_number_notes(context.response_payload, state, context.tpm_numbers.pool, is_snow_onboarding)


@given("order is set to fail with Bad_Request")
def order_for_bad_request_tpm(context):
    stub_accounts = StubAccounts()
    context.op_co_customer_id = context.tpm_account.op_co_customer_id = stub_accounts.dep.failed_bad_request
    context.payload['externalReference'][0]['id'] = context.op_co_customer_id
    context.market_code = context.tpm_account.market_code


@when("more numbers are added to the same TPM account")
def more_tpm_add_number(context):
    tpm_order_created_for_numbers(context, 'add', 5, 'pool', 'separate')
    TMFHandler.request_is_sent_to_create_service_order(context)
    add_tpm_numbers(context, crf_state="completed")


@when("kafka message for topic tmfmediator_command_send_tpmnotification is sent with {parameter}")
def payload_created_sent_to_tmfmediator_command_send_tpmnotification(context, parameter=None):
    topic_name = "tmfmediator_command_send_tpmnotification"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.event_type = context.payload["header"]["event_type"]
    context.marketplace_event_id = context.payload["tpm_customer_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.operation_id = context.payload["tpm_customer_request"]["client_reference"][
        "operation_id"] = read_xmldata.gen_uuid()
    context.market_code = context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"]["name"]
    context.op_co_customer_id = context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"][
        "op_co_customer_id"]

    if parameter == "blank_customerID":
        context.op_co_customer_id = context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"][
            "op_co_customer_id"] = ""
    elif parameter == "blank_opcoName":
        context.market_code = context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"]["name"] = ""
    elif parameter == "invalid_customerID":
        context.market_code = context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"]["name"] = "VFUK"

    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@then("data is validated in idmapper_event_tpmnotification_sent with {error}")
def payload_validation_idmapper_event_tpmnotification(context, error=None, email_status="not_sent"):
    context.consumer_payload = consumer_data.get_messages(context, 'idmapper_event_tpmnotification_sent')
    topic_validator.KafkaTopicValidator(context).idmapper_event_tpmnotification_sent(error=error,
                                                                                     email_status=email_status)


@given("service order is created for a staging TPM customer")
def create_staging_tpm_customer_service_order_with_specific_tenant(context):
    create_tpm_customer_service_order(context)
    tpm_characteristic = payload.ServiceOrderPayload(context.payload) \
        .get_characteristic(name="TpmCustomerInfo")

    context.tpm_account.tenant_id = tpm_characteristic['value']['tenantId'] = account.EXISTING_TPM_CUSTOMER[
        'staging_tenant']
    context.tpm_account.op_co_customer_id = context.payload['externalReference'][0]['id'] = \
        account.EXISTING_TPM_CUSTOMER['staging_opco_account']


@then("DEP sends Bad_Request response for TPM add number")
def bad_request_response_for_tpm_numbers(context):
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    common.update_middleware_correlation_id(context)
    common.save_marketplace_event_id(context)
    operations.validate_operations_order('ucc.tpm.numbers', 'add', context.service_order_id)
    item = payload.get_item_by_type_and_action(context.payload, 'ucc.tpm.numbers', action=Action.add)
    assert item is not None, 'No item found'

    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_create_addnumbers')
    if isinstance(context.consumer_payload, list):
        consumer_message = context.consumer_payload[-1]
    topic_validator.KafkaTopicValidator(context).tmfmediator_create_addnumbers(
        number_type=context.pool_type,
        item=item,
        consumer_message=consumer_message,
        category=context.category)
    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_command_add_crfnumber')
    topic_validator.KafkaTopicValidator(context).validate_topic("numbermanagement_command_add_crfnumber")
    CRFHandler.validate_crf_numbers_failed(context, "CRF_error")
    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_respond_numbersadded')
    topic_validator.KafkaTopicValidator(context).validate_topic('numbermanagement_respond_numbersadded',
                                                                error_type='bad_request', state='FAILED_PROVISIONING')


@given("New request raised for adding TPM numbers which are already provisioned")
def create_tpm_customer_with_numbers(context):
    tpm_account_created(context)
    tpm_order_created_for_numbers(context, 'add', 5, 'pool', 'separate')
    TMFHandler.request_is_sent_to_create_service_order(context)
    add_tpm_numbers(context, crf_state="completed")


@when("NAO processes the suspended order")
def processing_of_suspended_order(context, status='OPERATION_COMPLETED', config='ADD_TPM_NUMBERS'):
    context.service_order_item_id = str(payload.get_item_by_type(context.payload, 'ucc.tpm.numbers')[0] + 1)
    TMFHandler.support_topic_sent(context, status, config)


@given("a new TPM account is created and numbers are added")
def tpm_account_created_and_numbers_added(context):
    tpm_account_created(context)
    tpm_order_created_for_numbers(context, "add", 5, "pool", "separate")
    TMFHandler.request_is_sent_to_create_service_order(context)
    tpm_numbers_successfully_provisioned(context)


@given("payload is created for topic '{topic_name}' for TPM")
@given("payload is created for topic '{topic_name}' for TPM with '{account_type}' account")
def payload_created_for_topic_for_tpm(context, topic_name: str, account_type: str = "existing"):
    context.market_code = "VFDE"
    context.ucas_provider = "TPM"

    if account_type == "existing":
        tpm_account_created_and_numbers_added(context)
    elif account_type == "non_existing":
        context.op_co_customer_id = "12345678901"
        context.added_numbers = numbers.generate_pool(2, context.market_code)
    elif account_type == "failed_dep_response":
        stub_accounts = StubAccounts()
        context.op_co_customer_id = stub_accounts.dep.failed_bad_request
        context.added_numbers = numbers.generate_pool(2, context.market_code)
    else:
        raise NotImplementedError(f"value of {account_type=} is not implemented")

    logger.debug(f"{context.op_co_customer_id=}")
    logger.debug(f"{context.added_numbers=}")

    kafkaHandler.payload_created_for_topic(context, topic_name, refresh_mci=True)


@then("delete TPM numbers is processed successfully at CRF gateway")
def delete_tpm_numbers_processed_crf(context):
    crf_processing_delete_numbers(context, "completed")
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_crfnumber_deleted')
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name="crfgateway_event_crfnumber_deleted")


@then("delete TPM numbers fails at CRF gateway with '{error_type}' error")
def delete_tpm_numbers_fails_crf(context, error_type=None):
    if 'dep_notification' in error_type:
        status = get_status(error_type)
        crf_processing_delete_numbers(context, status)
    elif error_type == "non_existing_account":
        # Validate in db
        error_message = account.ACCOUNT_NOT_FOUND_DB_ERROR.format(market_code=context.market_code,
                                                                  op_co_customer_id=context.op_co_customer_id)
        crf.validate_crf_request_failed_db(context.middleware_correlation_id, error_message)
    elif error_type == "failed_dep_response":
        logger.info("DEP should send response '400 Bad Request' for TMF641 Request")
        crf.validate_crf_request_failed_db(context.middleware_correlation_id, "CRF API failed", "BAD_REQUEST")

    # Validate message in the topic
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_crfnumber_deleted')
    topic_validator.KafkaTopicValidator(context).validate_topic(
        topic_name="crfgateway_event_crfnumber_deleted",
        error_type=error_type
    )


def crf_processing_delete_numbers(context, final_crf_state):
    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, "acknowledged")

    # validate 'crfstub_process_resourceorder' topics
    # Remove the crf_stub_payload saved by add number flow
    if "crf_stub_payload" in context:
        del context.crf_stub_payload
    if common.config.is_dev_env:
        context.consumer_payload = consumer_data.get_messages(context, 'crfstub_process_resourceorder')
        topic_validator.KafkaTopicValidator(context).validate_topic(
            topic_name="crfstub_process_resourceorder",
            error_type=None,
            action="delete",
            pool=context.tpm_numbers.pool,
            account_category="TPM"
        )

    # Send CRF notification to make the request inProgress
    dep_notification_sent_with_status(context, "inProgress")

    # Send CRF notification to make the request to terminal state
    dep_notification_sent_with_status(context, final_crf_state)

    # Validate the CRF request status
    CRFHandler.validate_crf_request_state_db(context, final_crf_state)


@then("delete all TPM numbers fails at CRF gateway with '{error_type}' error")
def delete_all_tpm_numbers_fails_crf(context, error_type=None):
    if error_type == "failed_dep_notification":
        crf_processing_delete_all_numbers(context, "failed")
    elif error_type == "non_existing_account":
        # Validate in db
        error_message = account.ACCOUNT_NOT_FOUND_DB_ERROR.format(market_code=context.market_code,
                                                                  op_co_customer_id=context.op_co_customer_id)
        crf.validate_crf_request_failed_db(context.middleware_correlation_id, error_message)
    elif error_type == "failed_dep_response":
        logger.info("DEP should send response '400 Bad Request' for TMF641 Request")
        crf.validate_crf_request_failed_db(context.middleware_correlation_id, "CRF API failed", "BAD_REQUEST")

    # Validate message in the topic
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_all_crf_numbers_deleted')
    topic_validator.KafkaTopicValidator(context).validate_topic(
        topic_name="crfgateway_event_all_crf_numbers_deleted",
        error_type=error_type
    )


@then("delete all TPM numbers is processed successfully at CRF gateway")
def tpm_customer_is_ceased_successfully(context):
    crf_processing_delete_all_numbers(context, "completed")
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_all_crf_numbers_deleted')
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name="crfgateway_event_all_crf_numbers_deleted")


def crf_processing_delete_all_numbers(context, final_crf_state):
    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, "acknowledged")

    # validate 'crfstub_process_resourceorder' topic
    # Remove the crf_stub_payload saved by add number flow
    if "crf_stub_payload" in context:
        del context.crf_stub_payload
    if common.config.is_dev_env:
        context.consumer_payload = consumer_data.get_messages(context, 'crfstub_process_resourceorder')
        topic_validator.KafkaTopicValidator(context).validate_topic(
            topic_name="crfstub_process_resourceorder",
            error_type=None,
            action="delete",
            pool=None,
            account_category="TPM"
        )
    # Send CRF notification to make the request inProgress
    dep_notification_sent_with_status(context, "inProgress")
    # Send CRF notification to make the request to terminal state
    dep_notification_sent_with_status(context, final_crf_state)
    # Validate the CRF request status
    CRFHandler.validate_crf_request_state_db(context, final_crf_state)


@given("Service order is sent to add TPM numbers for {callback_state} state")
def tpm_service_order_for_callback(context, callback_state):
    TpmCallbackHandler.tpm_account_is_prepared_for_callback(context, callback_state)
    TpmCallbackHandler.initiate_service_order(context, 'acknowledged')
    common.save_marketplace_event_id(context)
    context.response_payload = context.response_payload.json()
    context.service_order_id = context.response_payload["id"]


@when("request is processed via DEP callback for {callback_state}")
def request_processed_via_dep_callback(context, callback_state):
    CRFHandler.notification_not_received(context)
    CRFHandler.crf_dep_called_for_status_time(context, 1)
    CRFHandler.validate_crf_request_state_db(context, callback_state)
    value = 'true' if callback_state == 'completed' else 'false'
    CRFHandler.set_field_to_value(context, 'isCrfRequestSuccessful', value)
    CRFHandler.set_last_timestamp_to_current(context)
    if callback_state == "completed":
        context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_crfnumber_added')
        KafkaTopicValidator(context).validate_topic('crfgateway_event_crfnumber_added')
        numbersHandler.retrieve_numbermanagement_respond_numbersadded_number_for_state(context, number_type='Mobile',
                                                                                       state='COMPLETED_PROVISIONING')
    else:
        CRFHandler.validate_crf_numbers_failed(context, "CRF_error")
        numbersHandler.retrieve_numbermanagement_respond_numbersadded_number_for_state(context, number_type=None,
                                                                                       state='FAILED_PROVISIONING')


@given("TPM account is prepared to return '{error_type}' for negative scenario")
def set_up_tpm_negative_account(context, error_type):
    if error_type == "failed_dep_response":
        stub_accounts = StubAccounts()
        op_co_customer_id = stub_accounts.dep.failed_bad_request
        context.tpm_account = TPMAccount(market_code=context.market_code, op_co_customer_id=op_co_customer_id)
        tpm_order_created_for_numbers(context, 'add', 5, 'pool', 'separate', op_co_customer_id)
    elif error_type == "non_existing":
        context.op_co_customer_id = "12345678910"
        tpm_order_created_for_numbers(context, 'add', 5, 'pool', 'separate', context.op_co_customer_id)


@then("delete tpm numbers have been failed with error message")
def delete_numbers_failed_with_error_msg(context):
    TMFHandler.send_request_to_endpoint(context, 'get_service_order_by_id')
    validationHandler.validate_order_status(context, 'failed')
    validationHandler.validate_error_message(context, 'failed_to_delete_tpm_numbers')


@when("DEP sends notification with '{error_notification}'")
def dep_error_in_notification(context, error_notification):
    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, "acknowledged")
    if common.config.is_dev_env:
        context.consumer_payload = consumer_data.get_messages(context, 'crfstub_process_resourceorder')
        topic_validator.KafkaTopicValidator(context).validate_topic(
            topic_name="crfstub_process_resourceorder",
            error_type=None,
            action="add",
            pool=context.tpm_numbers.pool,
            account_category="TPM"
        )
    error = errors.DEPNoteErrors.get_dep_error(error_notification, context.tpm_numbers.pool)
    # final_state = notifications.get_final_state_by_scenario(error_notification)
    dep_notification_sent_with_status(context, "failed", error)


@when("payload is prepared and sent to topic numbermanagement_command_add_crfnumber")
def sent_kafka_to_numbermanagement_command_add_crfnumber(context):
    topic_name = "numbermanagement_command_add_crfnumber"
    op_co_customer_id_existing_account = "88212104592"
    tenant_id = "650cd9b2-e936-11ef-b30f-d2d8bf7c58fe"
    context.payload = read_xmldata.read_jsonfile(topic_name)
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.marketplace_event_id = context.payload["crf_number_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.op_co_customer_id = context.payload["crf_number_request"]["op_co_details"][
        "op_co_customer_id"] = op_co_customer_id_existing_account
    context.market_code = context.payload["crf_number_request"]["op_co_details"]["name"] = "VFDE"
    context.tpm_account = TPMAccount(market_code=context.market_code, op_co_customer_id=context.op_co_customer_id,
                                     tenant_id=tenant_id)
    context.category = context.payload["crf_number_request"]["ucas_provider"] = "TPM"

    context.number_pool_list = context.payload["crf_number_request"]["pool"]
    context.tpm_numbers = NumbersOrderItem(
        quantity=len(context.number_pool_list),
        pool=context.number_pool_list,
        pool_type=PoolType.Mobile
    )
    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@then("delete numbers have been failed with '{error_type}'")
def tpm_delete_numbers_failed_in_notification(context, error_type):
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfmediator_create_deletenumbers.name)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.numbermanagement_command_delete_crfnumber.name)
    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, "acknowledged")
    if "crf_stub_payload" in context:
        del context.crf_stub_payload
    if common.config.is_dev_env:
        context.consumer_payload = consumer_data.get_messages(context, 'crfstub_process_resourceorder')
        topic_validator.KafkaTopicValidator(context).validate_topic(
            topic_name="crfstub_process_resourceorder",
            error_type=None,
            action="delete",
            pool=context.tpm_numbers.pool,
            account_category="TPM"
        )

    error_notes = errors.DEPNoteErrors.get_dep_error(error_type, context.tpm_numbers.pool)
    dep_notification_sent_with_status(context, "failed", error_notes)
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_crfnumber_deleted')
    topic_validator.KafkaTopicValidator(context).validate_topic(
        topic_name="crfgateway_event_crfnumber_deleted",
        error_type=error_type)

    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.numbermanagement_event_numbers_deleted.name)
    topic_validator.KafkaTopicValidator(context).numbermanagement_event_numbers_deleted(error_type=error_type,
                                                                                        state='FAILED_PROVISIONING')
    TMFHandler.validate_final_state(context, f'failed_{error_type}')


@given("a TPM customer is created in '{customer_country}' for '{market}'")
def create_tpm_account(context, customer_country, market):
    context.customer_country = customer_country
    context.market_code = market
    context.related_party = RelatedParty(context.market_code) if context.customer_country == 'DE' else RelatedParty('VFUK')
    context.new_data_model_enable = True

    if common.config.is_staging_env:
        create_tpm_customer_service_order(context, context.market_code,
                                          new_data_model_enable=context.new_data_model_enable)
    else:
        search_filter = {
            "market": context.market_code,
            "marketCountryCode": context.customer_country,
            # Exclude TPM accounts with IDs indicating bad request or server error
            "vodafoneId": {
                "$not": {"$regex": r"^CEASE_TPM_(BAD_REQUEST|SERVER_ERROR)"}
            }
        }
        context.existing_tpm_document = tpm.get_existing_tpm_account(search_filter)
        if context.existing_tpm_document is not None:
            context.tpm_account = TPMAccount(market_code=context.market_code,
                                            op_co_customer_id=context.existing_tpm_document["vodafoneId"],
                                            bgid=context.existing_tpm_document["bgid"],
                                            related_party=context.related_party)
        else:
            logging.info(f"There is not any TPM customer in '{customer_country}' for '{market}', creating a new one")
            create_tpm_customer_service_order(context, context.market_code,
                                              new_data_model_enable=context.new_data_model_enable)
            TMFHandler.request_is_sent_to_create_service_order(context)
            tpm_customer_created_in_middleware(context)


@given("a Service Order is created for TPM '{action}' numbers of '{provider}'")
def request_for_add_tpm_numbers(context, provider, action: str = "add"):
    context.number_provider = provider
    context.number_country = countries_data_manager.get_country_code(context.number_provider)
    if common.config.is_dev_env and not hasattr(context, 'existing_tpm_document') and not hasattr(context, 'tpm_account'):
            create_tpm_account(context, context.number_country, context.number_provider)

    match action:
        case Action.add:
            order_type = 'complex' if common.config.is_staging_env else 'separate'
            tpm_order_created_for_numbers(context, action, '5', 'pool', order_type,
                                     context.tpm_account.op_co_customer_id, context.number_provider, context.number_country)

        case Action.delete:
            if common.config.is_dev_env and not hasattr(context, 'tpm_numbers'):
                context.tpm_numbers = TPMNumbers(
                    quantity=5,
                    resource_type=TpmResourceType['pool'],
                    pool_type=PoolType.Mobile,
                    provider=context.number_provider,
                    country=context.number_country
                )
            tpm_order_created_for_numbers(context, action, '5', 'pool', 'separate',
                                          context.tpm_account.op_co_customer_id, context.number_provider,
                                          context.number_country)


@given ("the numbers of '{provider}' are already provisioned against a TPM customer in '{customer_country}' for '{market}'")
def tmp_customer_and_numbers_are_already_provisioned(context, provider, customer_country: str = 'DE', market: str = 'MNC'):
    # Check if a customer exists or not (if not, we create the payload for add TPM customer:
    create_tpm_account(context, customer_country, market)
    context.number_provider = provider
    context.number_country = countries_data_manager.get_country_code(context.number_provider)
    # Create the so for adding numbers on test env
    if common.config.is_staging_env:
        request_for_add_tpm_numbers(context, provider)
        TMFHandler.request_is_sent_to_create_service_order(context)
        tpm_numbers_successfully_provisioned(context)
        del context.service_order


@given("a Service Order is created for TPM '{action}' numbers with empty number '{field}'")
def update_new_fields_for_tpm_number_order(context, field, action):

    if not hasattr(context, 'number_provider') and not hasattr(context, 'number_country'):
        context.number_provider, context.number_country = (context.market_code, context.customer_country)

    if action == 'add':
        order_type = 'complex' if common.config.is_staging_env else 'separate'
        tpm_order_created_for_numbers(context, action, '5', 'pool', order_type,
                                        context.tpm_account.op_co_customer_id, context.number_provider,
                                        context.number_country)
    elif action == 'delete':
         request_for_add_tpm_numbers(context, context.number_provider, action)
    if field == 'provider':
        context.number_provider = update_number_country_field(context, field=field)
    else:
        context.number_country = update_number_country_field(context, field=field)


@given("the order is updated with '{provider_country}'")
@given("customer updates '{field}' with '{value}' in the service order")
def update_number_country_field(context, provider_country = None, value = None, field: str = 'country'):
    path = f"$..supportingResource.[0].resourceCharacteristic[0].value.{field}"
    if value is None:
        create_or_update_key(context.payload, path, provider_country)
    else:
        tpm.modify_new_tpm_fields(context.payload, value, path)
        context.number_provider = value








