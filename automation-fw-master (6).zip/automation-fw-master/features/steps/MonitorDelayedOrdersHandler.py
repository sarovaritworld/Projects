import re
import logging

from behave import given, then, when

from classes import common, database, delay, pod, tmf_svc_order_gw_api
from classes.domain.account import MSOCAccount, TPMAccount
from classes.payload_generators.TMF import Action, MSOCAccountPayloadGenerator
from classes.payload_generators.TMF.account_generator import TPMAccountPayloadGenerator
from features.steps import TMFHandler, TpmHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)

SLO_TIME = tmf_svc_order_gw_api.SLO


@given("service order is created to add '{customer}' customer")
def service_order_is_created_for_customer(context, customer: str):
    match customer:
        case 'unity':
            TMFHandler.order_account_for_product(context, action='add', product_type='OVERLAY_STANDARD',
                                                 market_code='VFIT')
            TMFHandler.update_service_order_config(context, config='SSO_NOK')

        case 'msoc':
            context.msoc_account = MSOCAccount(market_code='VFUK')
            context.payload = MSOCAccountPayloadGenerator(msoc_account=context.msoc_account,
                                                          action=Action.add).to_dict()

        case 'tpm':
            context.tpm_account = TPMAccount(market_code='VFUK')
            context.market_code = context.tpm_account.market_code
            context.payload = TPMAccountPayloadGenerator(tpm_account=context.tpm_account, action=Action.add).to_dict()
            TpmHandler.tpm_order_created_for_numbers(context, action='add', quantity=5, resource_type='pool',
                                                     order_type='separate')
            TpmHandler.order_for_bad_request_tpm(context)

        case _:
            raise NotImplementedError(
                f" Service order creation is not implemented for this {customer}")


def check_slo_time_limit() -> int | None:
    match = re.search(r'\d', SLO_TIME)
    return int(match.group()) if match else None


@when("SLO is breached")
def slo_breached_time_limit_has_been_passed(context):
    delay.wait_with_progress_bar(60 * tmf_svc_order_gw_api.CRON_JOB_FREQUENCY_MINUTES)
    document = database.get_service_order_with_start_date(context.service_order_id)
    assert 'sloBreachedDate' in document, 'sloBreachedDate key is not present even after actual SLO breach'


@then("SLO breached error message is logged")
def validate_slo_breached_parameter_and_log_message(context):
    slo_breached_msg = f"Service Order [{context.service_order_id}] has breached SLO of [{check_slo_time_limit()} minutes] after start date"
    log = pod.filter_logs('tmf-svc-order-gw-api', slo_breached_msg)
    assert len(log) == 1, "SLO Breach message not found in pod"


@then("validate that order has not breached SLO till time limit")
def validate_slo_not_breached_for_service_order(context):
    TMFHandler.retrieve_and_validate(context, "tmfgateway_process_serviceorder")
    delay.wait_with_progress_bar((60 * check_slo_time_limit()) - 1)
    document = database.get_service_order_with_start_date(context.service_order_id)
    assert 'sloBreachedDate' not in document, 'sloBreachedDate key is present without actual SLO breach'
