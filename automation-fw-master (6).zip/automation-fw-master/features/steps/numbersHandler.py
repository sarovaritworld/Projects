import json
import logging
from collections import Counter
from http import HTTPStatus

from behave import *

from classes import account, asserts, common, data, numbers, payload, read_xmldata
from classes.kafka import consumer_data
from classes.kafka.messages_filter import KafkaMessagesFilter
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.numbers import append_resource_characteristic, duplicate_number_suffix, generate_numberitem_for_poolrange, \
    get_pool
from features.steps import TpmHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("'{account_state}' account has been created and '{quantity}' numbers added as '{resource_type}'")
@given(
    "'{account_state}' account has been created for '{market}'/'{product_type}' and '{quantity}' numbers added as '{resource_type}'")
def validate_account_creation_and_resource_numbers_added(context, account_state, market='VFDE',
                                                         product_type='FULL_STACK_STANDARD', quantity='5',
                                                         resource_type='pool'):
    context.execute_steps(f"""Given account for '{product_type}' in '{market}' market is '{account_state}'""")

    context.execute_steps(f"""
        Given customer creates an order to 'add' '{quantity}' 'numbers' as '{resource_type}'
        When customer sends an order to Middleware
        And Pool number is 'added to' Middleware
    """)
    if hasattr(context, 'patch_milestones'):
        del context.patch_milestones


@given("customer orders numbers with '{field_name}' for '{action}'")
def generate_numbers_for_condition(context, field_name, action):
    logger.info(f'testing add numbers against {field_name}')
    context.payload = numbers.generate_invalid_numbers_payload(context, field_name, action)

    logger.info(f'generated payload: ')
    logger.info(json.dumps(context.payload, indent=3))


# And customer creates an order to 'add' '5' '<number_type>' 'numbers' with pooltype as '<pool_type>'
# And customer creates an order to 'add' '5' 'pool' 'numbers' with pooltype as 'FMC'
# When  customer creates an order to 'add' '5' 'pool' 'numbers' with pooltype as 'Presentation'
@given("customer creates an order to '{action}' '{quantity}' '{number_type}' '{items}' with pooltype as '{pool_type}'")
@when("customer creates an order to '{action}' '{quantity}' '{number_type}' '{items}' with pooltype as '{pool_type}'")
def create_order_for_number_with_pooltype(context, action, quantity, number_type, items, pool_type):
    context.pool_type = pool_type
    if action == "delete":
        if pool_type != "Presentation":
            context.op_co_customer_id = read_xmldata.readxml("opCoCustomerID_staging", "test_inputdata",
                                                             'appdirectinput')
            if common.config.is_dev_env:
                context.op_co_customer_id = read_xmldata.readxml("opCoCustomerID_dev", "test_inputdata",
                                                                 'appdirectinput')
        _payload = payload.append_item_to_payload(context, items, action)
        _payload["externalReference"][0]["id"] = context.op_co_customer_id

        number_item = payload.get_last_item(_payload)
        index = _payload['serviceOrderItem'].index(number_item)

        number_item_list = []
        if number_type == "pool_range":
            number_item = generate_numberitem_for_poolrange(context, context.pool_type, context.market_code, index,
                                                            number_item, quantity)
            context.number_fwpool_list = context.pool

        else:
            context.number_fwpool_list = numbers.generate_pool(quantity, context.market_code)
            number_item = append_resource_characteristic(number_item, index, resource_type='UccTenantPool',
                                                         pool=context.number_fwpool_list, pool_type=context.pool_type)

        number_item_list.append(number_item)
        _payload['serviceOrderItem'][index] = number_item
        context.payload = payload.refresh_ids(_payload)

    else:
        context.execute_steps(f"""
                           Given customer creates an order to '{action}' '{quantity}' '{items}' as '{number_type}'
                          """.format(action=action, quantity=quantity, items=items, number_type=number_type))


@given("service order contains item to delete same numbers")
def delete_numbers_from_payload(context):
    if not hasattr(context, 'tpm_account'):
        # for negative scenario
        TpmHandler.tpm_order_created_for_numbers(context, 'add', 5, 'pool', 'separate')

    context.payload = payload.update_action(context.payload, 'ucc.tpm.numbers', 'delete')


@given(
    "service order contains item to '{action}' '{quantity}' numbers in resource type '{resource_type}' and pool type '{pool_type}'")
@given(
    "service order contains item to '{action}' '{quantity}' numbers in resource type '{resource_type}' and pool type '{pool_type}' added to '{update_existing_payload}' order")
def validate_payload_numbers_resource_and_pooltype(context, action, quantity, resource_type, pool_type,
                                                   update_existing_payload=False):
    logger.info('incoming data: ')
    logger.info([action, quantity, resource_type, pool_type])
    logger.info('')
    # save test data to the context for validation: works only for single order

    context.action = action
    context.quantity = quantity
    context.resource_type = resource_type
    context.pool_type = pool_type

    # check if payload needs to be deleted
    if not update_existing_payload:
        try:
            del context.payload
        except AttributeError:
            pass

    context.payload = payload.compose_service_order(context)

    # generate number item
    number_item = numbers.generate_numbers_item(action, quantity, resource_type, pool_type,
                                                market_code=context.market_code)

    context.payload['serviceOrderItem'].append(number_item)

    numbers.save_numbers_to_context(context, 'numbers', number_item)
    context.start_number = numbers.get_start_number(number_item)
    context.all_numbers = numbers.get_all_numbers(number_item)

    context.payload = payload.refresh_ids(context.payload)
    logger.debug(f'{context.payload=}')


# And customer creates an order to 'add' '5' 'numbers' as 'pool'
@given("customer creates an order to '{action}' '{quantity}' '{items}' as '{number_type}'")
@when("customer creates an order to '{action}' '{quantity}' '{items}' as '{number_type}'")
def create_payload_for_numbers_with_conditions(context, action, quantity, items, number_type, dep_validation=False):
    # this step is used to order a number to already EXISTING account
    if hasattr(context, "payload") and (
            dep_validation or (action == "delete" and number_type not in numbers.negative_numbers)):
        del context.payload
    _payload = payload.append_item_to_payload(context, items, action)
    _payload = payload.refresh_ids(_payload)
    context.number_type = number_type
    context.quantity = quantity
    context.action = action

    # getting market code for isd code
    if not hasattr(context, 'market_code'):
        logging.error("No market_code exists in the context")

    _payload['externalId'] = context.external_id

    if number_type in numbers.negative_numbers:
        context.op_co_customer_id = common.get_opco_customer_id_by_number_type(number_type)
        context.market_code = 'VFUK'

    if number_type == 'pool_non_existing_account':
        pass
    else:
        context.idmapper_vf_id = context.op_co_customer_id
        context.execute_steps("""
            When the ID mapping API is accessible with Vodafone_ID
        """)
        if context.getresponse2.status_code != 200 and number_type in numbers.negative_numbers:
            context.execute_steps(f"""
                    Given 'confirmed' account has been created and '5' numbers added as '{number_type}'
                    """)
        elif context.getresponse2.status_code == HTTPStatus.OK:
            response = data.get_decoded_response(context.getresponse2)
            context.RC_ID = response["ringcentral_id"]

    _payload['externalReference'][0]['id'] = context.op_co_customer_id

    # before adding new numbers, we should pick the last soi! after that do the append_resource_characteristic
    # for append resource characteristic, we should pass only the soi, not the whole payload and append item outside it
    number_item = payload.get_last_item(_payload)
    index = _payload['serviceOrderItem'].index(number_item)
    if not hasattr(context, "added_numbers"):
        context.added_numbers = []
    if not hasattr(context, "pool_type"):
        context.pool_type = "Fixed"

    if action == "add" or number_type in numbers.negative_numbers:
        if 'pool_range' in number_type:
            if not hasattr(context, 'from_range_number'):
                context.from_range_number = numbers.generate_phone_number(context.market_code)
            if dep_validation:
                quantity = 2 * int(quantity)
            context.to_range_number = read_xmldata.add_range_number(context.from_range_number, quantity)
            context.number_fwpool_list = context.E164_FwPoolList = numbers.get_pool_range(context.from_range_number,
                                                                                          context.to_range_number)
            number_item = append_resource_characteristic(
                number_item,
                index,
                resource_type='UccTenantPoolRange',
                pool_range_from=context.from_range_number,
                pool_range_to=context.to_range_number,
                pool_type=context.pool_type
            )
            # context.added_numbers.append({"from_range_number": from_range_number, "to_range_number": to_range_number})
        else:
            if dep_validation and hasattr(context, "number_pool_list"):
                logger.info(f"Numbers were added previously: {context.number_fwpool_list}")
                context.pool = context.number_fwpool_list = context.number_pool_list
            else:
                context.number_fwpool_list = context.pool = numbers.generate_pool(quantity, context.market_code)
                logger.info(f"Generated numbers to add: {context.number_fwpool_list}")
            if "duplicate" in number_type:
                logging.info("Generating duplicates")
                if int(quantity) > 8:
                    context.number_fwpool_list = context.pool = context.pool[0:8] + context.pool[
                                                                                    0:len(context.pool) - 8]
                else:
                    context.pool[-1] = context.pool[0]
                logging.info(f"Generating duplicates {context.pool}")
            number_item = append_resource_characteristic(number_item, index, resource_type='UccTenantPool',
                                                         pool=context.pool, pool_type=context.pool_type)
            # context.added_numbers.append({"pool": pool})

    elif action == "delete":
        if number_type == "pool_range":
            from_range_number = numbers.get_pool_range_from(context.added_numbers[0])
            to_range_number = read_xmldata.add_range_number(from_range_number, quantity)

            number_item = append_resource_characteristic(
                number_item,
                index,
                resource_type='UccTenantPoolRange',
                pool_range_from=from_range_number,
                pool_range_to=to_range_number
            )

        else:
            number_pool_list = context.number_pool_list if dep_validation else numbers.get_pool(
                context.added_numbers[0])
            number_item = append_resource_characteristic(
                number_item,
                index,
                pool_type=context.pool_type,
                resource_type='UccTenantPool',
                pool=number_pool_list
            )

    context.added_numbers.append(number_item)
    logging.info(f'saving numbers item to the context, now added is: {context.added_numbers}')
    _payload['serviceOrderItem'][index] = number_item
    context.payload = payload.refresh_ids(_payload)
    logging.info(f"Final Payload: {context.payload}")
    logging.info("\n")


# payload is not added in 'tmfmediator_create_addnumber' topic for 'add_number'
@when("payload is not added in '{topic_name}' topic for '{event_type}'")
def verify_payload_does_not_exist_in_topic(context, topic_name, event_type):
    context.execute_steps(u"""
                                    Then user can retrieve payload from '{topic_name}'
                                    """.format(topic_name=topic_name))
    if event_type == "add_number":
        assert len(context.consumer_payload) <= 1, "Getting Multiple Payload for this event : {} for {} topic".format(
            event_type, topic_name)

    else:
        raise NotImplementedError(f"Validation for {event_type} of  {topic_name} is not implemented")


@when("Pool number is '{action_type}' Middleware")
@then("Pool number is '{action_type}' Middleware")
def validate_pool_number_mw(context, action_type):
    # if hasattr(context, 'main_number'):
    #     context.consumer_payload = numbers.remove_main_number_from_consumer_payload(context.consumer_payload,
    #                                                                                 context.main_number)
    # Covers all number flow in Middleware
    if action_type == 'added to':
        context.execute_steps(f"""
                 Then user retrieves and validates data in 'tmfmediator_create_addnumbers' topic with '{context.number_type}' number type
         """)
        context.execute_steps("""When number is added in RingCentral""")
    elif action_type == 'deleted from':
        context.execute_steps("""When number is deleted in RingCentral""")

    # only Fixed poolType goes to CRF
    if common.check_value_in_payload(context.payload, 'poolType', 'Fixed'):
        if hasattr(context, "duplicated_numbers"):
            context.execute_steps(
                f"Then user retrieves and validates data in 'numbermanagement_command_{context.action}_crfnumber' "
                "topic")
        context.execute_steps("""
                        When add numbers have provisioned in CRF
                    """)
    # not automated poolTypes should be completed by Jira
    for item in numbers.nonautomated_pooltype_list:
        if common.check_value_in_payload(context.payload, 'poolType', item):
            context.service_order = context.payload['serviceOrderItem']
            context.execute_steps("""
                                             Then JIRA tickets has been created successfully
                                             When BO tool sends PATCH request on 'service_order_item' level for 'numbers' is 'completed'
                                         """)
    if action_type == 'added to':
        context.execute_steps("""
                    Then user retrieves and validates data in 'numbermanagement_respond_numbersadded' topic for 'COMPLETED_PROVISIONING'
                """)
    elif action_type == 'deleted from':
        context.execute_steps("""
                Then user can retrieve and validate payload for kafka topic 'numbermanagement_event_numbers_deleted' for 'Fixed' number
                            """)


@then("user can validate payload for kafka topic '{topic_name}' for '{number_type}' number")
def validate_payload_for_kafka_topic_and_number_type(context, topic_name, number_type):
    # performed validation of topic based on action
    topics_list_with_similar_validation_set = ["numbermanagement_command_add_numbers",
                                               "numbermanagement_command_delete_numbers",
                                               "ringcentral_event_numbers_added",
                                               "ringcentral_event_numbers_deleted"]

    event_type_per_topic = {
        "numbermanagement_command_add_numbers": "ADD_NUMBER_REQUESTED",
        "numbermanagement_command_delete_numbers": "DELETE_NUMBER_REQUESTED",
        "ringcentral_event_numbers_added": "NUMBER_ADDED",
        "ringcentral_event_numbers_deleted": "NUMBER_DELETED"
    }

    logger.debug(f'validating topic {topic_name}')
    expected_soi = payload.remove_add_account_item(context.payload['serviceOrderItem'])
    logger.info(f'expected_soi: {expected_soi}')

    if isinstance(context.consumer_payload, dict):
        # For reasons I cannot understand consumer_payload is sometimes
        # a list of objects and sometimes just an object. This function
        # assumes that context.consumer_payload would be a list
        # This is an ugly workaround, even though I hate to do it :(
        # TODO: centralize the topic validation rather than multiple logics at different places
        context.consumer_payload = [context.consumer_payload]

    if hasattr(context, 'main_number'):
        actual_soi = numbers.remove_main_number_from_consumer_payload(context.consumer_payload, context.main_number)
    else:
        actual_soi = context.consumer_payload

    logger.info(f'actual_soi: {actual_soi}')

    if len(context.consumer_payload) < 1:
        raise Exception(f"Payloads are not added for add number event in kafka topic : {topic_name}")
    if len(expected_soi) != len(actual_soi):
        logger.info(f'that is case for negative scenario')
        actual_soi = payload.get_last_message(actual_soi)

    if topic_name == 'tmfmediator_create_addnumbers':
        KafkaTopicValidator(context).tmfmediator_create_addnumbers(context.pool_type, expected_soi[0], actual_soi[0])

    elif topic_name == 'tmfmediator_create_deletenumbers':
        actual_soi = sorted(actual_soi, key=lambda soi: soi['deleteNumbers']['marketplaceEventId'])

        if hasattr(context, "pool_type"):
            expected_soi = numbers.remove_add_number_item_by_pooltype(expected_soi, "Fixed")

        # for each item we have to check it's pool or pool range
        # for separate so we should have a new soi_id
        for i, item in enumerate(expected_soi):
            logger.debug(f"validating item with id {item['id']}, with type: {numbers.type_of_pool(item)}")
            logger.debug(f"with actual_soi: {actual_soi[i]}")
            validation_set = {
                "header.eventType": "DELETE_NUMBER_REQUESTED",
                "header.middlewareCorrelationId": context.middleware_correlation_id,
                "deleteNumbers.marketplace": "TMF",
                "deleteNumbers.marketplaceEventId": f"{context.service_order_id}/{item['id']}",
                "deleteNumbers.opCoDetails.name": context.payload["relatedParty"][0]["marketCode"],
                "deleteNumbers.opCoDetails.opCoCustomerId": context.op_co_customer_id,
                "deleteNumbers.pool.poolType": numbers.get_numbers_pooltype(item).upper()
            }
            logger.info(item)
            # get expected pool / pool range
            if numbers.is_pool(item):
                validation_set.update({"deleteNumbers.pool.pool": numbers.get_pool(item)})
            elif numbers.is_range(item):
                validation_set.update({"deleteNumbers.pool.poolRange.0.from": numbers.get_pool_range_from(item),
                                       "deleteNumbers.pool.poolRange.0.to": numbers.get_pool_range_to(item)})

            logger.debug(actual_soi[i])

            common.validate_message(actual_soi[i], validation_set)

    elif topic_name in topics_list_with_similar_validation_set:

        expected_numbers = numbers.get_numbers_list(expected_soi)

        validation_set = {
            "header.event_type": event_type_per_topic[topic_name],
            "phone_numbers.ucas_account_id": context.RC_ID,
        }

        for i, message in enumerate(actual_soi):
            logger.debug(f'expected_numbers {expected_numbers}')

            logger.debug(f'validating {actual_soi[i]}')
            common.validate_message(actual_soi[i], validation_set)

            try:
                numbers_from_from_message = numbers.get_numbers_from_message(message)
                asserts.in_list(sorted(numbers_from_from_message), expected_numbers, "removed numbers")
                logger.debug(f'numbers {numbers_from_from_message} validated and removed')
            except AssertionError:
                continue
        if hasattr(context, "duplicated_numbers"):
            asserts.equals(len(context.pool), len(actual_soi[0]["phone_numbers"]["phone_number_details"]),
                           "Pool should not contain duplicate numbers")

    # TODO: move validation to validation set class
    elif topic_name == "numbermanagement_event_numbers_deleted":
        if hasattr(context, "duplicated_numbers"):
            for number in context.duplicated_numbers:
                asserts.in_list(number, context.consumer_payload["numbersConfirmation"]["duplicatedNumbers"],
                                "duplicated number missing in confirmation")

        if hasattr(context, "pool_type"):
            expected_soi = numbers.remove_add_number_item_by_pooltype(expected_soi, "Fixed")

        expected_numbers = numbers.get_numbers_list(expected_soi)

        validation_set = {
            "header.eventType": "NUMBERS_DELETED_CONFIRMATION",
            "numbersConfirmation.marketplace": "TMF"
        }
        for item in expected_soi:
            validation_set.update({
                "header.middlewareCorrelationId": context.middleware_correlation_id,
                "numbersConfirmation.marketplaceEventId": f"{context.service_order_id}/{item['id']}"
            })

            for i, message in enumerate(actual_soi):
                logger.debug(f'expected_numbers {expected_numbers}')
                logger.debug(f'validating {actual_soi[i]}')
                common.validate_message(actual_soi[i], validation_set)

                try:
                    numbers_from_from_message = numbers.get_numbers_from_numbersConfirmation(message)
                    asserts.in_list(sorted(numbers_from_from_message), expected_numbers, "removed numbers")
                    logger.debug(f'numbers {numbers_from_from_message} validated and removed')
                except AssertionError:
                    continue
    else:
        raise NotImplementedError(f"Validation for  {topic_name} is not implemented")


@then("user can retrieve and validate payload for kafka topic '{topic_name}' for '{number_type}' number")
def retrieve_payload_for_kafka_topic_and_number_type(context, topic_name, number_type):
    context.execute_steps(u"""
                                    Then user can retrieve payload from '{topic_name}'
                                    And user can validate payload for kafka topic '{topic_name}' for '{number_type}' number
                                    """.format(topic_name=topic_name, number_type=number_type))


# RingCentral fails to provision 'add_presentation_number' with '<error_type>' error
# RingCentral fails to provision 'add_pool_number' with '<RC_error>' error
# RingCentral fails to provision 'add_pool_number' with 'pool_all_NOK' error
# RingCentral fails to provision 'add_pool_number' with 'pool_NOK' error
# RingCentral fails to provision 'add_pool_number' with 'bad_request' error
# RingCentral fails to provision 'add_pool_number' with 'internal_server_error' error
@then("RingCentral error '{error_type}' for '{event_type}' is validated")
@when("RingCentral fails to provision '{event_type}' with '{error_type}' error")
def validate_rc_error_for_event(context, event_type, error_type):
    number_topics = ["tmfmediator_create_addnumbers", "numbermanagement_command_add_numbers"]
    for topic_name in number_topics:
        context.execute_steps(f"""
            Then user can retrieve payload from '{topic_name}'
            And user can validate payload for kafka topic '{topic_name}' for 'add' number
            """)
    context.consumer_payload = consumer_data.get_messages(context, 'ringcentral_event_numbers_added')
    KafkaTopicValidator(context).ringcentral_event_numbers_added(error_type=error_type)


# RingCentral fails to deprovision 'delete_pool_number' with '<RC_error>' error
# RingCentral fails to deprovision 'delete_pool_number' with 'pool_all_NOK' error
# RingCentral fails to deprovision 'delete_pool_number' with 'pool_NOK' error
# RingCentral fails to deprovision 'delete_pool_number' with 'bad_request' error
@when("RingCentral fails to deprovision '{event_type}' with '{error_type}' error")
def process_rc_event_with_error(context, event_type, error_type):
    number_topics = ["tmfmediator_create_deletenumbers", "numbermanagement_command_delete_numbers"]
    for topic_name in number_topics:
        context.execute_steps(f"""
            Then user can retrieve payload from '{topic_name}'
            And user can validate payload for kafka topic '{topic_name}' for 'delete' number
            """)
    context.consumer_payload = consumer_data.get_messages(context, 'ringcentral_event_numbers_deleted')
    KafkaTopicValidator(context).validate_topic('ringcentral_event_numbers_deleted', error_type=error_type)


@then("user retrieves and validates data in 'tmfmediator_create_addnumbers' topic with '{number_type}' number type")
def retrieve_tmfmediator_create_addnumbers_data_with_number(context, number_type):
    if "duplicate" in number_type:
        number_type = "pool"
    context.execute_steps("""
                                Then user can retrieve payload from 'tmfmediator_create_addnumbers'
                                """)
    items = numbers.get_service_orders(number_type, context.service_order)
    logger.info(f"Service order items: {items}")

    consumer_messages = KafkaMessagesFilter(context).tmfmediator_create_addnumbers(number_type)
    logger.info(f"Received payload consumer messages: {consumer_messages}")

    items.sort(key=lambda item: item["id"])
    consumer_messages.sort(key=lambda msg: msg["addNumbers"]["marketplaceEventId"])
    asserts.equals(len(consumer_messages), len(items), "Number of received consumer messages")
    for index, consumer_message in enumerate(consumer_messages):
        logger.debug(f'Validate consumer message {index}: {consumer_message}')
        KafkaTopicValidator(context).tmfmediator_create_addnumbers(number_type, items[index], consumer_message)


@when("number is added in RingCentral")
def add_number_to_rc(context):
    number_topics = ["numbermanagement_command_add_numbers",
                     "ringcentral_event_numbers_added"]

    for topic_name in number_topics:
        context.execute_steps(f"""
                                        Then user can retrieve payload from '{topic_name}'
                                        # And user can validate payload for kafka topic '{topic_name}' for 'add' number
                                        And user validates the information in '{topic_name}'
                                        """)


@when("number is deleted in RingCentral")
def delete_number_from_rc(context):
    delete_number_topics = ["tmfmediator_create_deletenumbers", "numbermanagement_command_delete_numbers",
                            "ringcentral_event_numbers_deleted"]

    for topic_name in delete_number_topics:
        context.execute_steps(u"""
                                        Then user can retrieve payload from '{topic_name}'
                                        And user can validate payload for kafka topic '{topic_name}' for 'add' number
                                        """.format(topic_name=topic_name))


@when("duplicate numbers are removed from '{number_type}' by Middleware")
def remove_duplicate_numbers_from_type_mw(context, number_type):
    d = Counter()
    if "fwpool" in number_type:
        d = Counter(context.E164_LookupValue)
    elif number_type.startswith('all_duplicate') or hasattr(context, "E164_List") or number_type.endswith("duplicate"):
        d = Counter(context.E164_LookupValue)
        context.E164_List = list(set(context.E164_List))
        context.E164_LookupValue = list(set(context.E164_LookupValue))
        if hasattr(context, "number_fwpool_list"):
            context.number_fwpool_list = list(set(context.number_fwpool_list))
        if hasattr(context, "number_pool_list"):
            context.number_pool_list = list(set(context.number_pool_list))
    elif number_type.startswith("duplicate") and hasattr(context, "pool"):
        d = Counter(context.pool)
        context.pool = list(set(context.pool))
    context.duplicated_numbers = [k for k, v in d.items() if v > 1]


@then(
    "user retrieves and validates '{number_type}' number from 'numbermanagement_respond_numbersadded' topic for '{state}'")
def retrieve_numbermanagement_respond_numbersadded_number_for_state(context, number_type, state):
    context.execute_steps("""Then user can retrieve payload from 'numbermanagement_respond_numbersadded'""")
    logger.info(f"{context.consumer_payload=}")
    logger.info(f" ")
    KafkaTopicValidator(context).validate_topic(topic_name="numbermanagement_respond_numbersadded",
                                                number_type=number_type, state=state)


# And update numbers in the service order with 'value'
@given("update numbers in the service order with '{value}' for '{channel}'")
@given("update the numbers in the service order with '{value}'")
def update_numbers_with_values(context, value, channel="TMF"):
    context.number_type = context.usage_type = value
    context.new_pool = []

    if channel == "TMF":
        if value in ('same_account_partial_presentation', 'same_account_partial_inventory'):
            for i, number in enumerate(get_pool(context.payload['serviceOrderItem'][0])):
                modified_number = number + duplicate_number_suffix[value]
                if i == 0:
                    modified_number = number + duplicate_number_suffix['different_account']
                context.new_pool.append(modified_number)
            context.payload['serviceOrderItem'][0]['service']['supportingResource'][0]['resourceCharacteristic'][0][
                'value']['pool'] = context.new_pool

        else:
            for number in get_pool(context.payload['serviceOrderItem'][0]):
                context.new_pool.append(number + duplicate_number_suffix[value])
                context.payload['serviceOrderItem'][0]['service']['supportingResource'][0]['resourceCharacteristic'][0][
                    'value']['pool'] = context.new_pool

    elif channel == "Appdirect":
        if value.endswith('presentation'):
            key = 'fw_pool'
        else:
            key = 'pool'
        if value == 'same_account_partial_inventory':
            for i, number in enumerate(context.poolpayload[key]):
                modified_number = number + duplicate_number_suffix[value]
                if i == 0:
                    modified_number = number + duplicate_number_suffix['different_account']
                context.new_pool.append(modified_number)
            context.poolpayload['main_number'] = context.main_number_add = context.main_number_add + \
                                                                           duplicate_number_suffix['different_account']

        elif value in ("different_account_inventory", "different_account_presentation"):
            value = "different_account"
            for number in context.poolpayload[key]:
                context.new_pool.append(number + duplicate_number_suffix[value])

        else:
            if value in (
                    "MainCompanyNumber_inventory", "ForwardedNumber_presentation", "ForwardedCompanyNumber_inventory",
                    "DirectNumber_presentation"):
                value = value.split("_")[0]
            for number in context.poolpayload[key]:
                context.new_pool.append(number + duplicate_number_suffix[value])
            if context.number_type not in ("ForwardedNumber_presentation", "DirectNumber_presentation"):
                context.poolpayload['main_number'] = context.main_number_add = context.main_number_add + \
                                                                               duplicate_number_suffix[value]

        context.poolpayload[key] = context.new_pool


# And customer creates an order to 'add' 'same' numbers as '<pool_type>' against '<account_type>' account
@when("customer creates an order to 'add' 'same' numbers as '{pool_type}' against '{account_type}' account")
def create_add_same_numbers_order_for_account(context, pool_type, account_type):
    context.account_type = account_type
    context.pool_type = pool_type
    common.update_key(context.payload, 'poolType', pool_type)

    if account_type == "different":
        context.number_payload = context.payload
        del context.payload
        del context.op_co_customer_id

        account.create_new_account(context, 'FULL_STACK_STANDARD', "VFDE", "confirmed")
        payload.update_account_id(context.number_payload, context.op_co_customer_id)
        context.payload = context.number_payload

    logger.debug(f'Altered payload {context.payload=}')


# And user retrieves and validates 'same' numbers from 'ringcentral_event_numbers_added' topic for '<state>'
@then("user retrieves and validates 'same' numbers from 'ringcentral_event_numbers_added' topic for '{state}'")
def step_impl(context, state):
    context.usage_type = "Presentation"

    if context.pool_type == "Fixed":
        context.usage_type = "Inventory"

    expected_numbers = numbers.get_numbers_list(context.payload['serviceOrderItem'])

    topic_name = 'ringcentral_event_numbers_added'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)

    if state == "failure":
        if context.account_type == "different":
            context.consumer_payload = [context.consumer_payload[1]]
            KafkaTopicValidator(context).ringcentral_event_numbers_added(context.usage_type, expected_numbers,
                                                                         context.consumer_payload, "number_in_use")
        else:
            context.consumer_payload = [context.consumer_payload[-1]]
            KafkaTopicValidator(context).ringcentral_event_numbers_added(context.usage_type, expected_numbers,
                                                                         context.consumer_payload,
                                                                         "incompatible_usage_type")
    else:
        KafkaTopicValidator(context).ringcentral_event_numbers_added(context.usage_type, expected_numbers,
                                                                     context.consumer_payload[-1])
