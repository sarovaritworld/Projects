import logging

from behave import given, then

from classes import common, database, operations, read_xmldata
from classes.api.requests.ringcentral_gateway import stub_accounts
from classes.common import create_or_update_key
from classes.domain.account import Policies
from classes.kafka import KafkaTopics
from classes.kafka import consumer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF import Action, UnityAccountPayloadGenerator
from classes.utils import strtobool
from common_python.stub_accounts.stub_accounts import StubAccounts
from features.steps import TMFHandler
from features.steps import flowHandler, kafkaHandler
from features.steps.CRFHandler import processed_crf_number
from features.steps.kafkaHandler import get_messages

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)
stub_accounts = StubAccounts()


@given("add ucc.unity.tenant service order requested")
def add_ucc_unity_tenant_service_order_requested(context):
    TMFHandler.create_payload_add_unity_account(context, market_code='VFIT', product_type='FULL_STACK_STANDARD',
                                                order_type=None)
    context.service_type = 'ucc.unity.tenant'
    context.action = Action.add.name


@then("Tenant policy service characteristic are sent to the RingCentral")
def tenant_policy_service_characteristic_sent_to_ringcentral(context, error_type=None):
    get_messages(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    flowHandler.account_is_created(context)
    processed_crf_number(context)
    operations.validate_operations_order(context.service_type,
                                         context.action,
                                         context.service_order_id,
                                         'SET_POLICY_ACCESS')
    context.operation_id = database.get_operation_id_by_service_order_operation('SET_POLICY_ACCESS',
                                                                                context.service_order_id)

    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    common.update_middleware_correlation_id(context)
    tmfmediator_command_set_policy_access_topic_validated(context)
    ringcentral_event_policy_access_set_topic_validated(context, error_type)


@then("service order is completed for geo restriction")
def service_order_is_completed_for_geo_restriction(context):
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    TMFHandler.validate_service_order_final_state(context, 'completed')


@given("'{quantity}' '{policy}' is provided in Tenant policy service characteristic")
def quantity_policy_provided_in_tenant_policy_service_characteristic(context, quantity,
                                                                     policy):
    if context.unity_account.policies is None:
        policies = Policies(enabled=True)
    else:
        policies = context.unity_account.policies
    match policy:
        case 'geoLocations':
            geo_locations = Policies.get_country_codes(quantity)
            policies.geo_locations = geo_locations
        case 'ips':
            ips = Policies.generate_ip_addresses(quantity)
            policies.ips = ips

    context.unity_account.policies = policies
    context.payload = UnityAccountPayloadGenerator(unity_account=context.unity_account,
                                                   action=Action.add
                                                   ).to_dict()


@given("policies field '{field}' is set to '{value}'")
def field_set_to_value(context, field, value):
    create_or_update_key(context.payload, f'$..{field}', value)


@given("'{field}' policies are requested but not provided")
def policies_requested_but_not_provided(context, field):
    field_set_to_value(context, f'$..{field}', '')


@given("enabled value is set to '{enabled_value}' and '{field}' is provided")
def enabled_value_and_field_provided(context, enabled_value, field):
    quantity_policy_provided_in_tenant_policy_service_characteristic(context, 1, field)
    field_set_to_value(context, '$..enabled', strtobool(enabled_value))


@then("policies are not sent to RingCentral")
def policies_not_sent_to_ringcentral(context):
    get_messages(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    flowHandler.account_is_created(context)
    processed_crf_number(context)
    database.validate_operation_not_exists(context.service_order_id, 'SET_POLICY_ACCESS')


@given("account is updated to fail on '{error_type}'")
def account_updated_to_fail_on_failure_endpoint_in_rc(context, error_type):
    quantity_policy_provided_in_tenant_policy_service_characteristic(context, 1, 'geoLocations')
    prefix_mapping = {
        'failed_create_policy': stub_accounts.rc.geo_failed_create_policy_prefix,
        'failed_add_rule': stub_accounts.rc.geo_failed_add_rule_prefix,
        'failed_enable_policy': stub_accounts.rc.geo_failed_enable_policy_prefix
    }
    geo_op_co_customer_id = prefix_mapping.get(error_type) + read_xmldata.gen_opco(marketplace='TMF')
    context.unity_account.op_co_customer_id = context.op_co_customer_id = geo_op_co_customer_id
    create_or_update_key(context.payload, 'externalReference[0].id', geo_op_co_customer_id)


@then("geo restriction operation is suspended for '{error_type}'")
def geo_operation_suspended(context, error_type):
    tenant_policy_service_characteristic_sent_to_ringcentral(context, error_type)


def tmfmediator_command_set_policy_access_topic_validated(context):
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.tmfmediator_command_set_policy_access.name)
    KafkaTopicValidator(context).tmfmediator_command_set_policy_access()


def ringcentral_event_policy_access_set_topic_validated(context, error_type: str = None):
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.ringcentral_event_policy_access_set.name)
    KafkaTopicValidator(context).ringcentral_event_policy_access_set(error_type)
