import logging

from behave import *


# Given User creates fully onboarded initial order for 'Full Stack' with confirmed status
# Given User creates fully onboarded initial order for 'Full Stack' with confirmed status
@given("User creates fully onboarded initial order for '{product_name}' with confirmed status")
def create_product_onboarded_initial_order_confirmed_status(context, product_name):
    context.execute_steps(u"""
                    Given user purchases '{product_type}' product with 'Premium' level edition with license '5'
                    Then user can retrieve payload from 'appdirect_create_initialorder'
                    Then user can retrieve payload from 'ordermanagement_command_create_initialorder'
                    Then user can retrieve payload from 'ringcentral_event_initialorder_created'
                    Then validate user receives 'middleware_correlation_id' from 'ringcentral_event_initialorder_created'
                    Then validate user receives 'marketplace_event_id' from 'ringcentral_event_initialorder_created'
                    Then user validates the data in database for 'appdirect_create_initialorder'
                    Then user can retrieve payload from 'ordermanagement_event_account_created'
                    When user has a Complete Order payload for topic 'numbermanagement_command_complete_order'
                    And payload is sent to Kafka Topic 'numbermanagement_command_complete_order'
                    Then user can retrieve payload from 'ordermanagement_command_update_accountstatus'
                    Then user can retrieve payload from 'ringcentral_event_accountstatus_updated'
                    Then user can retrieve payload from 'ordermanagement_event_order_completed'
                    Then user validates 'success message' for 'Initial Order' in Appdirect Stub sent from Middleware
                    Then user validates 'success message' for 'Initial Order' in DataFactory Stub sent from Middleware

                    """.format(product_type=product_name))


# Given User creates 'Full Stack' initial order with unconfirmed status
# Given User creates 'Full Stack' initial order with unconfirmed status
@given("User creates '{product_name}' initial order with received status")
@given("User creates '{product_name}' initial order with unconfirmed status")
def create_product_initial_order_with_status(context, product_name):
    context.execute_steps(u"""
                    Given user purchases '{product_type}' product with 'Premium' level edition with license '5'
                    Then user can retrieve payload from 'appdirect_create_initialorder'
                    Then user can retrieve payload from 'ordermanagement_command_create_initialorder'
                    Then user can retrieve payload from 'ringcentral_event_initialorder_created'
                    Then validate user receives 'middleware_correlation_id' from 'ringcentral_event_initialorder_created'
                    Then validate user receives 'marketplace_event_id' from 'ringcentral_event_initialorder_created'
                    Then user validates the data in database for 'appdirect_create_initialorder'
                    Then user can retrieve payload from 'ordermanagement_event_account_created'
                    """.format(product_type=product_name))


# Given User creates 'Full Stack' initial order with error status
@given("User creates '{product_name}' initial order with error status")
def create_product_initial_order_with_error_status(context, product_name):
    context.execute_steps(u"""
                    Given User create put request for '{numbertype}'
                    Given user purchases '{product_type}' product with 'Premium' level edition with license '5'
                    Then user can retrieve payload from 'appdirect_create_initialorder'
                    Then user can retrieve payload from 'ordermanagement_command_create_initialorder'
                    Then user can retrieve payload from 'ringcentral_event_initialorder_created'
                    """.format(numbertype="Invalid_Parameter", product_type=product_name))


# Given user creates initial order for 'Full Stack' with 'Standard' level edition with license '5'
@given("user creates initial order for '{product_type}' with '{edition_type}' level edition with license '{no_of_lic}'")
def create_product_initial_order_with_edition_license(context, product_type, edition_type, no_of_lic):
    context.execute_steps(u"""
                    Given user purchases '{product_type}' product with '{edition_type}' level edition with license '{no_of_lic}'
		            Then user can retrieve payload from 'appdirect_create_initialorder'
		            Then user can retrieve payload from 'ordermanagement_command_create_initialorder'
		            Then user can retrieve payload from 'ringcentral_event_initialorder_created'
		            Then validate user receives new RingCentralID
                    Then user can retrieve payload from 'ordermanagement_event_account_created'

                    """.format(product_type=product_type, edition_type=edition_type, no_of_lic=no_of_lic))
    try:
        context.op_co_customer_id = context.consumer_payload['account']['op_co_details']['op_co_customer_id']
    except KeyError:
        logging.error(f'There is no key in {context.consumer_payload}')


# Given user creates initial order and retrieves the payload from the topics and updates the xml for 'json_del_request_body'
@given("user creates initial order and retrieves the payload from the topics and updates the xml for '{request_body}'")
def create_initial_order_retrieve_topic_payload_update_xml(context, request_body):
    context.jsonrequest_body = request_body
    context.execute_steps(u"""
                    Given user purchases '{product_type}' product with 'Premium' level edition with license '5'
		            Then user can retrieve payload from 'appdirect_create_initialorder'
		            Then user can retrieve payload from 'ordermanagement_command_create_initialorder'
		            Then user can retrieve payload from 'ringcentral_event_initialorder_created'
		            Then validate user receives new RingCentralID
                    Then user can retrieve payload from 'ordermanagement_event_account_created'

                    """.format(product_type="Full Stack"))
