import logging

from behave import *

from classes import asserts, common, payload
from classes.api.requests import tmf_gateway


@given("initial order successfully processed in Middleware")
def initial_order_processsed_in_mw(context):
    context.execute_steps("""
        When account is created
        And main number is added
        And number has been provisioned in CRF
        Then user retrieves and validates data in 'tmfmediator_command_update_accountstatus' topic
        """)


@when("account is created")
@then("account is created")
def account_is_created(context):
    context.execute_steps("""
        Then user retrieves and validates data in 'tmfmediator_command_create_initialorder' topic
        And user retrieves and validates data in 'ordermanagement_command_create_initialorder' topic
        And user retrieves and validates data in 'ringcentral_event_initialorder_created' topic
        And user retrieves and validates data in 'ordermanagement_event_account_created' topic
        """)


# TODO: validations of CRF should be within this step also
@when("main number is added")
def main_number_is_added(context):
    context.execute_steps("""
        Then user retrieves and validates data in tmfmediator_create_addnumbers topic for Main Number
        And user retrieves and validates data in numbermanagement_command_add_numbers topic for Main Number
        And user retrieves and validates data in ringcentral_event_numbers_added topic for Main Number      
        """)


@given("account is unconfirmed")
def account_unconfirmed(context):
    context.execute_steps("""
        Then user validates payload is not present in 'ordermanagement_command_update_accountstatus'
        And user validates payload is not present in 'ringcentral_event_accountstatus_updated'
        And user retrieves and validates data in 'ordermanagement_event_order_completed' topic with 'unconfirmed_account'
        """)


@given("account is confirmed")
@then("account is confirmed")
def account_confirmed(context):
    context.execute_steps("""
       Then user retrieves and validates data in 'ordermanagement_command_update_accountstatus' topic
       And user retrieves and validates data in 'ringcentral_event_accountstatus_updated' topic
       And user retrieves and validates data in 'ordermanagement_event_order_completed' topic
       """)


# Then RingCentral fails to 'add_main_number_patch'
@when("RingCentral fails to '{event_type}'")
def rc_fails_event_type(context, event_type):
    asserts.equals(context.negative_event_type, event_type, "event type")
    if event_type == "confirm_account":
        initial_order_processsed_in_mw(context)
        context.execute_steps("""
            Then user retrieves and validates data in 'ordermanagement_command_update_accountstatus' topic
            """)
        if not hasattr(context, 'confirmation_status'):
            context.execute_steps("""
                       Then user retrieves and validates 'error_message' from 'ringcentral_event_accountstatus_updated'
                       And user retrieves and validates data in 'ordermanagement_event_order_completed' topic with 'unconfirmed_account'
                       """)
        else:
            context.execute_steps("""
                       Then user retrieves and validates data in 'ringcentral_event_accountstatus_updated' topic
                       """)
    elif event_type == "add_main_number_patch":
        context.execute_steps("""
            When account is created
            Then user retrieves and validates data in 'tmfmediator_create_addnumbers' topic
            And user retrieves and validates data in 'numbermanagement_command_add_numbers' topic
            Then user retrieves error message from 'ringcentral_event_numbers_updated'
            Then user retrieves and validates data in 'numbermanagement_respond_numbersadded' topic with 'failed_add_main_number'
            """)
    elif event_type == "add_number":
        context.execute_steps("""
            When account is created
            Then user retrieves and validates data in 'tmfmediator_create_addnumbers' topic
            And user retrieves and validates data in 'numbermanagement_command_add_numbers' topic
            And user retrieves error message from 'ringcentral_event_numbers_added'
            And user retrieves and validates data in 'numbermanagement_respond_numbersadded' topic with 'failed_add_number'
            """)
    elif event_type == "create_account":
        context.execute_steps("""
            Then user retrieves and validates data in 'tmfmediator_command_create_initialorder' topic
            And user retrieves and validates data in 'ordermanagement_command_create_initialorder' topic
            And user retrieves error message from 'ringcentral_event_initialorder_created'
            And user retrieves and validates 'error_message' from 'ordermanagement_event_order_completed'
            """)
    else:
        assert False, "Validation scripts are not available for this Event:{} and {}".format(
            context.negative_event_type, event_type)


@when("customer sends an order to Middleware")
def customer_sends_an_order_to_middleware(context):
    context.response = tmf_gateway.Client().create_service_order(context.payload)
    context.response_payload = context.response.json()

    context.execute_steps("""
        Then user validates the response data for 'create_service_order' from TMF Service Order API Gateway
        And user retrieves and validates data in 'tmfgateway_process_serviceorder' topic
        """)

    # validate all topics for successful add account
    if payload.has_initial_order(context.payload):
        if not hasattr(context, "negative_event_type"):
            if getattr(context, "confirmation_status", False):
                context.negative_event_type = 'confirm_account'
            context.execute_steps("""Given initial order successfully processed in Middleware""")
            if hasattr(context, "activate_immediately") and context.activate_immediately is False:
                context.execute_steps("""Given account is unconfirmed""")
            elif not hasattr(context, "confirmation_status"):
                context.execute_steps("""Given account is confirmed""")
        if not common.config.is_crf_add_number_enabled:
            # keep only add account item
            context.service_order = [context.payload['serviceOrderItem'][0]]
            context.execute_steps("""   
            Then JIRA tickets has been created successfully
            When BO tool sends PATCH request on 'service_order_item' level for 'tenant' is 'completed'
""")
            del context.service_order
        context.add_account_validated = True
        # if hasattr(context, 'patch_milestones'):
        #     del context.patch_milestones


@when("customer sends an order to Middleware with CRF")
def customer_sends_service_order_to_mw_with_crf(context):
    context.execute_steps("""
        When Service Order processed successfully in TMF Gateway
        """)
    if payload.has_initial_order(context.payload):
        if not hasattr(context, "negative_event_type"):
            context.execute_steps("""
                When account is created
                And main number is added
            """)


@when("Service Order processed successfully in TMF Gateway")
def tmf_gw_service_order_processed(context):
    context.response = tmf_gateway.Client().create_service_order(context.payload)
    context.response_payload = context.response.json()

    logging.info(f"Response is :: {context.response_payload}")
    logging.info('\n')

    context.execute_steps("""
        Then user validates the response data for 'create_service_order' from TMF Service Order API Gateway
        And user retrieves and validates data in 'tmfgateway_process_serviceorder' topic
             """)


# TODO: remove this step to another module: this module is used to control the flow
@given("customer adds '{carrier_id}' under the '{service_order}' service order")
def carrier_id_added_under_service_order(context, carrier_id=None, service_order=None):
    context.service_order_type = service_order
    if carrier_id == "default":
        return
    if carrier_id == "Empty" and service_order == "add_tenant":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["carrierId"] = ""
        return
    if carrier_id == "Empty" and service_order == "add_number":
        context.payload["serviceOrderItem"][0]["service"]["supportingResource"][0]["resourceCharacteristic"][0][
            "value"]["carrierId"] = ""
        return
    context.carrier_id = str(carrier_id).replace("-", "_")
    if service_order == "add_tenant":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["carrierId"] = carrier_id
    else:
        context.payload["serviceOrderItem"][0]["service"]["supportingResource"][0]["resourceCharacteristic"][0][
            "value"]["carrierId"] = carrier_id
