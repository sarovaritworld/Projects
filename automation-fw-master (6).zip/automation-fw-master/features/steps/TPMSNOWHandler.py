import logging

from behave import given, then, when
from jsonpath_ng import parse

from classes import account, asserts, common, database, generate, read_xmldata, tpm, utils
from classes.api.requests import idmapper
from classes.data_factory import countries_data_manager
from classes.domain.account import ItsmProvisioning, TPMAccount
from classes.kafka import KafkaTopics, consumer_data, topic_validator
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF import Action
from classes.payload_generators.TMF.account_generator import TPMAccountPayloadGenerator
from classes.snow import SNOWAPIError, check_snow_onboarding_state
from classes.utils import to_json
from common_python.stub_accounts.stub_accounts import StubAccounts
from features.steps import TMFHandler, TpmHandler, databaseHandler, kafkaHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)

@given("TPM customer with SNOW onboarding details is processed for '{market}' market full onboarding as '{link_service_to_fully_onboarded_customer}'")
@given("TPM customer with SNOW onboarding details is processed for '{market}' market")
def tpm_customer_with_snow_onboarding_details_is_processed(context, market, link_service_to_fully_onboarded_customer=None):
    tpm_customer_creates_a_service_order_to_add_snow_onboarding_details(context, enable_provisioning=True, market=market, link_service_to_fully_onboarded_customer=link_service_to_fully_onboarded_customer)
    TMFHandler.request_is_sent_to_create_service_order(context)
    TpmHandler.tpm_customer_created_in_middleware(context)
    databaseHandler.validate_snow_characteristic_fields(context)


@given("Add TPM Number is ordered")
def add_number_is_ordered(context):
    TpmHandler.tpm_order_created_for_numbers(context, action='add', quantity=5, resource_type='pool',
                                             order_type='separate')
    TMFHandler.request_is_sent_to_create_service_order(context)


@when("Add TPM Numbers are processed in Middleware with email '{status}'")
def add_numbers_are_processed_in_middleware(context, status):
    tpm.validate_order_tpm_snow_operation(context.service_order_id)
    TpmHandler.tpm_numbers_successfully_provisioned(context)
    TpmHandler.validate_email_notification_sent_to_nao(context, status)


@when("Add TPM Numbers failed in Middleware")
def add_numbers_are_failed_in_middleware(context):
    tpm.validate_order_tpm_snow_operation(context.service_order_id)
    TpmHandler.tpm_numbers_failed_provisioning(context, 'FAILED_SERVICE_ORDER')


@then("TPM SNOW onboarding is processed in Middleware")
def tpm_snow_onboarding_is_processed_in_middleware(context):
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()
    check_snow_onboarding_state('ACTIVE', context.tpm_account.op_co_customer_id)
    if common.config.is_dev_env and context.market_code == "VFUK":
        database.validate_service_inventory_request_for_tpm(context.tpm_account.bgid,
                                                            context.tpm_account.itsm_provisioning.local_market_service_id,
                                                            context.tpm_account.itsm_provisioning.link_service_to_fully_onboarded_customer,
                                                            context.tpm_account.op_co_customer_id)
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created()
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)
    TpmHandler.validate_service_order_tpm_add_number(context, 'completed')


@given('TPM customer with SNOW onboarding details and add numbers are requested in same order')
def tpm_customer_with_snow_onboarding_details_and_add_numbers_are_requested_in_same_order(context,
                                                                                          enable_provisioning=True,
                                                                                          market_code='VFDE'):
    tpm_customer_creates_a_service_order_to_add_snow_onboarding_details(context, enable_provisioning, market_code)
    TpmHandler.tpm_order_created_for_numbers(context, action='add', quantity=5, resource_type='pool',
                                             order_type='complex')
    TMFHandler.request_is_sent_to_create_service_order(context)
    TpmHandler.tpm_customer_created_in_middleware(context)
    databaseHandler.validate_snow_characteristic_fields(context)


@given("tenant id is set to fail with '{outcome}' for TPM")
def tenant_id_is_set_to_fail_tpm(context, outcome: str):
    context.error_type = outcome
    # sending below tenant_id as per stub implementation for fail case
    stub_accounts = StubAccounts()
    context.tpm_tenant_id = stub_accounts.snow.snow_onboarding_failed_tenant_id
    context.snow_onboarding = False


@then('TPM SNOW onboarding is failed in Middleware')
def tpm_snow_onboarding_is_failed_in_middleware(context):
    logger.info(f'validating {getattr(context, "error_type")=}')
    context.snow_onboarding = False
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created(error_type=SNOWAPIError(),
                                                                        account_provisioned=False)
    context.service_order_item_id = '2'
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)
    TMFHandler.support_topic_sent(context, 'OPERATION_FAILED', 'SNOW')
    TMFHandler.validate_service_order_final_state(context, context.error_type)


@given('TPM account is already onboarded to SNOW')
def tpm_account_is_already_onboarded_to_snow(context):
    tpm_customer_with_snow_onboarding_details_and_add_numbers_are_requested_in_same_order(context)
    context.snow_onboarding_validated = True
    logger.info('account is onboarded')
    add_numbers_are_processed_in_middleware(context, "sent")
    tpm_snow_onboarding_is_processed_in_middleware(context)

    context.payload = None
    del context.snow_onboarding


@then('TPM SNOW onboarding is not processed twice')
def tpm_snow_onboarding_is_not_processed_twice(context):
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created(account_provisioned=False)
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)
    TMFHandler.validate_service_order_final_state(context, 'completed')


@given('TPM customer does not want to use automated service onboarding into SNOW')
def tpm_customer_with_snow_false(context):
    onboard_tpm_account(context, False)


@then('TPM SNOW onboarding is not processed for this account')
def tpm_snow_onboarding_is_not_processed(context):
    del context.snow_onboarding
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created(account_provisioned=False)
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)
    TMFHandler.validate_service_order_final_state(context, 'completed')


@then('TPM SNOW onboarding should not be triggered for this account')
def tpm_snow_onboarding_not_triggered(context):
    kafkaHandler.validate_payload_not_present_in_topic(context, 'tmfmediator_command_create_snowcustomer')


def onboard_tpm_account(context, enable_provisioning=True):
    """ TPM customer has been created and onboarded without DDIs"""

    tpm_customer_creates_a_service_order_to_add_snow_onboarding_details(context, enable_provisioning)
    TMFHandler.request_is_sent_to_create_service_order(context)
    TpmHandler.tpm_customer_created_in_middleware(context)
    context.tpm_customer_onboarded = True


@given("TPM customer creates a service order to add SNOW onboarding details for '{market}'")
def tpm_customer_creates_a_service_order_to_add_snow_onboarding_details(context, enable_provisioning=True,
                                                                        market="VFDE", link_service_to_fully_onboarded_customer: str = None):
    context.enable_provisioning = enable_provisioning
    context.snow_onboarding = True
    if common.config.is_staging_env:
        context.tpm_tenant_id = account.EXISTING_TPM_CUSTOMER['staging_itsm_tenant']
        market = 'VFUK'
    lmsid_pattern = "^[0-9A-Za-z-]{1,20}$"
    local_market_service_id = generate.string_by_regex(lmsid_pattern) if market == "VFUK" else None
    if link_service_to_fully_onboarded_customer:
        link_service_to_fully_onboarded_customer = bool(utils.strtobool(link_service_to_fully_onboarded_customer))
    tpm_account = TPMAccount(market_code=market,
                             tenant_id=getattr(context, 'tpm_tenant_id', None),
                             op_co_customer_id=getattr(context, 'op_co_customer_id', None),
                             itsm_provisioning=ItsmProvisioning(enable_provisioning=enable_provisioning,
                                                                local_market_service_id=local_market_service_id, link_service_to_fully_onboarded_customer=link_service_to_fully_onboarded_customer))
    context.payload = TPMAccountPayloadGenerator(tpm_account=tpm_account, action=Action.add).to_dict()
    context.tpm_account = tpm_account
    context.market_code = tpm_account.market_code
    context.op_co_customer_id = context.tpm_account.op_co_customer_id


def validate_itsm_info_in_id_mapper_api(context):
    param = {'market': context.tpm_account.market_code, 'vodafone_customer_id': context.tpm_account.op_co_customer_id}
    response_data = idmapper.Client().get_tpm_customer(param)
    context.response = response_data.json()
    logging.info("ID Mapper Response is :: ")
    logging.info(to_json(context.payload))

    # appending "T00:00:00Z" with date as id_mapper response is in ISO 8601 formate for exact assertion
    expected_contract_start_date = (context.tpm_account.itsm_provisioning.contract_start_date) + ("T00:00:00Z")
    expected_contract_end_date = (context.tpm_account.itsm_provisioning.contract_end_date) + ("T00:00:00Z")

    asserts.equals(context.tpm_account.itsm_provisioning.enable_provisioning,
                   context.response['itsm_provisioning']['enable_provisioning'], "Incorrect enable_provisioning value")
    asserts.equals(expected_contract_start_date, context.response['itsm_provisioning']['contract_start_date'],
                   "contract_start_date is not matching")
    asserts.equals(expected_contract_end_date, context.response['itsm_provisioning']['contract_end_date'],
                   "contract_end_date is not matching")


@given("service order is created to add TPM SNOW onboarding with an existing LMSID for VFUK market")
def create_service_order_with_existing_lmsid(context, enable_provisioning=True):
    context.snow_onboarding = True
    local_market_service_id = account.EXISTING_LOCAL_MARKET_SERVICE_ID['existing_lmsid']
    tpm_account = TPMAccount(market_code=context.market_code,
                             tenant_id=getattr(context, 'tpm_tenant_id', None),
                             itsm_provisioning=ItsmProvisioning(enable_provisioning=enable_provisioning,
                                                                local_market_service_id=local_market_service_id))
    context.payload = TPMAccountPayloadGenerator(tpm_account=tpm_account, action=Action.add).to_dict()
    context.tpm_account = tpm_account
    context.op_co_customer_id = context.tpm_account.op_co_customer_id


@then("TPM SNOW customer is failed in idmapper")
def tpm_snow_customer_is_failed_in_idmapper(context):
    if context.service_order_id:
        context.marketplace_event_id = context.service_order_id + "/1"  # 1st service_order_item
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    common.update_middleware_correlation_id(context)
    common.save_marketplace_event_id(context)

    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_create_tpmcustomer')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_create_tpmcustomer()

    TpmHandler.data_validated_in_idmapper_event_tpmcustomer_created(context, parameter='local_market_service_id',
                                                                    value='existing')


@given("Payload is created and sent to tmfmediator_command_create_tpmcustomer topic with itsminfo")
@given("kafka message for topic tmfmediator_command_create_tpmcustomer is sent with itsminfo {parameter} as {value}")
def payload_created_sent_to_tmfmediator_command_create_tpmcustomer_with_lmsid(context, parameter=None, value=None):
    context.snow_onboarding = True
    lmsid_pattern = "^[0-9A-Za-z-]{1,20}$"
    local_market_service_id = generate.string_by_regex(lmsid_pattern)
    itsm_provisioning = ItsmProvisioning(enable_provisioning=True, local_market_service_id=local_market_service_id)
    context.tpm_account = TPMAccount(market_code=context.market_code,
                                     tenant_id=getattr(context, 'tpm_tenant_id', None),
                                     itsm_provisioning=itsm_provisioning)

    # Read payload for the topic from test data json file
    topic_name = "tmfmediator_command_create_tpmcustomer"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")

    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.event_type = context.payload["header"]["event_type"]
    context.marketplace_event_id = context.payload["tpm_customer_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"]["name"] = context.market_code
    context.country_code = context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"][
        "country_code"] = countries_data_manager.get_country_code(context.market_code)
    context.op_co_customer_id = context.payload["tpm_customer_request"]["tpm_customer"]["op_co_details"][
        "op_co_customer_id"] = context.tpm_account.op_co_customer_id
    context.itsm_provisioning = context.payload["tpm_customer_request"]["tpm_customer"][
        "itsm_provisioning"] = itsm_provisioning.__dict__
    context.payload["tpm_customer_request"]["tpm_customer"]["itsm_provisioning"]["enable_provisioning"] = True
    key_path = {
        "local_market_service_id": "tpm_customer_request.tpm_customer.itsm_provisioning.local_market_service_id"}
    value_map = {
        "blank": "",
        "invalid": account.EXISTING_LOCAL_MARKET_SERVICE_ID['invalid_lmsid'],
    }
    if value in value_map:
        new_value = value_map[value]
        parse(key_path[parameter]).update(context.payload, new_value)

    kafkaHandler.payload_is_sent_for_kafka_topic(context, topic_name)
