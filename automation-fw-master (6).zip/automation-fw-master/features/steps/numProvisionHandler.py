import json
import logging
import os
from http import HTTPStatus

from classes import common
from classes.data_factory import countries_data_manager
from classes.utils import to_json

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)

from behave import *

from classes import read_xmldata, common, account, data
from classes.api.requests import number_management_api as nm
from classes.status_code_validator import StatusCodeValidator
from common_python import api_requests

MIDDLEWARE_API_SERVER = os.environ.get("MIDDLEWARE_API_SERVER")
SERIES_ONE = os.environ.get("PHONE_NUMBER_SERIES_ONE")
SERIES_TWO = os.environ.get("PHONE_NUMBER_SERIES_TWO")
UK_TELEPHONE_CODE = read_xmldata.readxml("UK_ISD_CODE", "test_inputdata", "num_prov")
DE_TELEPHONE_CODE = countries_data_manager.get_isd_code('VFDE') + countries_data_manager.get_area_code('VFDE')
NUMBER_OF_DIGIT = read_xmldata.readxml("NUMBER_OF_DIGIT", "test_inputdata", "num_prov")
MAX_NUM_LIMIT = read_xmldata.readxml("MAX_NUM_LIMIT", "test_inputdata", "num_prov")
NUMBER_MANAGEMENT_URL = "http://" + read_xmldata.readxml("number_management", "test_inputdata", "MS_urls")
INVALID_NUMBER_OF_DIGIT = read_xmldata.readxml("INVALID_NUMBER_OF_DIGIT", "test_inputdata", "num_prov")


@given('a list of numbers are received from DXL')
@then('a list of numbers are received from DXL')
def compose_nm_pool_url(context):
    context.finalurl = nm.Client.url_number_pool(context.market_code, context.op_co_customer_id)


@given("it contains a '{request_body}' in Requestbody")
@then("it contains a '{request_body}' in Requestbody")
def contains_requestbody(context, request_body='jsonrequest_body'):
    if "add_range_numbers" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("batch_AddNumber")
        context.main_number_add = SERIES_ONE + read_xmldata.gen_contact(5)
        context.admin_number_add = SERIES_ONE + read_xmldata.gen_contact(5)
        context.List_primary = [context.main_number_add, context.admin_number_add]
        poolarray_start_range_1 = int(SERIES_TWO + read_xmldata.gen_contact(5))
        poolarray_end_range_1 = int(poolarray_start_range_1) + 2
        poolarray_start_range_2 = int(SERIES_TWO + read_xmldata.gen_contact(5))
        poolarray_end_range_2 = int(poolarray_start_range_2) + 2
        fwpool_start_range = int(SERIES_TWO + read_xmldata.gen_contact(5))
        fwpool_end_range = int(fwpool_start_range) + 2
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'][0]['start'] = "+" + str(poolarray_start_range_1)
        context.poolpayload['pool'][0]['end'] = "+" + str(poolarray_end_range_1)
        context.poolpayload['pool'][1]['start'] = "+" + str(poolarray_start_range_2)
        context.poolpayload['pool'][1]['end'] = "+" + str(poolarray_end_range_2)
        context.poolpayload['fw_pool'][0]['start'] = "+" + str(fwpool_start_range)
        context.poolpayload['fw_pool'][0]['end'] = "+" + str(fwpool_end_range)

        context.E164_PoolList_1 = []
        context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))
        while poolarray_start_range_1 != poolarray_end_range_1:
            poolarray_start_range_1 += 1
            context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))
        context.E164_PoolList_2 = []
        context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))
        while poolarray_start_range_2 != poolarray_end_range_2:
            poolarray_start_range_2 += 1
            context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))

        context.E164_FwPoolList = []
        context.E164_FwPoolList.append("+" + str(fwpool_start_range))
        while fwpool_start_range != fwpool_end_range:
            fwpool_start_range += 1
            context.E164_FwPoolList.append("+" + str(fwpool_start_range))

        context.E164_List = context.List_primary + context.E164_PoolList_1 + context.E164_PoolList_2
        context.E164_LookupValue = context.List_primary + context.E164_PoolList_1 + context.E164_PoolList_2
        logging.info(f"E164 List for DELETE : {context.E164_List}")
        print(context.E164_PoolList_1)
        print(context.E164_PoolList_2)
        print(context.E164_FwPoolList)
    if "range_add_08_numbers" in request_body:
        # SERIES_ONE = SERIES_ONE
        context.poolpayload = read_xmldata.read_jsonfile("batch_AddNumber")
        # context.main_number_add = SERIES_ONE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        # context.admin_number_add = SERIES_ONE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.main_number_add = SERIES_ONE + read_xmldata.randomdigitnumber(44444, 99999)
        context.admin_number_add = SERIES_ONE + read_xmldata.randomdigitnumber(44444, 99999)
        context.List_primary = [context.main_number_add, context.admin_number_add]
        # poolarray_start_range_1 = int(SERIES_TWO + read_xmldata.gen_contact(NUMBER_OF_DIGIT))
        poolarray_start_range_1 = int(SERIES_ONE + read_xmldata.randomdigitnumber(44444, 99999))
        poolarray_end_range_1 = int(poolarray_start_range_1) + 2
        # poolarray_start_range_2 = int(SERIES_TWO + read_xmldata.gen_contact(NUMBER_OF_DIGIT))
        poolarray_start_range_2 = int(SERIES_ONE + read_xmldata.randomdigitnumber(44444, 99999))
        poolarray_end_range_2 = int(poolarray_start_range_2) + 2
        # fwpool_start_range = int(SERIES_TWO + read_xmldata.gen_contact(NUMBER_OF_DIGIT))
        fwpool_start_range = int("+4412367" + read_xmldata.randomdigitnumber(44444, 99999))
        fwpool_end_range = int(fwpool_start_range) + 2
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'][0]['start'] = "+" + str(poolarray_start_range_1)
        context.poolpayload['pool'][0]['end'] = "+" + str(poolarray_end_range_1)
        context.poolpayload['pool'][1]['start'] = "+" + str(poolarray_start_range_2)
        context.poolpayload['pool'][1]['end'] = "+" + str(poolarray_end_range_2)
        context.poolpayload['fw_pool'][0]['start'] = "+" + str(fwpool_start_range)
        context.poolpayload['fw_pool'][0]['end'] = "+" + str(fwpool_end_range)

        context.E164_PoolList_1 = []
        context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))
        while poolarray_start_range_1 != poolarray_end_range_1:
            poolarray_start_range_1 += 1
            context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))

        context.E164_PoolList_2 = []
        context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))
        while poolarray_start_range_2 != poolarray_end_range_2:
            poolarray_start_range_2 += 1
            context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))

        context.E164_FwPoolList = []
        context.E164_FwPoolList.append("+" + str(fwpool_start_range))
        while fwpool_start_range != fwpool_end_range:
            fwpool_start_range += 1
            context.E164_FwPoolList.append("+" + str(fwpool_start_range))

        context.number_fwpool_list = context.E164_FwPoolList
        context.E164_List = context.List_primary + context.E164_PoolList_1 + context.E164_PoolList_2 + context.E164_FwPoolList
        context.E164_LookupValue = context.List_primary + context.E164_PoolList_1 + context.E164_PoolList_2
        context.number_pool_list = context.E164_PoolList_1 + context.E164_PoolList_2
    if "range_add_15_numbers" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("batch_AddNumber")
        context.main_number_add = SERIES_ONE + read_xmldata.randomdigitnumber(44444, 99999)
        context.admin_number_add = SERIES_ONE + read_xmldata.randomdigitnumber(44444, 99999)
        context.List_primary = [context.main_number_add, context.admin_number_add]
        poolarray_start_range_1 = int(SERIES_ONE + read_xmldata.randomdigitnumber(44444, 99999))
        poolarray_end_range_1 = int(poolarray_start_range_1) + 5
        poolarray_start_range_2 = int(SERIES_TWO + read_xmldata.randomdigitnumber(44444, 99999))
        poolarray_end_range_2 = int(poolarray_start_range_2) + 3
        fwpool_start_range = int("+4479778" + read_xmldata.randomdigitnumber(44444, 99999))
        fwpool_end_range = int(fwpool_start_range) + 3
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'][0]['start'] = "+" + str(poolarray_start_range_1)
        context.poolpayload['pool'][0]['end'] = "+" + str(poolarray_end_range_1)
        context.poolpayload['pool'][1]['start'] = "+" + str(poolarray_start_range_2)
        context.poolpayload['pool'][1]['end'] = "+" + str(poolarray_end_range_2)
        context.poolpayload['fw_pool'][0]['start'] = "+" + str(fwpool_start_range)
        context.poolpayload['fw_pool'][0]['end'] = "+" + str(fwpool_end_range)

        context.E164_PoolList_1 = []
        context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))
        while poolarray_start_range_1 != poolarray_end_range_1:
            poolarray_start_range_1 += 1
            context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))

        context.E164_PoolList_2 = []
        context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))
        while poolarray_start_range_2 != poolarray_end_range_2:
            poolarray_start_range_2 += 1
            context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))

        context.E164_FwPoolList = []
        context.E164_FwPoolList.append("+" + str(fwpool_start_range))
        while fwpool_start_range != fwpool_end_range:
            fwpool_start_range += 1
            context.E164_FwPoolList.append("+" + str(fwpool_start_range))

        context.number_fwpool_list = context.E164_FwPoolList
        context.E164_List = context.List_primary + context.E164_PoolList_1 + context.E164_PoolList_2 + context.E164_FwPoolList
        context.E164_LookupValue = context.List_primary + context.E164_PoolList_1 + context.E164_PoolList_2
        logging.info(f"context.E164_List Total : {context.E164_List}")
        logging.info(f" ")
        context.E164_List_one = context.E164_List[:int(MAX_NUM_LIMIT)]
        logging.info(f"context.E164_List_one : {context.E164_List_one}")
        logging.info(f" ")
        context.E164_List_two = context.E164_List[int(MAX_NUM_LIMIT):]
        logging.info(f"context.E164_List_two : {context.E164_List_two}")
        logging.info(f" ")
        context.number_pool_list = context.E164_PoolList_1 + context.E164_PoolList_2
    if "range_add_15_fw_pool_numbers" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("batch_AddNumber_FwPool")
        fwpool_start_range = int("+4479778" + read_xmldata.randomdigitnumber(11111, 33333))
        fwpool_end_range = int(fwpool_start_range) + 15
        context.poolpayload['fw_pool'][0]['start'] = "+" + str(fwpool_start_range)
        context.poolpayload['fw_pool'][0]['end'] = "+" + str(fwpool_end_range)

        context.E164_FwPoolList = []
        context.E164_FwPoolList.append("+" + str(fwpool_start_range))
        while fwpool_start_range != fwpool_end_range:
            fwpool_start_range += 1
            context.E164_FwPoolList.append("+" + str(fwpool_start_range))
        context.number_fwpool_list = context.E164_FwPoolList
        context.E164_LookupValue = context.E164_List = context.E164_FwPoolList
    if "range_add_15_poolnumber" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("batch_AddNumber_poolnumber")
        poolarray_start_range_1 = int("+4433" + read_xmldata.randomdigitnumber(11111111, 33333333))
        poolarray_end_range_1 = int(poolarray_start_range_1) + 7
        poolarray_start_range_2 = int("+4466" + read_xmldata.randomdigitnumber(11111111, 33333333))
        if "duplicate" in request_body:
            poolarray_start_range_2 = poolarray_end_range_1 - 4
        poolarray_end_range_2 = int(poolarray_start_range_2) + 6
        context.poolpayload['pool'][0]['start'] = "+" + str(poolarray_start_range_1)
        context.poolpayload['pool'][0]['end'] = "+" + str(poolarray_end_range_1)
        context.poolpayload['pool'][1]['start'] = "+" + str(poolarray_start_range_2)
        context.poolpayload['pool'][1]['end'] = "+" + str(poolarray_end_range_2)

        context.E164_PoolList_1 = []
        context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))
        while poolarray_start_range_1 != poolarray_end_range_1:
            poolarray_start_range_1 += 1
            context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))

        context.E164_PoolList_2 = []
        context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))
        while poolarray_start_range_2 != poolarray_end_range_2:
            poolarray_start_range_2 += 1
            context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))

        context.E164_List = context.E164_PoolList_1 + context.E164_PoolList_2
        logging.info(f"context.E164_List Total : {context.E164_List}")
        logging.info(f" ")
        context.E164_LookupValue = context.E164_PoolList_1 + context.E164_PoolList_2
        context.E164_List_one = context.E164_List[:int(MAX_NUM_LIMIT)]
        logging.info(f"context.E164_List_one : {context.E164_List_one}")
        logging.info(f" ")
        context.E164_List_two = context.E164_List[int(MAX_NUM_LIMIT):]
        logging.info(f"context.E164_List_two : {context.E164_List_two}")
        logging.info(f" ")
        context.number_pool_list = context.E164_PoolList_1 + context.E164_PoolList_2
    if "delete_range_numbers" == request_body:
        context.poolpayload_json = read_xmldata.read_jsonfile("batch_DeleteNumber")
        poolarray_start_range_1 = int(SERIES_ONE + read_xmldata.randomdigitnumber(11111, 44444))
        poolarray_end_range_1 = int(poolarray_start_range_1) + 3
        poolarray_start_range_2 = int(SERIES_ONE + read_xmldata.randomdigitnumber(11111, 44444))
        poolarray_end_range_2 = int(poolarray_start_range_2) + 3
        fwpool_start_range = int(SERIES_ONE + read_xmldata.randomdigitnumber(11111, 44444))
        fwpool_end_range = int(fwpool_start_range) + 3
        context.poolpayload_json['pool'][0]['start'] = "+" + str(poolarray_start_range_1)
        context.poolpayload_json['pool'][0]['end'] = "+" + str(poolarray_end_range_1)
        context.poolpayload_json['pool'][1]['start'] = "+" + str(poolarray_start_range_2)
        context.poolpayload_json['pool'][1]['end'] = "+" + str(poolarray_end_range_2)
        context.poolpayload_json['fw_pool'][0]['start'] = "+" + str(fwpool_start_range)
        context.poolpayload_json['fw_pool'][0]['end'] = "+" + str(fwpool_end_range)
        context.poolpayload = context.poolpayload_json
        context.E164_PoolList_1 = []
        context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))
        while poolarray_start_range_1 != poolarray_end_range_1:
            poolarray_start_range_1 += 1
            context.E164_PoolList_1.append("+" + str(poolarray_start_range_1))

        context.E164_PoolList_2 = []
        context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))
        while poolarray_start_range_2 != poolarray_end_range_2:
            poolarray_start_range_2 += 1
            context.E164_PoolList_2.append("+" + str(poolarray_start_range_2))

        context.E164_FwPoolList = []
        context.E164_FwPoolList.append("+" + str(fwpool_start_range))
        while fwpool_start_range != fwpool_end_range:
            fwpool_start_range += 1
            context.E164_FwPoolList.append("+" + str(fwpool_start_range))
        context.E164_List = context.E164_PoolList_1 + context.E164_PoolList_2
        context.E164_LookupValue = context.E164_PoolList_1 + context.E164_PoolList_2
        logging.info(f"E164 List for DELETE: {context.E164_List}")
    if "add_invalid_range" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("batch_AddNumber")
        context.main_number_add = SERIES_ONE + read_xmldata.gen_contact(5)
        context.admin_number_add = SERIES_ONE + read_xmldata.gen_contact(5)
        poolarray_start_range_1 = "+4411444" + read_xmldata.gen_contact_batch_end()
        poolarray_end_range_1 = int(poolarray_start_range_1) - 3
        poolarray_start_range_2 = "+4422444" + read_xmldata.gen_contact_batch_end()
        poolarray_end_range_2 = int(poolarray_start_range_2) - 2
        fwpool_start_range = "+4411144" + read_xmldata.gen_contact_batch_end()
        fwpool_end_range = int(fwpool_start_range) - 3
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'][0]['start'] = poolarray_start_range_1
        context.poolpayload['pool'][0]['end'] = "+" + str(poolarray_end_range_1)
        context.poolpayload['pool'][1]['start'] = poolarray_start_range_2
        context.poolpayload['pool'][1]['end'] = "+" + str(poolarray_end_range_2)
        context.poolpayload['fw_pool'][0]['start'] = fwpool_start_range
        context.poolpayload['fw_pool'][0]['end'] = "+" + str(fwpool_end_range)
    if "delete_invalid_range" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("batch_DeleteNumber")
        poolarray_start_range_1 = "+4411444" + read_xmldata.gen_contact_batch_end()
        poolarray_end_range_1 = int(poolarray_start_range_1) - 3
        poolarray_start_range_2 = "+4422444" + read_xmldata.gen_contact_batch_end()
        poolarray_end_range_2 = int(poolarray_start_range_2) - 2
        fwpool_start_range = "+4411144" + read_xmldata.gen_contact_batch_end()
        fwpool_end_range = int(fwpool_start_range) - 3
        context.poolpayload['pool'][0]['start'] = poolarray_start_range_1
        context.poolpayload['pool'][0]['end'] = "+" + str(poolarray_end_range_1)
        context.poolpayload['pool'][1]['start'] = poolarray_start_range_2
        context.poolpayload['pool'][1]['end'] = "+" + str(poolarray_end_range_2)
        context.poolpayload['fw_pool'][0]['start'] = fwpool_start_range
        context.poolpayload['fw_pool'][0]['end'] = "+" + str(fwpool_end_range)
    if "jsonrequest_body" == request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        context.main_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.admin_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.pool_1, context.pool_2, context.pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.fw_1, context.fw_2, context.fw_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)

        if hasattr(context, "type") and "duplicate" in context.type:
            type_to_duplicate = context.type.split('_')
            if type_to_duplicate[2] == "main" and type_to_duplicate[3] == "pool":
                context.main_number_add = context.pool_1
            elif type_to_duplicate[2] == "main" and type_to_duplicate[3] == "admin":
                context.main_number_add = context.admin_number_add
            elif type_to_duplicate[2] == "admin" and type_to_duplicate[3] == "pool":
                context.admin_number_add = context.pool_1
            elif type_to_duplicate[2] == "pool" and type_to_duplicate[3] == "fwpool":
                context.pool_1 = context.fw_1

            else:
                raise NotImplementedError(f"Duplicate for {context.type} is not implemented")
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'] = context.number_pool_list
        context.poolpayload['fw_pool'] = context.number_fwpool_list
        context.E164_List = [context.main_number_add, context.admin_number_add, context.pool_1, context.pool_2,
                             context.pool_3, context.fw_1, context.fw_2, context.fw_3]
        context.E164_LookupValue = [context.main_number_add, context.admin_number_add, context.pool_1, context.pool_2,
                                    context.pool_3]
        context.E164_FwPoolList = context.number_fwpool_list
        count = "3"
        read_xmldata.update_xml("count", count)
        read_xmldata.update_xml("main_number_delete", context.main_number_add)
        read_xmldata.update_xml("admin_number_delete", context.admin_number_add)
        read_xmldata.update_xml("pool_1", context.pool_1)
        read_xmldata.update_xml("pool_2", context.pool_2)
        read_xmldata.update_xml("pool_3", context.pool_3)

    if "admin_number_only" == request_body:
        context.poolpayload = read_xmldata.read_jsonfile("admin_number")

        context.admin_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)

        context.poolpayload['admin_number'] = context.admin_number_add

        context.E164_List = [context.admin_number_add]
        context.E164_LookupValue = [context.admin_number_add]
    if "jsonrequest_body_only_forward_pool_number" == request_body:
        context.poolpayload = read_xmldata.read_jsonfile("forward_pool_number")
        context.fw_1, context.fw_2, context.fw_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        if "duplicate" in context.type:
            context.fw_1 = context.fw_2 = context.fw_3
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.poolpayload['fw_pool'] = context.number_fwpool_list
        context.E164_List = [context.fw_1, context.fw_2, context.fw_3]
        context.E164_LookupValue = [context.fw_1, context.fw_2, context.fw_3]
    if "jsonrequest_body_invalid_all" == request_body:
        updated_series = SERIES_ONE.replace("+", "")
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        context.main_number_add = updated_series + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.admin_number_add = updated_series + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.pool_1, context.pool_2, context.pool_3 = updated_series + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), updated_series + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), updated_series + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.fw_1, context.fw_2, context.fw_3 = updated_series + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), updated_series + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), updated_series + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'] = context.number_pool_list
        context.poolpayload['fw_pool'] = context.number_fwpool_list
        context.E164_List = [context.main_number_add, context.admin_number_add, context.pool_1, context.pool_2,
                             context.pool_3, context.fw_1, context.fw_2, context.fw_3]
        context.E164_List = ['+' + str(item) for item in context.E164_List]
        context.E164_LookupValue = [context.main_number_add, context.admin_number_add, context.pool_1, context.pool_2,
                                    context.pool_3]
        context.E164_LookupValue = ['+' + str(item) for item in context.E164_LookupValue]
        context.E164_FwPoolList = ['+' + str(item) for item in context.number_fwpool_list]
        count = "3"
        read_xmldata.update_xml("count", count)
        read_xmldata.update_xml("main_number_delete", context.main_number_add)
        read_xmldata.update_xml("admin_number_delete", context.admin_number_add)
        read_xmldata.update_xml("pool_1", context.pool_1)
        read_xmldata.update_xml("pool_2", context.pool_2)
        read_xmldata.update_xml("pool_3", context.pool_3)
    if "jsonrequest_body_onlypool" == request_body:
        context.poolpayload = read_xmldata.read_jsonfile("pool_number")
        context.pool_1, context.pool_2, context.pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.poolpayload['pool'] = context.number_pool_list
        context.E164_List = [context.pool_1, context.pool_2, context.pool_3]
        context.E164_LookupValue = [context.pool_1, context.pool_2, context.pool_3]
        count = "3"
        read_xmldata.update_xml("count", count)
        read_xmldata.update_xml("pool_1", context.pool_1)
        read_xmldata.update_xml("pool_2", context.pool_2)
        read_xmldata.update_xml("pool_3", context.pool_3)
    if "jsonrequest_body_NOKMain_OKPool" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        context.main_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.admin_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.pool_1, context.pool_2, context.pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.fw_1, context.fw_2, context.fw_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.poolpayload['main_number'] = context.main_number_add
        context.save_main_number = context.poolpayload['main_number']
        context.save_admin_number = context.poolpayload['admin_number']
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'] = context.number_pool_list
        context.poolpayload['fw_pool'] = context.number_fwpool_list
        context.E164_List = [context.main_number_add, context.admin_number_add, context.pool_1, context.pool_2,
                             context.pool_3]
    if "jsonrequest_body_OKMain_NOKPool" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")

        context.main_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.admin_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.pool_1, context.pool_2, context.pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.fw_1, context.fw_2, context.fw_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.poolpayload['main_number'] = context.main_number_add
        context.save_main_number = context.poolpayload['main_number']
        context.save_admin_number = context.poolpayload['admin_number']
        context.poolpayload['admin_number'] = context.admin_number_add
        context.poolpayload['pool'] = context.number_pool_list
        context.E164_List = [context.main_number_add, context.admin_number_add, context.pool_1, context.pool_2,
                             context.pool_3]
        count = "3"
        read_xmldata.update_xml("count", count)
        read_xmldata.update_xml("main_number_delete", context.main_number_add)
        read_xmldata.update_xml("admin_number_delete", context.admin_number_add)
        read_xmldata.update_xml("pool_1", context.pool_1)
        read_xmldata.update_xml("pool_2", context.pool_2)
        read_xmldata.update_xml("pool_3", context.pool_3)
        context.E164_LookupValue = context.E164_List

    if "jsonrequest_Main_Pool_SameAccount" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        context.main_number_add = DE_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.pool_1, context.pool_2, context.pool_3 = DE_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), DE_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), DE_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['pool'] = context.number_pool_list

    if "jsonrequest_Main_FwPool_SameAccount" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        context.main_number_add = DE_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.fw_1, context.fw_2, context.fw_3 = DE_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), DE_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), DE_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['fw_pool'] = context.number_fwpool_list

    if "json_del_request_body" in request_body:
        context.poolpayload_json = read_xmldata.read_jsonfile("delNumberProvision_12")
        context.main_number_delete = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.admin_number_delete = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.pool_1, context.pool_2, context.pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.fw_1, context.fw_2, context.fw_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
            NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_fwpool_list = [context.fw_1, context.fw_2, context.fw_3]
        context.poolpayload_json['main_number'] = context.main_number_delete
        context.poolpayload_json['admin_number'] = context.admin_number_delete
        context.poolpayload_json['pool'] = context.number_pool_list
        context.E164_List = [context.pool_1, context.pool_2, context.pool_3]
        count = "3"
        read_xmldata.update_xml("count", count)
        read_xmldata.update_xml("main_number_delete", context.main_number_delete)
        read_xmldata.update_xml("admin_number_delete", context.admin_number_delete)
        read_xmldata.update_xml("pool_1", context.pool_1)
        read_xmldata.update_xml("pool_2", context.pool_2)
        read_xmldata.update_xml("pool_3", context.pool_3)
        phone_num1 = read_xmldata.readxml("main_number_delete", "test_inputdata", 'appdirectinput')
        context.E164_LookupValue = context.E164_List
        context.poolpayload = context.poolpayload_json
    if "add_then_delete_body" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("Add_Then_Delete")
        read_xmldata.update_xml("pool_1", context.pool_1)

        context.poolpayload['pool'] = [context.pool_1]
        context.E164_List = [context.pool_1]
        context.E164_LookupValue = [context.pool_1]
    if "empty_body" in request_body:
        context.poolpayload = ""
    if "empty_pool_list" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        context.poolpayload['pool'] = [""]
        context.poolpayload['fw_pool'] = [""]
    if "duplicate_pool_nos" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        pool_1 = pool_2 = pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.number_pool_list = [pool_1, pool_2, pool_3]
        context.poolpayload['pool'] = context.number_pool_list
    if "duplicate_main_admin_nos" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("postNumberProvision_68_01")
        context.main_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.admin_number_add = context.main_number_add
        context.poolpayload['main_number'] = context.main_number_add
        context.poolpayload['admin_number'] = context.admin_number_add
    if "blank_range" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("delNumberProvision_12")
        context.poolpayload['main_number'] = ""
        context.poolpayload['admin_number'] = ""
    if "invalid_number" in request_body:
        context.poolpayload = read_xmldata.read_jsonfile("delNumberProvision_12")
        context.poolpayload['main_number'] = read_xmldata.gen_contact(7)
        context.poolpayload['admin_number'] = read_xmldata.gen_contact(7)
        context.poolpayload['pool'] = ['just a text', read_xmldata.gen_contact(17)]


# And“ it contains a 'valid' JWT Token
@given("it contains a '{type_jwt_token}' JWT Token")
@when("it contains a '{type_jwt_token}' JWT Token")
@then("it contains a '{type_jwt_token}' JWT Token")
def validate_jwt_token_contents(context, type_jwt_token):
    if "valid" in type_jwt_token:
        context.access_token = api_requests.AuthType.VALID
        context.header = {
            'Content-Type': 'application/json'
        }
    elif "no_bearer" in type_jwt_token:
        context.access_token = api_requests.AuthType.NO_BEARER
        context.header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    elif "expired" in type_jwt_token:
        context.access_token = api_requests.AuthType.EXPIRED
        context.header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    elif "blank_with_bearer" in type_jwt_token:
        logging.info(f"Blank Token Received")
        context.access_token = "Bearer "
        context.header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    elif "blank" in type_jwt_token:
        logging.info(f"Blank Token Received")
        context.access_token = ""
        context.header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    else:
        raise NotImplementedError(f"{type_jwt_token=}")
    context.header["Authorization"] = context.access_token


@when("lookup is performed for '{number}' with '{expected_status}'")
def perform_lookup(context, number, expected_status):
    logger.info(f'performing lookup for {number=}')
    context.get_lookup_info = nm.Client().lookup_number(number)
    StatusCodeValidator.validate_status_code_response(context.get_lookup_info.status_code, expected_status)
    if context.get_lookup_info.ok:
        context.response = data.get_decoded_response(context.get_lookup_info)
        logger.info(f"Look-up get {to_json(context.response)=}")


@when('Requested action is to add numbers to an account')
def validate_request_action_account_add_numbers(context):
    context.action = 'add'
    if hasattr(context, "ucc_mw_correlation_id"):
        context.header.update({'ucc-mw-correlation-id': context.ucc_mw_correlation_id})
    context.postresponse_NumberPool = nm.Client(token=context.access_token).add_numbers(context.market_code,
                                                                                        context.op_co_customer_id,
                                                                                        context.poolpayload,
                                                                                        context.header)


@when('Requested action is to delete numbers from an account')
def validate_request_action_account_delete_numbers(context):
    context.action = 'delete'
    context.postresponse_NumberPool = nm.Client(token=context.access_token).delete_numbers(context.market_code,
                                                                                           context.op_co_customer_id,
                                                                                           context.poolpayload)


@then("we will receive a '{status}' response")
def receive_status_response(context, status):
    StatusCodeValidator.receive_status_code_response(context, status)


@given("user creates a request to Number management for '{action}' operation")
def request_number_management_operation(context, action):
    if action == "Add":
        context.jsonrequest_body = "jsonrequest_body"
    elif action == "Add to Forwarded list":
        context.jsonrequest_body = "jsonrequest_body"
    elif action == "Delete":
        context.jsonrequest_body = "json_del_request_body"

    # TODO: replace to market_code in all sub steps
    context.market_code = 'VFUK'
    # create account part
    context.op_co_customer_id = None
    if common.config.is_dev_env:
        context.op_co_customer_id = account.get_reusable_account_number({
            'environment': common.config.ENVIRONMENT,
            'market_code': context.market_code,
            'confirmation_status': 'confirmed'
        })
    account.create_account_if_doesnt_exist(context, context.op_co_customer_id)
    contains_requestbody(context, context.jsonrequest_body)

    context.execute_steps(f"""
                        Then a list of numbers are received from DXL                     
                                                           """)


# And User wants to retrieve Number management operation status
@when('User wants to retrieve Number management operation status')
def retrieve_numbermanagement_operation_status(context):
    context.finalurl = f"{NUMBER_MANAGEMENT_URL}/number-management/v1/ucc/management/numbers/operation/status"
    context.execute_steps(u"""
            When user have a '{type}' UUID
            And it contains a '{type}' JWT Token
            And user sends request to get provisioning status
            """.format(type="valid"))


# And user fetches data from 'ordermanagement_event_account_created' and creates a request to Number management for 'Add' operation
@when("user fetches data from '{topic_name}' and creates a request to Number management for '{action}' operation")
def fetch_topic_data_and_create_numbermanagement_operation_request(context, topic_name, action):
    if action == "Add":
        context.jsonrequest_body = "jsonrequest_body"
    elif action == "Add to Forwarded list":
        context.jsonrequest_body = "jsonrequest_body"
    elif action == "Delete":
        context.jsonrequest_body = "json_del_request_body"
    elif action == "add_range_numbers":
        context.jsonrequest_body = "add_range_numbers"
    elif action == "delete_range_numbers":
        context.jsonrequest_body = "delete_range_numbers"

    context.execute_steps(f"""
                        Then user can retrieve payload from '{topic_name}'
                        Then it contains a 'valid_value' for market""")
    contains_requestbody(context)

    context.execute_steps(f"""
                        Then it contains a 'valid' JWT Token
                        Then a list of numbers are received from DXL                     
                                                           """)


@given("DXL sends request to number management for '{action}' operation")
def send_operation_request_from_dxl_to_numbermanagement(context, action):
    context.flag = 0
    if action == "Add":
        context.requested_action = "ADD"
    elif action == "Delete":
        context.requested_action = "DELETE"
    elif action == "Add_Range":
        context.requested_action = "ADD_RANGE"
    elif action == "Delete_Range":
        context.requested_action = "DELETE_RANGE"

    context.execute_steps(u"""
                        Then user can retrieve payload from '{kafkatopic}'
                        Then it contains a '{valid_value}' for market
                        Then it contains a '{token_type}' JWT Token
                        Then a list of numbers are received from DXL                     
                                                           """.format(kafkatopic="ordermanagement_event_account_created",
                                                                      valid_value="valid_value",
                                                                      token_type="valid"))


@when("user has a payload with the '{payload}' in request body")
def validate_payload_in_request_body(context, payload):
    if "mandatory_numbers" in payload:
        context.flag = 1
        contains_requestbody(context)

        context.save_main_number = context.poolpayload['main_number']
        context.save_admin_number = context.poolpayload['admin_number']
        del context.poolpayload['pool']
        del context.poolpayload['fw_pool']
        # context.E164_LookupValue = context.poolpayload['main_number']
    if "admin_number_only" in payload:
        context.flag = 1
        contains_requestbody(context)

        del context.poolpayload['main_number']
        context.save_admin_number = context.poolpayload['admin_number']
        del context.poolpayload['pool']
        del context.poolpayload['fw_pool']

    if "no_E164_numbers" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']
        del context.poolpayload['admin_number']
        del context.poolpayload['pool']
        del context.poolpayload['fw_pool']

    if "no_main_admin_numbers" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']
        del context.poolpayload['admin_number']
        # context.E164_LookupValue = context.poolpayload[0]['pool']

    if "no_fwpool_admin_numbers" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['admin_number']
        del context.poolpayload['fw_pool']
        # context.E164_LookupValue = context.poolpayload['main_number']

    if "no_main_number" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']
        # context.E164_LookupValue = context.poolpayload[0]['pool']

    if "no_admin_number" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['admin_number']

    if "no_pool_list" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['pool']
        # context.E164_LookupValue = context.poolpayload[0]['fw_pool']

    if "no_numbers_in_pool" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['pool']
        del context.poolpayload['fw_pool']

    if "no_fw_pool_list" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['fw_pool']
        # context.E164_LookupValue = context.poolpayload['admin_number']

    if "pool_number" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['fw_pool']
        del context.poolpayload['main_number']
        del context.poolpayload['admin_number']
        context.E164_List.remove(context.fw_1)
        context.E164_List.remove(context.fw_2)
        context.E164_List.remove(context.fw_3)
        context.E164_List.remove(context.main_number_add)
        context.E164_List.remove(context.admin_number_add)
        context.E164_List = context.number_pool_list[1]
        context.E164_LookupValue = context.E164_List

    if "void_main_number" in payload:
        contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']

    if "add_batch_no_main_number" in payload:
        contains_requestbody(context, 'add_range_numbers')

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']

    if "range_no_admin_main_number" in payload:
        contains_requestbody(context, 'add_range_numbers')

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']
        del context.poolpayload['admin_number']

    if "add_range_pool_list_missing" in payload:
        contains_requestbody(context, 'add_range_numbers')

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['pool']

    if "add_range_fw_pool_missing" in payload:
        contains_requestbody(context, 'add_range_numbers')

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['fw_pool']

    if "del_range_pool_list_missing" in payload:
        contains_requestbody(context, 'delete_range_numbers')

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['pool']

    if "del_range_fw_pool_missing" in payload:
        contains_requestbody(context, 'delete_range_numbers')

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['fw_pool']

    logging.info(f"POST REQUEST PAYLOAD: {context.poolpayload}")
    logging.info(f"Optional Parameters set for the requested action....")
    logging.info(f"-----------------")

    if context.requested_action == "ADD" or context.requested_action == "ADD_RANGE":
        context.execute_steps(u"""
                                When Requested action is to add numbers to an account""")

    elif context.requested_action == "DELETE" or context.requested_action == "DELETE_RANGE":
        context.execute_steps(u"""
                                When Requested action is to delete numbers from an account""")
    logging.info(f"REQUEST SENT SUCCESSFULLY..")
    logging.info(f"-----------------")
    context.save_customer_id = context.op_co_customer_id


@when("user creates a subsequent request to Number management for '{action}' operation")
def create_additional_numbermanagement_operation_request(context, action):
    if action == "Add":
        context.jsonrequest_body = "jsonrequest_body"
    elif action == "Delete":
        context.jsonrequest_body = "json_del_request_body"
    elif action == "Add_Range":
        context.jsonrequest_body = "add_range_numbers"
    elif action == "Delete_Range":
        context.jsonrequest_body = "delete_range_numbers"

        context.execute_steps(u"""
                                Then it contains a '{token_type}' JWT Token
                                Then a list of numbers are received from DXL                     
                                                                   """.format(
            jsonrequest_body=context.jsonrequest_body,
            token_type="valid"))


# And user places request for 'Delete' operation by providing 'all' numbers in the request
@when("user places request for '{action}' operation by providing '{type}' numbers in the request")
@given("user places request for '{action}' operation by providing '{type}' numbers in the request")
def request_operation_by_numbers(context, action, type):
    context.type = type
    context.action = action
    # TODO: replace to market_code in all sub steps
    if not getattr(context, 'market_code'):
        context.market_code = 'VFUK'
    # create account part
    context.op_co_customer_id = None
    if common.config.is_dev_env:
        context.op_co_customer_id = account.get_reusable_account_number({
            'environment': common.config.ENVIRONMENT,
            'market_code': context.market_code,
            'confirmation_status': 'confirmed'
        })
    account.create_account_if_doesnt_exist(context, context.op_co_customer_id)

    # not reachable ?? - does not have mapping in the tests
    if action == "Delete" and type == 'all':
        context.jsonrequest_body = "json_del_request_body"
        contains_requestbody(context, "json_del_request_body")
        context.execute_steps(f"""
                            Then a list of numbers are received from DXL
                            When Requested action is to delete numbers from an account                     
                                                               """)
    # not reachable ?? - does not have mapping in the tests
    elif action == "Delete" and type == "delete_range_numbers":
        context.jsonrequest_body = "delete_range_numbers"
        # context.jsonrequest_body = "json_del_request_body"
        contains_requestbody(context, type)

        context.execute_steps(u"""
                                    Then a list of numbers are received from DXL
                                    When Requested action is to delete numbers from an account                     
                                                                       """.format(request_body=context.jsonrequest_body,
                                                                                  valid_value="valid_value",
                                                                                  token_type="valid"))

    elif action == "Delete" and type == "Add_then_delete_range_numbers":
        context.jsonrequest_body = "Add_then_delete_range_numbers"
        contains_requestbody(context, type)

        context.execute_steps(f"""
                                    Then a list of numbers are received from DXL
                                    When Requested action is to delete numbers from an account                     
                                                                       """)
    # not reachable ?? - does not have mapping in the tests
    elif action == "Delete" and type == "no_main_number":
        context.jsonrequest_body = "no_main_number"
        context.requested_action = "DELETE"
        context.flag = 0
        contains_requestbody(context, type)

        context.execute_steps("""
                                            Then a list of numbers are received from DXL
                                            When Requested action is to delete numbers from an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    # not reachable ?? - does not have mapping in the tests
    elif action == "Delete" and type == "no_pool_list":
        context.jsonrequest_body = "no_pool_list"
        context.requested_action = "DELETE"
        context.flag = 0
        context.execute_steps("""
                                            Given user creates '{request_body}' for optional parameters
                                            Then a list of numbers are received from DXL
                                            When Requested action is to delete numbers from an account            
                                                                               """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    # not reachable ?? - does not have mapping in the tests
    elif action == "Delete" and type == "no_fw_pool_list":
        context.jsonrequest_body = "no_fw_pool_list"
        context.requested_action = "DELETE"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters
                                            Then a list of numbers are received from DXL
                                            When Requested action is to delete numbers from an account     
                                                                               """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Delete" and type in ("pool_number", "pool_number_duplicate"):
        context.jsonrequest_body = type
        context.requested_action = "DELETE"
        context.flag = 0
        context.execute_steps(u"""          
                                            Given user creates '{request_body}' for optional parameters
                                            Then a list of numbers are received from DXL
                                            When Requested action is to delete numbers from an account     
                                                                               """.format(numbertype="pool_delete",
                                                                                          request_body=context.jsonrequest_body,
                                                                                          token_type="valid"))

    elif action == "Delete" and type == "pool_number_NOK":
        if not hasattr(context, "poolpayload"):
            context.pool_1, context.pool_2, context.pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
                NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
                NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
            context.number_pool_list = [context.pool_1, context.pool_2, context.pool_3]
        context.jsonrequest_body = "pool_number"
        context.requested_action = "DELETE"
        context.RC_ID = '999666353'
        context.op_co_customer_id = 'all-NOK'
        context.flag = 0
        context.execute_steps(u"""          
                                            Given user creates '{request_body}' for optional parameters
                                            Then a list of numbers are received from DXL
                                            When Requested action is to delete numbers from an account     
                                                                               """.format(numbertype="pool_delete_NOK",
                                                                                          request_body=context.jsonrequest_body,
                                                                                          token_type="valid"))

    elif action == "Delete" and type == "admin_number_OK":
        context.jsonrequest_body = "admin_number"
        context.requested_action = "DELETE"
        context.flag = 0
        context.execute_steps(u"""          
                                            Given user creates '{request_body}' for optional parameters
                                            Then a list of numbers are received from DXL
                                            When Requested action is to delete numbers from an account     
                                                                               """.format(numbertype="admin_delete",
                                                                                          request_body=context.jsonrequest_body,
                                                                                          token_type="valid"))

    elif action == "Delete" and type == "admin_number_NOK":
        context.jsonrequest_body = "admin_number"
        context.requested_action = "DELETE"
        context.RC_ID = '999991452'
        context.number_type = 'NOK-OK'
        context.op_co_customer_id = 'NOK-OK'
        context.flag = 0
        context.execute_steps(u"""          
                                            Given user creates '{request_body}' for optional parameters
                                            Then a list of numbers are received from DXL
                                            When Requested action is to delete numbers from an account     
                                                                               """.format(numbertype="admin_delete_NOK",
                                                                                          request_body=context.jsonrequest_body,
                                                                                          token_type="valid"))

    elif action == "Add" and (type == 'all' or type.startswith('all_duplicate')):
        context.jsonrequest_body = "jsonrequest_body"
        contains_requestbody(context)

        context.execute_steps(f"""
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """)

    elif action == "Add_PutNotification" and type == 'all':
        context.jsonrequest_body = "jsonrequest_body"
        contains_requestbody(context)

        context.execute_steps("""
                            When user have a '{idtype}' UUID
                            And users sends an End Notification Request for 'Add' operation to Number management
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(request_body=context.jsonrequest_body,
                                                                          valid_value="valid_value",
                                                                          token_type="valid", idtype="valid"))

    elif action == "Add_PutNotification" and type == 'onlypool':
        context.jsonrequest_body = "jsonrequest_body_onlypool"
        contains_requestbody(context, 'jsonrequest_body_onlypool')

        context.execute_steps(u"""
                            When user have a '{idtype}' UUID
                            And users sends an End Notification Request for 'Add' operation to Number management
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(request_body=context.jsonrequest_body,
                                                                          valid_value="valid_value",
                                                                          token_type="valid", idtype="valid"))

    elif action == "Add_PutNotification" and type == 'only_forward_pool_number':
        context.jsonrequest_body = "jsonrequest_body_only_forward_pool_number"
        contains_requestbody(context, 'jsonrequest_body_only_forward_pool_number')

        context.execute_steps("""
                            When user have a '{idtype}' UUID
                            And users sends an End Notification Request for 'Add' operation to Number management
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(request_body=context.jsonrequest_body,
                                                                          valid_value="valid_value",
                                                                          token_type="valid", idtype="valid"))

    elif action == "Add_PutNotification" and type == "mandatory_numbers":
        context.jsonrequest_body = "mandatory_numbers"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters 
                                            When user have a '{idtype}' UUID
                                            And users sends an End Notification Request for 'Add' operation to Number management
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid", idtype="valid"))

    elif action == "Add_PutNotification" and type == "admin_number_only":
        context.jsonrequest_body = "admin_number_only"
        context.requested_action = "ADD"
        context.flag = 0
        contains_requestbody(context, type)
        context.execute_steps("""
                                            When user have a '{idtype}' UUID
                                            And users sends an End Notification Request for 'Add' operation to Number management
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid", idtype="valid"))

    elif action == "Add" and type == "admin_number_only":
        context.jsonrequest_body = "admin_number_only"
        context.requested_action = "ADD"
        context.flag = 0
        contains_requestbody(context, type)

        context.execute_steps(u"""
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and 'only_forward_pool_number' in type:
        context.jsonrequest_body = "jsonrequest_body_only_forward_pool_number"
        contains_requestbody(context, "jsonrequest_body_only_forward_pool_number")

        context.execute_steps(u"""
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(request_body=context.jsonrequest_body,
                                                                          valid_value="valid_value",
                                                                          token_type="valid"))

    elif action == "Add" and type == 'invalid_all':
        context.jsonrequest_body = "jsonrequest_body_invalid_all"
        contains_requestbody(context, "jsonrequest_body_invalid_all")

        context.execute_steps(u"""
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(
            valid_value="valid_value",
            token_type="valid"))

    elif action == "Add" and type in ('onlypool', 'pool_and_correlationID'):
        context.jsonrequest_body = "jsonrequest_body_onlypool"
        if type == 'pool_and_correlationID':
            context.ucc_mw_correlation_id = read_xmldata.gen_uuid()
            logging.info(f"New MW Correlation ID: {context.ucc_mw_correlation_id}")
        contains_requestbody(context, "jsonrequest_body_onlypool")

        context.execute_steps("""
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(
            valid_value="valid_value",
            token_type="valid"))

    elif action == "Add" and type == "no_main_number":
        context.jsonrequest_body = "no_main_number"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(f"""
            Given user creates '{context.jsonrequest_body}' for optional parameters 
            Then a list of numbers are received from DXL
            When Requested action is to add numbers to an account 
        """)

    elif action == "Add" and type == "no_admin_number":
        context.jsonrequest_body = "no_admin_number"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters 
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and type == "no_pool_list":
        context.jsonrequest_body = "no_pool_list"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters 
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and type == "no_fw_pool_list":
        context.jsonrequest_body = "no_fw_pool_list"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters 
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and type == "no_main_admin_numbers":
        context.jsonrequest_body = "no_main_admin_numbers"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters 
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and type == "no_fwpool_admin_numbers":
        context.jsonrequest_body = "no_fwpool_admin_numbers"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters 
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and type == "no_fw_pool_list":
        context.jsonrequest_body = "no_fw_pool_list"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                            Given user creates '{request_body}' for optional parameters 
                                            Then a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and type == "OKMain_NOKPool":
        context.jsonrequest_body = "OKMain_NOKPool"
        context.number_type = 'OK-NOK'
        context.op_co_customer_id = 'OK-NOK'
        context.RC_ID = '999611007'
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""  
                                            Given user creates '{request_body}' for optional parameters 
                                            And a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, numbertype="OK_Main_NOK_POOL", valid_value="valid_value",
            token_type="valid"))

    elif action == "Add" and type == "NOKMain_OKPool":
        context.jsonrequest_body = "NOKMain_OKPool"
        context.number_type = 'NOK-OK'
        context.op_co_customer_id = 'NOK-OK'
        context.RC_ID = '999991452'
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""

                                            Given user creates '{request_body}' for optional parameters
                                            And a list of numbers are received from DXL
                                            When Requested action is to add numbers to an account 
                                                                                """.format(
            request_body=context.jsonrequest_body, numbertype="NOK_Main_OK_POOL", valid_value="valid_value",
            token_type="valid"))

    elif action == "Add" and type == "mandatory_numbers":
        context.jsonrequest_body = "mandatory_numbers"
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(u"""
                                        Given user creates '{request_body}' for optional parameters 
                                        And a list of numbers are received from DXL
                                        When Requested action is to add numbers to an account 
                                                                                      """.format(
            request_body=context.jsonrequest_body, valid_value="valid_value", token_type="valid"))

    elif action == "Add" and type in ('add_range_numbers', 'duplicate_pool_poolrange'):
        # context.jsonrequest_body = "add_range_numbers"
        context.jsonrequest_body = type
        contains_requestbody(context, type)

        context.execute_steps(u"""
                            And a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(request_body=context.jsonrequest_body,
                                                                          valid_value="valid_value",
                                                                          token_type="valid"))

    elif action == "Add" and type in (
            "same_account_inventory", "different_account_inventory", "same_account_partial_inventory",
            "same_account_inventory_usageType", "same_account_presentation", "different_account_presentation",
            "same_account_presentation_usageType", "MainCompanyNumber_inventory", "ForwardedCompanyNumber_inventory",
            "ForwardedNumber_presentation", "DirectNumber_presentation"):
        context.market_code = 'VFDE'
        if "inventory" in type:
            context.jsonrequest_body = "Main_Pool_SameAccount"
            context.number_type = context.op_co_customer_id = 'same_account_inventory_de'
            context.RC_ID = '991697535853845'

        else:
            context.jsonrequest_body = "Main_FwPool_SameAccount"
            context.number_type = context.op_co_customer_id = 'same_account_pst_de'
            context.RC_ID = '991698314860578'

        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(f"""  
            Given user creates '{context.jsonrequest_body}' for optional parameters 
            And update numbers in the service order with '{type}' for 'Appdirect'
            And a list of numbers are received from DXL
            When Requested action is to add numbers to an account 
""")

    elif action == "Add" and type == 'range_add_08_numbers':
        context.jsonrequest_body = "range_add_08_numbers"
        contains_requestbody(context, type)

        context.execute_steps("""
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(
            valid_value="valid_value",
            token_type="valid"))

    elif action == "Add" and type == 'range_add_15_numbers':
        context.jsonrequest_body = "range_add_15_numbers"
        contains_requestbody(context, type)

        context.execute_steps("""
                            Then a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(
            valid_value="valid_value",
            token_type="valid"))

    elif action == "Add" and type == 'range_add_15_fw_pool_numbers':
        context.jsonrequest_body = "range_add_15_fw_pool_numbers"
        # context.RC_ID = '991697799009270'
        # context.op_co_customer_id = '77020531797'
        contains_requestbody(context, type)

        context.execute_steps("""
                            Given a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(
            valid_value="valid_value",
            token_type="valid"))

    elif action == "Add" and type in ('range_add_15_poolnumber', "range_add_15_poolnumber_duplicate"):
        context.jsonrequest_body = type
        # context.RC_ID = '991697799009270'
        # context.op_co_customer_id = '77020531797'
        contains_requestbody(context, type)

        context.execute_steps("""
                            Given a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(request_body=context.jsonrequest_body,
                                                                          valid_value="valid_value",
                                                                          token_type="valid"))

    elif action == "Delete" and type == 'range_08_numbers':
        context.jsonrequest_body = "range_del_08_numbers"
        contains_requestbody(context, type)

        context.execute_steps("""
                            Given a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(
            valid_value="valid_value",
            token_type="valid"))

    elif action == "Delete" and type == 'range_15_numbers':
        context.jsonrequest_body = "range_del_15_numbers"
        contains_requestbody(context, type)

        context.execute_steps("""
                            Given a list of numbers are received from DXL
                            When Requested action is to add numbers to an account                     
                                                               """.format(
            valid_value="valid_value",
            token_type="valid"))

    elif action == "Delete" and type == "only_forward_pool_number":
        if hasattr(context, 'E164_FwPoolList'):
            context.poolpayload = {"fw_pool": context.E164_FwPoolList}
            # We are deleting these now as these were used in add numbers and now we are deleting fw pool number only
            del context.E164_List
            del context.E164_LookupValue
        context.requested_action = "DELETE"
        context.flag = 0
        compose_nm_pool_url(context)
        context.execute_steps("""
        When Requested action is to delete numbers from an account 
        """)

    # We never delete forward pool numbers so we delete the object of fwpoolList
    # Also while creating payload for mandatory_numbers, admin_number_only, onlypool and no_fw_pool_list, we create a full payload and then delete the object of unnecessary things but so instead of deleting at individual level i am deleting from here
    if hasattr(context, 'E164_FwPoolList'):
        if action == "Delete" or type in ("mandatory_numbers", "admin_number_only", "onlypool", "no_fw_pool_list"):
            del context.E164_FwPoolList


# And user makes a reverse lookup for 'Delete' operation by providing 'forwardpool' numbers and validates 'successful' response
# And user makes a reverse lookup for 'Delete' operation by providing 'pool_num' numbers and validates 'unsuccessful' response
@then(
    "user makes a reverse lookup for '{action_type}' operation by providing '{action_for}' numbers and validates '{response_type}' response")
def reverse_lookup_by_numbers_action_type(context, action_type, action_for, response_type):
    logging.info(f"ActionType={action_type} and action_for is:{action_for}")

    if action_type == "Delete" and action_for == "pool_numbers" and response_type == "unsuccessful":
        for i in range(len(context.number_pool_list)):
            context.lookup_num = context.number_pool_list[i]
            perform_lookup(context, context.lookup_num, HTTPStatus.NOT_FOUND)

        context.execute_steps(u"""
                            Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number
                            Then user tries to make a reverse look up for successful add operation for Admin number
                            Then user tries to make a reverse look up for successful add operation for Main number
                            """.format())

    elif action_type == "Deletebulk" and action_for == "pool_numbersbulk" and response_type == "unsuccessful":
        for i in range(len(context.E164_List)):
            context.lookup_num = context.number_pool_list[i]
            perform_lookup(context, context.lookup_num, HTTPStatus.NOT_FOUND)

    elif action_type == "Delete" and action_for == "pool_numbers" and response_type == "successful":
        for i in range(len(context.number_pool_list)):
            context.lookup_num = context.number_pool_list[i]
            perform_lookup(context, context.lookup_num, HTTPStatus.OK)

        context.execute_steps("""
                                    Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number
                                    Then user tries to make a reverse look up for successful add operation for Admin number
                                    Then user tries to make a reverse look up for successful add operation for Main number
                                    """)

    elif action_type == "Delete" and action_for == "admin_number" and response_type == "unsuccessful":
        logging.info(f"context.admin_number_add : {context.admin_number_add}")
        perform_lookup(context, context.admin_number_add, HTTPStatus.NOT_FOUND)
        context.execute_steps("""
                                Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number
                                Then user tries to make a reverse look up for successful add operation for pool number
                                Then user tries to make a reverse look up for successful add operation for Main number
                                    """)

    elif action_type == "Delete" and action_for == "admin_number" and response_type == "successful":
        context.execute_steps("""
                                    Then user tries to make a reverse look up for successful add operation for pool number
                                    Then user tries to make a reverse look up for unsuccessful add operation for Admin number
                                    Then user tries to make a reverse look up for successful add operation for Main number
                                    Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number 
                                                    """)

    elif action_type == "Add" and action_for == "all" and response_type == "successful":
        context.execute_steps(u"""
                            Then user tries to make a reverse look up for successful add operation for pool number
                            Then user tries to make a reverse look up for successful add operation for Admin number
                            Then user tries to make a reverse look up for successful add operation for Main number
                            Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number 
                                            """.format())

    elif action_type == "Addbulk" and action_for == "all" and response_type == "successful":
        context.execute_steps(u"""
                            Then user tries to make a reverse look up for successful add operation for bulk Pool number
                            Then user tries to make a reverse look up for successful add operation for Admin number
                            Then user tries to make a reverse look up for successful add operation for Main number
                            Then user tries to make a reverse look up for unsuccessful add operation for bulk Forward Pool number 
                                            """.format())

    elif action_type == "Add" and action_for == "OKMain_NOKPool" and response_type == "successful":
        for i in range(len(context.number_pool_list)):
            context.lookup_num = context.number_pool_list[i]
            context.get_lookup_info = nm.Client().lookup_number(context.lookup_num)
            response = context.get_lookup_info.content.decode('utf-8')
            logging.info(f"Look-up get response Payload : {json.dumps(response, indent=3)}")
            logging.info(f"context.get_lookup_info Pool number : {context.get_lookup_info}")
            StatusCodeValidator.validate_status_code_response(context.get_lookup_info.status_code, HTTPStatus.NOT_FOUND)

        context.execute_steps("""
                                        Then user tries to make a reverse look up for successful add operation for Main number
                                        Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number 
                                            """)

    elif action_type == "Add" and action_for == "NOKMain_OKPool" and response_type == "successful":
        logging.info(f"context.main_number_add : {context.main_number_add}")
        assert context.get_response["status"][
                   "state"] == "ERROR", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "ERROR")
        perform_lookup(context, context.main_number_add, HTTPStatus.NOT_FOUND)

        context.execute_steps("""
                                Then user tries to make a reverse look up for successful add operation for pool number
                                Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number                
                                                    """)

    elif action_type == "Add" and action_for == "no_main_number" and response_type == "successful":
        context.execute_steps("""
                                Then user tries to make a reverse look up for successful add operation for pool number
                                Then user tries to make a reverse look up for successful add operation for Admin number
                                Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number   
                                                    """)

    elif action_type == "Add" and action_for == "no_admin_number" and response_type == "successful":
        context.execute_steps(u"""
                                   Then user tries to make a reverse look up for successful add operation for pool number
                                   Then user tries to make a reverse look up for successful add operation for Main number
                                   Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number   
                                                       """.format())
    elif action_type == "Add" and action_for == "no_pool_numbers" and response_type == "successful":
        context.execute_steps(u"""
                                   Then user tries to make a reverse look up for successful add operation for Admin number
                                   Then user tries to make a reverse look up for successful add operation for Main number
                                   Then user tries to make a reverse look up for unsuccessful add operation for Forward Pool number   
                                                       """.format())
    elif action_type == "Add" and action_for == "mandatory_numbers" and response_type == "successful":
        context.execute_steps(u"""
                                   Then user tries to make a reverse look up for successful add operation for Main number
                                                       """.format())
    elif action_type == "Add" and action_for == "no_forward_pool_numbers" and response_type == "successful":
        context.execute_steps(u"""
                                    Then user tries to make a reverse look up for successful add operation for Admin number
                                    Then user tries to make a reverse look up for successful add operation for Main number
                                    Then user tries to make a reverse look up for successful add operation for pool number   
                                                        """.format())

    else:
        assert 1 == 0, "We are not validating this event"


# Then user tries to make a reverse look up for successful add operation for pool number
@then("user tries to make a reverse look up for successful add operation for pool number")
def reverse_lookup_pool_number_successful_add_operation(context):
    for i in range(len(context.number_pool_list)):
        perform_lookup(context, context.number_pool_list[i], HTTPStatus.OK)


# Then user tries to make a reverse look up for successful add operation for pool number
@then("user tries to make a reverse look up for successful add operation for bulk Pool number")
def reverse_lookup_bulk_pool_number_successful_add_operation(context):
    context.lookup_num = context.E164_PoolList_1[1]
    perform_lookup(context, context.lookup_num, HTTPStatus.OK)

    context.lookup_num = context.E164_PoolList_2[1]
    perform_lookup(context, context.lookup_num, HTTPStatus.OK)


@then("user tries to make a reverse look up for unsuccessful add operation for Admin number")
def reverse_lookup_admin_number_unsuccessful_add_operation(context):
    perform_lookup(context, context.admin_number_add, HTTPStatus.NOT_FOUND)


@then("user tries to make a reverse look up for unsuccessful add operation for Forward Pool number")
def reverse_lookup_forward_pool_number_unsuccessful_add_operation(context):
    for i in range(len(context.number_fwpool_list)):
        context.lookup_num = context.number_fwpool_list[i]
        perform_lookup(context, context.lookup_num, HTTPStatus.NOT_FOUND)


@then("user tries to make a reverse look up for unsuccessful add operation for bulk Forward Pool number")
def reverse_lookup_bulk_forward_pool_number_unsuccessful_add_operation(context):
    context.lookup_num = context.E164_FwPoolList[1]
    perform_lookup(context, context.lookup_num, HTTPStatus.NOT_FOUND)

    context.lookup_num = context.E164_FwPoolList[-1]
    perform_lookup(context, context.lookup_num, HTTPStatus.NOT_FOUND)


# Then user tries to make a reverse look up for successful add operation for Main number
@then("user tries to make a reverse look up for successful add operation for Main number")
def reverse_lookup_main_number_successful_add_operation(context):
    logging.info(f"context.main_number_add : {context.main_number_add}")
    perform_lookup(context, context.main_number_add, HTTPStatus.OK)


# Then user tries to make a reverse look up for successful add operation for Admin number
@then("user tries to make a reverse look up for successful add operation for Admin number")
def reverse_lookup_admin_number_successful_add_operation(context):
    logging.info(f"context.admin_number_add : {context.admin_number_add}")
    perform_lookup(context, context.admin_number_add, HTTPStatus.OK)


@given("user sends an order to '{action}' an account to Middleware for '{number_types}' and '{market}'")
@when("user sends an order to '{action}' an account to Middleware for '{number_types}' and '{market}'")
def send_account_action_order_for_number_mw(context, number_types, market, action):
    context.flag = 0
    if number_types in ("mandatory_numbers", "all", "range_add_15_numbers", "onlypool"):
        context.jsonrequest_body = number_types
        if number_types == "all":
            context.jsonrequest_body = "jsonrequest_body"
        if number_types == "onlypool":
            context.jsonrequest_body = "jsonrequest_body_onlypool"
        if number_types == "mandatory_numbers":
            context.execute_steps(f"""
                        Given user creates '{context.jsonrequest_body}' for optional parameters """)
        else:
            contains_requestbody(context, context.jsonrequest_body)

        context.execute_steps(f"""
                    Given user creates initial order for 'Full Stack' with 'Standard' level edition with license '5'
                    And it contains a '{market}' for market
                    And it contains a 'valid' JWT Token
                   """)

    elif number_types == "NOKMain_OKPool":
        context.jsonrequest_body = number_types
        context.number_type = 'NOK-OK'
        context.op_co_customer_id = 'NOK-OK'
        context.RC_ID = '999991452'
        context.requested_action = "ADD"
        context.flag = 0
        context.execute_steps(f"""
                                   Given user creates '{context.jsonrequest_body}' for optional parameters
                                   Then it contains a 'valid_value' for market
                                   Then it contains a 'valid' JWT Token
                                                                """)

    elif number_types == "pool_number" and action == "delete":
        context.jsonrequest_body = "pool_number"
        context.requested_action = "DELETE"
        context.flag = 0
        if hasattr(context, "E164_FwPoolList"):
            del context.E164_FwPoolList
        context.execute_steps(f"""          
                                            Given user creates '{context.jsonrequest_body}' for optional parameters
                                            Then it contains a 'valid' JWT Token    """)


@when("user wants to '{action}' numbers to the same account")
def execute_add_remove_numbers_to_same_account(context, action):
    add_number_topics = ["numbermanagement_command_add_numbers", "ringcentral_event_numbers_added"]
    delete_number_topics = ["numbermanagement_command_delete_numbers", "ringcentral_event_numbers_deleted"]

    if action.lower() == 'add':
        number_topics = add_number_topics
        context.execute_steps(u"""
                    Given a list of numbers are received from DXL
                    When Requested action is to add numbers to an account
                    Then we will receive a '202' response""")

    elif action.lower() == 'delete':
        number_topics = delete_number_topics
        context.execute_steps(u"""
                    Given a list of numbers are received from DXL
                    When Requested action is to delete numbers from an account
                    Then we will receive a '202' response""")

    for topic_name in number_topics:
        context.execute_steps(f"""
                                    Then user validates payload is present in '{topic_name}'
                                    And user validates '{action}' numbers information in '{topic_name}'
                                    """)


@when("Middleware will send a response email to the user for '{number_types}'")
def response_email_for_number_mw(context, number_types):
    context.execute_steps("""
            When number has been provisioned in CRF
            And user wants to retrieve Number management operation status""")
    if number_types == "NOKMain_OKPool":
        context.execute_steps(f"""
            Then user validates Error message in response of operation status for '{number_types}'
            And user validates payload is not present in 'numbermanagement_command_complete_order'
         """)
    else:
        context.execute_steps(f"""
            Then user validates response of operation status for '{number_types}'
            And user can retrieve payload from 'numbermanagement_command_complete_order'
         """)


@when("Middleware will validate the request from crf for '{number_types}'")
def validate_request_number_from_crf(context, number_types):
    context.execute_steps(f"""
    Then CRF id saved in DB
    And user retrieves and validates data in 'crfstub_process_resourceorder' topic
    When CRF notification is sent with status 'failed'
    Then User wants to retrieve Number management operation status
    Then user validates Error message in response of operation status for '{number_types}'
    And user validates payload is not present in 'numbermanagement_command_complete_order'
            """)


@when("user wants to add range_of_15 numbers to the same account")
def add_range_15_to_same_account(context):
    context.execute_steps("""
            Given a list of numbers are received from DXL
            When Requested action is to add numbers to an account
            Then we will receive a '202' response
            And user validates 'first_08' numbers are present in 'numbermanagement_command_add_numbers'
            And user validates 'next_07' numbers are present in 'numbermanagement_command_add_numbers'
            And user validates 'first_08' numbers are present in 'ringcentral_event_numbers_added'
            And user validates 'next_07' numbers are present in 'ringcentral_event_numbers_added'
                          """)


@when("Middleware will respond to the request for '{number_types}' and '{action}'")
def resonse_number_action_request_mw(context, number_types, action):
    if number_types != "Add_Range_15_numbers":
        context.execute_steps("""
        When User wants to retrieve Number management operation status""")
    if number_types == "all":
        context.execute_steps(f"""
        Then user validates 'pending' response of operation status for '{action}' operation for '{number_types}' numbers
                          """)


@given("user places an order to add an account to Middleware")
def order_add_account_to_mw(context):
    context.execute_steps("""
        When user places request for 'Add' operation by providing 'all' numbers in the request
        Then we will receive a '202' response """)


@when("Middleware confirms the order")
def confirm_order_mw(context):
    context.execute_steps("""
            When number has been provisioned in CRF
            And User wants to retrieve Number management operation status
            Then user validates response of operation status for 'addall'
		                    """)


@when("Middleware performs '{additional_action}' for the request")
def execute_action_for_request_mw(context, additional_action):
    context.execute_steps(f"""	
            When User wants to retrieve Number management operation status
            Then user validates response of operation status for '{additional_action}'
            And user validates payload is present in 'numbermanagement_command_complete_order'
            """)
