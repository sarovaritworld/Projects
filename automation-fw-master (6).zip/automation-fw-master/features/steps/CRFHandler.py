import json
import logging
import time

import camel_converter
from behave import given, when, then

from classes import database, asserts, payload, crf, common, polling, numbers, account, read_xmldata, pod
from classes.api.requests import idmapper, crf_gateway_api, ringcentral_gateway
from classes.kafka import consumer_data, KafkaTopics, KafkaMsgValidationSet, producer_data
from classes.utils import strtobool
from features.steps import TMFHandler, kafkaHandler, callbackHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@when("number has been deprovisioned in CRF")
@when("number has been provisioned in CRF")
def processed_crf_number(context):
    if common.config.is_crf_add_number_enabled:
        context.execute_steps(u"""
                    Then CRF id saved in DB
                    And user can retrieve payload from 'crfstub_process_resourceorder'
                    When CRF notification is sent with status 'completed'
                    Then state of CRF request is 'completed' in DB
         """)


@when("resource updated with status '{status}'")
def resource_updated_with_status(context, status):
    crf_id_saved_in_db(context)
    kafkaHandler.get_messages(context, 'crfstub_process_resourceorder')
    crf_notification_sent_with_status(context, status)
    validate_crf_request_state_db(context, status)


@when("add numbers have provisioned in CRF")
def processed_crf_add_numbers(context):
    context.execute_steps("""Then remove main number id and get only add numbers CRF ids""")
    logging.info(f'{context.add_number_crf_ids=}')
    for crf_id in context.add_number_crf_ids:
        context.crf_request_id = crf_id
        context.execute_steps("""
                Then user can retrieve payload from 'crfstub_process_resourceorder'
                When CRF notification is sent with status 'completed'
                Then state of CRF request is 'completed' in DB
            """)


@then("CRF request saved in DB")
def validate_crf_request_saved_db(context):
    document = database.get_crf_document(context.middleware_correlation_id)
    logging.info(f'crf_request document: {database.parse_json(document)}')
    asserts.equals(bool(document), True, 'initial document exists')


@then("state of CRF request is '{state}' in DB")
def validate_crf_request_state_db(context, state):
    if not common.config.is_crf_add_number_enabled:
        return
    if common.config.is_staging_env and state != 'completed':
        # pass all the states for staging except completed: process happen very quickly,
        # and we are not able to have acknowledged and inProgress in time
        return
    # wait for a specific status: for dev we control notifications and status SHOULD be as expected
    # for staging we validate only completed status in order to go forward for validations
    # increasing timeout from 180 to 210 secs for test env as we are not getting crf order document in completed state
    timeout = 300 if common.config.is_staging_env else 100
    state = camel_converter.to_snake(state).upper()

    # to remove conditions when defect https://jira.tools.aws.vodafone.com/browse/UN-26216 is fixed

    if common.config.UN_26216_workaround:
        # to delete when fixed
        documents = polling.wait_until(
            lambda: database.get_all_crf_documents(context.middleware_correlation_id),
            f"CRF order document in state {state}",
            stop_when=lambda docs: any([doc['crfOrderInfo']['order']['state'] == state for doc in docs]),
            timeout=timeout)
        if len(documents) > 1:
            logger.warning('CRF document is more than one')
        document = next((doc for doc in documents if doc['crfOrderInfo']['order']['state'] == state), None)
    else:
        document = polling.wait_until(
            lambda: database.get_crf_document(context.middleware_correlation_id),
            f"CRF order document in state {state}",
            stop_when=lambda doc: doc and doc['crfOrderInfo']['order']['state'] == state,
            timeout=timeout)
    logging.info(f'crf_request document: {document}')


@then("state of CRF parent request is '{state}' in DB")
def validate_crf_parent_request_state(context, state):
    timeout = 180 if common.config.is_staging_env else 60
    document = polling.wait_until(
        lambda: database.get_crf_parent_requests_document(context.event_id),
        f"CRF order document in state {state}",
        stop_when=lambda doc: doc and doc['state'] == state.upper(),
        timeout=timeout)

    logging.info(f'crf_parent_requests document: {document}')


# And CRF notification is sent with status 'completed'
@when("CRF notification is sent with status '{state}'")
@when("CRF notification is sent with status '{state}' with expected response '{expected_response}'")
def crf_notification_sent_with_status(context, state, expected_response=201, notes=None):
    if common.config.is_staging_env:
        return
    context.notification = state

    if "crf_stub_payload" not in context:
        context.crf_stub_payload = context.consumer_payload
    # here to send notification for crf_notification to update to a state
    crf.send_notification(state, context.crf_stub_payload, int(expected_response), "tmf652", notes)


@then("CRF id saved in DB")
@then("CRF id saved in DB for '{search_strategy}'")
def crf_id_saved_in_db(context, search_strategy=None):
    if not common.config.is_crf_add_number_enabled:
        context.execute_steps("""Then JIRA tickets has been created successfully""")
        return

    # Find the CRF document matching the order (there are a few options for what field to compare)
    logging.info(f'middleware correlation id {context.middleware_correlation_id}')
    if search_strategy == "complex_SO":
        context.crf_request_id = crf.get_crf_doc_with_action(context.middleware_correlation_id, action=context.action)
    elif search_strategy == "last_request":
        timeout, period = (150, 5) if common.config.is_staging_env else (60, 2)
        document = polling.wait_until(
            lambda: database.get_crf_document_by_marketplace_event(context.marketplace_event_id),
            f"CRF request document for {context.marketplace_event_id=}", timeout=timeout, period=period,
            stop_when=lambda doc: doc and 'crfOrderInfo' in doc)
        logger.info(f"CRF request {document=}")
        context.crf_request_id = document['crfOrderInfo']['order']['_id']
    elif search_strategy is None:
        context.crf_request_id = crf.get_resource_order_id(context.middleware_correlation_id)
    else:
        raise NotImplementedError(f"{search_strategy=}")


@then("validate crf parent request in db")
def validate_crf_parent_requests_in_db(context):
    logging.info(f'eventId {context.event_id}')
    document = polling.wait_until(
        lambda: database.get_crf_parent_requests_document(context.event_id),
        'CRF order document')
    logger.info(f'crf_parent_requests document: {database.parse_json(document)}')

    validation_set = {
        "correlationId": context.middleware_correlation_id,
        "eventType": "DELETE_ALL_NUMBERS_REQUESTED",
        "initialCrfRequest.opcoDetails.name": context.market_code,
        "initialCrfRequest.opcoDetails.opcoCustomerId": context.op_co_customer_id
    }
    common.validate_message(document, validation_set)


def get_crf_order_ids(context):
    crf_order_ids = []
    documents = crf.get_all_crf_docs(context.middleware_correlation_id)
    for document in documents:
        logger.info(f'crf_request document: {database.parse_json(document)}')
        crf_order_ids.append(document['crfOrderInfo']['order']['_id'])
    return crf_order_ids


@then("remove main number id and get only add numbers CRF ids")
def retrieve_crf_add_numbers_ids(context):
    documents = polling.wait_until(lambda: crf.get_all_crf_docs(context.middleware_correlation_id),
                                   'CRF order document')

    logging.info(f'crf_request document: {database.parse_json(documents)}')
    context.add_number_crf_ids = []
    if hasattr(context, "main_number"):
        for document in documents:
            if ("poolList" in document["initialCrfRequest"]
                    and context.main_number in document["initialCrfRequest"]["poolList"]):
                documents.remove(document)
    for document in documents:
        if 'order' not in document['crfOrderInfo']:
            logger.error(f"order is not created, error {document['crfOrderInfo']}")
            raise Exception('CRF order was not created')
        else:
            context.add_number_crf_ids.append(document['crfOrderInfo']['order']['_id'])


@given("operation is set to fail with '{error_type}'")
@given("account is set to fail with '{error_type}'")
def update_account_id_in_payload_for_condition(context, error_type):
    context.error_type = error_type
    context.number_type = error_type
    context.op_co_customer_id = common.get_opco_customer_id_by_number_type(error_type)
    payload.update_account_id(context.payload, context.op_co_customer_id)
    account = idmapper.Client(context.op_co_customer_id, market_code=context.market_code).get_account()
    context.RC_ID = account.ringcentral_id()


@given("number is set to fail with '{error_type}'")
def update_number_in_payload(context, error_type):
    context.error_type = error_type
    # delete resource in crf does not contain account id, so we fetch failures via first number sent
    payload.update_number_for_crf_delete(context.payload, numbers.crf_negative_numbers[error_type])


@then("validate DB for successful '{action}'")
def validate_db_action_success(context, action):
    status = database.get_listener_status()
    expected_status = True
    if action == "deregistration":
        expected_status = False
    asserts.equals(status, expected_status, "Listener status in DB")


@given("no endpoint is already registered")
def endpoint_not_registered(context):
    status = database.get_listener_status()
    if status:
        kafkaHandler.insert_message_in_topic_with_failure_point(
            context,
            'support_command_unregister_crf_tmf652_listener',
            'valid_data')
        validate_db_action_success(context, 'deregistration')


# separate this step into 2: provision and deprovision
@then("CRF fails to provision numbers with '{failure_point}' error")
def validate_crf_numbers_failed(context, failure_point):
    if hasattr(context, 'action'):
        topic_dict = {
            'add': 'crfgateway_event_crfnumber_added',
            'delete': 'crfgateway_event_crfnumber_deleted'
        }
        topic = topic_dict[context.action]
        context.execute_steps(f"""
                Then user retrieves and validates data in '{topic}' topic with '{failure_point}'
        """)
    else:
        logging.warning(
            'there might be a problem with composing a payload. please make sure you are saving context.action value')


@then("user retrieves and validates data in '{topic_name}' topic for '{state}'")
def retrieve_topic_data_for_state(context, topic_name, state):
    context.execute_steps("""Then user can retrieve payload from '{topic_name}'""".format(topic_name=topic_name))
    context.consumer_payload = context.consumer_payload[-1]

    if topic_name == 'numbermanagement_respond_numbersadded':
        validation_set = KafkaMsgValidationSet().numbermanagement_respond_numbers_added(state=state)
        common.validate_message(context.consumer_payload, validation_set)
        if hasattr(context, "duplicated_numbers"):
            for number in context.duplicated_numbers:
                asserts.in_list(number, context.consumer_payload["numbersConfirmation"]["duplicatedNumbers"],
                                "duplicated number missing in confirmation")
    elif topic_name == 'numbermanagement_event_numbers_deleted':
        validation_set = KafkaMsgValidationSet().numbermanagement_event_numbers_deleted(state=state)
        common.validate_message(context.consumer_payload, validation_set)
    else:
        raise NotImplementedError(
            f"Topic name {topic_name} must be one of [numbermanagement_respond_numbersadded,numbermanagement_event_numbers_deleted]")

    logging.info(f"THIS IS VALIDATION_SET: {validation_set}")
    logging.info(f"THIS IS CONSUMER PAYLOAD: {context.consumer_payload}")

    common.validate_message(context.consumer_payload, validation_set)


@when("notification has not been received")
def notification_not_received(context):
    # callbacks are running every crf.FREQUENCY minutes, wait until they make some calls
    logger.info('Waiting for job to perform a callback.....')
    logger.debug(f'{crf.SLO=}')
    logger.debug(f'{crf.SLA=}')
    logger.debug(f'{crf.FREQUENCY=}')
    # wait for 1 callback + extra
    time.sleep(crf.FREQUENCY * 2 * 60)
    logger.info('Waiting finished!')


@when("SLA has been breached")
def sla_breached(context):
    # callbacks are running every crf.FREQUENCY minutes, wait until they make some calls
    logger.info('Waiting for SLA to breach.....')
    logger.info(f'SLA value: {crf.SLA} seconds')

    time.sleep(int(crf.SLA))
    time.sleep(crf.FREQUENCY * 2 * 60)
    logger.info('Waiting finished!')


@then("error to DXL is logged")
def dxl_error_logged(context):
    logs = pod.filter_logs('crf-gateway', context.crf_request_id)
    callback_error = crf.CALLBACK_ERROR_TO_DXL
    if 'notification_type' in context and context.notification_type == 'tmf641':
        callback_error = crf.TMF641_CALLBACK_ERROR_TO_DXL
    for entry in logs:
        logger.debug(f'{entry=}')
    asserts.equals(logs[-1].count(callback_error.format(context.crf_request_id)), 1, "SLA errors in logs)")
    # check that Resource/Service Order history ends with SLA breach message
    logger.info(callback_error)
    logger.info(context.crf_request_id)

    assert callback_error.format(context.crf_request_id) in logs[-1], \
        "crf-gateway logs should contain an error"


@then("error to DXL is not logged")
def dxl_error_not_logged(context):
    logs = pod.filter_logs('crf-gateway', context.crf_request_id)
    assert crf.CALLBACK_ERROR_TO_DXL not in logs, \
        "crf-gateway logs should NOT contain an error"


@given("account is prepared to return '{callback_state}' from CRF")
def crf_account_prepared_for_callback(context, callback_state):
    callbackHandler.save_customer_id_for_callback(context, callback_state)
    account.create_account_if_doesnt_exist(vodafone_id=context.op_co_customer_id,
                                           product_type='FULL_STACK_STANDARD',
                                           market_code='VFUK',
                                           context=context)
    context.callback_state = callback_state


@then("there should be expected count of callbacks")
def callback_count_expected(context):
    # need to think about how measure the frequency
    # because order might be created on one time but actually called back on another
    calls_count = int(crf.SLA) / int(crf.SLO)
    logger.info(f'{calls_count=}')

    # read messages from db for this particular resource_order_id
    callbacks_requests = database.get_all_callback_calls(context.crf_request_id)
    logger.info(f'{len(callbacks_requests)} callbacks count')
    asserts.equals(len(callbacks_requests), calls_count, 'amount of callbacks before SLA has breached')


@given("resource order is created")
def resource_order_created(context):
    crf.initiate_resource_order(context)
    logger.info(f'{context.crf_request_id=}')


@given("resource order state is '{non_terminal_state}'")
def resource_order_state(context, non_terminal_state):
    # add numbers request
    crf.initiate_resource_order(context)
    logger.info(f'{context.crf_request_id=}')
    # pick up message
    context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.crfstub_process_resourceorder.name)
    context.crf_stub_payload = context.consumer_payload

    if context.consumer_payload['state'] != context.callback_state.upper():
        crf.send_notification(non_terminal_state, context.crf_stub_payload)


@given("an account is created with main_number '{number_type}'")
def account_created_with_main_number(context, number_type):
    customer_id_prefix_dict = {
        "existing_with_cac": ringcentral_gateway.VFID_SAVE_CAC_PREFIX,
        "existing_without_cac": ringcentral_gateway.VFID_SAVE_DB_PREFIX,
        "retry_pass": ringcentral_gateway.VFID_RETRY_PASS_PREFIX,
        "retry_fail": ringcentral_gateway.VFID_RETRY_FAIL_PREFIX
    }
    customer_id_prefix = customer_id_prefix_dict[number_type] if number_type in customer_id_prefix_dict else ""
    context.op_co_customer_id = customer_id_prefix + read_xmldata.gen_RCID()
    context.market_code = "VFUK"
    account.create_new_account(context,
                               product_type="FULL_STACK_STANDARD",
                               market_code=context.market_code,
                               confirmation_status="confirmed")
    if hasattr(context, "main_number"):
        logger.info(f"{context.main_number=}")


@given("an account is created without main_number")
def account_created_without_main_number(context):
    # Removed main_number and timestamp from this account in RCStub db for specific scenario testing
    context.market_code = "VFUK"
    context.op_co_customer_id = ringcentral_gateway.VFID_NO_MAIN_NUMBER


@when("user sends a request with '{main_number_type}' phone number to CRF gateway numbers API")
def request_to_crf_gateway_numbers_api(context, main_number_type):
    if main_number_type == "non_existing":
        context.main_number = "1212121212"
    else:
        account_created_with_main_number(context, main_number_type)
    context.response = crf_gateway_api.Client(token=context.access_token).get_numbers(context.main_number)
    context.number_details_response = context.response.json()
    logger.info("GET number details from CRF Gateway Response:")
    logger.info(json.dumps(context.number_details_response, indent=2))


@then("response contains correct information {cac_info} CAC info")
def response_contains_correct_information_with_cac_info(context, cac_info):
    allowed_cac_info_param_values = ["with", "without"]
    if cac_info not in allowed_cac_info_param_values:
        logger.error(f"Unknown value for cac_info parameter {cac_info}. "
                     f"Allowed values are {allowed_cac_info_param_values}")
    has_cac_info = (cac_info == "with")
    crf.validate_number_details(context.number_details_response,
                                context.main_number,
                                has_cac_info)


@then("CRF is called DEP for status {expected_num_callbacks:d} time")
def crf_dep_called_for_status_time(context, expected_num_callbacks: int):
    # check that job is running?
    with database.open_database('automation-fw', 'crf_callbacks') as db:
        callbacks_requests = db.get_documents('resource_id', context.crf_request_id)
    logger.info(f"{callbacks_requests=}")
    asserts.equals(len(callbacks_requests), expected_num_callbacks, "number of CRF callbacks")


@then("field 'lastUpdatedTimestamp' is set to current_timestamp")
def set_last_timestamp_to_current(context):
    document = crf.wait_for_crf_document(context.middleware_correlation_id)
    logger.info(f'{document=}')
    dt = document['lastUpdatedTimestamp']
    logger.info(f'{context.scenario_start_time=}')
    logger.info(dt)
    assert dt > context.scenario_start_time, "Field lastUpdatedTimestamp in CRF document"


@then("field 'slaBreachNotificationSentTimestamp' is set to current_timestamp")
def set_notification_timestamp_to_current(context):
    document = crf.wait_for_crf_document(context.middleware_correlation_id)
    logger.info(f'{document=}')
    try:
        sla_breach_notification_sent_timestamp = document['crfOrderInfo']['slaBreachNotificationSentTimestamp']
    except KeyError:
        raise Exception("slaBreachNotificationSentTimestamp field is not found") from None
    logger.info(f'{context.scenario_start_time=}')
    logger.info(f'{sla_breach_notification_sent_timestamp}')
    assert sla_breach_notification_sent_timestamp > context.scenario_start_time, \
        "Field sla_breach_notification_sent_timestamp in CRF document"
    processing_time = sla_breach_notification_sent_timestamp - document['crfOrderInfo']['orderCreatedTimestamp']
    logger.info(f'{str(processing_time)=} of resource order')


@then("field '{field_name}' is set to '{value}'")
def set_field_to_value(context, field_name, value):
    document = crf.wait_for_crf_document(context.middleware_correlation_id)
    logger.info(f'{document=}')

    asserts.equals(common.is_key_present(field_name, document), True, f'{field_name} field presence')

    logger.info(common.check_value_in_payload(document, field_name, value))
    asserts.equals(common.check_value_in_payload(document, field_name, strtobool(value)), True, f'{field_name} field')


@then("field '{field_name}' is not set")
def field_not_set(context, field_name):
    document = crf.wait_for_crf_document(context.middleware_correlation_id)
    logger.info(f'{document=}')

    asserts.equals(common.is_key_present(field_name, document), False, f'{field_name} field presence')


@given("kafka message for topic numbermanagement_command_add_crfnumber is sent")
def sent_kafka_to_numbermanagement_command_add_crfnumber(context):
    topic_name = "numbermanagement_command_add_crfnumber"
    op_co_customer_id_existing_account = "88802373400"
    context.payload = read_xmldata.read_jsonfile(topic_name)
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.marketplace_event_id = context.payload["crf_number_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.op_co_customer_id = context.payload["crf_number_request"]["op_co_details"][
        "op_co_customer_id"] = op_co_customer_id_existing_account
    context.category = context.payload["crf_number_request"]["ucas_provider"] = "MSOC"
    context.carrier_id = context.payload["crf_number_request"]["carrier_id"] = "VCS_LM"
    context.number_pool_list = context.payload["crf_number_request"]["pool"]
    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@given("request is processed for crf notification state")
def request_is_processed_for_crf_notification_state(context):
    sent_kafka_to_numbermanagement_command_add_crfnumber(context)
    crf_id_saved_in_db(context)
    validate_crf_request_state_db(context, state='acknowledged')
    context.action = 'add'
    TMFHandler.retrieve_and_validate(context, 'crfstub_process_resourceorder')


@then("resource order notifications are validated against conflicting states")
def resource_order_notifications_validated_against_conflicting_states(context):
    validate_crf_request_state_db(context, state='completed')
    crf_notification_sent_with_status(context, state='failed', expected_response=int(409))
    validate_crf_request_state_db(context, state='completed')


@then("resource order for notification is completed")
def resource_order_for_notification_completed(context):
    validate_crf_request_state_db(context, state='completed')
    TMFHandler.retrieve_and_validate(context, 'crfgateway_event_crfnumber_added')
