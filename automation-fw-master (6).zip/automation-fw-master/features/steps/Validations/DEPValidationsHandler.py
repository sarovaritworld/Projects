import logging
from typing import Any
from behave import when, then, given

from classes import common, notifications, msoc_numbers, crf
from classes.dep_validation import get_expected_numbers_status, get_numbers_from_different_account, \
    get_numbers_for_scenario, validate_crf_document, get_notification_scenario
from classes.utils import to_json
from classes.kafka import consumer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from features.steps import MSOCHandler, TMFHandler, CRFHandler, numbersHandler, flowHandler, jiraHandler, patchHandler
from features.steps.accountHandler import create_account_prerequisite

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


def refresh_numbers_list(context, action, numbers_status: str, account_status: str, cac_mismatch: bool = False):
    """
    Refreshes a list of numbers in the context to be added/deleted as per the scenario
    :param context:
    :param action:
    :param numbers_status: type of mixture of numbers
    :param account_status:
    :param cac_mismatch:
    :return: list of updated numbers
    """
    # context.number_pool_list may be not exist for delete scenario
    context.number_pool_list = getattr(context, "number_pool_list", [])
    logger.info(f"refresh_numbers_list: before refresh numbers {context.number_pool_list}")
    # Find numbers added to some different account from reusable account json
    different_numbers = get_numbers_from_different_account(
        context.category,
        context.market_code,
        context.op_co_customer_id
    )
    same_numbers = context.number_pool_list[:]  # Copy
    minimum_numbers_count = 5
    context.new_numbers = []
    current_numbers_count = len(context.number_pool_list)
    if action == "add" and (
            current_numbers_count < minimum_numbers_count or len(different_numbers) < minimum_numbers_count):
        logger.warning(f"Too small list of numbers to work with, test may not work as expected "
                       f"{context.number_pool_list=}, {different_numbers=}")

    context.number_pool_list = get_numbers_for_scenario(
        numbers_status,
        account_status,
        context.number_pool_list,
        different_numbers,
        context.market_code
    )
    logger.info(f"refresh_numbers_list: after refresh numbers {context.number_pool_list}")

    if action == "add":
        # Save new numbers to the context as we need them while preparing note for notification for add scenario
        context.new_numbers = [i for i in context.number_pool_list
                               if i not in different_numbers
                               and i not in same_numbers]

    # Prepare numbers expected status for further validation
    if account_status in ["same", "new"]:
        context.expected_numbers_status = get_expected_numbers_status(
            action,
            context.number_pool_list,
            same_numbers,
            different_numbers,
            cac_mismatch
        )
    else:
        # When numbers are provisioned to different account, DEP doesn't send numbers details
        context.expected_numbers_status = {}

    logger.debug(f"{context.new_numbers=}")
    logger.info(f"{context.expected_numbers_status=}")


def send_notification_with_dep_validation_note(context, action, numbers_status, account_status):
    # Send notification to move the request in to 'inProgress' state
    TMFHandler.retrieve_and_validate(context, 'crfstub_process_resourceorder')
    CRFHandler.crf_notification_sent_with_status(context, 'inProgress')

    # Send notification with the note about the status of numbers being added or deleted
    scenario = get_notification_scenario(action, numbers_status)
    notes = notifications.get_notes_for_notification(context, scenario, account_status)
    final_state = notifications.get_final_state_by_scenario(scenario)
    CRFHandler.crf_notification_sent_with_status(context, state=final_state, notes=notes)


@when("a request is sent to '{action}' the '{numbers_status}' numbers to '{account_status}' '{category}' account")
def send_number_operation_request(context, action, numbers_status, account_status, category, cac_mismatch=False):
    quantity = 5
    pool_type = "pool"
    context.action = action

    # Refresh numbers
    refresh_numbers_list(context, action, numbers_status, account_status, cac_mismatch)


    match category.upper():
        case "MSOC":
            MSOCHandler.msoc_order_created_for_numbers(
                context,
                action,
                quantity,
                pool_type,
                'separate',
                "VCS-LM",
                context.number_pool_list
            )
            msoc_numbers.update_msoc_numbers_context(context , is_dep_validation=True)
        case "UNITY":
            numbersHandler.create_payload_for_numbers_with_conditions(
                context,
                action,
                quantity,
                'numbers',
                pool_type,
                True
            )
        case _:
            logger.error(f"Invalid value for account type {category}")
    flowHandler.customer_sends_an_order_to_middleware(context)


@when("a request is sent to add same numbers but without CAC configuration")
def send_add_numbers_request_without_cac_config(context):
    send_number_operation_request(context, "add", "provisioned", "same", "MSOC", True)
    # Disable validation of cacId for this scenario as in context we would have saved cacId which would be added to
    del context.number_cac_id


@then("user validates result of '{action}' number operation is '{expected_result}' for '{numbers_status}' numbers to '{account_status}' account")
def validate_number_operation_result(
        context: Any,
        action: str,
        expected_result: str,
        numbers_status: str,
        account_status: str):
    """
    Validates number operation result
    """
    match action:
        case "add":
            if hasattr(context, 'msoc_account'):
                MSOCHandler.validate_tmfmediator_create_addnumbers_for_msoc_number(context)
            else:
                numbersHandler.retrieve_tmfmediator_create_addnumbers_data_with_number(context, context.pool_type)
            tmf_mediator_topic = "tmfmediator_create_addnumbers"
            number_management_topic = "numbermanagement_command_add_crfnumber"
            crf_confirmation_topic = "crfgateway_event_crfnumber_added"
        case "delete":
            tmf_mediator_topic = "tmfmediator_create_deletenumbers"
            number_management_topic = "numbermanagement_command_delete_crfnumber"
            crf_confirmation_topic = "crfgateway_event_crfnumber_deleted"
        case _:
            raise NotImplementedError(f"Unsupported {action=}")

    # TMFHandler.retrieve_and_validate(context, tmf_mediator_topic)
    TMFHandler.retrieve_and_validate(context, number_management_topic)
    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, 'acknowledged')

    if common.config.is_dev_env:
        send_notification_with_dep_validation_note(context, action, numbers_status, account_status)

    # Validate crf_request document is updated correctly
    document = crf.wait_for_crf_document(context.middleware_correlation_id, 'isCrfRequestSuccessful', timeout=180)
    logger.info(f"crf_request document is: {to_json(document)}")
    validate_crf_document(document, expected_result, context.expected_numbers_status)

    # Validate CRF Confirmation message
    context.consumer_payload = consumer_data.get_messages(context, crf_confirmation_topic)
    crf_error_type = None if expected_result == "Successful" else "CRF_error"
    KafkaTopicValidator(context).validate_topic(crf_confirmation_topic, error_type=crf_error_type)
    if expected_result == "Successful":
        if context.category == "MSOC":
            jiraHandler.validate_jira_ticket_creation_success(context)
            patchHandler.send_patch_request_from_bo_tool(context, "update_service_order", "ucc.msoc.numbers", "completed")
        TMFHandler.send_request_to_endpoint(context, 'get_service_order_by_id')
        TMFHandler.validate_final_state(context, 'completed')


@then("user validates result of add number operation is '{expected_result}' without CAC config")
def validate_add_numbers_without_cac_result(context, expected_result):
    validate_number_operation_result(context, "add", expected_result, "provisioned", "same")


@given("a '{category}' customer account is created")
def tenant_category_account_is_created(context, category: str):
    context.category = category.upper()
    match category:
        case "MSOC":
            MSOCHandler.process_msoc_create_account_for_market(context, 'VFUK', billing_info=True)
        case "UNITY":
            create_account_prerequisite(context, 'FULL_STACK_STANDARD', 'VFUK', 'confirmed')
        case _:
            raise NotImplementedError(f"Please implement create account for {category=}")
