import logging
from datetime import datetime, timedelta
from http import HTTPStatus
import re

import camel_converter
from behave import *

from classes import asserts, common, data_files, database, polling, read_xmldata
from classes.utils import to_json

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


# And user validates 'JWT_error_message' in database for 'ordermanagement_command_update_accountstatus'
@then("user validates '{error_type}' in database for '{kafka_topic_name}'")
def validate_error_kafka_topic_db(context, error_type, kafka_topic_name):
    if kafka_topic_name == "ordermanagement_command_update_accountstatus":

        document = database.create_db_connection(context.marketplaceEventID)
        assert len(document) > 0, "Document for Create Account is not present in database "
        print("Document from database for Account status :: ", document)
        print(" ")
        if error_type == "JWT_error_message":
            orderStatus = document["orderStatus"]
            error_code = document["errorDetails"]["errorCode"]
            error_message = document["errorDetails"]["description"]
            assert orderStatus == "Error", "orderStatus :: {} is not present in Database :: {}".format(orderStatus,
                                                                                                       "Error")
            assert error_code == "UCAS_PROVIDER_ERROR", "orderStatus :: {} is not present in Database :: {}".format(
                error_code,
                "UCAS_PROVIDER_ERROR")
            assert error_message == "JwtToken is not present in token from RingCentral API", "orderStatus :: {} is not present in Database :: {}".format(
                error_message,
                "JwtToken is not present in token from RingCentral API")
    elif kafka_topic_name == "appdirect_create_shippingaddress":
        document = database.get_shipping_records(context.marketplaceEventID)
        assert len(document) > 0, "Document for Change License is not present in database "
        print("Document from database for Purchase Master Device :: ", document)
        print(" ")
        database_payload = {}
        # locationType = document["locationType"]
        status = document["status"]
        marketplaceEventId = document["marketplaceEventId"]
        marketplaceAccountId = document["shippingAddress"]["marketplaceAccountId"]
        # context.accountLocationID = document["accountLocationId"]
        error_message = document["errorDetails"]["description"]
        error_code = document["errorDetails"]["errorCode"]

        assert context.marketplaceEventID == marketplaceEventId, "marketplaceEventID :: {} is not present in Database :: {} ".format(
            context.marketplaceEventID, marketplaceEventId)
        assert context.marketplaceAccountID == marketplaceAccountId, "marketplaceAccountID :: {} is not present in Database :: {} ".format(
            context.marketplaceAccountID, marketplaceAccountId)
        if error_type == "Account_Uncofirm_Error":
            assert status == "Error", "Status :: {} is not present in Database :: {} ".format(
                status, "Error")
            assert error_message == "Customer Account does not have a complete Initial Order: Failed to find Initial Order", "Error message :: {} is not present in Database :: {} ".format(
                error_message, "Customer Account does not have a complete Initial Order: Failed to find Initial Order")
            assert error_code == "ACCOUNT_NOT_FOUND", "Error Code :: {} is not present in Database :: {} ".format(
                error_code, "ACCOUNT_NOT_FOUND")
        else:
            assert 1 == 0, "Validation scripts are not available for this event"
    elif kafka_topic_name in ["numbermanagement_command_add_numbers", "numbermanagement_command_delete_numbers"]:
        document = database.get_number_management_all_batches(context.RC_ID)
        assert len(document) > 0, "Document for Create Account is not present in database"
        sorted_document = sorted(document, key=lambda x: x['createdTime'])[-1]
        logging.info(f' Sorted Document {sorted_document} \n')
        logging.info(f'\n State of Number Management Batch {sorted_document["statusState"]}')
        assert sorted_document['statusState'] == error_type, "Batch status did not matched with databases"

    else:

        assert 1 == 0, "Validation scripts are not available for this event"


# Then user validates data in database for 'complete' order for 'appdirect_create_changelicense'
# Then user validates data in database for 'received' order for 'appdirect_create_changelicense'
# And user validates data in database for 'incomplete' order for 'appdirect_create_changelicense'
@then("user validates data in database for '{data_type}' order for '{kafka_topic_name}'")
def validate_data_type_kafka_topic_db(context, data_type, kafka_topic_name):
    database_payload = {}
    document = database.create_db_connection(context.marketplaceEventID)
    assert len(document) > 0, "Document for Change License is not present in database "
    print("Document from database for Change License :: ", document)
    print(" ")

    if data_type == "complete":
        status = "Complete"
        description = ""
        errorCode = ""
        source = ""
    elif data_type == "received":
        status = "Received"
        description = ""
        errorCode = ""
        source = ""
    elif data_type == "incomplete":
        status = "Error"
        description = read_xmldata.readxml("license_errorMessage", "appdirect_inputdata", "AppdirectUI")
        errorCode = "UNKNOWN_ERROR"
        source = "Ringcentral"

    orderStatus = document["orderStatus"]
    orderType = document["orderType"]
    source_db = document["errorDetails"]["source"]
    description_db = document["errorDetails"]["description"]
    errorCode_db = document["errorDetails"]["errorCode"]
    marketplaceEventId = document["marketplaceEventId"]
    # marketplaceAccountId = document["marketplaceAccountId"]
    correlationIdFromMarketplace = document["correlationIdFromMarketplace"]
    # opcoID = document["opcoID"]
    opcoAccountId = document["opCoAccountId"]
    ucasAccountId = document["ucasAccountId"]
    emailAddress = document["primaryContactDetails"]["emailAddress"]
    mobile = document["primaryContactDetails"]["mobile"]
    no_of_lic = document["orderDetails"]["quantity"]
    skuID = document["orderDetails"]["skuID"]
    packageID = document["orderDetails"]["packageID"]
    companyName = document["companyName"]

    # database_payload["opco_billing_account_num"] = document["additionalOpCoData"]["opCoBillingAccountNumber"]
    # database_payload["opco_billing_ref"] = document["additionalOpCoData"]["opCoBillingServiceReference"]
    # database_payload["opco_opportunity_id"] = document["additionalOpCoData"]["opCoOpportunityId"]
    # database_payload["opco_order_reference_id"] = document["additionalOpCoData"]["opCoOrderReference"]
    database_payload["address_line_1"] = document["companyHeadQuartersAddress"]["street"]
    # database_payload["address_line_2"] = document["companyHeadQuartersAddress"]["street2"]
    database_payload["town_city"] = document["companyHeadQuartersAddress"]["city"]
    # database_payload["state_county_region"] = document["companyHeadQuartersAddress"]["state"]
    database_payload["postcode"] = document["companyHeadQuartersAddress"]["zip"]
    database_payload["country"] = document["companyHeadQuartersAddress"]["country"]
    database_payload["first_name"] = document["primaryContactDetails"]["firstname"]
    database_payload["last_name"] = document["primaryContactDetails"]["lastname"]
    # event = document["orderHistory"]["event"]
    # accountstatus = document["orderHistory"]["accountstatus"]

    for item in database_payload:
        mandatory_value = read_xmldata.readxml(item, "appdirect_inputdata", 'AppdirectUI')
        print("Data from Appdirect : {} and Data from Initial Order Kafka : {}".format(mandatory_value,
                                                                                       database_payload[item]))
        assert mandatory_value in database_payload[item], "Item {} is not present in Database {}".format(
            mandatory_value, database_payload)

    assert context.marketplaceEventID == marketplaceEventId, "externalOrderId :: {} is not present in Database :: {} ".format(
        context.marketplaceEventID, marketplaceEventId)
    # assert context.marketplaceAccountID == marketplaceAccountID, "marketplaceAccountID :: {} is not present in Database :: {} ".format(
    #     context.marketplaceAccountID, marketplaceAccountID)
    assert context.middleware_correlation_id == correlationIdFromMarketplace, "middlewareCorrelationID :: {} is not present in Database :: {} ".format(
        context.middleware_correlation_id, correlationIdFromMarketplace)
    assert context.mobile == mobile, "Contact Number :: {} is not present in Database :: {}".format(context.mobile,
                                                                                                    mobile)
    assert context.RC_ID == ucasAccountId, "opcoAccountID :: {} is not present in Database :: {}".format(
        context.RC_ID, ucasAccountId)
    assert context.email == emailAddress, "Email ID :: {} is not present in Database :: {}".format(context.email,
                                                                                                   emailAddress)
    assert context.new_license == str(no_of_lic), "Number of license :: {} is not present in Database :: {}".format(
        context.new_license,
        no_of_lic)
    assert context.skuID == skuID, "skuID :: {} is not present in Database :: {}".format(context.skuID, skuID)
    assert context.edition_type == packageID, "edition_type :: {} is not present in Database :: {}".format(
        context.edition_type, packageID)
    assert orderType == "ChangeLicense", "orderType :: {} is not present in Database :: {}"
    assert orderStatus == status, "orderStatus :: {} is not present in Database :: {}"
    assert source_db == source, "source :: {} is not present in Database :: {}"
    assert description_db == description, "description :: {} is not present in Database :: {}"
    assert errorCode_db == errorCode, "errorCode :: {} is not present in Database :: {}"
    # assert companyName == "", "companyName :: {} is not present in Database :: {}"
    assert opcoAccountId == "", "opcoAccountID :: {} is not present in Database :: {}"


# And user validates different adddress in database for 'appdirect_create_shippingaddress'
@then("user validates different adddress in database for '{kafka_topic_name}'")
def validate_address_kafka_topic_db(context, kafka_topic_name):
    if kafka_topic_name == "appdirect_create_shippingaddress":
        document = database.get_shipping_records(context.marketplaceEventID)
        assert len(document) > 0, "Document for Change License is not present in database "
        print("Document from database for Purchase Master Device :: ", document)
        print(" ")
        database_payload = {}
        # locationType = document["locationType"]
        status = document["status"]
        marketplaceEventId = document["marketplaceEventId"]
        marketplaceAccountId = document["shippingAddress"]["marketplaceAccountId"]
        # context.accountLocationID = document["accountLocationId"]

        database_payload["address_line_1"] = document["shippingAddress"]["company"]["location"]["shippingAddress"][
            "street"]
        database_payload["address_line_2"] = document["shippingAddress"]["company"]["location"]["shippingAddress"][
            "street2"]
        database_payload["town_city"] = document["shippingAddress"]["company"]["location"]["shippingAddress"]["city"]
        database_payload["postcode"] = document["shippingAddress"]["company"]["location"]["shippingAddress"]["zip"]
        database_payload["country"] = document["shippingAddress"]["company"]["location"]["shippingAddress"]["country"]

        assert context.marketplaceEventID == marketplaceEventId, "marketplaceEventID :: {} is not present in Database :: {} ".format(
            context.marketplaceEventID, marketplaceEventId)
        assert context.marketplaceAccountID == marketplaceAccountId, "marketplaceAccountID :: {} is not present in Database :: {} ".format(
            context.marketplaceAccountID, marketplaceAccountId)
        assert status == "Accepted", "Status :: {} is not present in Database :: {} ".format(
            status, "Accepted")

        # {'shippingAddress': {'street': '1,Oak Street', 'street2': '1,Oak Street', 'city': 'London', 'state': 'London', 'zip': 'W5 5TH', 'country': 'GB'}
        assert database_payload["address_line_1"] == context.address1, "Item {} is not present in Database {}".format(
            database_payload["address_line_1"], context.address1)
        assert database_payload["address_line_2"] == context.address2, "Item {} is not present in Database {}".format(
            database_payload["address_line_2"], context.address2)
        assert database_payload["town_city"] == context.city, "Item {} is not present in Database {}".format(
            database_payload["town_city"], context.city)
        assert database_payload["country"] == "GB", "Item {} is not present in Database {}".format(
            database_payload["country"], "GB")
        assert database_payload["postcode"] == context.postcode, "Item {} is not present in Database {}".format(
            database_payload["postcode"], context.postcode)

    else:
        assert 1 == 0, "Validation scripts are not available for this event"


# And user validates the data in database for 'appdirect_create_addonorder'
@then("user validates the data in database for '{kafka_topic_name}'")
def validate_data_for_kafka_topic_db(context, kafka_topic_name):
    if kafka_topic_name == "appdirect_create_initialorder":
        # once RC_ID is created it takes sometime to get the ID updated in DB.
        # So this while loop will help us to iterate database search upto 8 times with 3 sec interval untill RC_ID got Found
        count = 1
        time_slice = data_files.read_config("common.yml", "timeouts.kafka_timer")
        while count < 9:
            read_xmldata.wait_to_connect(time_slice)
            document = database.create_db_connection(context.marketplaceEventID)
            assert len(document) > 0, "Document for Create Account is not present in database "
            if document["ucasAccountId"] == context.RC_ID:
                logging.info(f"ucasAccountId is found: {context.RC_ID}")
                break
            count += 1

        database_payload = {}
        logging.info(f"Document from database for Create Account :: {document}")

        orderType = document["orderType"]
        orderStatus = document["orderStatus"]
        marketplaceEventId = document["marketplaceEventId"]
        marketplaceAccountId = document["marketplaceAccountId"]
        correlationIdFromMarketplace = document["correlationIdFromMarketplace"]
        opCoAccountId = document["opCoAccountId"]
        ucasAccountId = document["ucasAccountId"]
        emailAddress = document["primaryContactDetails"]["emailAddress"]
        mobile = document["primaryContactDetails"]["mobile"]
        no_of_lic = document["orderDetails"]["quantity"]
        skuID = document["orderDetails"]["skuID"]
        packageID = document["orderDetails"]["packageID"]

        database_payload["companyName"] = document["companyName"]
        database_payload["opco_billing_account_num"] = document["additionalOpCoData"]["opCoBillingAccountNumber"]
        database_payload["opco_billing_ref"] = document["additionalOpCoData"]["opCoBillingServiceReference"]
        database_payload["opco_opportunity_id"] = document["additionalOpCoData"]["opCoOpportunityId"]
        opco_order_reference_id = document["additionalOpCoData"]["opCoOrderReference"]
        database_payload["address_line_1"] = document["companyHeadQuartersAddress"]["street"]
        database_payload["address_line_2"] = document["companyHeadQuartersAddress"]["street2"]
        database_payload["town_city"] = document["companyHeadQuartersAddress"]["city"]
        # database_payload["state_county_region"] = document["companyHeadQuartersAddress"]["state"]
        database_payload["postcode"] = document["companyHeadQuartersAddress"]["zip"]
        database_payload["country"] = document["companyHeadQuartersAddress"]["country"]
        database_payload["first_name"] = document["primaryContactDetails"]["firstname"]
        database_payload["last_name"] = document["primaryContactDetails"]["lastname"]
        # event = document["orderHistory"]["event"]
        # accountstatus = document["orderHistory"]["accountstatus"]

        for item in database_payload:
            mandatory_value = read_xmldata.readxml(item, "appdirect_inputdata", 'AppdirectUI')
            print("Data from Appdirect : {} and Data from Initial Order Kafka : {}".format(mandatory_value,
                                                                                           database_payload[item]))
            assert mandatory_value in database_payload[item], "Item {} is not present in Database {}".format(
                mandatory_value, database_payload)

        assert context.op_co_order_reference == opco_order_reference_id, "externalOrderId :: {} is not present in Database :: {} ".format(
            context.op_co_order_reference, opco_order_reference_id)
        assert context.op_co_customer_id == opCoAccountId, "marketplaceAccountID :: {} is not present in Database :: {} ".format(
            context.op_co_customer_id, opCoAccountId)
        assert context.middleware_correlation_id == correlationIdFromMarketplace, "middlewareCorrelationID :: {} is not present in Database :: {} ".format(
            context.middleware_correlation_id, correlationIdFromMarketplace)
        assert context.mobile == mobile, "Contact Number :: {} is not present in Database :: {}".format(context.mobile,
                                                                                                        mobile)
        # assert context.opco_crm_customer_id == opCoAccountId, "opco_crm_customer_id :: {} is not present in Database :: {} ".format(
        # context.opco_crm_customer_id, opCoAccountId)
        assert context.email == emailAddress, "Email ID :: {} is not present in Database :: {}".format(context.email,
                                                                                                       emailAddress)
        assert context.initial_license == str(
            no_of_lic), "Number of license :: {} is not present in Database :: {}".format(
            context.initial_license,
            no_of_lic)
        assert context.skuID == skuID, "skuID :: {} is not present in Database :: {}".format(context.skuID, skuID)
        assert context.edition_type == packageID, "packageID :: {} is not present in Database :: {}".format(
            context.edition_type, packageID)
        assert context.RC_ID == ucasAccountId, "RC_ID :: {} is not present in Database :: {}".format(
            context.RC_ID, ucasAccountId)
        assert orderType == "InitialOrder", "orderType :: {} is not present in Database :: {}".format(orderType,
                                                                                                      "InitialOrder")
        assert orderStatus == "UcasReceived", "orderStatus :: {} is not present in Database :: {}".format(orderStatus,
                                                                                                          "UcasReceived")

    elif kafka_topic_name == "appdirect_create_addonorder":
        document = database.create_db_connection(context.marketplaceEventID)
        assert len(document) > 0, "Document for Change License is not present in database "
        print("Document from database for Purchase addon order :: ", document)
        print(" ")

        orderStatus = document["orderStatus"]
        orderType = document["orderType"]
        marketplaceEventID = document["marketplaceEventId"]
        correlationIdFromMarketplace = document["correlationIdFromMarketplace"]
        ucasAccountID = document["ucasAccountId"]
        no_of_lic = document["orderDetails"]["quantity"]
        skuID = document["orderDetails"]["skuID"]

        assert context.marketplaceEventID == marketplaceEventID, "externalOrderId :: {} is not present in Database :: {} ".format(
            context.marketplaceEventID, marketplaceEventID)
        assert context.middleware_correlation_id == correlationIdFromMarketplace, "middlewareCorrelationID :: {} is not present in Database :: {} ".format(
            context.middleware_correlation_id, correlationIdFromMarketplace)
        assert context.RC_ID == ucasAccountID, "RC_ID :: {} is not present in Database :: {}".format(
            context.RC_ID, ucasAccountID)
        assert context.skuID == skuID, "skuID :: {} is not present in Database :: {}".format(context.skuID, skuID)
        assert orderType == "AddOnOrder", "orderType :: {} is not present in Database :: {}".format(orderType,
                                                                                                    "AddOnOrder")
        assert orderStatus == "Complete", "orderStatus :: {} is not present in Database :: {}".format(orderStatus,
                                                                                                      "Received")
    elif kafka_topic_name == "appdirect_create_shippingaddress":
        document = database.get_shipping_records(context.marketplaceEventID)
        assert len(document) > 0, "Document for Change License is not present in database "
        print("Document from database for Purchase Master Device :: ", document)
        print(" ")
        database_payload = {}
        # locationType = document["locationType"]
        status = document["status"]
        marketplaceEventId = document["marketplaceEventId"]
        marketplaceAccountId = document["shippingAddress"]["marketplaceAccountId"]
        # context.accountLocationID = document["accountLocationId"]

        database_payload["address_line_1"] = document["shippingAddress"]["company"]["location"]["shippingAddress"][
            "street"]
        database_payload["town_city"] = document["shippingAddress"]["company"]["location"]["shippingAddress"]["city"]
        database_payload["postcode"] = document["shippingAddress"]["company"]["location"]["shippingAddress"]["zip"]
        database_payload["country"] = document["shippingAddress"]["company"]["location"]["shippingAddress"]["country"]

        assert context.marketplaceEventID == marketplaceEventId, "marketplaceEventID :: {} is not present in Database :: {} ".format(
            context.marketplaceEventID, marketplaceEventId)
        assert context.marketplaceAccountID == marketplaceAccountId, "marketplaceAccountID :: {} is not present in Database :: {} ".format(
            context.marketplaceAccountID, marketplaceAccountId)
        assert status == "Accepted", "Status :: {} is not present in Database :: {} ".format(
            status, "Accepted")
        # assert locationType == "ShippingAddress", "locationStatus :: {} is not present in Database :: {} ".format(
        #     locationType, "ShippingAddress")

        for item in database_payload:
            mandatory_value = read_xmldata.readxml(item, "appdirect_inputdata", 'AppdirectUI')
            print("Data from Appdirect : {} and Data from purchase master device DB : {}".format(mandatory_value,
                                                                                                 database_payload[
                                                                                                     item]))
            assert mandatory_value in database_payload[item], "Item {} is not present in Database {}".format(
                mandatory_value, database_payload)
    elif kafka_topic_name == "Notification_Registration":
        context.execute_steps(u"""
                When user runs a query in database to fetch the '{database_value}' for respective '{reference_value}'
                            """.format(database_value="isActiveTrue", reference_value="subscription_id"))

        print("Notification_Registration")
    elif kafka_topic_name == "Notification_UnRegistration":
        context.execute_steps(u"""
                When user runs a query in database to fetch the '{database_value}' for respective '{reference_value}'
                            """.format(database_value="isActiveFalse", reference_value="subscription_id"))
        print("Notification_UnRegistration")
    else:
        assert 1 == 0, "Validation scripts are not available for this event"


# And user validates the error message in database for 'appdirect_create_initialorder'
@then("user validates the error message in database for '{kafka_topic_name}'")
def validate_error_for_kafka_topic_db(context, kafka_topic_name):
    if kafka_topic_name == "appdirect_create_initialorder":
        database_payload = {}
        document = database.create_db_connection(context.marketplaceEventID)
        assert len(document) > 0, "Document for Create Account is not present in database "
        print("Document from database for Create Account :: ", document)
        print(" ")

        orderType = document["orderType"]
        orderStatus = document["orderStatus"]
        marketplaceEventId = document["marketplaceEventId"]
        marketplaceAccountId = document["marketplaceAccountId"]
        correlationIdFromMarketplace = document["correlationIdFromMarketplace"]
        error_description = document["errorDetails"]["description"]
        error_code = document["errorDetails"]["errorCode"]

        assert context.middleware_correlation_id == correlationIdFromMarketplace, "middlewareCorrelationID :: {} is not present in Database :: {} ".format(
            context.middleware_correlation_id, correlationIdFromMarketplace)
        assert error_description == context.RC_error_message, "error_description :: {} is not present in Database :: {}".format(
            error_description, context.RC_error_message)
        assert error_code == context.RC_error_code, "error_code :: {} is not present in Database :: {}".format(
            error_code, context.RC_error_code)

        assert orderType == "InitialOrder", "orderType :: {} is not present in Database :: {}".format(orderType,
                                                                                                      "InitialOrder")
        assert orderStatus == "Error", "orderStatus :: {} is not present in Database :: {}".format(orderStatus, "Error")
    elif kafka_topic_name == "appdirect_create_changelicense":
        database_payload = {}
        document = database.create_db_connection(context.marketplaceEventID)
        assert len(document) > 0, "Document for Change License is not present in database "
        print("Document from database for Change License :: ", document)
        print(" ")

        orderType = document["orderType"]
        orderStatus = document["orderStatus"]
        marketplaceEventId = document["marketplaceEventId"]
        marketplaceAccountId = document["marketplaceAccountId"]
        correlationIdFromMarketplace = document["correlationIdFromMarketplace"]
        error_description = document["errorDetails"]["description"]
        error_code = document["errorDetails"]["errorCode"]

        assert context.middleware_correlation_id == correlationIdFromMarketplace, "middlewareCorrelationID :: {} is not present in Database :: {} ".format(
            context.middleware_correlation_id, correlationIdFromMarketplace)
        assert error_description == "Cannot remove licences.", "orderStatus :: {} is not present in Database :: {}".format(
            error_description, "Cannot remove licences.")
        assert error_code == "UCAS_PROVIDER_ERROR", "orderStatus :: {} is not present in Database :: {}".format(
            error_code, context.RC_error_code)

        assert orderType == "ChangeLicense", "orderType :: {} is not present in Database :: {}".format(orderType,
                                                                                                       "ChangeLicense")
        assert orderStatus == "Error", "orderStatus :: {} is not present in Database :: {}".format(orderStatus, "Error")
    elif kafka_topic_name == "ordermanagement_command_update_accountstatus":
        # database_payload = {}
        document = database.create_db_connection(context.marketplaceEventID)
        assert len(document) > 0, "Document for Change License is not present in database "
        print("Document from database for Change License :: ", document)
        print(" ")

        orderType = document["orderType"]
        orderStatus = document["orderStatus"]
        marketplaceEventId = document["marketplaceEventId"]
        marketplaceAccountId = document["marketplaceAccountId"]
        correlationIdFromMarketplace = document["correlationIdFromMarketplace"]
        error_description = document["errorDetails"]["description"]
        error_code = document["errorDetails"]["errorCode"]

        assert context.oldmiddlewareCorrelationID == correlationIdFromMarketplace, "middlewareCorrelationID :: {} is not present in Database :: {} ".format(
            context.oldmiddlewareCorrelationID, correlationIdFromMarketplace)
        assert error_description == context.RC_account_status_error_message, "error_description :: {} is not present in Database :: {}".format(
            error_description, context.RC_account_status_error_message)
        assert error_code == context.RC_account_status_error_code, "error_code :: {} is not present in Database :: {}".format(
            error_code, context.RC_account_status_error_code)

        assert orderType == "InitialOrder", "orderType :: {} is not present in Database :: {}".format(orderType,
                                                                                                      "InitialOrder")
        assert orderStatus == "Error", "orderStatus :: {} is not present in Database :: {}".format(orderStatus, "Error")
    else:
        assert 1 == 0, "Validation scripts are not available for this order"


# When user runs a query in database to fetch the 'UID' for respective 'UUID'
# When user runs a query in database to fetch the 'isActiveTrue' for respective 'subscription_id'
@when("user runs a query in database to fetch the '{database_value}' for respective '{reference_value}'")
def fetch_value_from_ref_db(context, database_value, reference_value):
    if database_value == "UID" and reference_value == "UUID":
        document = database.get_uid_nummgnt(context.status_get_response_num_pool_uuid)
        assert len(document) > 0, "Document for number mgnt is not present in database "
        logging.info(f'DB Record is : {document}')
        logging.info(" ")
        context.NumPool_UUID = document["requestUid"]
        logging.info(f'UUID is : {context.NumPool_UUID}')
        logging.info(" ")

    if database_value == "UID" and reference_value == "presentation_number":
        with database.open_database('number-management-api', 'InterstitialPool') as db:
            document = db.get_first_document('numbers', context.number_fwpool_list[0])
            assert document is not None, "Document for number mgnt is not present in database "
            logging.info(f"Document from database for number mgnt ::  {document}")
            context.NumPool_UUID = document["requestUid"]
            logging.info(f"UID from database ::{context.NumPool_UUID}")

    if reference_value == "subscription_id":
        document = database.get_listener_document(context.subscription_id)
        logging.info(document)
        assert len(document) > 0, "Document for Notification is not present in database"
        if database_value == "isActiveTrue":
            asserts.field_equals(document["isActive"], True, "subscription isActive")
        elif database_value == "isActiveFalse":
            asserts.field_equals(document["isActive"], False, "subscription isActive")


@given("user gets all '{status}' '{items}' from database")
def fetch_status_items_db(context, status, items):
    if items == 'subscriptions':
        if status == 'active':
            search_value = True
        elif status == 'not active':
            search_value = False
        context.subscriptions = database.get_notification_collection('isActive', search_value)


@then("'{requested_data}' is fetched from DB")
def fetch_data_db(context, requested_data):
    document = database.get_crf_document(requested_data)


@then("BGID is stored in database")
def bgid_is_stored_in_database(context):
    logging.info(f'op_co_customer_id :: {context.op_co_customer_id}')
    with database.open_database("id-mapper-api", "MsocCustomer") as db:
        document = polling.wait_until(lambda: db.get_first_document("vodafoneId", context.op_co_customer_id),
                                      'id mapper document')
        logging.info(f'msoc customer document: {database.parse_json(document)}')
        assert 'bgid' in document, "BGID was not saved in DB"
        context.bgid = document['bgid']
        logging.info(f"BGID from database ::  {context.bgid}")
        if 'msoc_account' in context:
            context.msoc_account.bgid = document['bgid']
        if 'snow_onboarding' in context:
            logger.debug('validating snow onboarding fields')
            asserts.equals(document['itsmProvisioning']['enableProvisioning'],
                           context.msoc_account.itsm_provisioning.enable_provisioning,
                           'enable_provisioning')
            asserts.equals(str(document['itsmProvisioning']['contractStartDate'].date()),
                           context.msoc_account.itsm_provisioning.contract_start_date,
                           'contract_start_date')
            asserts.equals(str(document['itsmProvisioning']['contractEndDate'].date()),
                           context.msoc_account.itsm_provisioning.contract_end_date,
                           'contract_end_date')
            if 'link_service_to_fully_onboarded_customer' in context:
                asserts.equals(document['itsmProvisioning']['linkServiceToFullyOnboardedCustomer'],
                               context.msoc_account.itsm_provisioning.link_service_to_fully_onboarded_customer,
                               'Validation failed for link_service_to_fully_onboarded_customer')


@when('Billing Identifiers are validated in Database')
def validate_billing_ids_db(context):
    logging.info(f'op_co_customer_id :: {context.op_co_customer_id}')
    with database.open_database("id-mapper-api", "MsocCustomer") as db:
        document = polling.wait_until(lambda: db.get_first_document("vodafoneId", context.op_co_customer_id),
                                      'id mapper document',
                                      stop_when=lambda document: document and 'countryBillingInformation' in document)
        logging.info(f'msoc customer document: {database.parse_json(document)}')
        assert context.service_identifier == document['countryBillingInformation']['GB'][
            'serviceIdentifier'], "Service Identifier was not saved in DB"
        assert context.customer_reference_number == document['countryBillingInformation']['GB'][
            'customerReferenceNumber'], "Customer Reference Number was not saved in DB"
        logging.info(f"Billing Identifiers from database :: Service Identifier:{context.service_identifier},"
                     f"Customer Reference Number:{context.customer_reference_number}")


@then("user validates retry count '{expected_attempts:d}' from database for '{response_code:d}'")
def validate_retry_count_for_code_db(context, expected_attempts: int, response_code: int) -> None:
    """Validate TMF Service Order Gateway number of attempts to send a notification.

    RC-stub increments "counter" in a DB document for each attempt.
    """
    if response_code in [HTTPStatus.TOO_MANY_REQUESTS, HTTPStatus.INTERNAL_SERVER_ERROR]:
        query = {
            "event.serviceOrder.externalReference.0.id": context.op_co_customer_id,
            # focus on 1 type of notification (related to SOI)
            "description": {"$regex": "^Service Order Item state value changed"},
        }
        if "subscription_test_id" in context:
            query["subscription_test_id"] = context.subscription_test_id
        logging.info(f"Searching for notification info in DB with {query=}")

        with database.open_database('automation-fw', 'tmf-notifications') as db:
            def get_notification_doc() -> dict | None:
                """Get the document with info for the current notification attempt."""
                if doc := db.collection.find_one(query):
                    logging.debug(
                        f"Current number of notification attempts: {doc['counter']} (for eventId={doc['eventId']})")
                    return doc
                logging.debug("No notification attempt yet")
                return None

            for index in range(expected_attempts):
                expected_counter = index + 1
                notification = polling.wait_until(
                    get_notification_doc, f'occurrence of notification attempt #{expected_counter}',
                    stop_when=lambda doc: doc is not None and doc["counter"] >= expected_counter,
                    timeout=2 * 60,
                )
        assert notification
        logging.info(f"Final notification in DB after {notification['counter']} attempts: {to_json(notification)}")
        asserts.equals(notification['counter'], expected_attempts, "Number of notification attempts")
        context.event_id = notification['eventId']

    elif response_code == HTTPStatus.OK:
        with database.open_database('automation-fw', 'tmf-notifications') as db:
            polling.wait_until(
                lambda: db.collection.count_documents({'eventId': context.notification_event_id}) == expected_attempts,
                f"presence of {expected_attempts} notifications")

    else:
        raise NotImplementedError(f"validate retry count for {response_code=}")


# This function will create param fields and fetch data from 'tmf-svc-order-gw-api' DB
@then("user retrieve and validate service order data from database")
def validate_service_order_db(context):
    num_of_records_from_get_response = int(context.response.headers['X-Total-Count'])
    logging.info(f"Number of records from get response :: {num_of_records_from_get_response}")
    filter_param = {}
    for key, value in context.param.items():
        if 'market' in key:
            updated_market = {'relatedParty.marketCode': value}
            filter_param.update(updated_market)

        elif 'Date' in key:
            start_date = datetime.fromisoformat(value)
            end_date = start_date + timedelta(days=1)
            updated_date = {key: {'$gte': start_date, '$lt': end_date}}
            filter_param.update(updated_date)

        elif 'state' in key:
            updated_state = {key: camel_converter.to_snake(value).upper()}
            filter_param.update(updated_state)

        elif 'externalReference' in key:
            updated_query = {'externalReference._id': value}
            filter_param.update(updated_query)

        else:
            new_record = ({key: value})
            filter_param.update(new_record)

    with database.open_database("tmf-svc-order-gw-api", "serviceorder") as db:
        num_of_records_from_db = db.collection.count_documents(filter_param)
        logging.info(f"Number of records from DB :: {num_of_records_from_db}")
        asserts.equals(num_of_records_from_db, num_of_records_from_get_response,
                       f"Records are not matching with database for {context.param}")


@then("user retrieve and validate the date range filter data")
def validate_date_range_filter(context):
    num_of_records_from_get_response = int(context.response.headers['X-Total-Count'])
    logging.info(f"{num_of_records_from_get_response=}")

    values_list = list(context.param.values())
    keys_list = list(context.param.keys())

    start_date = datetime.fromisoformat(values_list[0])
    if len(values_list) > 1:
        end_date = datetime.fromisoformat(values_list[1])
    else:
        end_date = start_date + timedelta(days=1)

    if "." in keys_list[0]:
        op1 = "$" + keys_list[0].split(".")[1]  # 1st field is a "from/start" date
        field = keys_list[0].split('.')[0]
    else:
        op1 = "$gte"
        field = keys_list[0]

    if len(keys_list) > 1:
        op2 = "$" + keys_list[1].split(".")[1]  # 2nd field is a "to/end" date
    else:
        op2 = "$lt"

    with database.open_database("tmf-svc-order-gw-api", "serviceorder") as db:

        if (len(keys_list) == 1) and "." in keys_list[0]:
            num_of_records_from_db = db.collection.count_documents({field: {op1: start_date}})
        else:
            num_of_records_from_db = db.collection.count_documents({field: {op1: start_date, op2: end_date}})
        logging.info(f"{num_of_records_from_db=}")

    asserts.equals(num_of_records_from_get_response, num_of_records_from_db,
                   'Total Service Order with date range filter')


@then("validate state in RC initial order request")
def validate_state_in_rc_initial_order_request(context):
    if common.config.is_dev_env:
        with database.open_database("automation-fw", "rc-stub-requests") as db:
            document = polling.wait_until(lambda: db.get_first_document("externalAccountId",
                                                                        f'{context.market_code}_{context.op_co_customer_id}'),
                                          'Ring central request from DB',
                                          stop_when=lambda document: document)
            logging.info(f'document: {database.parse_json(document)}')
            asserts.equals(context.state, document['companyAddress']['state'], "State field")


@then("Msoc customer is deleted from database for {market}")
def check_customer_exists_in_id_mapper_db(context, market, exists=True):
    with database.open_database("id-mapper-api", "MsocCustomer") as db:

        document = db.collection.find_one({"vodafoneId": context.op_co_customer_id, 'market': market})
        logger.debug(f'Msoc customer document: {document=}')
        if exists:
            assert document is None, "Msoc Customer is not deleted from DB"
        else:
            assert document is not None, "Msoc Customer document is getting in NumberManagement DB"


@then("Customer is deleted from number management database")
def check_customer_exists_in_num_mgmt_db(context, market, exists=True):
    with database.open_database("number-management-api", "Customer") as db:
        document = db.collection.find_one({"customerId": context.op_co_customer_id, 'market': market})
        logger.debug(f'customer document: {document=}')
        if exists:
            assert document is None, "Customer is not deleted from Number Management DB"
        else:
            assert document is not None, "Customer document is getting in NumberManagement DB"


@when("BGID is stored in database for TPM customer")
def bgid_stored_for_tpm_customer(context):
    logging.info(f'op_co_customer_id: {context.tpm_account.op_co_customer_id}')
    document = polling.wait_until(lambda: database.get_tpm_account_documents({
        "vodafoneId": context.tpm_account.op_co_customer_id,
        "market": context.tpm_account.market_code}),
                                  'id mapper document', stop_when=lambda doc: len(doc) > 0)
    context.tpm_account.bgid = document[0]['bgid']
    logging.info(f'document: {database.parse_json(document)}')


def validate_snow_characteristic_fields(context):
    with database.open_database("id-mapper-api", "TpmCustomer") as db:
        document = polling.wait_until(lambda: database.get_tpm_account_documents({
            "vodafoneId": context.tpm_account.op_co_customer_id,
            "market": context.tpm_account.market_code}),
                                      'id mapper document', stop_when=lambda doc: len(doc) > 0)
        logging.info(f'{document}=')
        asserts.equals(document[0]['itsmProvisioning']['enableProvisioning'],
                       context.tpm_account.itsm_provisioning.enable_provisioning, 'snow enable provisioning status')
        asserts.equals(re.search(r'\d+-\d+-\d+', str(document[0]['itsmProvisioning']['contractStartDate'])).group(0),
                       context.tpm_account.itsm_provisioning.contract_start_date, 'snow contract start date')
        asserts.equals(re.search(r'\d+-\d+-\d+', str(document[0]['itsmProvisioning']['contractEndDate'])).group(0),
                       context.tpm_account.itsm_provisioning.contract_end_date, 'snow contract end date')
        if context.market_code == "VFUK":
            asserts.equals(document[0]['itsmProvisioning']['localMarketServiceId'],
                           context.tpm_account.itsm_provisioning.local_market_service_id,
                           'snow local market service id')
        logging.info('SNOW Fields validated')
