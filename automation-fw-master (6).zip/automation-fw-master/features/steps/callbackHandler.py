import datetime

import camel_converter

from classes import common


def save_customer_id_for_callback(context, callback_state):
    # in order to response with specific call back
    # when we create resource order it should be done for specific account
    context.op_co_customer_id = f'CRF_Callback_{camel_converter.to_snake(callback_state).upper()}'
    # generate for staging a new account for the day
    if common.config.is_staging_env:
        context.op_co_customer_id = f'CRF_Callback_{str(datetime.date.today())}'
