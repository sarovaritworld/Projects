import json
import logging

from behave import *

from classes import tmf, read_xmldata, payload, common, patch, asserts
from classes.kafka.msg_validation_set import KafkaMsgValidationSet
from classes.payload_generators.TMF import patch_generator


@when("user needs to create a patch request for '{level}' level for '{item_to_change}' to change status to '{status}'")
def create_patch_request_to_update_status(context, level, item_to_change, status):
    if item_to_change == 'tenant' and common.config.is_crf_add_number_enabled:
        return
    item_to_change = payload.get_item_to_change(item_to_change)
    logging.info(f'{context.payload}')
    index, item = payload.get_item_by_type(context.payload, item_to_change)
    logging.info(f'{index=} {item=}')
    if "msoc" not in item_to_change:
        items = payload.get_items_by_type(context.payload, f'ucc.unity.{item_to_change}')
        if len(items) > 1 and item_to_change == 'numbers':
            for item in items:
                if not hasattr(context, 'patch_payload'):
                    context.patch_payload = patch.generate_patch(level, item_to_change, status, item['id'] - 1)
                else:
                    context.patch_payload = patch.generate_complex_patch(context.patch_payload, level, item_to_change,
                                                                             status, item['id'] - 1)
            return
    context.patch_payload = patch.generate_patch(level, item_to_change, status, index)
    if hasattr(context, 'complex_so_flag'):
        context.patch_payload[0]['path'] = "/serviceOrderItem/1/state"
    logging.info(f"Payload for PATCH request is created:")
    logging.info(json.dumps(context.patch_payload, indent=3))


@when("Patch request is created for '{action}' service_characteristics for '{item_to_change}'")
def create_patch_request_for_service_characteristics_item(context, action, item_to_change):
    index, item = payload.get_item_by_type(context.payload, f'ucc.unity.{item_to_change}')
    logging.info(f'{index=} {item=}')
    context.order_id = read_xmldata.gen_contact(8)
    context.patch_payload = patch.additional_patch(action, context.order_id, item['id'] - 1)

    logging.info(f"Payload for PATCH request is created:")
    logging.info(json.dumps(context.patch_payload, indent=3))


@when("Patch request is created for '{action}' '{field}' in tenant with error")
def create_patch_request_for_field_in_tenant(context, action, field):
    patch_characteristics = read_xmldata.read_jsonfile("replace_tenant_error")
    for characteristic in patch_characteristics:
        if characteristic["name"] == field:
            break
    else:
        raise NotImplementedError(f"No pre-defined payload implemented for {field=}")

    if action == "add":
        characteristic["op"] = action
    characteristic["name"] = 'abc'

    context.patch_payload = [characteristic]
    logging.info(f"Payload for {field} is created:")
    logging.info(json.dumps(context.patch_payload, indent=3))


# Then user needs to create a 'success' patch request with 'missing_item_op' value for serviceOrderItem
@when("user needs to create a '{order_type}' patch request with '{value_type}' value for serviceOrderItem")
def create_patch_request_for_serviceOrderItem_with_value(context, order_type, value_type):
    payload_type = 'update_service_order'
    if order_type == 'failed':
        payload_type = 'update_service_order_with_error'

    context.patch_payload = patch_generator.create_payload_for_patch(payload_type, "License")

    if value_type == "missing_item_op":
        context.patch_payload[0]["op"] = ""
    elif value_type == "missing_item_path":
        context.patch_payload[0]["path"] = ""
    elif value_type == "missing_item_state":
        context.patch_payload[0]["value"] = ""

    elif value_type == "missing_note_path":
        context.patch_payload[1]["path"] = ""
    elif value_type == "missing_note_op":
        context.patch_payload[1]["op"] = ""

    elif value_type == "missing_milestone_path":
        context.patch_payload[2]["path"] = ""
    elif value_type == "missing_milestone_status":
        context.patch_payload[2]["status"] = ""
    elif value_type == "missing_milestone_op":
        context.patch_payload[2]["op"] = ""

    elif value_type == "incorrect_item_op":
        context.patch_payload[0]["op"] = "delete"
    elif value_type == "incorrect_item_path":
        context.patch_payload[0]["path"] = "/serviceOrderItem/10/state/"
    elif value_type == "incorrect_item_status":
        context.patch_payload[0]["value"] = "completed"

    elif value_type == "incorrect_note_op":
        context.patch_payload[1]["op"] = "delete"
    elif value_type == "incorrect_note_path":
        context.patch_payload[1]["path"] = "/note/state/"

    elif value_type == "incorrect_milestone_status":
        context.patch_payload[2]["status"] = "acknowledged"
    elif value_type == "incorrect_milestone_path":
        context.patch_payload[2]["path"] = "/milestone/milestone/-"
    elif value_type == "incorrect_milestone_op":
        context.patch_payload[2]["op"] = "delete"

    elif value_type == "service_order_state":
        context.patch_payload[0]["status"] = "completed"
        context.patch_payload[0]["path"] = "/state"
    elif value_type == "invalid_json_body":
        context.patch_payload = read_xmldata.read_jsonfile("create_service_order")
    elif value_type == "invalid_service_id":
        context.service_order_id = "628357cf767d2124cc0b60c32342344"
    elif value_type == "error_section_of_item":
        context.patch_payload[2]["path"] = "/serviceOrderItem/2/errorMessage/-"
    elif value_type == "valid_json":
        pass
    else:
        assert 1 == 0, "We are not validating this event"
    logging.info(f"Payload for {order_type} is created:")
    logging.info(json.dumps(context.patch_payload, indent=3))


# Then user validates 'INVALID_REQUEST' response from TMF Service Order Gateway Microservice
@then("user validates '{response_type}' response from TMF Service Order Gateway Microservice")
def validate_tmf_service_order_gw_response(context, response_type):
    validation_set = KafkaMsgValidationSet(context).invalid_request(response_type)
    logging.info(f"validation_set for {response_type} : {validation_set}")
    for field_name, expected in validation_set.items():
        actual = common.get_field(context.response_payload, field_name)
        asserts.field_equals(actual, expected, field_name)


@given("that '{item}' service order item is '{status}'")
def validate_service_order_item(context, item, status):
    context.execute_steps("""
    Given customer orders 'add' '5' '{item}' for 'LC_DL-UNL_50'
    When customer sends an order to Middleware
    Then JIRA tickets has been created successfully
    When BO tool sends PATCH request on 'service_order_item' level for '{item}' is '{status}'
    """.format(item=item, status=status))


@then("patch error message is present for '{outcome}'")
def validate_patch_error_message(context, outcome):
    tmf.validate_error_message(context, outcome)


@when("BO tool sends PATCH request on '{level}' level for '{item}' is '{status}'")
def send_patch_request_from_bo_tool(context, level, item, status):
    logging.debug(f'doing patch for {level} {item} to {status}')
    if item in ['account', 'tenant'] and common.config.is_crf_add_number_enabled:
        return
    context.execute_steps("""
    When user needs to create a patch request for '{level}' level for '{item_to_change}' to change status to '{status}'
    And user sends a patch request for 'update_service_order' to TMF Service Order Gateway Microservice
    Then user validates '200' response
    """.format(level=level, item_to_change=item, status=status))
    context.item_to_change = item
    # patch milestone and note should be added to all status transition except for failed
    if status != 'failed':

        if not hasattr(context, 'patch_milestones'):
            context.patch_milestones = []
        context.patch_milestones.append(tmf.get_patch_milestone(item))
