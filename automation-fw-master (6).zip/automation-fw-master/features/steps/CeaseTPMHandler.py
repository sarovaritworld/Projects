import logging

from behave import given, then, when

from classes import common, polling, s3_bucket, utils
from classes import database, errors
from classes.common import create_or_update_key
from classes.domain.account import TPMAccount
from classes.kafka import consumer_data, topic_validator
from classes.payload_generators.TMF import Action
from classes.payload_generators.TMF.account_generator import TPMAccountPayloadGenerator
from features.steps import CRFHandler, CeaseMSOCHandler, TMFHandler, TpmHandler, databaseHandler, flowHandler, \
    validationHandler

logger = logging.getLogger(__name__)


@given("TPM customer has been created with numbers added into it")
def tpm_customer_created_with_numbers(context):
    TpmHandler.tpm_account_created(context)
    numbers_added_into_tpm_customer(context)


@given("TPM customer has been created without numbers added into it")
def tpm_customer_created_without_numbers(context):
    TpmHandler.tpm_account_created(context)


@then("TPM Customer is ceased successfully")
def tpm_customer_is_ceased_successfully(context, account_delete_skipped=False):
    # Delete All TPM Numbers flow
    database.get_operation_id_by_service_order_operation('DELETE_ALL_NUMBERS', context.service_order_id)
    CeaseMSOCHandler.tmfmediator_command_delete_all_numbers_topic_is_validated(context)
    common.update_middleware_correlation_id(context)
    CeaseMSOCHandler.numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context)
    TpmHandler.tpm_customer_is_ceased_successfully(context)
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, context.market_code)
    CeaseMSOCHandler.numbermanagement_event_all_numbers_deleted_is_validated(context)
    if not account_delete_skipped:
        CeaseMSOCHandler.tmfmediator_command_delete_account_is_validated(context)
        common.update_middleware_correlation_id(context)
        validate_tpm_cease_account_id_mapper_db(context)
        validate_cease_email_notification_sent_to_nao(context)
        CeaseMSOCHandler.idmapper_event_account_deleted_is_validated(context)
        TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
        TpmHandler.validate_service_order_tpm(context, "completed")


@then("TPM Customer failed to cease with '{status}'")
def tpm_customer_not_ceased(context, status):
    flowHandler.customer_sends_an_order_to_middleware(context)
    CeaseMSOCHandler.tmfmediator_command_delete_all_numbers_topic_is_validated(context)
    CeaseMSOCHandler.numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context)
    TpmHandler.delete_all_tpm_numbers_fails_crf(context, status)
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, context.market_code, False)
    CeaseMSOCHandler.numbermanagement_event_all_numbers_deleted_is_validated(context, status)

    TMFHandler.support_topic_sent(context, "OPERATION_FAILED", "CEASE_TPM_CUSTOMER")
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
    validationHandler.validate_error_message(context, status)


@then("Unable to add tpm numbers to ceased TPM Customer")
def unable_to_add_tpm_numbers_to_ceased_tpm_customer(context):
    CeaseMSOCHandler.validate_the_service_order_is_failed_with_error_message(context, "add_tpm_numbers")


@given("Cease TPM customer has been ordered with non existing tpm account for {market}")
def cease_tpm_customer_has_been_ordered_with_non_existing_tpm_account(context, market):
    tpm_cease_customer_ordered(context, market)
    customer_updates_field_with_value_in_cease_tpm_customer_service_order(
        context,
        "op_co_customer_id",
        "12345678901")
    flowHandler.customer_sends_an_order_to_middleware(context)


@then("validate that service order is failed with error message for cease tpm")
def validate_the_service_order_is_failed_with_error_message_cease_tpm(context):
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
    CeaseMSOCHandler.validate_error_message_cease_account(context.response_payload, None)


@given("customer updates '{field}' with '{value}' in cease TPM customer service order")
def customer_updates_field_with_value_in_cease_tpm_customer_service_order(context, field, value):
    if value == 'null':
        value = ''

    path = 'serviceOrderItem.[0]'

    replace_data = {
        'id': f'{path}.[{field}]',
        'action': f'{path}.[{field}]',
        '@type': f'{path}.[{field}]',
        'serviceType': f'{path}.["service"].[{field}]',
        'op_co_customer_id': 'externalReference.[0].id'
    }

    create_or_update_key(context.payload, replace_data[field], value)
    logging.info(f"Updated request payload for cease TPM customer is :: {utils.to_json(context.payload)}")


@given("Cease TPM customer service order has been created for '{market_code}'")
@when("Cease TPM customer service order has been created for '{market_code}'")
def tpm_cease_customer_ordered(context, market_code):
    market_code = 'VFUK' if not hasattr(context, "new_data_model_enable") and common.config.is_staging_env else market_code
    context.op_co_customer_id, tenant_id, bgid, name = (context.tpm_account.op_co_customer_id,
                                                        context.tpm_account.tenant_id,
                                                        context.tpm_account.bgid, context.tpm_account.name) \
        if hasattr(context, 'tpm_account') else (None, None, None, None)
    related_party = None if not hasattr(context, 'related_party') else context.related_party
    context.tpm_account = TPMAccount(market_code=market_code, op_co_customer_id=context.op_co_customer_id,
                                     tenant_id=tenant_id, bgid=bgid, name=name, related_party=related_party)
    context.market_code = context.tpm_account.market_code
    context.action = Action.delete
    context.category = context.tpm_account.category.upper()
    context.payload = TPMAccountPayloadGenerator(tpm_account=context.tpm_account, action=context.action).to_dict()
    logging.info(f"Cease TPM Request: {utils.to_json(context.payload)}")


def numbers_added_into_tpm_customer(context):
    TpmHandler.tpm_order_created_for_numbers(context, 'add', '5', 'pool', 'separate')
    TMFHandler.request_is_sent_to_create_service_order(context)
    TpmHandler.tpm_numbers_successfully_provisioned(context)
    TpmHandler.validate_email_notification_sent_to_nao(context, email_status="sent")
    TpmHandler.validate_service_order_tpm_add_number(context, 'completed')


@then("email is sent to NAO for cease customer")
def validate_cease_email_notification_sent_to_nao(context):
    search_property = context.existing_tpm_document["msTeamsTenantId"] if getattr(context, 'existing_tpm_document', False) \
        else context.tpm_account.tenant_id
    mails = polling.wait_until(lambda: s3_bucket.get_email(search_property, number_of_emails=2, search_in='body'),
                               f"Email for {search_property}", period=5, timeout=120,
                               stop_when=lambda x: len(x) > 0)
    mail_to_validate = None
    for mail in mails:
        if "removed from" in mail.get_body().get_content():
            mail_to_validate = mail
    TpmHandler.validate_notification_email(context, mail_to_validate, operation="cease")


@then("account is hard deleted in id mapper db")
def validate_tpm_cease_account_id_mapper_db(context):
    document = polling.wait_until(lambda: database.get_tpm_account_documents({
        "vodafoneId": context.tpm_account.op_co_customer_id,
        "market": context.tpm_account.market_code}), 'id mapper document',
                                  stop_when=lambda doc: len(doc) == 0)
    logger.info(f"{document}")


@given("service order is created to add tpm account with ceased tpm account")
def service_order_with_ceased_account(context):
    tpm_customer = database.get_tpm_account_document(
        {"market": "VFDE", 'vodafoneId': {'$not': {'$regex': '^CEASE_TPM'}}})
    logger.info(f"{tpm_customer=}")
    context.tpm_account = TPMAccount.from_tpm_customer_document(tpm_customer)
    tpm_cease_customer_ordered(context, "VFDE")
    TMFHandler.request_is_sent_to_create_service_order(context)
    tpm_customer_is_ceased_successfully(context)
    context.payload = TPMAccountPayloadGenerator(tpm_account=context.tpm_account, action=Action.add).to_dict()


@when("Add numbers to ceased TPM account")
def add_numbers_to_ceased_or_existing_tpm_account(context):
    TpmHandler.tpm_order_created_for_numbers(context, 'add', '5', 'pool', 'separate')
    TMFHandler.request_is_sent_to_create_service_order(context)


@given("TPM customer has been created with numbers added into it with '{error_type}'")
def tpm_customer_created_with_error(context, error_type):
    TpmHandler.create_tpm_customer_service_order(context, error_type=error_type)
    TMFHandler.request_is_sent_to_create_service_order(context)
    TpmHandler.tpm_customer_created_in_middleware(context)


@then("TPM Customer is ceased successfully after '{error}'")
def tpm_customer_is_ceased_successfully_after_error(context, error, account_delete_skipped=False):
    # Delete All TPM Numbers flow
    database.get_operation_id_by_service_order_operation('DELETE_ALL_NUMBERS', context.service_order_id)
    CeaseMSOCHandler.tmfmediator_command_delete_all_numbers_topic_is_validated(context)
    common.update_middleware_correlation_id(context)
    CeaseMSOCHandler.numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context)
    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, "acknowledged")

    if "crf_stub_payload" in context:
        del context.crf_stub_payload
    if common.config.is_dev_env:
        context.consumer_payload = consumer_data.get_messages(context, 'crfstub_process_resourceorder')
        topic_validator.KafkaTopicValidator(context).validate_topic(
            topic_name="crfstub_process_resourceorder",
            error_type=None,
            action="delete",
            pool=None,
            account_category="TPM"
        )
    notes = errors.DEPNoteErrors.get_dep_error(error)
    TpmHandler.dep_notification_sent_with_status(context, "failed", notes)
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_all_crf_numbers_deleted')
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name="crfgateway_event_all_crf_numbers_deleted")
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, context.market_code)
    CeaseMSOCHandler.numbermanagement_event_all_numbers_deleted_is_validated(context)
    if not account_delete_skipped:
        CeaseMSOCHandler.tmfmediator_command_delete_account_is_validated(context)
        common.update_middleware_correlation_id(context)
        validate_tpm_cease_account_id_mapper_db(context)
        validate_cease_email_notification_sent_to_nao(context)
        CeaseMSOCHandler.idmapper_event_account_deleted_is_validated(context)
        TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
        TpmHandler.validate_service_order_tpm(context, "completed")
