import logging

from behave import given, then, when

from classes import account, common, database, read_xmldata
from classes import snow
from classes.domain.account import MSOCAccount, TPMAccount
from classes.kafka import KafkaTopics, consumer_data, producer_data, topic_validator
from classes.kafka.topic_validator import KafkaTopicValidator
from features.steps import CeaseMSOCHandler, CeaseTPMHandler, MSOCHandler, TMFHandler, TpmHandler, databaseHandler, \
    flowHandler, kafkaHandler, validationHandler
from features.steps.SNOWHandler import customer_with_snow_and_add_ddis, \
    snow_onboarding_not_processed
from features.steps.TPMSNOWHandler import add_numbers_are_processed_in_middleware, \
    tpm_account_is_already_onboarded_to_snow, \
    tpm_customer_with_snow_onboarding_details_and_add_numbers_are_requested_in_same_order, \
    tpm_snow_onboarding_is_processed_in_middleware

logger = logging.getLogger(__name__)


@when("kafka message for topic tmfmediator_command_delete_snowcustomer is sent with {parameter}")
def payload_created_sent_to_tmfmediator_command_delete_snowcustomer(context, parameter=None):
    topic_name = "tmfmediator_command_delete_snowcustomer"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"][
        "middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.marketplace_event_id = context.payload["snow_offboarding"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.operation_id = context.payload["snow_offboarding"]["client_reference"][
        "operation_id"] = read_xmldata.gen_uuid()

    if hasattr(context, 'op_co_customer_id'):
        context.payload["snow_offboarding"]["op_co_details"]["name"] = context.market_code
        context.payload["snow_offboarding"]["ucas_provider"] = context.ucas_provider
        context.payload["snow_offboarding"]["op_co_details"]["op_co_customer_id"] = context.op_co_customer_id

    else:
        context.op_co_customer_id = context.payload["snow_offboarding"]["op_co_details"][
            "op_co_customer_id"] = read_xmldata.gen_opco(marketplace='TMF')
        context.ucas_provider = context.payload["snow_offboarding"]["ucas_provider"]
        context.market_code = context.payload["snow_offboarding"]["op_co_details"]["name"]

        if parameter == "invalid_ucas_provider":
            context.ucas_provider = context.payload["snow_offboarding"]["ucas_provider"] = "RINGCENTRAL"
        elif parameter == "invalid_opcoName":
            context.market_code = context.payload["snow_offboarding"]["op_co_details"]["name"] = "VFVF"
        elif parameter == "MNC_opco":
            context.market_code = context.payload["snow_offboarding"]["op_co_details"]["name"] = "MNC"
        elif parameter == "blank_customerID":
            context.op_co_customer_id = context.payload["snow_offboarding"]["op_co_details"]["op_co_customer_id"] = ""

    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@then("data is validated in snowgateway_event_snowcustomer_deleted with success")
@then("data is validated in snowgateway_event_snowcustomer_deleted with '{deprovisioned}'")
def payload_validation_snow_customer_deleted(context, deprovisioned=False):
    context.consumer_payload = consumer_data.get_messages(context, 'snowgateway_event_snowcustomer_deleted')
    topic_validator.KafkaTopicValidator(context).snowgateway_event_snowcustomer_deleted(deprovisioned)


def find_opco_customer_id(context):
    opco_account = getattr(context, 'tpm_account', getattr(context, 'msoc_account', None))
    if opco_account:
        context.op_co_customer_id = opco_account.op_co_customer_id
        context.ucas_provider = "TPM" if hasattr(context, 'tpm_account') else "MSOC"


@then("the SNOW off-boarding request for the account is successfully completed")
def account_ceased_successfully_in_snow(context):
    database.get_service_order_operation(context.service_order_id, 'SNOW_OFFBOARDING')
    CeaseTPMHandler.tpm_customer_is_ceased_successfully(context, True) if context.ucas_provider == 'TPM' else \
        CeaseMSOCHandler.cease_msoc_customer_for_market(context, context.market_code, True)
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_delete_snowcustomer')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_delete_snowcustomer()
    common.update_middleware_correlation_id(context)
    context.enable_provisioning = getattr(context, 'enable_provisioning', False)
    logging.info(f"{context.enable_provisioning=}")
    if context.enable_provisioning:
        snow.check_snow_onboarding_state('DELETED', context.op_co_customer_id)
    payload_validation_snow_customer_deleted(context, context.enable_provisioning)
    CeaseMSOCHandler.tmfmediator_command_delete_account_is_validated(context)
    databaseHandler.check_customer_exists_in_id_mapper_db(context, context.market_code)
    CeaseMSOCHandler.idmapper_event_account_deleted_is_validated(context)
    context.account_deprovisioned = True if context.enable_provisioning else False
    context.snow_offboarding = True
    TpmHandler.validate_service_order_tpm(context, 'completed') if context.ucas_provider == 'TPM' else \
        validationHandler.validates_msoc_customer_or_number_status(context, 'completed')


@then("the SNOW off-boarding request for the ceased account is successful")
def already_ceased_account_success(context):
    find_opco_customer_id(context)
    payload_created_sent_to_tmfmediator_command_delete_snowcustomer(context)
    snow.check_snow_onboarding_state('DELETED', context.op_co_customer_id)
    payload_validation_snow_customer_deleted(context, False)


@given("a new TPM Account is onboarded without SNOW")
def tpm_account_not_onboarded_in_snow(context, enable_provisioning=False, market_code='VFDE'):
    tpm_customer_with_snow_onboarding_details_and_add_numbers_are_requested_in_same_order(context, enable_provisioning,
                                                                                          market_code)
    add_numbers_are_processed_in_middleware(context, 'sent')
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created(account_provisioned=enable_provisioning)
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")


@given("a new {ucas_provider} account is onboarded which will fail to offboard due to {parameter} Error")
def account_onboarding_for_error(context, ucas_provider, parameter):
    market_code = "VFPT" if parameter == "Technical" else "VFIT"
    del context.market_code
    if ucas_provider == 'TPM':
        tpm_account_not_onboarded_in_snow(context, True, market_code)
    elif ucas_provider == 'MSOC':
        msoc_account_not_onboarded_in_snow(context, True, market_code)


@then("the cease request to SNOW fails with error")
def account_failed_to_cease(context):
    database.get_service_order_operation(context.service_order_id, 'SNOW_OFFBOARDING')
    CeaseTPMHandler.tpm_customer_is_ceased_successfully(context, True) if context.ucas_provider == 'TPM' else \
        CeaseMSOCHandler.cease_msoc_customer_for_market(context, context.market_code, True)
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_delete_snowcustomer')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_delete_snowcustomer()
    common.update_middleware_correlation_id(context)
    payload_validation_snow_customer_deleted(context, 'system_error')
    snow.check_snow_onboarding_state('ACTIVE', context.op_co_customer_id)
    context.account_deprovisioned = False
    context.snow_offboarding = False
    TpmHandler.validate_service_order_tpm(context, 'inProgress') if context.ucas_provider == 'TPM' else \
        validationHandler.validates_msoc_customer_or_number_status(context, 'inProgress')


@when("a {ucas_provider} Account is already ceased in SNOW")
def account_is_already_ceased(context, ucas_provider):
    if ucas_provider == 'TPM':
        context.tpm_account = TPMAccount(market_code='VFDE')
        context.tpm_account.op_co_customer_id = account.EXISTING_TPM_CUSTOMER['ceased_account_number']

    elif ucas_provider == 'MSOC':
        context.msoc_account = MSOCAccount(market_code='VFDE')
        context.msoc_account.op_co_customer_id = account.EXISTING_MSOC_CUSTOMER['ceased_account_number']


@given('a new MSOC Account is onboarded without SNOW')
def msoc_account_not_onboarded_in_snow(context, enable_provisioning=False, market_code='VFDE'):
    customer_with_snow_and_add_ddis(context, enable_provisioning, market_code)
    context.snow_onboarding_validated = True
    logger.info('account is onboarded')
    MSOCHandler.validate_msoc_numbers_request(context, 'add')
    snow_onboarding_not_processed(context)


@when('a service order is sent to cease the account')
def cease_account_order_is_sent(context):
    find_opco_customer_id(context)
    CeaseTPMHandler.tpm_cease_customer_ordered(context, context.market_code) if context.ucas_provider == 'TPM' else \
        CeaseMSOCHandler.msoc_cease_customer_ordered(context, context.market_code)
    flowHandler.customer_sends_an_order_to_middleware(context)
    if hasattr(context, "created_jira_ticket_keys"):
        del context.created_jira_ticket_keys


@given('TPM account is already ceased in SNOW')
def already_ceased_in_snow(context):
    tpm_account_is_already_onboarded_to_snow(context)
    cease_account_order_is_sent(context)
    account_ceased_successfully_in_snow(context)


@when('a service order is sent to recreate the same account')
def recreate_ceased_account_in_snow(context):
    tpm_customer_with_snow_onboarding_details_and_add_numbers_are_requested_in_same_order(context)


@then('the SNOW on-boarding request for the account is successfully completed')
def recreate_ceased_account_in_snow(context):
    add_numbers_are_processed_in_middleware(context, "sent")
    tpm_snow_onboarding_is_processed_in_middleware(context)
