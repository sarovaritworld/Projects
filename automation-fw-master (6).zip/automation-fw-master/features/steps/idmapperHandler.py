import json
import logging

from behave import *

from classes import asserts, common, data, data_files, database, polling, read_xmldata
from classes.api.requests import idmapper
from classes.api.validations import APIResponseValidationSet
from classes.database import get_unity_accounts_count
from classes.status_code_validator import StatusCodeValidator
from features.steps import databaseHandler, kafkaHandler


@given("a '{type_of_ID}' Ringcentral_ID provided to service")
def validate_rc_id_provided(context, type_of_ID):
    if "valid" in type_of_ID:
        context.idmapper_rc_id = context.RC_ID
    elif "blank" in type_of_ID:
        context.idmapper_rc_id = ""
    elif "Wrong" in type_of_ID:
        context.idmapper_rc_id = "abcd"
    else:
        raise NotImplementedError(f"{type_of_ID=}")


@given("a '{type_of_ID}' Vodafone_ID provided to service")
def validate_vf_id_provided(context, type_of_ID):
    if "valid" in type_of_ID:
        context.idmapper_vf_id = context.op_co_customer_id
    elif "blank" in type_of_ID:
        context.idmapper_vf_id = ""
    elif "Wrong" in type_of_ID:
        context.idmapper_vf_id = "abcd"
    else:
        raise NotImplementedError(f"{type_of_ID=}")


# And the ID mapping API is accessible with Ringcentral_ID
@then("the ID mapping API is accessible with Ringcentral_ID")
def validate_rc_id_mapping_api_available(context):
    # We previously sent a 'create account' kafka message
    timeout = data_files.read_config("common.yml", "timeouts.kafka_timer")

    client = idmapper.Client(token=context.access_token)

    account = polling.wait_until(
        lambda: client.get_account(context.idmapper_rc_id),
        "an account with this Ringcentral ID exists",
        stop_when=lambda account: account.exists,
        raises=False,  # on timeout, do not raise an exception (keep the last 404)
        timeout=timeout)
    context.getresponse1 = account.response


# And the ID mapping API is accessible with Vodafone_ID
@when("the ID mapping API is accessible with Vodafone_ID")
def validate_vf_id_mapping_api_available(context):
    # We previously sent a 'create account' kafka message
    timeout = data_files.read_config("common.yml", "timeouts.kafka_timer")

    client = idmapper.Client(context.idmapper_vf_id, market_code=context.market_code, token=context.access_token)

    account = polling.wait_until(
        lambda: client.get_account(),
        "an account with this Vodafone ID exists",
        stop_when=lambda account: account.exists,
        raises=False,  # on timeout, do not raise an exception (keep the last 404)
        timeout=timeout)
    context.getresponse2 = account.response


@then("reply with a '{expected_code}' response for '{endpoint_to_test}'")
def response_with_code_for_endpoint(context, expected_code, endpoint_to_test):
    if endpoint_to_test == "Ringcentral_ID":
        current_code = context.getresponse1.status_code
    elif endpoint_to_test == "Vodafone_ID":
        current_code = context.getresponse2.status_code
    elif endpoint_to_test == "create sub-account":
        current_code = context.post_handler_response.status_code
    elif endpoint_to_test == "get user details":
        current_code = context.get_handler_response.status_code
    elif endpoint_to_test == "delete user account":
        current_code = context.delete_handler_response.status_code
    else:
        raise IdMapperHandlerException(f"endpoint_to_test '{endpoint_to_test}' not found in endpoint_dict")
    StatusCodeValidator.reply_with_status_response_for_endpoint_to_test(current_code, expected_code)


@then('respond with a valid Vodafone_ID')
def response_with_valid_vf_id(context):
    # expected_id = read_xmldata.readxml("VF_ID_Value", "test_inputdata", "ID_Mapping")
    expected_id = context.op_co_customer_id
    logging.debug(f"Expected Vodafone ID: {expected_id}")
    decodedresponse = context.getresponse1.content.decode('utf-8')
    jsonresponse = json.loads(decodedresponse)
    actual_id = jsonresponse["vodafone_id"]
    logging.info(f"Vodafone ID in response: {actual_id}")
    context.vodafone_account_id = actual_id
    assert expected_id in actual_id, "Response ID: {} and expected ID: {}".format(actual_id, expected_id)


@then("respond with a Ringcentral_ID '{RC_ID_Value}'")
def response_with_rc_id_value(context, RC_ID_Value):
    if "valid" in RC_ID_Value:
        expected_id = context.RC_ID
    else:
        expected_id = read_xmldata.readxml("RC_ID_Value", "test_inputdata", "ID_Mapping")
    decodedresponse = context.getresponse2.content.decode('utf-8')
    jsonresponse = json.loads(decodedresponse)
    actual_id = jsonresponse["ringcentral_id"]
    logging.info("Ringcentral_ID in response: {}".format(actual_id))
    assert expected_id in actual_id, "Response ID: {} and expected ID: {}".format(actual_id, expected_id)


@when("a '{request_type}' request is provided to create a sub-account")
def validate_request_type_for_sub_account_creation(context, request_type):
    market_code = read_xmldata.readxml("market", "test_inputdata", "appdirectinput")
    if 'valid_body_request' in request_type or 'only_vf_user_id' in request_type or 'only_rc_user_id' in request_type:
        # valid format: [regexp 0-9a-zA-Z_-]+
        context.vodafone_user_id = read_xmldata.vf_rc_user_id_generator()
        context.duplicated_vf_user_id = context.vodafone_user_id
        context.ringcentral_user_id = read_xmldata.vf_rc_user_id_generator()
        context.duplicated_rc_user_id = context.ringcentral_user_id
        # Validate the rcUserId to have it in a good way:
        context.ringcentral_user_id = asserts.validate_and_fix_ringcentral_user_id(context.ringcentral_user_id)
        context.duplicated_rc_user_id = context.ringcentral_user_id
        # re-check if these ids are in the correct format
        logging.debug(f"The current {context.ringcentral_user_id=} is in a valid format")
        logging.debug(f"The current {context.duplicated_rc_user_id=} is in a valid format")

    elif 'request_body_as_email_id' in request_type:
        # as part of new feature UN-37815 valid format includes '@/./-'
        context.vodafone_user_id = read_xmldata.gen_email()
        context.ringcentral_user_id = read_xmldata.vf_rc_user_id_generator()
    elif 'invalid_vf_user_id_format' in request_type:
        context.vodafone_user_id = read_xmldata.invalid_vf_rc_user_id_generator()
        context.ringcentral_user_id = read_xmldata.vf_rc_user_id_generator()
    elif 'invalid_rc_user_id_format' in request_type:
        context.vodafone_user_id = read_xmldata.vf_rc_user_id_generator()
        context.ringcentral_user_id = read_xmldata.invalid_vf_rc_user_id_generator()
    elif 'not_account' in request_type:
        # I'll use the default user_ids but changing the post url
        context.vodafone_account_id = read_xmldata.gen_RCID()
        market_code = 'VF_UNKNOWN'
    elif 'duplicated_vf_user_id' in request_type:
        context.vodafone_user_id = context.duplicated_vf_user_id
        context.ringcentral_user_id = read_xmldata.vf_rc_user_id_generator()
        # Validate the rcUserId to have it in a good way:
        context.ringcentral_user_id = asserts.validate_and_fix_ringcentral_user_id(context.ringcentral_user_id)
        # re-check if these ids are in the correct format
        logging.debug(f"The current {context.ringcentral_user_id=} is in a valid format")
    elif 'duplicated_rc_user_id' in request_type:
        context.vodafone_user_id = read_xmldata.vf_rc_user_id_generator()
        context.ringcentral_user_id = context.duplicated_rc_user_id
    elif 'blank_market' in request_type:
        context.vodafone_account_id = read_xmldata.gen_RCID()
        market_code = ''
    elif 'blank_vf_user_id' in request_type:
        context.vodafone_user_id = ''
        context.ringcentral_user_id = read_xmldata.vf_rc_user_id_generator()
    elif 'blank_rc_user_id' in request_type:
        context.vodafone_user_id = read_xmldata.vf_rc_user_id_generator()
        context.ringcentral_user_id = ''
    else:
        raise NotImplementedError

    client = idmapper.Client(context.vodafone_account_id, market_code, token=context.access_token)
    context.sub_account_bodyrequest = client.create_user_default_payload()

    try:
        context.sub_account_bodyrequest["vodafone_user_id"] = context.vodafone_user_id
        context.sub_account_bodyrequest["ringcentral_user_id"] = context.ringcentral_user_id

        if 'only_vf_user_id' in request_type:
            del context.sub_account_bodyrequest["ringcentral_user_id"]
        elif 'only_rc_user_id' in request_type:
            del context.sub_account_bodyrequest["vodafone_user_id"]

    except Exception:
        if 'not_account' in request_type or 'blank_market' in request_type:
            logging.info("Using defaults  user ids")
            logging.info(" ")
        else:
            logging.error("Exception assigning user id")
            raise

    context.post_handler_response = client.create_user(context.sub_account_bodyrequest)

    try:
        logging.info(f'Response: ')
        logging.info(json.dumps(json.loads(context.post_handler_response.content), indent=3))
    except ValueError:
        logging.info(f'No body response.')
    except Exception as ex:
        logging.error(context.post_handler_response)
        logging.error("Exception " + str(ex))


@then("user ids are '{action}' DB")
def process_user_ids_in_db_with_action(context, action):
    try:
        logging.info(f"Searching user account details")
        document = database.get_rc_user_id(context.vodafone_user_id)
        if document is not None:
            logging.debug(f"User document: {list(document)}")
            logging.info(f'User document: {database.parse_json(document)}')
            ringcentral_user_id = document['ringcentralUserId']
            vodafone_user_id = document['vodafoneUserId']
            if 'saved in' in action:
                asserts.field_equals(ringcentral_user_id, context.ringcentral_user_id, 'ringcentralUserId')
                asserts.field_equals(vodafone_user_id, context.vodafone_user_id, 'vodafoneUserId')
            elif 'deleted from' in action:
                logging.error("User account details have not been deleted from database.")
                raise AssertionError("User account details have not been deleted from database.")
            logging.info('')
        else:
            if 'saved in' in action:
                logging.error("User account details have not been saved in database.")
                raise AssertionError("User account details have not been saved in database.")
            elif 'deleted from' in action:
                logging.info(f"There are not users details related to vodafoneUserId: {context.vodafone_user_id}")
            logging.info('')
    except Exception:
        logging.error(f"Exception while searching ids in DB")
        raise


@given("an user account already created")
def user_account_already_exists(context):
    context.execute_steps("""
    When a 'valid_body_request' request is provided to create a sub-account
    Then reply with a '201' response for 'create sub-account'
      And user ids are 'saved in' DB
    """)


@then("user can retrieve an User entity sub-account details")
@then("user can retrieve an User entity sub-account details for '{request_type}'")
def validate_retrieve_user_sub_account_details(context, request_type='valid'):
    # Retrieves a User entity and its parent account details based on a User's market, Vodafone ID and Vodafone User ID.
    vodafone_account_id = context.vodafone_account_id
    vodafone_user_id = context.vodafone_user_id
    market_code = read_xmldata.readxml("market", "test_inputdata", "appdirectinput")

    if 'blank_market' in request_type:
        market_code = ''
    elif 'not_existing_vf_user_id' in request_type:
        vodafone_user_id = read_xmldata.vf_rc_user_id_generator()
    elif 'not_existing_vf_account_id' in request_type:
        vodafone_account_id = read_xmldata.gen_RCID()
    elif 'invalid_vf_user_id_format' in request_type:
        vodafone_user_id = read_xmldata.invalid_vf_rc_user_id_generator()
        logging.debug(f"Invalid format vodafone_user_id:{vodafone_user_id}")

    client = idmapper.Client(vodafone_account_id, market_code, token=context.access_token)
    context.get_handler_response = client.get_user(vodafone_user_id)

    try:
        logging.info(f'Response: {context.get_handler_response.status_code}')
        logging.info(json.dumps(json.loads(context.get_handler_response.content), indent=3))
    except ValueError:
        logging.info(f'No body response.')
    except Exception as ex:
        logging.error(context.get_handler_response)
        logging.error("Exception " + str(ex))
        raise ex


@when("user deletes an existing sub-account")
@when("user try to delete an '{request_type}' User entity sub-account")
def delete_existing_sub_account(context, request_type='valid'):
    # Retrieves a User entity and its parent account details based on a User's market, Vodafone ID and Vodafone User ID.
    vodafone_account_id = context.vodafone_account_id
    vodafone_user_id = context.vodafone_user_id
    market_code = read_xmldata.readxml("market", "test_inputdata", "appdirectinput")

    if 'not_existing_market' in request_type:
        market_code = 'VF_UNKNOWN'
    elif 'not_existing_vf_user_id' in request_type:
        vodafone_user_id = read_xmldata.vf_rc_user_id_generator()
    elif 'not_existing_vf_account_id' in request_type:
        vodafone_account_id = read_xmldata.gen_RCID()
    elif 'invalid_vf_user_id_format' in request_type:
        vodafone_user_id = read_xmldata.invalid_vf_rc_user_id_generator()
        logging.debug(f"Invalid format vodafone_user_id:{vodafone_user_id}")

    client = idmapper.Client(vodafone_account_id, market_code, token=context.access_token)
    context.delete_handler_response = client.delete_user(vodafone_user_id)
    logging.info(f'Response: {context.delete_handler_response.status_code}')


@given('RC_ID saved to the context')
def validate_save_rc_id_to_context(context):
    context.execute_steps("""
                    Given it contains a 'valid' JWT Token
                    And a 'valid' Vodafone_ID provided to service
                    When the ID mapping API is accessible with Vodafone_ID
                """)
    logging.info(f'{context.getresponse2=}')
    response = data.get_decoded_response(context.getresponse2)
    try:
        context.RC_ID = response["ringcentral_id"]
    except KeyError:
        logging.error(f'ringcentral id is not available in the {response.text=}')
        raise


@given("MSOC account has been created")
def validate_msoc_account_creation(context, with_snow_onboarding=None):
    kafkaHandler.payload_created_for_topic(context, 'tmfmediator_command_create_msoccustomer')
    kafkaHandler.payload_is_sent_for_kafka_topic(context, 'tmfmediator_command_create_msoccustomer')
    databaseHandler.bgid_is_stored_in_database(context)
    kafkaHandler.get_messages(context, 'idmapper_event_msoccustomer_created')
    kafkaHandler.validate_topic(context, 'idmapper_event_msoccustomer_created')


# And MSOC account is looked up by the '<search_property>' and '<search_property2>' with '<value>'
@when("MSOC account is looked up by the '{search_property}' and '{search_property2}' with '{value}'")
@when("MSOC account is looked up by '{search_property}'")
def lookup_msoc_account_by_properties(context, search_property, search_property2=None, value=None):
    context.include_all_data = search_property2 == "include_all_data" and value == "true"
    if 'VF_ID' in search_property and search_property2 and value:
        param = {'market': 'VFUK', 'vodafone_account_id': context.op_co_customer_id, search_property2: value}
    elif 'bgid' in search_property and search_property2 and value:
        param = {'bgid': context.bgid, search_property2: value}
    elif 'BGID' in search_property:
        param = {'bgid': context.bgid}
    elif 'invalid_bgid' in search_property:
        context.bgid = 'invalid_bgid'
        param = {'bgid': context.bgid}
    elif 'VF_ID' in search_property:
        param = {'market': context.market_code, 'vodafone_account_id': context.op_co_customer_id}
    elif 'non_existing_account_bgid' in search_property:
        context.bgid = '1234567890'
        param = {'bgid': context.bgid}
    elif 'missing_market' in search_property:
        context.op_co_customer_id = "VF1234"
        param = {'vodafone_account_id': context.op_co_customer_id}
    elif 'invalid_market' in search_property:
        context.market_code = 'AA'
        context.op_co_customer_id = "VF1234"
        param = {'market': context.market_code, 'vodafone_account_id': context.op_co_customer_id}
    elif 'missing_vodafone_account_id' in search_property:
        context.market_code = "VFUK"
        param = {'market': context.market_code}
    else:
        raise NotImplementedError(f"{search_property=} MSOC account looked up")
    logging.info(f"Params: {param}")
    context.response = idmapper.Client().get_msoc_account(param)


@then("MSOC account information is correct")
def validate_msoc_account_information_correct(context):
    expected_account = {
        'market': context.market_code,
        'vodafone_id': context.op_co_customer_id,
        'msoc_bgid': context.bgid,
        'name': context.customer_name
    }

    message = context.response.json()

    for field_name, expected in expected_account.items():
        actual = common.get_field(message, field_name)
        asserts.field_equals(actual, expected, field_name)


@when("a look up request is sent to ID Mapper by '{value}'")
@when("a look up request is sent to ID Mapper with {value}")
def look_up_for_tpm_customer(context, value):
    match value:
        case 'BGID':
            param = {'bgid': context.tpm_account.bgid}
        case 'market_customerID':
            param = {'market': context.tpm_account.market_code,
                     'vodafone_customer_id': context.tpm_account.op_co_customer_id}
        case 'invalid_Market':
            param = {'market': 'ABCD', 'vodafone_customer_id': '88820116994'}
        case 'invalid_CustomerID':
            param = {'market': 'VFUK', 'vodafone_customer_id': 'VF123456'}
        case 'invalid_BGID':
            param = {'bgid': '1234567890'}
        case 'invalid_bgid_QueryParameter':
            param = {'void': '1000'}
        case 'invalid_QueryParameter':
            param = {'mrket': 'VFUK', 'vodafone_customer_id': 'VF123456'}
        case _:
            raise NotImplementedError(f'Query parameter is not provided')
    context.response = idmapper.Client().get_tpm_customer(param)


@then("id-mapper sends '{status_code}' response and TPM account information")
def validate_response_and_account_information(context, status_code):
    StatusCodeValidator.validate_status_code_response(context.response.status_code, status_code)
    actual_response = context.response.json()
    logging.info(f"Response: {actual_response}")
    validation_set = APIResponseValidationSet(context).get_tpm_customer_validation_set()
    common.validate_message(actual_response, validation_set)


# And user attempts to retrieve number of unity accounts specific to 'VFUK'
@given("user attempts to retrieve number of unity accounts specific to '{market}'")
def retrieve_market_unity_account_quantity(context, market):
    if 'blank_market' in market:
        param = None
    elif 'invalid_market' in market:
        param = {'market': 'AA'}
    else:
        context.market_code = market
        param = {'market': context.market_code}
    context.response = idmapper.Client().get_unity_accounts(param)


# And the number of accounts specific to market are retrieved and validated
@then("the number of accounts specific to market are retrieved and validated")
def validate_market_account_number_quantity(context):
    if hasattr(context, "page"):
        asserts.equals(context.response.json()["paging"]["page"], int(context.page), 'page')
        asserts.equals(context.response.json()["paging"]["perPage"], int(context.per_page), 'perPage')

    context.unity_accounts_count = get_unity_accounts_count(context.market_code)

    logging.info(f"{context.response.json()['paging']['totalElements']=}")
    asserts.equals(context.response.json()["paging"]["totalElements"], context.unity_accounts_count,
                   'Total unity accounts')


# And user attempts to retrieve the number of unity accounts specific to '<market>' '<page>' and '<per_page>'
@given("user attempts to retrieve the number of unity accounts specific to '{market}' '{page}' and '{per_page}'")
def retrieve_market_account_quantity_for_page(context, market, page, per_page):
    context.market_code = market
    context.page = page
    context.per_page = per_page
    param = {'market': context.market_code, 'page': context.page, 'perPage': context.per_page}
    context.response = idmapper.Client().get_unity_accounts(param)


# And extended MSOC account information is validated
@then("extended MSOC account information is validated")
def validate_extended_msoc_account_information(context):
    validation_set = APIResponseValidationSet(context).get_msoc_account_customer_info()
    context.response = context.response.json()
    logging.info(json.dumps(context.response, indent=3))
    logging.info('')
    common.validate_message(context.response, validation_set)


class IdMapperHandlerException(Exception):
    def __init__(self, message):
        super().__init__(message)
