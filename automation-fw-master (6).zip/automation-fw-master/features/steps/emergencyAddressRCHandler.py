import logging

from behave import given, when, then

from classes import common, database, read_xmldata, utils
from classes.kafka import consumer_data, producer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from common_python.stub_accounts.stub_accounts import StubAccounts
from features.steps import TMFHandler, kafkaHandler, flowHandler, validationHandler, CRFHandler


@then("Emergency address is added in RC")
def emergency_address_added_in_rc(context):
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    flowHandler.account_is_created(context)
    database.get_service_order_operation(context.service_order_id, 'SET_EMERGENCY_ADDRESS')
    tmfmediator_command_set_emergencyaddress_topic_is_validated(context)
    ringcentral_event_emergencyaddress_set_is_validated(context, invalid_data=None)


@given("Add Unity account service order is created with '{error_type}'")
def request_for_add_unity_account_updated_for_error(context, error_type: str):
    TMFHandler.create_payload_add_unity_account(context,None, 'FULL_STACK_STANDARD', 'VFUK')
    rc_accounts = StubAccounts()
    if error_type == 'unity_invalid_data':
        context.payload['externalReference'][0][
            'id'] = context.op_co_customer_id = f"{rc_accounts.rc.emergency_bad_req_prefix}_{read_xmldata.gen_opco(marketplace='TMF')}"
    else:
        context.payload['externalReference'][0][
            'id'] = context.op_co_customer_id = f"{rc_accounts.rc.emergency_server_error_prefix}_{read_xmldata.gen_opco(marketplace='TMF')}"
    logging.info(f"Request Payload is : {context.payload}")


@then("Unity account has been successfully onboarded")
def unity_account_successfully_onboarded(context):
    flowHandler.main_number_is_added(context)
    CRFHandler.processed_crf_number(context)
    TMFHandler.account_is_created_successfully(context)
    TMFHandler.validate_final_state(context, 'completed')


@then("Unable to add emergency address in RC due to {error_type}")
def unable_to_add_emergency_address_in_rc(context, error_type: str):
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    flowHandler.account_is_created(context)
    database.get_service_order_operation(context.service_order_id, 'SET_EMERGENCY_ADDRESS')
    tmfmediator_command_set_emergencyaddress_topic_is_validated(context)
    ringcentral_event_emergencyaddress_set_is_validated(context, invalid_data=error_type)


@then("Unity account onboarding has failed")
def unity_account_onboarding_failed(context):
    flowHandler.main_number_is_added(context)
    validationHandler.validate_order_status(context, 'inProgress')


@then("tmfmediator_command_set_emergencyaddress topic is validated")
def tmfmediator_command_set_emergencyaddress_topic_is_validated(context):
    topic = 'tmfmediator_command_set_emergencyaddress'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).tmfmediator_command_set_emergencyaddress()


@then("data is validated in ringcentral_event_emergencyaddress_set for {invalid_data}")
def ringcentral_event_emergencyaddress_set_is_validated(context, invalid_data=None):
    topic = 'ringcentral_event_emergencyaddress_set'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).ringcentral_event_emergencyaddress_set(invalid_data)


@when("kafka message for topic tmfmediator_command_set_emergencyaddress is sent with {parameter}")
def payload_for_tmfmediator_command_set_emergencyaddress_topic(context, parameter):
    topic_name = "tmfmediator_command_set_emergencyaddress"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.event_type = context.payload["header"]["event_type"]
    context.marketplace_event_id = context.payload["emergency_address_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.operation_id = context.payload["emergency_address_request"]["client_reference"][
        "operation_id"] = read_xmldata.gen_uuid()
    context.RC_ID = context.payload["emergency_address_request"]["ucas_account_id"]

    path = 'emergency_address_request.company.location.emergency_address.'

    replace_data = {
        'street': f'{path}.[{parameter}]',
        'city': f'{path}.[{parameter}]',
        'zip': f'{path}.[{parameter}]'
         }
    common.create_or_update_key(context.payload, replace_data[parameter], "")
    logging.info(f"Updated request payload is : {utils.to_json(context.payload)}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)


@given("payload is updated for {parameter}")
def unity_account_updated_for_invalid_parameter(context, parameter):
    value = ''
    path = 'serviceOrderItem.[0].service.place.[0]'

    replace_data = {
        'role': f'{path}.[{parameter}]',
        'city': f'{path}.[{parameter}]',
        'postcode': f'{path}.[{parameter}]',
        'streetName': f'{path}.[{parameter}]'
    }

    common.create_or_update_key(context.payload, replace_data[parameter], value)
    logging.info(f"Updated request payload is : {utils.to_json(context.payload)}")


@then("Unable to add emergency address in RC but add number succeeded")
def create_account_failed_rc(context):
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    flowHandler.account_is_created(context)
    database.get_service_order_operation(context.service_order_id, 'SET_EMERGENCY_ADDRESS')
    tmfmediator_command_set_emergencyaddress_topic_is_validated(context)
    ringcentral_event_emergencyaddress_set_is_validated(context, invalid_data='unity_invalid_data')
    flowHandler.main_number_is_added(context)
    CRFHandler.processed_crf_number(context)
    validationHandler.validate_order_status(context, 'inProgress')