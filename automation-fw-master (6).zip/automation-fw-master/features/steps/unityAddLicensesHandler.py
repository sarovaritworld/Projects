import logging

from classes import license
from classes import operations, read_xmldata
from classes.domain.account import UnityAccount
from classes.kafka import KafkaTopics
from classes.kafka import consumer_data, producer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.license import LicenseOrderItem
from classes.payload_generators.TMF.license_generator import LicensePayloadGenerator
from classes.payload_generators.TMF.payload_generator import Action
from classes.status_code_validator import StatusCodeValidator
from features.steps import kafkaHandler, validationHandler
from features.steps.TMFHandler import create_payload_add_unity_account, request_is_sent_to_create_service_order, \
    retrieve_and_validate, validate_final_state
from features.steps.accountHandler import create_account_prerequisite
from features.steps.flowHandler import given, initial_order_processsed_in_mw, then, when
from features.steps.sharedHandler import validate_status_response


@given("'{account_confirmation_status}' unity account is provisioned already")
def make_service_order_create_confirmed_unity_account_validate_success(context, account_confirmation_status):
    create_account_prerequisite(context, "FULL_STACK_STANDARD", "VFUK", account_confirmation_status)

    if 'unconfirmed' in getattr(context, 'confirmation_status', ''):
        del context.initial_license


@when("a service order is sent to '{action}' licenses to a non-existing account")
@when("a service order is sent to '{action}' '{licenses_count}' more licenses")
def request_order_for_license_count(context, action, licenses_count: int = 1, sku_id: str = 'LC_DL-UNL_50'):
    context.action = action
    if not hasattr(context, 'unity_account'):
        if not hasattr(context, 'op_co_customer_id'):
            context.unity_account = UnityAccount(market_code='VFUK')
        else:
            context.unity_account = UnityAccount(op_co_customer_id=context.op_co_customer_id, market_code='VFUK')
    context.unity_license = LicenseOrderItem(quantity=licenses_count, id=sku_id)
    context.payload = LicensePayloadGenerator(context.unity_account, getattr(Action, action),
                                              context.unity_license).to_dict()
    context.op_co_customer_id = context.unity_account.op_co_customer_id
    request_is_sent_to_create_service_order(context)


@when("a complex service order is sent to '{action}' a unity account and '{license_count}' more licenses")
def create_complex_service_order_with_license(context, action, license_count, sku_id: str = "LC_DL-UNL_50"):
    context.action = action
    create_payload_add_unity_account(context, 'create_service_order', 'FULL_STACK_STANDARD', 'VFUK')
    context.unity_license = LicenseOrderItem(quantity=license_count, id=sku_id)
    context.payload = LicensePayloadGenerator(context.unity_account, getattr(Action, action),
                                              context.unity_license,
                                              context.payload).to_dict()
    request_is_sent_to_create_service_order(context)


@given("an '{error}' account is provisioned already")
def fetch_failing_stub_account(context, error):
    match error:
        case "add_license_bad_request":
            context.RC_ID = "995757138"
            context.op_co_customer_id = "Account_does_not_exist_in_RC"
        case "add_license_server_error":
            context.op_co_customer_id = "Server_Not_found"
            context.RC_ID = "991923415"
        case "max_license_limit":
            context.op_co_customer_id = "NOK_Bad_Request"
            context.RC_ID = "990095274"
    context.unity_account = UnityAccount(op_co_customer_id=context.op_co_customer_id, market_code="VFUK")


@then("add license request fails with an '{error}'")
def licenses_addition_fails_with_error(context, error):
    licenses_addition_resolved(context, status_code=201, error=error)


@then("add license request have been failed with an error message '{error}'")
def add_license_fails_with_error_message(context, error):
    validationHandler.validate_order_status(context, 'failed')
    validationHandler.validate_error_message(context, error)


@then("the new licenses are successfully added to the account")
def licenses_addition_resolved(context, status_code=201, error: str = None):
    validate_status_response(context, status_code)
    retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    operations.validate_operations_order("ucc.unity.license", "add", context.service_order_id)
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_add_unitylicense.name)
    KafkaTopicValidator(context).tmfmediator_command_add_unitylicense()
    kafkaHandler.get_messages(context, KafkaTopics.ringcentral_event_unitylicense_added.name)
    KafkaTopicValidator(context).ringcentral_event_unitylicense_added(error)
    if error:
        if error in ('invalid_sku_id', 'max_license_limit'):
            # for invalid_request which means the operation state will be 'failed'
            add_license_fails_with_error_message(context, error)
        else:
            # for system error which means the operation is suspendable (final state 'inProgress')
            validationHandler.validate_order_status(context, 'inProgress')
    else:
        # for positive scenarios
        validate_final_state(context, 'completed')


@when("a service order is sent to '{action}' licenses with invalid SKU ID")
def invalid_sku_service_order(context, action):
    context.action = action
    invalid_service_order_licenses_addition(context, "invalid_SKU_ID", "LC_INVALID_123", action)


@when("a service order is sent to add licenses with invalid '{parameter}' with '{value}'")
def invalid_service_order_licenses_addition(context, parameter, value, action='add'):
    if not hasattr(context, 'unity_account'):
        op_co_customer_id = None if not hasattr(context, 'op_co_customer_id') else context.op_co_customer_id
        context.unity_account = UnityAccount(market_code='VFUK', op_co_customer_id=op_co_customer_id)
    context.unity_license = LicenseOrderItem()
    context.payload = LicensePayloadGenerator(context.unity_account, getattr(Action, action),
                                              context.unity_license).to_dict()
    license.modify_licenses_addition_payload(context.payload, parameter, value)
    request_is_sent_to_create_service_order(context)
    if parameter == "invalid_SKU_ID":
        context.unity_license.id = value


@then("validate the error response and error code")
def validate_response_error_msg_code(context):
    StatusCodeValidator.validate_status_code_response(context.response.status_code, 400)


@then("the account is successfully provisioned")
def account_is_created(context):
    retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    initial_order_processsed_in_mw(context)


@when("kafka message for topic tmfmediator_command_add_unitylicense is sent with {error}")
def payload_created_and_send_for_tmfmediator_command_add_unitylicense(context, error):
    topic_name = "tmfmediator_command_add_unitylicense"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.event_type = context.payload["header"]["event_type"]
    context.marketplace_event_id = context.payload["license_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.operation_id = context.payload["license_request"]["client_reference"][
        "operation_id"] = read_xmldata.gen_uuid()
    context.RC_ID = context.payload["license_request"]["ucas_account_id"]
    match error:
        case "blank_sku_id":
            context.sku_id = context.payload["license_request"]["order"]["sku_id"] = ""
        case "zero_quantity":
            context.quantity = context.payload["license_request"]["order"]["quantity"] = 0
    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)
    if not hasattr(context, 'unity_license'):
        order = context.payload["license_request"]["order"]
        context.unity_license = LicenseOrderItem(quantity=order["quantity"], id=order["sku_id"])


@then("data is validated in ringcentral_event_unitylicense_added with {error}")
def data_is_validated_in_ringcentral_event_unitylicense_added(context, error):
    topic = "ringcentral_event_unitylicense_added"
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).ringcentral_event_unitylicense_added(error)
