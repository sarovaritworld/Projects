import json
import logging
from datetime import datetime

from behave import *

from classes import (account, asserts, common, database, msoc_numbers, numbers, payload, polling, read_xmldata)
from classes.api.requests import ringcentral_gateway
from classes.common import config, create_or_update_key
from classes.exceptions import NotFoundError
from classes.kafka import consumer_data, producer_data, utils
from classes.kafka.msg_validation_set import KafkaMsgValidationSet
from classes.kafka.topic_validator import KafkaTopicValidator, ServiceOrderItemFilter
from classes.kafka.topics import Topic
from classes.utils import strtobool
from common_python.stub_accounts.stub_accounts import StubAccounts

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)

UK_TELEPHONE_CODE = read_xmldata.readxml("UK_ISD_CODE", "test_inputdata", "num_prov")
NUMBER_OF_DIGIT = read_xmldata.readxml("NUMBER_OF_DIGIT", "test_inputdata", "num_prov")


# Given user Creates a payload for topic "appdirect_create_changelicense"
# Given payload is created for topic 'appdirect_create_addonorder'
@given("payload is created for topic '{topic_name}'")
@given("payload is created for topic '{topic_name}' with '{listener}'")
def payload_created_for_topic(context, topic_name, listener=None, refresh_mci: bool = False, category="UNITY"):
    context.payload = read_xmldata.read_jsonfile(topic_name)
    if not hasattr(context, 'middleware_correlation_id') or refresh_mci:
        context.middleware_correlation_id = read_xmldata.gen_uuid()
    if hasattr(context, 'request_uuid'):
        context.payload['phone_numbers']['request_uuid'] = context.request_uuid
    context.payload['header']['event_id'] = read_xmldata.gen_uuid()
    context.payload['header']['middleware_correlation_id'] = context.middleware_correlation_id

    if "appdirect_create_changelicense" in topic_name:
        context.marketplaceEventID = read_xmldata.gen_uuid()
        read_xmldata.update_xml("marketplace_eventID_changelicense", context.marketplaceEventID)
        context.payload['change_license']['marketplace_event_id'] = context.marketplaceEventID
        context.payload['change_license']['marketplace_info']['ucas_account_id'] = "888831115"
        context.payload['change_license']['primary_contact_details']['email'] = context.email = read_xmldata.gen_email()
        context.payload['change_license']['primary_contact_details'][
            'contact_phone'] = context.mobile = numbers.generate_phone_number('VFUK')
        context.payload['change_license']['op_co_details'][
            'op_co_customer_id'] = context.op_co_customer_id = read_xmldata.gen_opco("Appdirect")
        context.payload['change_license']['order_details']['quantity'] = context.new_license = 4
        context.marketplaceBaseURL = config.appdirect_stub["url"]
        context.payload['change_license']['marketplace_info']['marketplace_base_url'] = context.marketplaceBaseURL
        context.skuID = "LC_DL-UNL_50"
        context.edition_type = "1136"
    elif "appdirect_create_addonorder" in topic_name:
        context.marketplaceEventID = read_xmldata.gen_uuid()
        read_xmldata.update_xml("marketplace_eventID_changelicense", context.marketplaceEventID)
        context.payload['order']['marketplace_event_id'] = context.marketplaceEventID
        context.payload['order']['ucas_account_id'] = "999765382"
        context.payload['order']['order_details']['quantity'] = context.quantity = 4
        context.marketplaceBaseURL = config.appdirect_stub["url"]
        context.payload['order']['marketplace_info']['marketplace_base_url'] = context.marketplaceBaseURL
        context.skuID = "LC_ALN_38"
        context.company_name = "Test Automation"
    elif "numbermanagement_command_complete_order" in topic_name:
        context.RC_ID = "666263059"
    elif "tmfmediator_command_set_ssoconfig" in topic_name:
        context.service_order_id = read_xmldata.gen_uuid()
        context.service_order_item_id = "1"
        context.idp_entity_id = context.payload['sso_config_request']['sso_config']['idp_entity_id']
        context.payload['sso_config_request']['client_reference'][
            'marketplace_event_id'] = f"{context.service_order_id}/{context.service_order_item_id}"
        context.payload['sso_config_request']['ucas_account_id'] = context.RC_ID = read_xmldata.gen_RCID()
    elif "tmfmediator_command_set_accountserviceinfo" in topic_name:
        context.service_order_id = read_xmldata.gen_uuid()
        context.service_order_item_id = "1"
        context.payload['setAccountServiceInfoRequest']['client_reference'][
            'marketplace_event_id'] = f"{context.service_order_id}/{context.service_order_item_id}"
        context.payload['setAccountServiceInfoRequest']['ucas_account_id'] = context.RC_ID = read_xmldata.gen_RCID()
        context.max_extension_length = context.payload['setAccountServiceInfoRequest']['limits'][
            'maxExtensionLimitLength']
    elif "tmfmediator_command_create_msoccustomer" in topic_name:
        context.service_order_id = read_xmldata.gen_uuid()
        context.service_order_item_id = "1"
        context.payload['msoc_customer_request']['client_reference'][
            'marketplace_event_id'] = f"{context.service_order_id}/{context.service_order_item_id}"
        context.payload['msoc_customer_request']['msoc_account']['op_co_details'][
            'op_co_customer_id'] = context.op_co_customer_id = read_xmldata.gen_opco()
        context.payload['msoc_customer_request']['msoc_account'][
            'ms_teams_tenant_id'] = context.ms_teams_tenant_id = "MS-" + read_xmldata.randomdigitnumber(111111, 999999)
        context.customer_name = context.payload['msoc_customer_request']['msoc_account']['name']
        context.city = context.payload['msoc_customer_request']['msoc_account']['hq_address']['city']
        context.postcode = context.payload['msoc_customer_request']['msoc_account']['hq_address']['zip']
        context.country_code = context.payload['msoc_customer_request']['msoc_account']['hq_address']['country']
        context.hq_street_full = context.payload['msoc_customer_request']['msoc_account']['hq_address']['street']
        context.consent_countries = context.payload['msoc_customer_request']['msoc_account']['consent_countries']
        context.customer_domains = context.payload['msoc_customer_request']['msoc_account']['customer_domains']
        context.first_name = context.payload['msoc_customer_request']['msoc_account']['contact']['first_name']
        context.last_name = context.payload['msoc_customer_request']['msoc_account']['contact']['last_name']
        context.email = context.payload['msoc_customer_request']['msoc_account']['contact']['email']
        context.payload['msoc_customer_request']['msoc_account']['contact'][
            'phone_number'] = context.phone_number = "+" + read_xmldata.gen_contact(12)

    elif "tmfmediator_command_add_msoccountrybilling" in topic_name:
        context.service_order_id = read_xmldata.gen_uuid()
        context.service_order_item_id = "1"
        if not hasattr(context, "op_co_customer_id"):
            context.payload['msoc_customer_request']['msoc_account']['op_co_details'][
                'op_co_customer_id'] = context.op_co_customer_id = read_xmldata.gen_opco()
        context.payload['msoc_customer_request']['client_reference'][
            'marketplace_event_id'] = f"{context.service_order_id}/{context.service_order_item_id}"
        context.name = context.payload['msoc_customer_request']['msoc_account']['op_co_details']['name']
        context.payload['msoc_customer_request']['msoc_account']['op_co_details'][
            'op_co_customer_id'] = context.op_co_customer_id
        context.country = context.payload['msoc_customer_request']['msoc_account']['billing_information']['country']
        if hasattr(context, "service_identifier") and hasattr(context, "customer_reference_number"):
            context.existing_service_identifier = context.service_identifier
            context.existing_customer_reference_number = context.customer_reference_number
        context.service_identifier = context.payload['msoc_customer_request']['msoc_account']['billing_information'][
            'service_identifier'] = "SI-" + read_xmldata.gen_contact(5)
        context.customer_reference_number = \
            context.payload['msoc_customer_request']['msoc_account']['billing_information'][
                'customer_reference_number'] = "CRN-" + read_xmldata.gen_contact(5)
        context.country_code = common.get_field(context.payload,
                                                'msoc_customer_request.msoc_account.billing_information.country')

    elif "support_command_retry_tmf_notification" in topic_name:
        query = {
            'event.serviceOrder.externalReference.id': context.op_co_customer_id,
            # focus on 1 type of notification (related to SOI)
            "description": {"$regex": "^Service Order Item state value changed"},
        }
        with database.open_database('automation-fw', 'tmf-notifications') as db:
            document = polling.wait_until(
                lambda: db.collection.find_one(query), 'Notifications document from DB')
        context.notification_event_id = document['eventId']
        logging.info(f"Notification id is :: {context.notification_event_id}")

        context.payload["retry_tmf_notification"]["notification_event_id"][0] = context.notification_event_id
        context.payload["retry_tmf_notification"]["listener_id"][0] = context.subscription_id
        if listener == "without_listener":
            del context.payload["retry_tmf_notification"]["listener_id"]

    elif topic_name in ('tmfmediator_create_addnumbers', 'tmfmediator_create_deletenumbers'):
        action = "add_numbers" if topic_name == 'tmfmediator_create_addnumbers' else "delete_numbers"
        context.service_order_id = read_xmldata.gen_uuid()
        context.service_order_item_id = "1"
        context.payload[action][
            'marketplace_event_id'] = context.marketplace_event_id = f"{context.service_order_id}/{context.service_order_item_id}"
        context.payload[action]['op_co_details']["name"] = context.market_code
        context.payload[action]['op_co_details']["op_co_customer_id"] \
            = database.get_any_customer_id(category,
                                           context.market_code) if listener is None else read_xmldata.gen_opco()

        # default json payload stored in testdata is for Unity
        # we can either store 3 different json or tailor it here
        if category == "UNITY":
            context.payload[action]["ucas_provider"] = "RINGCENTRAL"
        elif category == "MSOC":
            # for MSOC key of pool of numbers is "msoc_pool"
            context.payload[action]["ucas_provider"] = "MSOC"
            context.payload[action]["msoc_pool"] = context.payload[action].pop("pool")
            del context.payload[action]["msoc_pool"]["site_id"]
        elif category == "TPM":
            # for TPM key of pool of numbers is "tpm_pool"
            context.payload[action]["ucas_provider"] = "TPM"
            context.payload[action]["tpm_pool"] = context.payload[action].pop("pool")
            context.payload[action]["tpm_pool"]["pool_type"] = "MOBILE"
            del context.payload[action]["tpm_pool"]["site_id"]

        context.op_co_customer_id = context.payload[action]['op_co_details']['op_co_customer_id']
        context.payload['header']['timestamp'] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        context.kafka_payload = context.payload

    elif "tmfmediator_create_msoc_addnumbers" in topic_name:
        context.service_order_id = read_xmldata.gen_uuid()
        context.service_order_item_id = "1"
        context.payload['add_numbers'][
            'marketplace_event_id'] = context.marketplace_event_id = f"{context.service_order_id}/{context.service_order_item_id}"
        context.op_co_customer_id = context.payload['add_numbers']['op_co_details']['op_co_customer_id']
        context.name = context.payload['add_numbers']['op_co_details']["name"]
        context.category = context.payload['add_numbers']['ucas_provider']
        context.payload['header']['timestamp'] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

    elif topic_name == "numbermanagement_command_delete_numbers":
        context.payload['header']['timestamp'] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        if hasattr(context, 'all_numbers'):
            context.payload['phone_numbers']['phone_number_details'] = [{"phone_number": x} for x in
                                                                        context.all_numbers]
        context.E164_LookupValue = [item['phone_number'] for item in
                                    context.payload['phone_numbers']['phone_number_details']]

    # TODO: same function as delete, but for add you can query and add up usage type for the payload.
    elif topic_name == "numbermanagement_command_add_numbers":
        context.payload['header']['timestamp'] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        if hasattr(context, 'all_numbers'):
            context.payload['phone_numbers']['phone_number_details'] = [
                {"phone_number": x, "usage_type": context.pool_type} for x in context.all_numbers]
        context.E164_LookupValue = [item['phone_number'] for item in
                                    context.payload['phone_numbers']['phone_number_details']]
    elif topic_name == 'numbermanagement_command_update_numbers':
        context.main_number_id = context.payload['phone_numbers']['phone_number_details'][0]['id']
    elif "idmapper_event_account_deleted" in topic_name:
        logging.info(f"payload is :: {context.payload}")
        context.service_order_item_id = "1"
        context.payload['delete_account']['op_co_details']['op_co_customer_id'] = context.op_co_customer_id
        context.payload['delete_account']['client_reference'][
            'marketplace_event_id'] = f"{context.service_order_id}/{context.service_order_item_id}"
        context.ucas_provider = context.payload["delete_account"]["ucas_provider"]
        context.market_code = context.payload['delete_account']['op_co_details']['name']
        context.marketplace = context.payload['delete_account']['client_reference']['marketplace']
    elif topic_name == "numbermanagement_command_delete_crfnumber":
        context.payload["crf_number_request"]["ucas_provider"] = context.ucas_provider
        context.payload["crf_number_request"]["op_co_details"]["name"] = context.market_code
        context.payload["crf_number_request"]["op_co_details"]["op_co_customer_id"] = context.op_co_customer_id
        context.payload["crf_number_request"]["pool"] = context.added_numbers
    elif topic_name == "numbermanagement_command_delete_all_crf_numbers":
        context.payload["delete_all_numbers"]["ucas_provider"] = context.ucas_provider
        context.payload["delete_all_numbers"]["op_co_details"]["name"] = context.market_code
        context.payload["delete_all_numbers"]["op_co_details"]["op_co_customer_id"] = context.op_co_customer_id
    else:
        logger.debug(f'There are no specific conditions for this topic: {topic_name}')


@given("user update main number '{main_number}' in the payload")
def update_payload_main_number(context, main_number):
    context.invalid_E164_Number = main_number
    invalid_number = {
        'with_space_before': ' +441159124544',
        'with_space_after': '+441159124544 ',
        'with_space_in-between': '+4411591 24544',
        'with_double_plus': '++441159124544'
    }
    context.payload['add_numbers']['main_number'] = invalid_number[main_number]


@given("user has a Create Account payload for topic '{topicname}' using '{marketplace}'")
def step_attacked_by(context, topicname, marketplace):
    if "ordermanagement_command_create_initialorder" in topicname and 'TMF' in marketplace:
        context.payload = read_xmldata.read_jsonfile("ordermanagement_command_create_initialorder_tmf")
        currenttime = datetime.now()
        dt_string = currenttime.strftime("%d%m%Y%H%M%S")
        context.email = "Automation" + dt_string + "@vodafone.com"
        context.payload["order"]['primary_contact_details']['email'] = context.email
        logger.info("Email: {}".format(context.email))
        logger.info(" ")
        context.mobile = "+1231" + read_xmldata.gen_contact()
        context.payload["order"]['primary_contact_details']['contact_phone'] = context.mobile
        context.middleware_correlation_id = read_xmldata.gen_uuid()
        context.payload["header"]['middleware_correlation_id'] = context.middleware_correlation_id
        context.marketplaceEventID = read_xmldata.gen_uuid() + "/" + read_xmldata.gen_uuid()
        context.payload["order"]['marketplace_event_id'] = context.marketplaceEventID
        context.op_co_customer_id = read_xmldata.gen_opco(marketplace="Appdirect")
        context.payload["order"]['op_co_details']['op_co_customer_id'] = context.op_co_customer_id
        context.marketplace = "TMF"
    elif "ordermanagement_event_account_created" in topicname and 'TMF' in marketplace:
        context.marketplace = "TMF"
        context.execute_steps(u"""
                Given user has a Create Account payload for topic '{topic_name}'
                """.format(topic_name=topicname))
        context.payload['account']['marketplace'] = context.marketplace
    else:
        assert "True" == "False", "No payload creation is available for this kafka {}".format(topicname)


@given("user has a Create Account payload for topic '{topicname}'")
def validate_create_account_payload_for_topic(context, topicname):
    context.payload = read_xmldata.read_jsonfile(topicname)
    if "ordermanagement_command_create_initialorder" in topicname:
        currenttime = datetime.now()
        dt_string = currenttime.strftime("%d%m%Y%H%M%S")
        context.email = "Automation" + dt_string + "@vodafone.com"
        context.payload["order"]['primary_contact_details']['email'] = context.email
        logger.info("Email: {}".format(context.email))
        logger.info(" ")
        context.mobile = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.payload["order"]['primary_contact_details']['contact_phone'] = context.mobile
        context.middleware_correlation_id = read_xmldata.gen_uuid()
        context.payload["header"]['middleware_correlation_id'] = context.middleware_correlation_id
        context.marketplaceEventID = read_xmldata.gen_uuid()
        context.payload["order"]['marketplace_event_id'] = context.marketplaceEventID
        context.externalAccountId = read_xmldata.gen_uuid()
        context.payload["order"]['marketplace_account_id'] = context.externalAccountId
        context.payload["order"]['op_co_details'][
            'op_co_customer_id'] = context.op_co_customer_id = read_xmldata.gen_opco(marketplace="Appdirect")
        context.marketplace = "APPDIRECT"
    elif "ringcentral_event_initialorder_created" in topicname:
        context.payload_RC_IO = read_xmldata.read_jsonfile("ringcentral_event_initialorder_created")
        context.RC_ID = "99" + read_xmldata.gen_contact(7)
        context.marketplaceEventID = read_xmldata.gen_uuid()
        context.payload_RC_IO['completed_order']['ucas_account_id'] = context.RC_ID
        context.payload_RC_IO['completed_order']['marketplace_event_id'] = context.marketplaceEventID
    elif "ordermanagement_complete_initialorder" in topicname:
        context.payload_acc_CI = read_xmldata.read_jsonfile("ordermanagement_complete_initialorder")
        context.payload_acc_CI['eventId'] = context.marketplaceEventID
        context.rcid = "99" + read_xmldata.gen_contact(7)
        context.payload_acc_CI['accountIdentifier'] = context.rcid
    elif "appdirect_create_initialorder" in topicname:
        context.payload = read_xmldata.read_jsonfile("appdirect_create_initialorder")
        currenttime = datetime.now()
        dt_string = currenttime.strftime("%d%m%Y%H%M%S")
        context.email = "Automation" + dt_string + "@vodafone.com"
        context.payload['order']['primary_contact_details']['email'] = context.email
        logger.info("Email :: {}".format(context.email))
        logger.info(" ")
        context.mobile = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        eventID = read_xmldata.gen_uuid()
        middlewareCorrelationID = read_xmldata.gen_uuid()
        marketplaceEventID = read_xmldata.gen_uuid()
        marketplaceAccountID = read_xmldata.gen_uuid()
        context.op_co_customer_id = read_xmldata.gen_opco(marketplace="Appdirect")
        context.payload['order']['primary_contact_details']['contact_phone'] = context.mobile
        context.payload['header']['event_id'] = eventID
        context.payload['order']['marketplace_event_id'] = marketplaceEventID
        context.payload['header']['middleware_correlation_id'] = middlewareCorrelationID
        context.payload['order']['marketplace_account_id'] = marketplaceAccountID
        context.payload['order']['op_co_details']['op_co_customer_id'] = context.op_co_customer_id
    elif "appdirect_create_changelicense" in topicname:
        context.RC_ID = "99" + read_xmldata.gen_contact(7)
        logger.info("context.RC_ID > " + context.RC_ID)
        logger.info(" ")
        context.payload = read_xmldata.read_jsonfile(topicname)
        eventID = read_xmldata.gen_uuid()
        middlewareCorrelationID = read_xmldata.gen_uuid()
        context.marketplaceEventID = read_xmldata.gen_uuid()
        currenttime = datetime.now()
        dt_string = currenttime.strftime("%d%m%Y%H%M%S")
        context.email = "Automation" + dt_string + "@vodafone.com"
        logger.info("Email: {}".format(context.email))
        logger.info(" ")
        context.mobile = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
        context.op_co_customer_id = read_xmldata.gen_opco(marketplace="Appdirect")
        context.payload['header']['event_id'] = eventID
        context.payload['change_license']['marketplace_event_id'] = context.marketplaceEventID
        context.payload['header']['middleware_correlation_id'] = middlewareCorrelationID
        context.payload['change_license']['marketplace_info']['ucas_account_id'] = context.RC_ID
        context.payload['change_license']['primary_contact_details']['email'] = context.email
        context.payload['change_license']['primary_contact_details']['contact_phone'] = context.mobile
        context.payload['change_license']['op_co_details']['op_co_customer_id'] = context.op_co_customer_id
        context.new_license = int(20)
        context.payload['change_license']['order_details']['quantity'] = context.new_license
        context.marketplaceBaseURL = config.appdirect_stub["url"]
        context.skuID = "LC_DL-UNL_50"
        context.edition_type = "1136"
    elif "appdirect_create_addonorder" in topicname:
        context.RC_ID = "99" + read_xmldata.gen_contact(7)
        logger.info("context.RC_ID > " + context.RC_ID)
        logger.info(" ")
        context.payload = read_xmldata.read_jsonfile(topicname)
        eventID = read_xmldata.gen_uuid()
        context.middleware_correlation_id = read_xmldata.gen_uuid()
        context.marketplaceEventID = read_xmldata.gen_uuid()
        context.payload['header']['event_id'] = eventID
        context.payload['order']['marketplace_event_id'] = context.marketplaceEventID
        context.payload['header']['middleware_correlation_id'] = context.middleware_correlation_id
        context.payload['order']['ucas_account_id'] = context.RC_ID
        context.quantity = int(20)
        context.payload['order']['order_details']['quantity'] = context.quantity
        context.skuID = "LC_DL-BAS_178"
        context.company_name = "Test Automation"
    elif "ordermanagement_event_account_created" in topicname:
        logger.info("==============Before json ============ ")
        context.payload = read_xmldata.read_jsonfile(topicname)
        logger.info("==============after json ============ ")
        context.event_id = read_xmldata.gen_uuid()
        context.middleware_correlation_id = read_xmldata.gen_uuid()
        context.marketplace_event_id = read_xmldata.gen_uuid()
        context.RC_ID = "99" + read_xmldata.gen_contact(7)
        context.op_co_customer_id = read_xmldata.gen_opco(marketplace="Appdirect")
        context.vodafone_account_id = context.op_co_customer_id
        context.market_code = read_xmldata.readxml("market", "test_inputdata", "appdirectinput")
        context.payload["header"]["event_id"] = context.event_id
        context.payload["header"]["middleware_correlation_id"] = context.middleware_correlation_id
        context.payload["account"]["marketplace_event_id"] = context.marketplace_event_id
        context.payload["account"]["ucas_account_id"] = context.RC_ID
        context.payload["account"]["op_co_details"]["op_co_customer_id"] = context.op_co_customer_id
        context.payload["account"]["op_co_details"]["name"] = context.market_code
        logger.info("Payload :" + json.dumps(context.payload, indent=3))
    elif "numbermanagement_command_complete_order" in topicname:
        context.payload = read_xmldata.read_jsonfile(topicname)
        context.RC_ID = "99" + read_xmldata.gen_contact(7)
        context.payload['header']['event_id'] = read_xmldata.gen_uuid()
        context.payload['header']['middleware_correlation_id'] = context.middleware_correlation_id
        context.payload["account"]["ucas_account_id"] = context.RC_ID
    elif "ordermanagement_event_order_completed" in topicname:
        context.payload = read_xmldata.read_jsonfile(topicname)
        context.payload["completed_order"]["marketplace_event_id"] = context.marketplaceEventID
        context.payload["header"]["middleware_correlation_id"] = context.middleware_correlation_id
    elif "ringcentral_event_accountstatus_updated" in topicname:
        context.payload = read_xmldata.read_jsonfile("ringcentral_event_accountstatus_updated_success")
        context.payload["account_status_changed"]["marketplace_event_id"] = context.marketplaceEventID
        context.payload["header"]["middleware_correlation_id"] = context.middleware_correlation_id
    else:
        raise NotImplementedError(f"No implementation for the {topicname=}")


@given("user creates a '{message_type}' payload for topic '{topicname}'")
def create_message_type_payload_for_topic(context, message_type, topicname):
    # upload different payloads
    context.payload = read_xmldata.read_jsonfile(topicname)
    if "addLicense_error" in message_type:
        context.payload = read_xmldata.read_jsonfile("ordermanagement_event_order_completed_addlicense_error")
    elif "error_message" in message_type:
        context.payload = read_xmldata.read_jsonfile("ordermanagement_event_order_completed_initial_error")
        context.RC_error_message = context.payload["completed_order"]["error"]["error_message"]
    elif "Success_Master_Device" in message_type:
        context.payload = read_xmldata.read_jsonfile("ordermanagement_event_order_completed_Success_master")

    context.service_order_id = context.marketplaceEventID = read_xmldata.gen_uuid()
    context.service_order_item_id = "1"
    context.marketplace_event_id = context.service_order_id + "/" + context.service_order_item_id
    context.middleware_correlation_id = read_xmldata.gen_uuid()
    context.payload["header"]["middleware_correlation_id"] = context.middleware_correlation_id
    if "ordermanagement_event_order_completed" in topicname:
        context.payload["completed_order"]["marketplace_event_id"] = context.marketplaceEventID
        context.payload["completed_order"]["account"]["marketplace_event_id"] = context.marketplaceEventID
        context.payload["completed_order"]["marketplace_info"]["marketplace_base_url"] = config.appdirect_stub["url"]
        context.RC_ID = read_xmldata.gen_RCID()
        context.payload["completed_order"]["ucas_account_id"] = context.RC_ID
        context.payload["completed_order"]["account"]["ucas_account_id"] = context.RC_ID
        context.payload["completed_order"]["account"]["op_co_details"][
            "op_co_customer_id"] = context.op_co_customer_id = read_xmldata.gen_opco(marketplace="Appdirect")
        if "Success_Master_Device" in message_type:
            context.MW_location_id = context.payload["completed_order"]["middleware_account_location_id"]
            context.payload["completed_order"]["ucas_account_id"] = ''
            context.payload["completed_order"]["account"]["ucas_account_id"] = ''
        elif "no_vfid" in message_type:
            context.payload["completed_order"]["account"]["op_co_details"]["op_co_customer_id"] = ""
        elif "no_opco" in message_type:
            context.payload["completed_order"]["account"]["op_co_details"]["name"] = ""
        elif "no_customer" in message_type:
            context.payload["completed_order"]["account"]["name"] = ""
        elif "incorrect_order_type" in message_type:
            context.payload["completed_order"]["order_type"] = "NOT_INITIAL_ORDER"
        elif "error_message" in message_type:
            context.payload["completed_order"]["ucas_account_id"] = ''
            context.payload["completed_order"]["account"]["ucas_account_id"] = ''
    elif "ordermanagement_create_deviceorder" in topicname:
        if "Success_Addon_Device" in message_type:
            context.payload["order"]["marketplace_event_id"] = context.marketplaceEventID
            context.payload["order"]["marketplace_info"]["marketplace_base_url"] = config.appdirect_stub["url"]
    elif "ordermanagement_create_changelicense" in topicname:
        context.payload["change_license"]["marketplace_event_id"] = context.marketplaceEventID
        context.payload["change_license"]["marketplace_info"]["marketplace_base_url"] = config.appdirect_stub["url"]

    elif "numbermanagement_command_add_numbers" in topicname:
        context.payload['header']['event_id'] = read_xmldata.gen_uuid()
        context.RC_ID = context.payload['phone_numbers']['ucas_account_id'] = ringcentral_gateway.td_ringcentral_id[
            "ok_nok_rc_id"]

    elif "tmfmediator_command_set_ssoconfig" in topicname:
        context.payload['sso_config_request']['client_reference']['marketplace_event_id'] = context.marketplace_event_id
        context.idp_entity_id = context.payload["sso_config_request"]["sso_config"]["idp_entity_id"]
        if message_type == "negative_scenario":
            context.payload["sso_config_request"]["ucas_account_id"] = ringcentral_gateway.td_ringcentral_id[
                "negative_rc_id"]
    elif "tmfmediator_command_set_accountserviceinfo" in topicname:
        context.payload['setAccountServiceInfoRequest']['client_reference'][
            'marketplace_event_id'] = context.marketplace_event_id
        context.max_extension_length = context.payload['setAccountServiceInfoRequest']['limits'][
            'maxExtensionLimitLength']
        if message_type == "negative_scenario":
            context.payload['setAccountServiceInfoRequest']['ucas_account_id'] = context.RC_ID = \
                ringcentral_gateway.td_ringcentral_id["negative_rc_id"]

    elif "tmfmediator_command_create_msoccustomer" in topicname:
        context.service_order_id = read_xmldata.gen_uuid()
        context.payload['msoc_customer_request']['msoc_account'][
            'ms_teams_tenant_id'] = payload.generate_msoc_tenantid()
        context.service_order_item_id = "1"
        context.customer_name = context.payload['msoc_customer_request']['msoc_account']['name']
        context.country_code = context.payload['msoc_customer_request']['msoc_account']['hq_address']['country']
        context.payload['msoc_customer_request']['client_reference'][
            'marketplace_event_id'] = f"{context.service_order_id}/{context.service_order_item_id}"
        context.payload['msoc_customer_request']['msoc_account']['op_co_details'][
            'op_co_customer_id'] = context.op_co_customer_id = read_xmldata.gen_opco()
        if message_type == "blank_account_id":
            context.payload['msoc_customer_request']['msoc_account']['op_co_details']['op_co_customer_id'] = ""
        if message_type == "blank_consent_countries":
            context.payload['msoc_customer_request']['msoc_account']['consent_countries'] = []

    elif "tmfmediator_command_delete_account" in topicname:
        context.payload['delete_account']['op_co_details']['op_co_customer_id'] = context.op_co_customer_id
        if "invalid" in message_type:
            context.payload['delete_account']['op_co_details'][
                'op_co_customer_id'] = context.op_co_customer_id = "88607374711"

        context.payload['delete_account']['client_reference'][
            'marketplace_event_id'] = f"{context.service_order_id}/{context.service_order_item_id}"
        context.ucas_provider = context.payload["delete_account"]["ucas_provider"]
        context.market_code = context.payload['delete_account']['op_co_details']['name']
        context.marketplace = context.payload['delete_account']['client_reference']['marketplace']

    elif "tmfmediator_command_add_msoccountrybilling" in topicname:
        context.country = context.payload['msoc_customer_request']['msoc_account']['billing_information']['country']
        context.service_identifier = context.payload['msoc_customer_request']['msoc_account']['billing_information'][
            'service_identifier']
        context.customer_reference_number = \
            context.payload['msoc_customer_request']['msoc_account']['billing_information'][
                'customer_reference_number']
        if message_type == "blank_service_identifier":
            context.service_identifier = \
                context.payload['msoc_customer_request']['msoc_account']['billing_information'][
                    'service_identifier'] = ""
        if message_type == "blank_customer_reference_number":
            context.customer_reference_number = \
                context.payload['msoc_customer_request']['msoc_account']['billing_information'][
                    'customer_reference_number'] = ''
        if message_type == "blank_country":
            context.country = context.payload['msoc_customer_request']['msoc_account']['billing_information'][
                'country'] = ''

    else:
        assert False, f"No payload creation is available for this kafka {topicname}"


@when("user has a Complete Order payload for topic '{topicname}'")
def validate_complete_order_payload_for_topic(context, topicname):
    if "numbermanagement_command_complete_order" in topicname:
        context.payload = read_xmldata.read_jsonfile("numbermanagement_command_complete_order")
        if not context.middleware_correlation_id:
            context.middleware_correlation_id = read_xmldata.gen_uuid()
        context.payload['header']['event_id'] = read_xmldata.gen_uuid()
        context.payload['header']['middleware_correlation_id'] = context.middleware_correlation_id
        context.payload["account"]["ucas_account_id"] = context.RC_ID
    else:
        assert False, "We are not creating any payload for this topic {}".format(context.topic)


# And payload is sent to Kafka Topic 'tmfmediator_command_create_initialorder'
# When payload is sent to Kafka Topic "ordermanagement_command_create_initialorder"
# When payload is sent to Kafka Topic "emailreceiver_event_received_email"
# When payload is sent to Kafka Topic 'numbermanagement_command_complete_order'
@when("payload is sent to Kafka Topic '{topicname}'")
def payload_is_sent_for_kafka_topic(context, topicname):
    logger.info(f"Payload for {topicname}:")
    logger.info(context.payload)

    context.kafka_send_message_response = producer_data.send_data(context.payload, topicname)


# And user retrieves Location ID  from 'ordermanagement_event_order_completed'
@then("user retrieves Location ID  from '{topicname}'")
def retrieve_location_id_from_topic(context, topicname):
    # TODO: step to be deleted as only used in Purchase Device
    try:
        context.MW_location_id = context.consumer_payload["completed_order"]["middleware_account_location_id"]
    except:
        raise Exception("Unable to retrieve Location ID")


# And user validates payload is present in 'ringcentral_event_initialorder_created'
# And user validates payload is present in 'ordermanagement_event_order_completed'
# And user validates payload is present in 'numbermanagement_command_complete_order'
@then("user validates payload is present in '{topicname}'")
def validate_payload_presence_in_topic(context, topicname):
    context.execute_steps(f"Then user can retrieve payload from '{topicname}'")


# And user retrieves error message from 'ringcentral_event_initialorder_created'
# Then user retrieves error message from 'ringcentral_event_initialorder_created'
@then("user retrieves error message from '{topicname}'")
def retrieve_error_message_from_topic(context, topicname):
    context.execute_steps(u"""
                      Then user can retrieve payload from '{topicname}'                        
                                                      """.format(topicname=topicname))

    if "ringcentral_event_initialorder_created" in topicname:
        logger.info("Ring Central Response: {}".format(json.dumps(context.consumer_payload, indent=3)))
        logger.info(" ")
        assert len(context.consumer_payload) > 0, "Payload is not present in kafka : {} ".format(
            topicname)
        try:
            context.RC_ID = context.consumer_payload["completed_order"]["account"]["ucas_account_id"]
        except KeyError:
            logger.info('payload might not have ucas_account_id')
        try:
            context.RC_status = context.consumer_payload["completed_order"]["status"]
        except KeyError:
            context.RC_status = False
            logger.info('status absense means false by default')
        try:
            context.RC_error_code = context.consumer_payload["completed_order"]["error"]["error_code"]
            context.RC_error_message = context.consumer_payload["completed_order"]["error"]["error_message"]
        except KeyError:
            raise Exception('keys RC_error_code and RC_error_message should be present in this case')
    elif "ringcentral_event_numbers_updated" in topicname:
        logger.info("Ring Central Response: {}".format(json.dumps(context.consumer_payload, indent=3)))
        logger.info(" ")
        assert len(context.consumer_payload) > 0, "Payload is not present in kafka : {} ".format(
            topicname)
        if len(context.consumer_payload["phone_numbers"]["phone_number_details"][0]["errors"]) > 0:
            context.RC_error_code = context.consumer_payload["phone_numbers"]["phone_number_details"][0]["errors"][0][
                "error_code"]
            context.RC_error_message = \
                context.consumer_payload["phone_numbers"]["phone_number_details"][0]["errors"][0]["error_message"]
            context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
        else:
            assert False, "Error Message does not added for update number"
    elif "ringcentral_event_numbers_added" in topicname:
        NOK_Add_Number_1 = read_xmldata.readxml("NOK_Add_Number_1", "RC_inputdata", "RC_errors")
        error_message_1 = f'errorCode:\"PRT-102\", message:\"{NOK_Add_Number_1}\"'
        validation = {"phone_numbers.phone_number_details.0.errors.0.error_code": "UCAS_PROVIDER_ERROR",
                      "phone_numbers.phone_number_details.0.phone_number": context.main_number,
                      "phone_numbers.phone_number_details.0.errors.0.error_message": error_message_1
                      }
        common.validate_message(context.consumer_payload, validation)
    else:
        assert False, "Invalid Topic Name"


@then("user retrieves payload from '{topicname}' by providing event id")
def retrieve_payload_from_topic_by_event_id(context, topicname):
    logger.info(f"Topic Name : {topicname}")
    if "appdirect_create_initialorder" in topicname:
        context.consumer_payload = consumer_data.received_data(topicname, context.marketplaceEventID)
        try:
            context.marketplaceEventID = context.consumer_payload["order"]["marketplace_event_id"]
            context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
            context.marketplaceAccountID = context.consumer_payload["order"]["marketplace_account_id"]
            context.oldmiddlewareCorrelationID = context.middleware_correlation_id
            context.op_co_billing_account_number = context.consumer_payload["order"]["op_co_details"][
                "op_co_billing_account_number"]
            context.op_co_billing_service_reference = context.consumer_payload["order"]["op_co_details"][
                "op_co_billing_service_reference"]
            context.op_co_order_reference = context.consumer_payload["order"]["op_co_details"][
                "op_co_order_reference"]
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    else:
        raise NotImplementedError(f"{topicname=} is not supported in this step")


# And user can retrieve payload from 'tmfmediator_command_create_initialorder'
# And user can retrieve payload from 'emailreceiver_event_received_email'
# And user can retrieve payload from 'ringcentral_event_initialorder_created'
# Then user can retrieve payload from 'ringcentral_event_initialorder_created'
# Then user can retrieve payload from 'ordermanagement_event_order_completed'
# Then user can retrieve payload from 'ordermanagement_command_update_accountstatus'

@then("user can retrieve payload from '{topicname}'")
def get_messages(context, topicname):
    if type(topicname) is Topic:
        topicname = topicname.name

    logger.info("Topic Name: {}".format(topicname))

    if common.skip_stub_actions(topicname):
        return

    topic_search_field = utils.get_search_field(context, topicname)

    if topicname in (
            "emailreceiver_event_received_email", "ordermanagement_command_create_initialorder",
            'tmfmediator_create_deletenumbers'):
        timeout_tag = "email_kafka_timer"
    else:
        timeout_tag = None  # Keep default (depending on environment)

    # Check for an indication on the expected number of messages
    multi_msg_min_count = None
    if filter_fct := ServiceOrderItemFilter(context).get_filter_fct(topicname):
        multi_msg_min_count = filter_fct(context.service_order).num_received_messages

    context.consumer_payload = consumer_data.received_data(
        topicname, topic_search_field, timeout_tag=timeout_tag,
        multi_msg_min_count=multi_msg_min_count)

    # saving data from payload
    if "appdirect_create_initialorder" in topicname:
        try:
            context.marketplaceEventID = context.consumer_payload["order"]["marketplace_event_id"]
            context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
            context.marketplaceAccountID = context.consumer_payload["order"]["marketplace_account_id"]
            context.oldmiddlewareCorrelationID = context.middleware_correlation_id
            context.op_co_billing_account_number = context.consumer_payload["order"]["op_co_details"][
                "op_co_billing_account_number"]
            context.op_co_billing_service_reference = context.consumer_payload["order"]["op_co_details"][
                "op_co_billing_service_reference"]
            context.op_co_order_reference = context.consumer_payload["order"]["op_co_details"][
                "op_co_order_reference"]
            context.marketplace = context.consumer_payload["order"]["marketplace"]
            logger.info(context.marketplace)
            logger.info("")
        except KeyError as ex:
            logger.info(ex)
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif "tmfgateway_process_serviceorder" in topicname:
        context.category = context.consumer_payload["tmfServiceOrder"]["category"]
        context.middleware_correlation_id = context.consumer_payload["header"]["middlewareCorrelationId"]
    elif "ringcentral_event_initialorder_created" in topicname:
        try:
            context.RC_ID = context.consumer_payload["completed_order"]["account"]["ucas_account_id"]
            context.RC_status = context.consumer_payload["completed_order"]["status"]
            context.ucas_provider = context.consumer_payload["completed_order"]["account"]["ucas_provider"]
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")
    elif "ordermanagement_create_changelicense" in topicname:
        try:
            context.marketplaceEventID = context.consumer_payload["change_license"]["marketplace_event_id"]
            context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif "tmfmediator_command_create_initialorder" in topicname:

        try:
            logger.debug(context.consumer_payload)
            context.tmfmediator_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
            context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
            context.marketplaceEventID = context.consumer_payload["order"]["marketplace_event_id"]
            context.marketplace = context.consumer_payload["order"]["marketplace"]
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif "numbermanagement_command_complete_order" in topicname:
        try:
            context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
            validation_set = KafkaMsgValidationSet(context).numbermanagement_command_complete_order()
            common.validate_message(context.consumer_payload, validation_set)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif "ordermanagement_command_update_accountstatus" in topicname:
        try:
            account_status = context.consumer_payload["account"]["account_status"]
            context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
            context.marketplaceEventID = context.consumer_payload["account"]["marketplace_event_id"]
            assert account_status == "CONFIRMED", "Account status {} is not matched".format(account_status)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif "ringcentral_event_accountstatus_updated" in topicname:
        try:
            if not context.consumer_payload["account_status_changed"]["request_successful"]:
                context.RC_account_status_error_code = context.consumer_payload["account_status_changed"]["error"][
                    "error_code"]
                context.RC_account_status_error_message = context.consumer_payload["account_status_changed"]["error"][
                    "error_message"]
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")
    elif "ordermanagement_event_order_completed" in topicname:
        try:
            marketplaceEventID = context.consumer_payload["completed_order"]["marketplace_event_id"]
            assert marketplaceEventID == context.marketplaceEventID, "marketplaceEventID {} is not matched".format(
                marketplaceEventID)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")
    elif "appdirect_create_shippingaddress" in topicname:
        context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
    elif "appdirect_create_addonorder" in topicname:
        context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
    elif "ordermanagement_create_deviceorder" in topicname:
        context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
    elif "numbermanagement_command_delete_numbers" in topicname:
        context.middleware_correlation_id = context.consumer_payload[-1]["header"]["middleware_correlation_id"]
    # TODO: check if common.update_middleware_correlation_id() can be used
    elif "numbermanagement_command_add_numbers" in topicname:
        context.middleware_correlation_id = context.consumer_payload[-1]["header"]["middleware_correlation_id"]
    elif "crfstub_process_resourceorder" in topicname:
        if not common.config.is_staging_env:
            context.crf_stub_payload = context.consumer_payload
    elif topicname == "emailreceiver_event_received_email":
        context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
    elif topicname == "tmfmediator_command_set_ssoconfig":
        context.sso_operation_id = context.consumer_payload["ssoConfigRequest"]["clientReference"]["operation_id"]
    elif topicname == "tmfmediator_command_set_accountserviceinfo":
        context.extension_operation_id = context.consumer_payload["setAccountServiceInfoRequest"]["clientReference"][
            "operation_id"]
    elif topicname == "tmfmediator_command_create_msoccustomer":
        if isinstance(context.consumer_payload, list):
            context.consumer_payload = context.consumer_payload[-1]
        context.operation_id = context.consumer_payload["msocCustomerRequest"]["clientReference"]["operation_id"]
    elif topicname == "jiraticketmediator_respond_jiraticket":
        logger.debug('this code should be invoked')
        if ("created_jira_ticket_keys" not in context
                or (hasattr(context, "msoc_service_order_type")
                    and context.msoc_service_order_type == "separate"
                    and msoc_numbers.has_add_msoc_numbers(context.payload))
                or msoc_numbers.has_delete_msoc_numbers(context.payload)):
            context.created_jira_ticket_keys = []
        context.created_jira_ticket_keys.extend([
            message["jiraTicketCreated"]["ticketKey"]
            for message in context.consumer_payload or ()
            if message["jiraTicketCreated"]["success"]])
        logging.info(f" JIRA Tickets :: {context.created_jira_ticket_keys}")
        logging.info("\n")
    elif topicname in ["ringcentral_event_numbers_added", "ringcentral_event_numbers_deleted"]:
        context.event_type = context.consumer_payload[0]["header"]["event_type"]
    elif topicname == 'tmfmediator_command_add_msoccountrybilling':
        common.update_middleware_correlation_id(context)
        context.marketplace_event_id = context.consumer_payload['msocCustomerRequest']['clientReference'][
            'marketplace_event_id']

    elif topicname == "ringcentral_event_accountserviceinfo_updated":
        if isinstance(context.consumer_payload, list):
            context.consumer_payload = context.consumer_payload[-1]


# And user validates payload is not present in 'ordermanagement_command_update_accountstatus'
# And user validates payload is not present in 'appdirect_create_changelicense'
@then(u"user validates payload is not present in '{topicname}'")
def validate_payload_not_present_in_topic(context, topicname):
    search_field = utils.get_search_field(context, topicname)
    context.consumer_payload = consumer_data.received_data(
        topicname, search_field, timeout_tag="kafka_buffer_timer", raises=False)
    assert context.consumer_payload is None, f"Payload should NOT be present in kafka for: {topicname}"
    logger.info("As expected: payload is not present")


@then("validate user receives '{Id}' from '{topicname}'")
def validate_receival_id_from_topic(context, Id, topicname):
    if "ringcentral_event_initialorder_created" in topicname:
        if "middleware_correlation_id" in Id:
            try:
                middleware_correlation_id = context.consumer_payload["header"]['middleware_correlation_id']
                assert middleware_correlation_id in context.middleware_correlation_id, \
                    "Item {} is not present in Topic {}".format(context.middleware_correlation_id, topicname)
            except KeyError:
                logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

        elif "marketplace_event_id" in Id:
            try:
                marketplace_event_id = context.consumer_payload["completed_order"]['marketplace_event_id']
                assert marketplace_event_id in context.marketplaceEventID, \
                    "Item {} is not present in Topic {}".format(context.marketplaceEventID, topicname)
            except KeyError:
                logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

        elif "externalAccountId" in Id:
            try:
                response_externalAccountId = context.consumer_payload["account"]['external_account_id']
                assert response_externalAccountId in context.externalAccountId, \
                    "Item {} is not present in Topic {}".format(context.externalAccountId, topicname)
            except KeyError:
                logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

        elif "externalTransactionId" in Id:
            try:
                response_externalTransactionId = context.consumer_payload["account"]['external_transaction_id']
                assert response_externalTransactionId in context.externalTransactionId, \
                    "Item {} is not present in Topic {}".format(context.externalTransactionId, topicname)
            except KeyError:
                logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

        elif "externalOrderId" in Id:
            try:
                response_externalOrderId = context.consumer_payload["account"]['external_order_id']
                assert response_externalOrderId in context.externalOrderId, \
                    "Item {} is not present in Topic {}".format(context.externalOrderId, topicname)
            except KeyError:
                logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

        elif "RingCentralID" in Id:
            try:
                assert context.RC_ID in context.consumer_payload["completed_order"]['ucas_account_id'], \
                    "Item {} is not present in Topic {}".format(context.RC_ID, topicname)
            except KeyError:
                logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    ######################################################################################################
    elif Id == "externalAccountId" and topicname == "ordermanagement_command_create_initialorder":
        try:
            response_externalAccountId = context.consumer_Acct_CI["account"]['external_account_id']
            assert response_externalAccountId in context.externalAccountId, \
                "Item {} is not present in Topic {}".format(context.consumer_Acct_CI["account"]['external_account_id'],
                                                            topicname)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif Id == "externalTransactionId" and topicname == "ordermanagement_command_create_initialorder":
        try:
            response_externalTransactionId = context.consumer_Acct_CI["account"]['external_transaction_id']
            assert response_externalTransactionId in context.externalTransactionId, \
                "Item {} is not present in Topic {}".format(
                    context.consumer_Acct_CI["account"]['external_transaction_id'],
                    topicname)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif Id == "externalOrderId" and topicname == "ordermanagement_command_create_initialorder":
        try:
            response_externalTransactionId = context.consumer_Acct_CI['externalTransactionId']
            assert response_externalTransactionId in context.externalOrderId, \
                "Item {} is not present in Topic {}".format(context.consumer_Acct_CI["account"]['external_order_id'],
                                                            topicname)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    #######################################################################
    elif Id == "externalAccountId" and topicname == "ordermanagement_event_account_created":
        try:
            response_externalAccountId = context.consumer_Acct_CA["account"]['external_account_id']
            assert response_externalAccountId in context.payload_RC_IO["account"]['external_account_id'], \
                "Item {} is not present in Topic {}".format(context.payload_RC_IO["account"]['external_account_id'],
                                                            topicname)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif Id == "externalTransactionId" and topicname == "ordermanagement_event_account_created":
        try:
            response_externalTransactionId = context.consumer_Acct_CA["account"]['external_transaction_id']
            assert response_externalTransactionId in context.payload_RC_IO["account"]['external_transaction_id'], \
                "Item {} is not present in Topic {}".format(context.payload_RC_IO["account"]['external_transaction_id'],
                                                            topicname)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif Id == "externalOrderId" and topicname == "ordermanagement_event_account_created":
        try:
            response_externalTransactionId = context.consumer_Acct_CA['externalTransactionId']
            assert response_externalTransactionId in context.payload_RC_IO["account"]['external_order_id'], \
                "Item {} is not present in Topic {}".format(context.payload_RC_IO["account"]['external_order_id'],
                                                            topicname)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    elif Id == "RingCentralID" and topicname == "ordermanagement_event_account_created":
        try:
            assert context.RC_ID in context.consumer_Acct_CA["account"]['id'], \
                "Item {} is not present in Topic {}".format(context.payload_RC_IO["account"]['id'],
                                                            topicname)
        except KeyError:
            logger.info("KeyError for topic: " + topicname + " : Please check the keys in JSON")

    else:
        assert "True" == "False", "No validation for this id ={}".format(Id)


@given("user updates value of '{field}' as '{value}'")
def update_field_as_value(context, field, value):
    if field == "optional_attributes" and value == "blank":
        context.payload['additionalData']['prop1'] = ""
        context.payload['additionalData']['prop2'] = ""
    if "ZIPCODE" in field and "invalid_zip" in value:
        context.payload["order"]["company"]["location"]['head_quarters_address']['zip'] = "gtfr5"
    if "ZIPCODE" in field and "blank" in value:
        context.payload["order"]["company"]["location"]['head_quarters_address']['zip'] = ""
    if "EmailID" in field and "blank" in value:
        context.payload["order"]['primary_contact_details']['email'] = ""

    ##########context.payload['contactInfo']['email'] = ""
    if field == "FirstName" and value == "blank":
        context.payload['order']['primary_contact_details']['first_name'] = ""
    if "contactPhone" in field and "invalid" in value:
        context.payload["order"]['primary_contact_details']['contact_phone'] = "abcd"
    if field == "EmailID" and value == "blank":
        context.payload["order"]['primary_contact_details']['email'] = ""
    if "EmailID" in field and "invalid_email_id" in value:
        context.payload["order"]['primary_contact_details']['email'] = "abcd"
    if field == "EmailID" and value == "duplicate_email_id":
        context.payload["order"]['primary_contact_details']['email'] = "automation18102021093244@vodafone.com"
    if field == "LastName" and value == "blank":
        context.payload['order']['primary_contact_details']['last_name'] = ""
    if field == "middleware_correlation_id" and value == "duplicate_middleware_correlation_id":
        context.payload['header']['middleware_correlation_id'] = "80565539-ef48-485b-9798-7472a825c89a"
    if field == "opcoCustomerId" and value == "duplicate_opcoCustomerId":
        context.payload["order"]["op_co_details"]["op_co_customer_id"] = "8175450323"
    if 'activate_immediately' in field or 'send_welcome_email' in field or 'send_confirmation_email' in field:
        field = field.replace("'", '')
        value = value.replace("'", '')

        if "tenant_flow_settings" not in context.payload["order"]:
            logger.info("tenant_flow_settings is not in context, setting up default set of flow settings")
            settings = {
                "activate_immediately": True,
                "send_welcome_email": True,
                "send_confirmation_email": False
            }
            context.payload["order"]['tenant_flow_settings'] = settings
        context.payload["order"]['tenant_flow_settings'][field] = bool(strtobool(value))
        logger.info(" ")


@then("user validates '{field}' in '{topicname}' payload")
def validate_file_in_topic_payload(context, field, topicname):
    if 'ordermanagement_command_update_accountstatus' in topicname and 'activate_immediately' in field:
        logger.info(field)
        field = field.replace("'", '')
        activate_immediately = context.consumer_payload["account"]["tenant_flow_settings"][field]
        assert activate_immediately is True, f"Expected true for {field}, but got {activate_immediately}"
    else:
        logger.warning("Validation not implemented for '{field=}' in '{topicname=}'")


# And user validates RingCentralID
@then("user validates RingCentralID")
def validate_rc_id(context):
    try:
        RC_ID_IO = context.consumer_data_IO['accountId']
    except KeyError:
        logger.info("KeyError for RingCentralID; Please check the keys in JSON")
    assert RC_ID_IO in context.RC_ID, "RingCentral ID {} is not present in Consumer {}".format(RC_ID_IO,
                                                                                               context.RC_ID)


# Then validate account creation is failed
@then("validate account creation is failed")
def validate_failed_account_creation(context):
    result = consumer_data.received_data(
        'ringcentral_event_initialorder_created', context.externalAccountId, raises=False)
    assert result is None, \
        f"Payload should NOT be present in kafka for: ringcentral_event_initialorder_created"
    logger.info("As expected: payload is not present")


# And user can retrieve Change license payload from 'appdirect_create_changelicense'
@then(u"user can retrieve Change license payload from '{kafka_topic_name}'")
def validate_retrieval_payload_from_kafka_topic(context, kafka_topic_name):
    context.marketplaceEventID = read_xmldata.readxml("marketplace_eventID_changelicense", "test_inputdata",
                                                      "appdirectinput")
    context.execute_steps(u"""
                          Then user can retrieve payload from '{topicname}'                        
                                                          """.format(topicname=kafka_topic_name))


# And user validates the 'mandatory' information in 'ringcentral_respond_changelicense' for 'reductional' license
# And user validates the 'mandatory' information in 'ringcentral_respond_changelicense' for 'additional' license
@then(u"user validates the '{information_type}' information in '{kafka_topic_name}' for '{type}' license")
def validate_information_in_kafka_topic_for_license(context, information_type, kafka_topic_name, _type):
    if _type == "additional":
        license_errorMessage = ""
        reduced_license = int(context.new_license2) - int(context.new_license1)
    elif _type == "reductional":
        license_errorMessage = ""
        reduced_license = str(int(context.new_license2) - int(context.new_license1))

    consumer_payload = {}
    try:
        middlewareCorrelationID = context.consumer_payload["header"]["middleware_correlation_id"]
        marketplaceEventID = context.consumer_payload["license_changed"]["marketplace_event_id"]
        # requestSuccessful = context.consumer_payload["licence_change"]["requestSuccessful"]
        no_of_lic = context.consumer_payload["license_changed"]["quantity_added"]
        skuID = context.consumer_payload["license_changed"]["sku_id"]
        kafka_errorMessage = context.consumer_payload["license_changed"]["error"]["error_message"]
    except KeyError:
        logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")
    logger.info("reduced_license -- > " + reduced_license)
    logger.info("")

    assert context.middleware_correlation_id == middlewareCorrelationID, "middlewareCorrelationID = {} is not present in Consumer {}".format(
        context.middleware_correlation_id, middlewareCorrelationID)
    assert context.marketplaceEventID == marketplaceEventID, "marketplaceEventID :: {} is not present in Consumer {}".format(
        context.marketplaceEventID, marketplaceEventID)
    assert str(reduced_license) == str(no_of_lic), "Number of license :: {} is not present in Consumer {}".format(
        reduced_license, no_of_lic)
    assert context.skuID == skuID, "skuID :: {} is not present in Consumer {}".format(context.skuID, skuID)
    assert kafka_errorMessage == license_errorMessage, "Error message = {} is present in Consumer {}".format(
        kafka_errorMessage, license_errorMessage)


# And user validates purchase addon information in 'ringcentral_respond_changelicense'
#################################################################################################################################
@then(u"user validates purchase addon information in '{kafka_topic_name}'")
def validate_purchase_addon_information_in_kafka_topic(context, kafka_topic_name):
    context.company_name = read_xmldata.readxml("company_name", "test_inputdata", "appdirectinput")
    if kafka_topic_name == "ringcentral_respond_changelicense":
        validation_set = KafkaMsgValidationSet(context).ring_central_respond_change_license(
            test_type="purchase_addon_information")
        if "error" in context.consumer_payload["license_changed"]:
            validation_set.update({"license_changed.error.error_message": ""})
        common.validate_message(context.consumer_payload, validation_set)

    elif kafka_topic_name == "appdirect_create_addonorder":
        try:
            middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
            marketplaceEventID = context.consumer_payload["order"]["marketplace_event_id"]
            ucas_account_id = context.consumer_payload["order"]["ucas_account_id"]
            company = context.consumer_payload["order"]["company"]["name"]
            quantity = context.consumer_payload["order"]["order_details"]["quantity"]
            sku_id = context.consumer_payload["order"]["order_details"]["sku_id"]
            _type = context.consumer_payload["order"]["order_details"]["type"]
        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

        assert context.marketplaceEventID == marketplaceEventID, "marketplaceEventID :: {} is not present in Consumer {}".format(
            context.marketplaceEventID, marketplaceEventID)
        assert context.RC_ID == ucas_account_id, "ucas_account_id :: {} is not present in Consumer {}".format(
            context.RC_ID, ucas_account_id)
        assert context.skuID == sku_id, "sku_id :: {} is not present in Consumer {}".format(
            context.skuID, sku_id)
        assert int(context.quantity) == quantity, "quantity :: {} is not present in Consumer {}".format(
            context.quantity, quantity)
        assert context.company_name == company, "company name {} is not present in Consumer {} ".format(
            context.company_name, company)
        assert _type == "LICENSE", "type {} is not present in Consumer {} ".format(type, "LICENSE")


# And user validates 'blank' error message in 'ringcentral_respond_changelicense' in Middleware
# And user validates 'valid' error message in 'ringcentral_respond_changelicense' in Middleware
#################################################################################################################################
@then(u"user validates '{message_type}' error message in '{kafka_topic_name}' in Middleware")
def validate_error_message_in_kafka_topic_mw(context, message_type, kafka_topic_name):
    if kafka_topic_name == "ringcentral_respond_changelicense":
        if message_type == "valid":
            license_errorMessage = read_xmldata.readxml("license_errorMessage", "appdirect_inputdata", "AppdirectUI")
        elif message_type == "blank":
            license_errorMessage = ""
        elif message_type == "JWT":
            license_errorMessage = "JwtToken is not present in token from RingCentral API"
    context.consumer_payload = consumer_data.received_data(kafka_topic_name, context.marketplaceEventID)
    logger.info(
        "Ringcentral respond change license payload: {}".format(json.dumps(context.consumer_payload, indent=3)))
    logger.info(" ")
    try:
        middlewareCorrelationID = context.consumer_payload["header"]["middleware_correlation_id"]
        marketplaceEventID = context.consumer_payload["license_changed"]["marketplace_event_id"]
        no_of_lic = context.consumer_payload["license_changed"]["quantity_added"]
        reduced_license = int(context.new_license) - int(context.initial_license)
        skuID = context.consumer_payload["license_changed"]["sku_id"]
        kafka_errorMessage = context.consumer_payload["license_changed"]["error"]["error_message"]
        context.RC_error_code = context.consumer_payload["license_changed"]["error"]["error_code"]
    except KeyError:
        logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

    assert kafka_errorMessage == license_errorMessage, "Error message = {} is not present in Consumer {}".format(
        kafka_errorMessage, license_errorMessage)
    assert context.middleware_correlation_id == middlewareCorrelationID, "middlewareCorrelationID = {} is not present in Consumer {}".format(
        context.middleware_correlation_id, middlewareCorrelationID)
    assert context.marketplaceEventID == marketplaceEventID, "marketplaceEventID :: {} is not present in Consumer {}".format(
        context.marketplaceEventID, marketplaceEventID)
    assert context.skuID == skuID, "skuID :: {} is not present in Consumer {}".format(context.skuID, skuID)


# Then user validates the information in 'emailreceiver_event_received_email'
# And user validates the information in 'appdirect_create_changelicense'
# user validates the information in 'ordermanagement_command_create_initialorder'
#################################################################################################################################
@then("user validates the information in '{kafka_topic_name}'")
@then("user validates the information in '{kafka_topic_name}' with '{error_type}'")
def validate_topic(context, kafka_topic_name, error_type=None):
    if not common.config.is_crf_add_number_enabled and kafka_topic_name in utils.crf_topics_add_number:
        logger.info('CRF feature is not enabled, skip this step')
        return
    logger.debug(f'consumer_payload: {context.consumer_payload}')
    if error_type is not None:
        KafkaTopicValidator(context).validate_topic(kafka_topic_name, error_type)
        return

    context.company_name = read_xmldata.readxml("company_name", "test_inputdata", "appdirectinput")
    # numbermanagement_command_add_numbers is actually supported! so it should be unified
    if kafka_topic_name == "numbermanagement_command_add_numbers":
        all_numbers_expected = numbers.get_all_numbers_expected(context)
        all_numbers_actual = numbers.get_all_numbers_actual(context.consumer_payload)

        asserts.equals(sorted(all_numbers_actual), sorted(list(set(all_numbers_expected))),
                       'numbermanagement_command_add_numbers numbers list')

        if not utils.has_multiple_messages(context.consumer_payload):
            usage_type = 'Inventory'
            if not hasattr(context, 'E164_FwPoolList'):
                usage_type = 'Presentation'
            KafkaTopicValidator(context).numbermanagement_command_add_numbers(usage_type, all_numbers_expected,
                                                                           context.consumer_payload)
        # this might be useful for all cases
        common.update_middleware_correlation_id(context)

    elif kafka_topic_name == "appdirect_create_initialorder":
        consumer_payload = {}
        try:
            context.eventID = context.consumer_payload["header"]["event_id"]
            company_name = context.consumer_payload["order"]["company"]["name"]
            consumer_payload["address_line_1"] = \
                context.consumer_payload["order"]["company"]["location"]["head_quarters_address"]["street"]
            consumer_payload["address_line_2"] = \
                context.consumer_payload["order"]["company"]["location"]["head_quarters_address"]["street2"]
            consumer_payload["town_city"] = \
                context.consumer_payload["order"]["company"]["location"]["head_quarters_address"]["city"]
            # consumer_payload["state_county_region"] = context.consumer_payload["order"]["company"]["location"]["head_quarters_address"]["state"]
            consumer_payload["postcode"] = str(
                context.consumer_payload["order"]["company"]["location"]["head_quarters_address"]["zip"])
            consumer_payload["country"] = \
                context.consumer_payload["order"]["company"]["location"]["head_quarters_address"][
                    "country"]
            consumer_payload['first_name'] = context.consumer_payload["order"]["primary_contact_details"]["first_name"]
            consumer_payload["last_name"] = context.consumer_payload["order"]["primary_contact_details"]["last_name"]
            consumer_payload["opco_billing_account_num"] = context.consumer_payload["order"]["op_co_details"][
                "op_co_billing_account_number"]
            consumer_payload["opco_billing_ref"] = context.consumer_payload["order"]["op_co_details"][
                "op_co_billing_service_reference"]
            consumer_payload["opco_opportunity_id"] = context.consumer_payload["order"]["op_co_details"][
                "op_co_opportunity_id"]
            consumer_payload["opco_order_reference_id"] = context.consumer_payload["order"]["op_co_details"][
                "op_co_order_reference"]
            contact_number = context.consumer_payload["order"]["primary_contact_details"]["contact_phone"]
            con_email_id = context.consumer_payload["order"]["primary_contact_details"]["email"]
            con_no_of_lic = context.consumer_payload["order"]["order_details"]["quantity"]
            opco_crm_customer_id = context.consumer_payload["order"]["op_co_details"]["op_co_customer_id"]
            context.mobile = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
            context.op_co_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata",
                                                             "appdirectinput")
        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

        assert context.mobile == contact_number, "Contact Number = {} is not present in Consumer {}".format(
            context.mobile, contact_number)
        assert context.op_co_customer_id == opco_crm_customer_id, "opco_crm_customer_id = {} is not match with {} in Consumer".format(
            context.op_co_customer_id, opco_crm_customer_id)
        assert context.email == con_email_id, "Email ID= {} is not present in Consumer {}".format(
            context.email, con_email_id)
        assert context.initial_license == str(
            con_no_of_lic), "Number of license = {} is not present in Consumer {}".format(
            context.initial_license, con_no_of_lic)
        assert context.company_name == company_name, "company name {} is not match with kafka comapany name {} ".format(
            context.company_name, company_name)
        for item in consumer_payload:
            mandatory_value = read_xmldata.readxml(item, "appdirect_inputdata", 'AppdirectUI')
            logger.info("Data from Appdirect : {} and Data from Initial Order Kafka : {}".format(mandatory_value,
                                                                                                 consumer_payload[
                                                                                                     item]))
            logger.info(" ")
            assert mandatory_value in consumer_payload[item], "Item {} is not present in Consumer {}".format(
                mandatory_value, consumer_payload)
    # check here
    elif kafka_topic_name == "ordermanagement_command_create_initialorder":
        KafkaTopicValidator(context).ordermanagement_command_create_initialorder()
        common.update_middleware_correlation_id(context)
    elif kafka_topic_name == "tmfmediator_command_create_msoccustomer":
        context.operation_id = context.consumer_payload["msocCustomerRequest"]["clientReference"]["operation_id"]
    elif kafka_topic_name == "tmfmediator_command_set_ssoconfig":
        context.sso_operation_id = context.consumer_payload["ssoConfigRequest"]["clientReference"]["operation_id"]
    elif kafka_topic_name == "appdirect_create_changelicense":
        consumer_payload = {}
        try:
            marketplaceEventID = context.consumer_payload["change_license"]["marketplace_event_id"]
            middlewareCorrelationID = context.consumer_payload["header"]["middleware_correlation_id"]
            marketplaceBaseURL = context.consumer_payload["change_license"]["marketplace_info"]["marketplace_base_url"]
            emailAddress = context.consumer_payload["change_license"]["primary_contact_details"]["email"]
            contact_number = context.consumer_payload["change_license"]["primary_contact_details"]["contact_phone"]
            no_of_lic = context.consumer_payload["change_license"]["order_details"]["quantity"]
            opco_customer_id = context.consumer_payload["change_license"]["op_co_details"]["op_co_customer_id"]
            skuID = context.consumer_payload["change_license"]["order_details"]["sku_id"]
            ucasAccountID = context.consumer_payload["change_license"]["ucas_account_id"]
            packageID = context.consumer_payload["change_license"]["order_details"]["package_id"]
        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

        try:
            consumer_payload["address_line_1"] = \
                context.consumer_payload["change_license"]["company"]["location"]["head_quarters_address"]["street"]
            # consumer_payload["address_line_2"] = \
            # context.consumer_payload["changeLicense"]["company"]["location"]["headquartersAddress"]["streetAddress2"]
            consumer_payload["town_city"] = \
                context.consumer_payload["change_license"]["company"]["location"]["head_quarters_address"]["city"]
            consumer_payload["state_county_region"] = \
                context.consumer_payload["change_license"]["company"]["location"]["head_quarters_address"]["state"]
            consumer_payload["postcode"] = \
                context.consumer_payload["change_license"]["company"]["location"]["head_quarters_address"]["zip"]
            consumer_payload["country"] = \
                context.consumer_payload["change_license"]["company"]["location"]["head_quarters_address"]["country"]

            consumer_payload["first_name"] = context.consumer_payload["change_license"]["primary_contact_details"][
                "first_name"]
            consumer_payload["last_name"] = context.consumer_payload["change_license"]["primary_contact_details"][
                "last_name"]
            consumer_payload["opco_billing_account_num"] = context.consumer_payload["change_license"]["op_co_details"][
                "op_co_billing_account_number"]
            consumer_payload["opco_billing_ref"] = context.consumer_payload["change_license"]["op_co_details"][
                "op_co_billing_service_reference"]
            consumer_payload["opco_opportunity_id"] = context.consumer_payload["change_license"]["op_co_details"][
                "op_co_opportunity_id"]
            consumer_payload["opco_order_reference_id"] = context.consumer_payload["change_license"]["op_co_details"][
                "op_co_order_reference"]
        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

        assert context.marketplaceEventID == marketplaceEventID, "marketplaceEventID= {} is not present in Consumer {}".format(
            context.marketplaceEventID, marketplaceEventID)
        # assert context.middleware_correlation_id == middlewareCorrelationID, "middlewareCorrelationID = {} is not present in Consumer ##{}".format(
        # context.middleware_correlation_id, middlewareCorrelationID)
        assert marketplaceBaseURL in context.URL, "marketplaceBaseURL= {} is not present in Consumer {}".format(
            context.URL, marketplaceBaseURL)
        assert context.email == emailAddress, "email= {} is not present in Consumer {}".format(
            context.email, emailAddress)
        assert context.mobile == contact_number, "mobile= {} is not present in Consumer {}".format(
            context.mobile, contact_number)
        assert context.new_license == str(
            no_of_lic), "new_license= {} is not present in Consumer {}".format(
            context.new_license, no_of_lic)
        assert context.op_co_customer_id == opco_customer_id, "opCoCustomerID= {} is not present in Consumer {}".format(
            context.op_co_customer_id, opco_customer_id)
        assert context.skuID == skuID, "skuID= {} is not present in Consumer {}".format(
            context.skuID, skuID)
        assert context.RC_ID == ucasAccountID, "RC_ID= {} is not present in Consumer {}".format(
            context.RC_ID, ucasAccountID)
        assert context.edition_type == packageID, "edition_type ::{} is not present in Consumer {}".format(
            context.edition_type, packageID)

        for item in consumer_payload:
            mandatory_value = read_xmldata.readxml(item, "appdirect_inputdata", 'AppdirectUI')
            logger.info("Data from xml= {} and Data from Change License Kafka {}".format(
                mandatory_value, consumer_payload[item]))
            assert mandatory_value in consumer_payload[
                item], "mandatory_value ::{} is not present in Consumer {}".format(
                mandatory_value, consumer_payload)

    elif kafka_topic_name == "ordermanagement_create_changelicense":
        try:
            marketplaceEventID = context.consumer_payload["marketplaceEventID"]
            middlewareCorrelationID = context.consumer_payload["middlewareCorrelationID"]
            ucasAccountID = context.consumer_payload["ucasAccountID"]  # this should be compared with ?
            skuID = context.consumer_payload["licenseDetails"]["skuID"]
            packageID = context.consumer_payload["licenseDetails"]["packageID"]  # this should be compared with ?
            no_of_lic = context.consumer_payload["licenseDetails"]["quantity"]
        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

        assert context.marketplaceEventID == marketplaceEventID, "marketplaceEventID :: {} is not present in Consumer {}".format(
            context.marketplaceEventID, marketplaceEventID)
        assert context.middleware_correlation_id == middlewareCorrelationID, "middlewareCorrelationID = {} is not present in Consumer {}".format(
            context.middleware_correlation_id, middlewareCorrelationID)
        assert context.skuID == skuID, "skuID :: {} is not present in Consumer {}".format(
            context.skuID, skuID)
        assert context.new_license == str(
            no_of_lic), "Number of license :: {} is not present in Consumer {}".format(
            context.new_license, no_of_lic)
        assert context.RC_ID == ucasAccountID, "ucasAccountID :: {} is not present in Consumer {}".format(
            context.RC_ID, ucasAccountID)
        assert context.skuID == skuID, "skuID :: {} is not present in Consumer {}".format(
            context.skuID, skuID)
        assert context.edition_type == packageID, "packageID :: {} is not present in Consumer {}".format(
            context.edition_type, packageID)

    elif kafka_topic_name == "ringcentral_respond_changelicense":
        validation_set = KafkaMsgValidationSet(context).ring_central_respond_change_license(
            test_type="validate_information")

        if "error" in context.consumer_payload["license_changed"]:
            validation_set.update({"license_changed.error.error_message": ""})
        common.validate_message(context.consumer_payload, validation_set)

    elif kafka_topic_name == "ordermanagement_event_account_created":
        validation_set = KafkaMsgValidationSet(context).ordermanagement_event_account_created()
        common.validate_message(context.consumer_payload, validation_set)

    elif kafka_topic_name == "emailreceiver_event_received_email":
        try:
            attachment_name = context.consumer_payload["email"]["attachments"][0]["name"]
        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")
        assert context.Attachment_Field_Value == attachment_name, "attachment_name : {} is not present in kafka topic {}".format(
            context.Attachment_Field_Value, attachment_name)

    elif kafka_topic_name == "numbermanagement_command_complete_order":
        validation_set = KafkaMsgValidationSet(context).numbermanagement_command_complete_order()
        common.validate_message(context.consumer_payload, validation_set)

    elif kafka_topic_name == "idmapper_event_msoccustomer_created":
        validation_set = KafkaMsgValidationSet(context).idmapper_event_msoccustomer_created()
        common.validate_message(context.consumer_payload, validation_set)

    elif kafka_topic_name == "tmfmediator_command_update_accountstatus":
        validation_set = KafkaMsgValidationSet(context).tmfmediator_command_update_accountstatus()
        common.validate_message(context.consumer_payload, validation_set)

    elif kafka_topic_name == "appdirect_create_deviceshipment":
        consumer_payload = {}
        try:
            middlewareCorrelationID = context.consumer_payload["header"]["middleware_correlation_id"]
            event_type = context.consumer_payload["header"]["event_type"]
            marketplaceEventID = context.consumer_payload["shipping_address"]["marketplace_event_id"]
            marketplaceAccountID = context.consumer_payload["shipping_address"]["marketplace_account_id"]

            consumer_payload["address_line_1"] = \
                context.consumer_payload["shipping_address"]["company"]["location"]["shipping_address"]["street"]
            consumer_payload["town_city"] = \
                context.consumer_payload["shipping_address"]["company"]["location"]["shipping_address"]["city"]
            consumer_payload["postcode"] = \
                context.consumer_payload["shipping_address"]["company"]["location"]["shipping_address"]["zip"]
            consumer_payload["country"] = \
                context.consumer_payload["shipping_address"]["company"]["location"]["shipping_address"]["country"]

        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

        assert context.middleware_correlation_id == middlewareCorrelationID, "middlewareCorrelationID : {} is not present in kafka topic {}".format(
            context.middleware_correlation_id, middlewareCorrelationID)
        assert context.marketplaceEventID == marketplaceEventID, "marketplaceEventID : {} is not present in kafka topic {}".format(
            context.marketplaceEventID, marketplaceEventID)
        assert context.marketplaceAccountID == marketplaceAccountID, "marketplaceAccountID : {} is not present in kafka topic {}".format(
            context.marketplaceAccountID, marketplaceAccountID)
        assert event_type == "SHIPPING_ADDRESS_PROVIDED", "Event_type : {} is not present in kafka topic".format(
            event_type)

        for item in consumer_payload:
            mandatory_value = read_xmldata.readxml(item, "appdirect_inputdata", 'AppdirectUI')
            logger.info("Data from Appdirect : {} and Data from Device Order Kafka : {}".format(mandatory_value,
                                                                                                consumer_payload[
                                                                                                    item]))
            logger.info(" ")
            assert mandatory_value in consumer_payload[item], "Item {} is not present in Consumer {}".format(
                mandatory_value, consumer_payload)

    elif kafka_topic_name == "ordermanagement_create_deviceorder":
        consumer_payload = {}
        try:
            middlewareCorrelationID = context.consumer_payload["header"]["middleware_correlation_id"]
            event_type = context.consumer_payload["header"]["event_type"]
            marketplaceEventID = context.consumer_payload["order"]["marketplace_event_id"]
            ucas_account_id = context.consumer_payload["order"]["ucas_account_id"]
            middleware_shipping_id = context.consumer_payload["order"]["middleware_shipping_id"]
            quantity = context.consumer_payload["order"]["order_details"]["quantity"]
            sku_id = context.consumer_payload["order"]["order_details"]["sku_id"]
            _type = context.consumer_payload["order"]["order_details"]["type"]

            consumer_payload["address_line_1"] = \
                context.consumer_payload["order"]["company"]["location"]["shipping_address"]["street"]
            consumer_payload["town_city"] = \
                context.consumer_payload["order"]["company"]["location"]["shipping_address"]["city"]
            consumer_payload["postcode"] = \
                context.consumer_payload["order"]["company"]["location"]["shipping_address"]["zip"]
            consumer_payload["country"] = \
                context.consumer_payload["order"]["company"]["location"]["shipping_address"]["country"]
        except KeyError:
            logger.info("KeyError for topic: " + kafka_topic_name + " : Please check the keys in JSON")

        assert context.middleware_correlation_id == middlewareCorrelationID, "middlewareCorrelationID : {} is not present in kafka topic {}".format(
            context.middleware_correlation_id, middlewareCorrelationID)
        assert context.marketplaceEventID == marketplaceEventID, "marketplaceEventID : {} is not present in kafka topic {}".format(
            context.marketplaceEventID, marketplaceEventID)
        assert context.RC_ID == ucas_account_id, "ucas_account_id : {} is not present in kafka topic {}".format(
            context.RC_ID, ucas_account_id)

        assert context.accountLocationID == middleware_shipping_id, "middleware_shipping_id : {} is not present in kafka topic {}".format(
            context.accountLocationID, middleware_shipping_id)
        assert event_type == "ORDER_DEVICE_REQUESTED", "Event_type : {} is not present in kafka topic".format(
            event_type)

        assert context.quantity == quantity, "quantity : {} is not present in kafka topic {}".format(
            context.quantity, quantity)
        assert context.sku_id == sku_id, "sku_id : {} is not present in kafka topic {}".format(
            context.sku_id, sku_id)
        assert quantity == "DEVICE", "Order _type : {} is not present in kafka topic".format(type)

        for item in consumer_payload:
            mandatory_value = read_xmldata.readxml(item, "appdirect_inputdata", 'AppdirectUI')
            logger.info("Data from Appdirect : {} and Data from Device Order Kafka : {}".format(mandatory_value,
                                                                                                consumer_payload[
                                                                                                    item]))
            logger.info(" ")
            assert mandatory_value in consumer_payload[item], "Item {} is not present in Consumer {}".format(
                mandatory_value, consumer_payload)

    elif kafka_topic_name == "ringcentral_event_numbers_added" and error_type is None:
        all_numbers_expected = numbers.get_all_numbers_expected(context)
        all_numbers_actual = numbers.get_all_numbers_actual(context.consumer_payload)

        asserts.equals(sorted(all_numbers_actual), sorted(list(set(all_numbers_expected))),
                       'ringcentral_event_numbers_added numbers list')

        if not utils.has_multiple_messages(context.consumer_payload):
            usage_type = 'Inventory'
            if not hasattr(context, 'E164_FwPoolList'):
                usage_type = 'Presentation'
            KafkaTopicValidator(context).ringcentral_event_numbers_added(usage_type, all_numbers_expected,
                                                                         context.consumer_payload)
        common.update_middleware_correlation_id(context)

    elif kafka_topic_name == "ringcentral_event_accountstatus_updated":
        if hasattr(context, 'confirmation_status') and context.confirmation_status == 'not_confirmed_by_RingCentral':
            validation = {"account_status_changed.error.error_code": "UCAS_PROVIDER_ERROR"}
        else:
            validation = {"header.event_type": "ACCOUNT_STATUS_CHANGED",
                          "account_status_changed.marketplace": context.marketplace,
                          "account_status_changed.marketplace_event_id": context.marketplaceEventID,
                          "account_status_changed.request_successful": True,
                          "account_status_changed.account_status": "CONFIRMED"}
            if "error" in context.consumer_payload:
                validation.update({"account_status_changed.error.error_code": "NO_ERROR",
                                   "account_status_changed.error.error_message": ""})
        common.validate_message(context.consumer_payload, validation)

    elif kafka_topic_name == "crfstub_process_resourceorder":
        if not common.config.is_staging_env:
            context.crf_stub_payload = context.consumer_payload
        account_category = None
        if hasattr(context, 'payload'):
            # here means we go by TMF flow:
            # for each number we have a dict
            if "crf_number_request" in context.payload:
                pool = context.payload['crf_number_request']['pool']
                account_category = context.payload["crf_number_request"]["ucas_provider"]

            elif payload.has_initial_order(context.payload):
                item = payload.get_item_by_type(context.payload, 'ucc.unity.tenant')[1]
                pool = [numbers.get_main_number(item)]
            elif payload.has_msoc_cac_configuration(context.payload) and not msoc_numbers.has_add_msoc_numbers(
                    context.payload):
                pool = context.number_pool_list
                account_category = "MSOC"
            elif hasattr(context, "previously_added_numbers"):
                account_category = "MSOC"
                pool = context.previously_added_numbers
                logger.info(f"{context.previously_added_numbers=}")
                del context.previously_added_numbers
            elif msoc_numbers.has_add_msoc_numbers(context.payload) or msoc_numbers.has_delete_msoc_numbers(
                    context.payload):
                item = payload.get_item_by_type(context.payload, 'ucc.msoc.numbers')[1]
                context.order_id = item['id']
                pool = numbers.get_all_numbers(item)
                account_category = "MSOC"
            elif payload.has_cease_msoc_account(context.payload):
                pool = context.number_pool_list
                account_category = "MSOC"
                context.operation = "CEASE"
            else:
                item = payload.get_item_by_type(context.payload, 'ucc.unity.numbers')[1]
                context.order_id = item['id']
                pool = numbers.get_all_numbers(item)

            logging.info(f'numbers get from the pool {pool}')
        else:
            # NM flow
            logging.info(context.poolpayload)
            pool = context.E164_List
        context.consumer_payload["orderItem"] = sorted(context.consumer_payload["orderItem"],
                                                       key=lambda x: int(
                                                           numbers.get_e164_numbers_from_order_item(x)[0]))
        context.consumer_payload["orderItem"][0]["resource"]["resourceCharacteristic"] = \
            sorted(context.consumer_payload["orderItem"][0]["resource"]["resourceCharacteristic"],
                   key=lambda x: x["name"])
        logger.info(context.consumer_payload)

        validation_set = KafkaMsgValidationSet(context).crfstub_process_resourceorder(context.action,
                                                                                      pool,
                                                                                      account_category)
        common.validate_message(context.consumer_payload, validation_set)

    elif KafkaTopicValidator.is_topic_supported(kafka_topic_name):
        KafkaTopicValidator(context).validate_topic(kafka_topic_name, error_type)
        # common.update_middleware_correlation_id(context)
        common.save_marketplace_event_id(context)
    else:
        assert "True" == "False", "Validation scripts are not available for this kafka topic:{}".format(
            kafka_topic_name)


# Then user validates 'error_message' in 'ordermanagement_event_order_completed'
# Then user validates 'Quantity must be more than existing licences in RingCentral' in 'ordermanagement_event_order_completed'
#################################################################################################################################
@then(u"user validates '{err_message}' in '{kafka_topic_name}'")
def validate_error_message_in_kafka_topic(context, err_message, kafka_topic_name):
    if kafka_topic_name == "ordermanagement_event_order_completed":
        validation_set = KafkaMsgValidationSet(context).ordermanagement_event_order_completed(err_message)
        common.validate_message(context.consumer_payload, validation_set)

    elif kafka_topic_name == "ringcentral_respond_changelicense":
        validation_set = KafkaMsgValidationSet(context).ring_central_respond_change_license(error_type=err_message)
        common.validate_message(context.consumer_payload, validation_set)
    elif kafka_topic_name == "ringcentral_event_accountstatus_updated":

        if err_message == "JWT_error_message":
            validation_set = KafkaMsgValidationSet(context).ring_central_respond_account_status(error_type=err_message)
            common.validate_message(context.consumer_payload, validation_set)
        elif err_message == "error_message":
            validation_set = KafkaMsgValidationSet(context).ring_central_respond_account_status(error_type=err_message)
            for field_name, expected in validation_set.items():
                actual = common.get_field(context.consumer_payload, field_name)
                asserts.field_equals(actual, expected, field_name)
            common.validate_message(context.consumer_payload, validation_set)
    elif kafka_topic_name == "ringcentral_event_numbers_added":
        KafkaTopicValidator(context).ringcentral_event_numbers_added(context.pool_type, context.consumer_payload,
                                                                     error_type=err_message)
    elif kafka_topic_name == "ringcentral_event_numbers_deleted":
        KafkaTopicValidator(context).validate_topic('ringcentral_event_numbers_deleted', error_type=err_message)
    elif kafka_topic_name in ('numbermanagement_respond_numbersadded', 'numbermanagement_event_numbers_deleted'):
        KafkaTopicValidator(context).validate_topic(kafka_topic_name, error_type=err_message)

    else:
        assert False, "Validation scripts are not available for this kafka topic:{}".format(
            kafka_topic_name)


# And user validates 'Add' numbers information in 'numbermanagement_command_add_numbers'
#################################################################################################################################
@then(u"user validates '{action_type}' numbers information in '{kafka_topic_name}'")
def validate_numbers_information_in_kafka_topic(context, action_type, kafka_topic_name):
    context.company_name = read_xmldata.readxml("company_name", "test_inputdata", "appdirectinput")
    context.request_uuid = context.consumer_payload[-1]["phone_numbers"]["request_uuid"]
    common.update_middleware_correlation_id(context=context)

    topic_action = kafka_topic_name + ":" + action_type
    if topic_action in numbers.topic_action_list:
        if topic_action == "numbermanagement_command_add_numbers:Add":
            context.middleware_correlation_id = context.consumer_payload[-1]["header"]["middleware_correlation_id"]
        if hasattr(context, 'E164_LookupValue'):
            numbers.fetch_and_validate_numbers(context, kafka_topic_name, context.E164_LookupValue)
    elif topic_action in numbers.topic_action_range_list:
        if hasattr(context, 'E164_List'):
            numbers.fetch_and_validate_numbers(context, kafka_topic_name, context.E164_List)
    else:
        assert False, "ERROR: Kafka topic with supplied action doesn't match in list"
    if hasattr(context, 'E164_FwPoolList'):
        numbers.fetch_and_validate_numbers(context, kafka_topic_name, context.E164_FwPoolList)


@then("user validates '{numbercount}' numbers are present in '{topicname}'")
def validate_numbers_present_in_topic(context, numbercount, topicname):
    logger.debug(f"{context.poolpayload=}")
    if numbercount == "first_08":
        total_list = context.E164_List_one
    elif numbercount == "next_07":
        total_list = context.E164_List_two
    elif numbercount == "8":
        total_list = context.E164_List
    else:
        assert False, "no Condition found"
    if "numbermanagement_command_add_numbers" in topicname:
        logger.warning(f'Fix me! this step should not be supported')
        raise NotImplementedError(f'{context.tags=}')

    elif "ringcentral_event_numbers_added" in topicname:
        logger.warning(f'Fix me! this step should not be supported')
        raise NotImplementedError(f'{context.tags=}')

    if "numbermanagement_command_delete_numbers" in topicname:
        if numbercount == "first_08":
            search_value = context.E164_List[0]
            logger.info(f"first pool number : {search_value}")
        elif numbercount == "next_07":
            search_value = context.E164_List_two[0]
            logger.info(
                f"first 5 pool number : {search_value}")  # TODO: check why we were logging context.E164_PoolList_2[0]
        elif numbercount == "8":
            search_value = context.E164_PoolList_1[0]
        else:
            raise NotImplementedError(f"{numbercount=}")
        context.consumer_payload = consumer_data.received_data(
            topicname, search_value)

        numbers.fetch_and_validate_numbers(context, topicname, total_list)
    elif "ringcentral_event_numbers_deleted" in topicname:
        if numbercount == "first_08":
            search_value = context.E164_List[0]
        elif numbercount == "next_07":
            search_value = context.E164_List_two[0]
        elif numbercount == "8":
            search_value = context.E164_PoolList_1[0]
        else:
            raise NotImplementedError(f"{numbercount=}")
        context.consumer_payload = consumer_data.received_data(
            topicname, search_value)
        logger.info(
            "Ringcentral Respond deletenumber Payload : {}".format(json.dumps(context.consumer_payload, indent=3)))
        try:
            context.consumer_payload = context.consumer_payload[-1]
            ucas_account_id = context.consumer_payload["phone_numbers"]["ucas_account_id"]
            for i in range(len(total_list)):
                phone_number = context.consumer_payload["phone_numbers"]["phone_number_details"][i]["phone_number"]
                if phone_number not in total_list:
                    logger.error(f"Phone number {phone_number} not in expected list: {total_list}")
                    raise Exception("Phone number not in expected list")
        except (KeyError, IndexError):
            logger.info(
                "KeyError/IndexError for topic: " + topicname + " : Please check the JSON payload")
            assert 1 == 0, "KeyError/IndexError for topic: {} : Please check the JSON payload".format(
                topicname)
        assert context.RC_ID == ucas_account_id, "Ucas_account_id : {} is not present in kafka topic {}".format(
            context.RC_ID, ucas_account_id)
        context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]


@when("message is put into '{topic_name}' with '{failure_point}'")
@given("message is put into '{topic_name}' with '{failure_point}'")
@given("message is put into '{topic_name}' to fail in '{failure_point}'")
@when("message is put into '{topic_name}' to fail in '{failure_point}'")
def insert_message_in_topic_with_failure_point(context, topic_name, failure_point):
    logger.info(topic_name)
    context.topic = topic_name
    context.payload = read_xmldata.read_jsonfile(topic_name)
    context.market_code = 'VFUK'

    if failure_point in ["valid_data", "unique_site_id"]:
        search_filter = {
            "environment": common.config.ENVIRONMENT,
            "market_code": context.market_code,
            "confirmation_status": "confirmed",
        }
        op_co_customer_id = account.get_reusable_account_number(search_filter)
        assert op_co_customer_id, f"This test requires a reusable account with {search_filter}"
    elif failure_point == "RingCentral":
        op_co_customer_id = "Account_does_not_exist_in_RC"
    elif failure_point == "id_mapper_invalid":
        op_co_customer_id = "INVALID"
    elif failure_point == "CRF_Bad_Response":
        op_co_customer_id = "CRF_number_Bad_Request"
    elif failure_point == "max_char_lenght":
        op_co_customer_id = account.LONG_NAME_ACCOUNT["account_number"]
    elif failure_point == "blank_pool":
        create_or_update_key(context.payload, "crf_number_request.pool", [])
        op_co_customer_id = account.get_reusable_account_number({"market_code": context.market_code})
    elif failure_point == "blank_vodafone_id":
        create_or_update_key(context.payload, "crf_number_request.op_co_details.op_co_customer_id", "")
        op_co_customer_id = ""
    else:
        raise NotImplementedError(f"{failure_point=}")

    # First value in dict supposed to be a decorator function and second value is the argument it
    update_messages_callback = {"numbermanagement_command_add_crfnumber": (
        payload.update_payload_nm_crf, op_co_customer_id),
        "support_command_register_crf_tmf652_listener": (
            payload.update_payload_reg_crf_listener, ""),
        "support_command_unregister_crf_tmf652_listener": (
            payload.update_payload_reg_crf_listener, ""),
        "numbermanagement_command_delete_crfnumber": (payload.update_payload_nm_crf,
                                                      op_co_customer_id)}

    # saving the function in variable from above dictionary required for payload update for a specific kafka topic
    update_message_function = update_messages_callback[topic_name][0]
    update_message_function(context.payload, update_messages_callback[topic_name][1])
    context.op_co_customer_id = op_co_customer_id
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"]
    if "crf_number_request" in context.payload:
        context.marketplaceEventID = context.payload["crf_number_request"]["client_reference"]['marketplace_event_id']
        context.payload["crf_number_request"].setdefault("ucas_provider", "RINGCENTRAL")
    logger.info(f'payload to send {context.payload}')
    context.action = context.payload["header"]["event_type"].split('_')[0].lower()
    if failure_point == 'unique_site_id':
        context.payload["crf_number_request"]['site_id'] = context.site_id = read_xmldata.gen_contact(5)

    context.execute_steps(f"""
        When payload is sent to Kafka Topic '{topic_name}'
    """)


# TODO: update update_key() function to return False or raise an Exception if key is not found (there is a built in Exception for such cases)
# And key 'ucas_account_id' is updated in the payload
@given("key '{key}' is updated in the payload")
@given("key '{key}' is updated in the payload with value '{value}'")
def update_key_value_in_payload(context, key, value=False):
    if key == 'ucas_account_id':
        if not value:
            value = read_xmldata.gen_RCID()
            context.RC_ID = value
            common.update_key(context.payload, key, value)
        else:
            context.RC_ID = ringcentral_gateway.td_ringcentral_id.get(value)
            common.update_key(context.payload, key, context.RC_ID)

    elif key == 'usage_type':
        common.update_key(context.payload, key, value)

    else:
        raise NotFoundError(f"{key} = is not found in the payload ")


@then("data in numbermanagement_command_delete_numbers topic is validated")
def validate_number_management_create_deletenumber_topic(context):
    topic_name = 'numbermanagement_command_delete_numbers'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    all_numbers_expected = numbers.get_all_numbers_expected(context)
    all_numbers_actual = numbers.get_all_numbers_actual(context.consumer_payload)
    logger.info(f'{all_numbers_actual=}')
    logger.info(f'{all_numbers_expected=}')

    asserts.equals(sorted(all_numbers_actual), sorted(list(set(all_numbers_expected))),
                   f'{topic_name} numbers list')

    if not utils.has_multiple_messages(context.consumer_payload):
        context.consumer_payload = [context.consumer_payload]

    for message in context.consumer_payload:
        KafkaTopicValidator(context).numbermanagement_command_delete_numbers(all_numbers_expected, message)

    common.update_middleware_correlation_id(context)


@step("data in ringcentral_event_numbers_deleted topic is validated")
def validate_rc_response_deletenumber_topic(context):
    topic_name = 'ringcentral_event_numbers_deleted'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    all_numbers_expected = numbers.get_all_numbers_expected(context)
    all_numbers_actual = numbers.get_all_numbers_actual(context.consumer_payload)
    logger.info(f'{all_numbers_actual=}')
    logger.info(f'{all_numbers_expected=}')

    asserts.equals(sorted(all_numbers_actual), sorted(list(set(all_numbers_expected))),
                   f'{topic_name} numbers list')

    if not utils.has_multiple_messages(context.consumer_payload):
        context.consumer_payload = [context.consumer_payload]

    for message in context.consumer_payload:
        KafkaTopicValidator(context).ringcentral_event_numbers_deleted(all_numbers_expected, message)


@given("user update account id '{ucas_account_id}' in the payload")
def update_account_id_in_payload(context, ucas_account_id):
    stub_accounts = StubAccounts()
    account_id_path = f'phone_numbers.{ucas_account_id}'
    inventory_numbers = len(context.payload['phone_numbers']['phone_number_details'])
    for index in range(inventory_numbers):
        usage_type_path = f'phone_numbers.phone_number_details[{index}].usage_type'
        create_or_update_key(context.payload, usage_type_path, 'Inventory')
    value = context.RC_ID = stub_accounts.rc.jwt_token_retry_account_id
    create_or_update_key(context.payload, account_id_path, value)
