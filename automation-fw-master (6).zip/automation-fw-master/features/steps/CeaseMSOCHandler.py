import logging

from behave import given, when, then

from classes import utils, asserts, read_xmldata, common, errors
from classes.domain.account import MSOCAccount
from classes.kafka import consumer_data, producer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF.account_generator import MSOCAccountPayloadGenerator
from classes.payload_generators.TMF.payload_generator import Action
from features.steps import MSOCHandler, TMFHandler, CRFHandler, databaseHandler, jiraHandler, patchHandler, \
    validationHandler
from features.steps.flowHandler import customer_sends_an_order_to_middleware

logger = logging.getLogger(__name__)


@given("MSOC customer has been created with billing info and add {quantity} numbers in resource type for '{market}'")
def msoc_customer_has_been_created_with_billing_info_and_add_numbers_in_resource_type(context, quantity, market):
    if quantity == 'multiple_batch':
        quantity = '15' if common.config.is_dev_env else '105'
    MSOCHandler.request_payload_for_msoc_customer_with_billing_info_add_numbers_generated(context, quantity, market)
    MSOCHandler.new_msoc_customer_onboarded(context)
    MSOCHandler.msoc_billing_request_processed(context)
    MSOCHandler.validate_msoc_numbers_request(context, action=Action.add)


@given("MSOC customer has been created with billing info without adding numbers for {market}")
def msoc_customer_has_been_created_with_billing_info_without_adding_numbers(context, market):
    MSOCHandler.request_payload_for_msoc_customer_with_billing_info_generated(context, market)
    MSOCHandler.new_msoc_customer_onboarded(context)
    MSOCHandler.msoc_billing_request_processed(context)


@given("Cease MSOC customer has been ordered for '{market}'")
@when("Cease MSOC customer has been ordered for '{market}'")
def cease_msoc_customer_has_been_ordered(context, market):
    msoc_cease_customer_ordered(context, market)
    customer_sends_an_order_to_middleware(context)


@then("MSOC Customer is ceased successfully")
def msoc_customer_is_ceased_successfully(context):
    tmfmediator_command_delete_all_numbers_topic_is_validated(context)
    numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context)
    CRFHandler.validate_crf_parent_requests_in_db(context)
    CRFHandler.validate_crf_parent_request_state(context, "IN_PROGRESS")
    crf_order_ids = CRFHandler.get_crf_order_ids(context)

    for context.crf_request_id in crf_order_ids:
        TMFHandler.retrieve_and_validate(context, "crfstub_process_resourceorder")
        CRFHandler.crf_notification_sent_with_status(context, "completed")
        CRFHandler.validate_crf_request_state_db(context, "completed")

    CRFHandler.validate_crf_parent_request_state(context, "COMPLETED")
    crfgateway_event_all_crf_numbers_deleted_topic_is_validated(context)
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, context.market_code)
    numbermanagement_event_all_numbers_deleted_is_validated(context)
    jiraHandler.validate_jira_ticket_creation_success(context)
    patchHandler.send_patch_request_from_bo_tool(context, "update_service_order", "ucc.msoc.customer", "completed")
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
    tmfmediator_command_delete_account_is_validated(context)
    common.update_middleware_correlation_id(context)
    databaseHandler.check_customer_exists_in_id_mapper_db(context, context.market_code)
    idmapper_event_account_deleted_is_validated(context)
    validationHandler.validates_msoc_customer_or_number_status(context, "completed")


@then("MSOC Customer without numbers is ceased successfully")
def msoc_customer_without_numbers_is_ceased_successfully(context):
    tmfmediator_command_delete_all_numbers_topic_is_validated(context)
    numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context)
    CRFHandler.validate_crf_parent_requests_in_db(context)
    CRFHandler.validate_crf_parent_request_state(context, "COMPLETED")
    crfgateway_event_all_crf_numbers_deleted_topic_is_validated(context)
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, context.market_code)
    numbermanagement_event_all_numbers_deleted_is_validated(context)
    jiraHandler.validate_jira_ticket_creation_success(context)
    patchHandler.send_patch_request_from_bo_tool(context, "update_service_order", "ucc.msoc.customer", "completed")
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
    tmfmediator_command_delete_account_is_validated(context)
    common.update_middleware_correlation_id(context)
    databaseHandler.check_customer_exists_in_id_mapper_db(context, context.market_code)
    idmapper_event_account_deleted_is_validated(context)
    validationHandler.validates_msoc_customer_or_number_status(context, "completed")


@then("Cease MSOC Customer is successful for {market}")
def cease_msoc_customer_for_market(context, market, account_delete_skipped=False):
    tmfmediator_command_delete_all_numbers_topic_is_validated(context)
    common.update_middleware_correlation_id(context)
    numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context)
    CRFHandler.validate_crf_parent_requests_in_db(context)
    CRFHandler.validate_crf_parent_request_state(context, "IN_PROGRESS")
    crf_order_ids = CRFHandler.get_crf_order_ids(context)

    for context.crf_request_id in crf_order_ids:
        TMFHandler.retrieve_and_validate(context, "crfstub_process_resourceorder")
        CRFHandler.crf_notification_sent_with_status(context, "completed")
        CRFHandler.validate_crf_request_state_db(context, "completed")

    CRFHandler.validate_crf_parent_request_state(context, "COMPLETED")
    crfgateway_event_all_crf_numbers_deleted_topic_is_validated(context)
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, market)
    numbermanagement_event_all_numbers_deleted_is_validated(context)
    jiraHandler.validate_jira_ticket_creation_success(context)
    patchHandler.send_patch_request_from_bo_tool(context, "update_service_order", "ucc.msoc.customer", "completed")
    if not account_delete_skipped:
        tmfmediator_command_delete_account_is_validated(context)
        common.update_middleware_correlation_id(context)
        databaseHandler.check_customer_exists_in_id_mapper_db(context, market)
        idmapper_event_account_deleted_is_validated(context)
        validationHandler.validates_msoc_customer_or_number_status(context, "completed")


@then("MSOC Customer is not ceased for {market}")
def msoc_customer_not_ceased_for_market(context, market):
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, market, False)
    databaseHandler.check_customer_exists_in_id_mapper_db(context, market, False)


@then("MSOC Customer failed to cease with '{crf_request1}' '{crf_request2}' '{status}'")
def msoc_customer_failed_to_cease(context, crf_request1, crf_request2, status):
    tmfmediator_command_delete_all_numbers_topic_is_validated(context)
    numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context)
    CRFHandler.validate_crf_parent_requests_in_db(context)
    CRFHandler.validate_crf_parent_request_state(context, "IN_PROGRESS")
    crf_order_ids = CRFHandler.get_crf_order_ids(context)
    """adding flag_counter variable to test the 'PARTIAL' scenario
        (one child is in 'completed' and other is in 'Failed' then parent will be in 'PARTIAL' state)"""
    flag_counter = 0
    context.status = status
    for context.crf_request_id in crf_order_ids:
        if context.status == 'partial':
            context.status = crf_request1
        TMFHandler.retrieve_and_validate(context, "crfstub_process_resourceorder")
        CRFHandler.crf_notification_sent_with_status(context, "inProgress")
        if context.status == crf_request1 and flag_counter > 0:
            context.status = crf_request2
        CRFHandler.crf_notification_sent_with_status(context, context.status)
        CRFHandler.validate_crf_request_state_db(context, context.status)
        flag_counter = flag_counter + 1

    CRFHandler.validate_crf_parent_request_state(context, status.upper())
    crfgateway_event_all_crf_numbers_deleted_topic_is_validated(context, status)
    databaseHandler.check_customer_exists_in_num_mgmt_db(context, context.market_code, False)
    numbermanagement_event_all_numbers_deleted_is_validated(context, status)
    TMFHandler.support_topic_sent(context, "OPERATION_FAILED", "CEASE_MSOC_CUSTOMER")
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
    validationHandler.validates_msoc_customer_or_number_status(context, 'failed')


@then("Unable to add msoc numbers to ceased MSOC Customer")
def unable_to_add_msoc_numbers_to_ceased_msoc_customer(context):
    validate_the_service_order_is_failed_with_error_message(context, "add_msoc_numbers")


@given("Cease MSOC customer has been ordered with non existing msoc account for {market}")
def cease_msoc_customer_has_been_ordered_with_non_existing_msoc_account(context, market):
    msoc_cease_customer_ordered(context, market)
    customer_updates_field_with_value_in_cease_msoc_customer_service_order(
        context,
        "op_co_customer_id",
        "12345678901")
    customer_sends_an_order_to_middleware(context)


def msoc_cease_customer_ordered(context, market):
    op_co_customer_id = getattr(context, 'op_co_customer_id', None)
    msoc_account = MSOCAccount(market_code=market, op_co_customer_id=op_co_customer_id)
    context.action = Action.delete
    context.payload = MSOCAccountPayloadGenerator(msoc_account=msoc_account, action=context.action).to_dict()


@when("customer updates '{field}' with '{value}' in cease MSOC customer service order")
def customer_updates_field_with_value_in_cease_msoc_customer_service_order(context, field, value):
    if value == 'null':
        value = ''

    if field in ('id', 'action', '@type'):
        context.payload["serviceOrderItem"][0][field] = value
    elif field == 'serviceType':
        context.payload["serviceOrderItem"][0]["service"][field] = value
    elif field == "op_co_customer_id":
        context.payload["externalReference"][0]["id"] = value
    else:
        raise NotImplementedError(f"{field} is not supported")

    logging.info(f"Updated request payload for cease MSOC customer is :: {utils.to_json(context.payload)}")


@then("tmfmediator_command_delete_all_numbers topic is validated")
def tmfmediator_command_delete_all_numbers_topic_is_validated(context):
    topic = 'tmfmediator_command_delete_all_numbers'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    context.ucas_provider = context.consumer_payload["delete_all_numbers"]["ucas_provider"]
    KafkaTopicValidator(context).tmfmediator_command_delete_all_numbers()


@then("numbermanagement_command_delete_all_crf_numbers topic is validated")
def numbermanagement_command_delete_all_crf_numbers_topic_is_validated(context):
    topic = 'numbermanagement_command_delete_all_crf_numbers'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    context.event_id = context.consumer_payload["header"]["event_id"]
    KafkaTopicValidator(context).numbermanagement_command_delete_all_crf_numbers()


@then("validate that service order is failed with error message")
def validate_the_service_order_is_failed_with_error_message(context, number_category=None):
    TMFHandler.send_request_to_endpoint(context, "get_service_order_by_id")
    validate_error_message_cease_account(context.response_payload, number_category)


def validate_error_message_cease_account(response, number_category):
    error_code = response["serviceOrderItem"][0]["errorMessage"][0]["code"]
    error_message = response["serviceOrderItem"][0]["errorMessage"][0]["message"]
    error_reason = response["serviceOrderItem"][0]["errorMessage"][0]["reason"]

    if number_category == 'add_msoc_numbers':
        expected_error_message = "Failed to process operation ADD_MSOC_NUMBERS"
    elif number_category == 'add_tpm_numbers':
        expected_error_message = "Failed to process operation ADD_TPM_NUMBERS"
    else:
        expected_error_message = "Failed to process operation DELETE_ALL_NUMBERS"

    asserts.field_equals(error_code, errors.ACCOUNT_NOT_FOUND, "Error Code")
    asserts.field_equals(error_message, expected_error_message, "Error Message")
    asserts.field_equals(error_reason, "Customer has not been onboarded", "Error Reason")


@given('create and send payload for numbermanagement_command_delete_all_crf_numbers with non existing MSOC account')
def create_and_send_payload_to_numbermanagement_command_delete_all_crf_numbers(context):
    topic_name = "numbermanagement_command_delete_all_crf_numbers"
    context.consumer_payload = read_xmldata.read_jsonfile(topic_name)
    common.update_middleware_correlation_id(context)
    context.event_id = context.consumer_payload["header"]["eventId"] = read_xmldata.gen_uuid()
    context.market_code = context.consumer_payload["delete_all_numbers"]["op_co_details"]["name"]
    context.op_co_customer_id = context.consumer_payload["delete_all_numbers"]["op_co_details"]["op_co_customer_id"]
    context.kafka_send_message_response = producer_data.send_data(context.consumer_payload, topic_name)


@then('validate error in crfgateway_event_all_crf_numbers_deleted')
def validate_error_crfgateway_event_all_crf_numbers_deleted(context):
    CRFHandler.validate_crf_parent_requests_in_db(context)
    CRFHandler.validate_crf_parent_request_state(context, "FAILED")
    topic = 'crfgateway_event_all_crf_numbers_deleted'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    validate_error_response_in_crfgateway_event_all_crf_numbers_deleted(context.consumer_payload)


def validate_error_response_in_crfgateway_event_all_crf_numbers_deleted(response):
    error_code = response["delete_all_numbers"]["error"]["error_code"]
    error_message = response["delete_all_numbers"]["error"]["error_message"]

    asserts.field_equals(error_code, errors.ACCOUNT_NOT_FOUND, "Error Code")
    asserts.field_equals(error_message, "Customer has not been onboarded", "Error Message")


def crfgateway_event_all_crf_numbers_deleted_topic_is_validated(context, error_type=None):
    topic = 'crfgateway_event_all_crf_numbers_deleted'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).crfgateway_event_all_crf_numbers_deleted(error_type)


def tmfmediator_command_delete_account_is_validated(context):
    topic = 'tmfmediator_command_delete_account'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).tmfmediator_command_delete_account()


def numbermanagement_event_all_numbers_deleted_is_validated(context, error_type=None):
    topic = 'numbermanagement_event_all_numbers_deleted'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).numbermanagement_event_all_numbers_deleted(error_type)


def idmapper_event_account_deleted_is_validated(context):
    topic = 'idmapper_event_account_deleted'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).idmapper_event_account_deleted()


@when("Add numbers to ceased MSOC account")
def add_numbers_to_ceased_or_existing_account(context):
    MSOCHandler.msoc_order_created_for_numbers(context, 'add', '5', 'pool', 'separate')
    customer_sends_an_order_to_middleware(context)
