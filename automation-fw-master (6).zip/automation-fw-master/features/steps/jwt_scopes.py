import logging
import os
from typing import Any

import uuid
from behave import given, then, when

from classes import asserts, read_xmldata, crf, common
from classes.api.requests import idmapper, tmf_resource_inventory
from classes.exceptions import NotFoundError
from common_python import api_requests

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("request contains a JWT with scope '{scope}'")
def validate_request_contains_jwt_scope(context: Any, scope: str) -> None:
    context.scope_requested = scope
    if scope == "__ALL_SCOPES__":
        scope = ""  # JWT server requests with "" return a JWT valid for all scopes

    if scope == "__VALID__":
        context.access_token = api_requests.AuthType.VALID
    elif scope == "__NO_JWT__":
        context.access_token = ""
    else:
        context.access_token = api_requests.get_valid_authorization(scope)


@given("request header is set for the email server")
def set_request_header_for_email_server(context: Any) -> None:
    context.header = {
        "Authorization": context.access_token,
        "Content-Type": "application/json",
        "Media-Type": "application/json",
        "X-Request-ID": str(uuid.uuid1()),
    }


@when("request for unity accounts is sent to ID Mapper API")
def response_account_request_to_id_mapper(context: Any) -> None:
    client = idmapper.Client(token=context.access_token)
    context.response = client.get_unity_accounts({'market': "VFUK"})


@when("request with non existent account is sent to ID Mapper API with '{query_type}' query")
def response_non_existent_account_request_to_id_mapper(context: Any, query_type: str) -> None:
    client = idmapper.Client(token=context.access_token)
    query = {'bgid': '1234567890'}
    if query_type == "extended":
        query["include_all_data"] = "true"
    context.response = client.get_msoc_account(query)


@when("request with non existent account is sent to Number Management API")
def response_non_existent_account_request_to_number_management(context: Any) -> None:
    NON_EXISTENT_NUMBER = "+441111111111"
    MIDDLEWARE_API_SERVER = os.environ["MIDDLEWARE_API_SERVER"]
    lookup_url = read_xmldata.readxml("lookup_url_endpoint_nummgnt", "test_inputdata", "num_prov")
    url = MIDDLEWARE_API_SERVER + lookup_url + NON_EXISTENT_NUMBER
    context.response = api_requests.get(url, token=context.access_token)


@when("request is sent to CRF gateway notification api")
def send_request_crf_gw_notification(context):
    # Below payload is the simplest payload for a non-existing resource order, only to test token
    # with correct token it will return 404 Not Found
    # with incorrect token it will return 403 Forbidden
    simplest_notification_payload = {
        "event": {
            "resourceOrder": {
                "id": "c0e8d96e-4424-11ef-9bb4-9e5d99831412",
                "state": "COMPLETED"
            }
        }
    }
    context.response = api_requests.post(url=crf.TMF652_NOTIFICATION_URL,
                                         json=simplest_notification_payload,
                                         token=context.access_token)


@then("response indicates access was '{expected_access}'")
def validate_access_response(context: Any, expected_access: str) -> None:
    for attribute in ("response", "getresponse", "postresponse"):
        if attribute in context:
            response = getattr(context, attribute)
            break
    else:
        raise NotFoundError("context has no response from previous steps")

    logger.info(f"Response status: {response.status_code}")
    match response.status_code:
        case 403:
            actual_access = "FORBIDDEN"
        case 401:
            actual_access = "UNAUTHORIZED"
        case 501:
            actual_access = "NOT_IMPLEMENTED"
        case _:
            actual_access = "ALLOWED"
    asserts.equals(actual_access, expected_access, f"API access using JWT scope '{context.scope_requested}'")


@when("request for TPM customer is sent to ID Mapper API")
def request_to_id_mapper_for_tpm_customer(context: Any) -> None:
    client = idmapper.Client(token=context.access_token)
    context.response = client.get_tpm_customer({'bgid': '1000'})


@when("request sent to TMF Service Resource Gateway API")
def request_sent_to_tmf_resource_gw_api(context):
    client = tmf_resource_inventory.Client(token=context.access_token)
    context.response = client.get_resource_by_id('628357cf767d2124cc0b60c3')
