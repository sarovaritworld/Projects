import parse
import logging

from behave import *

from common_python import api_requests
from classes import pod
from classes.status_code_validator import StatusCodeValidator


# -- TYPE CONVERTER: For a simple, positive integer number.
@parse.with_pattern(r"\d+")
def parse_number(text):
    return int(text)


# -- REGISTER TYPE-CONVERTER: With behave
register_type(Number=parse_number)


@when("an HTTP GET request is made to '{microservice}' at port '{port}' using the endpoint '{endpoint}'")
def http_get_request_to_microservice_port_endpoint(context, microservice, port, endpoint):
    pod_ips = pod.get_pod_ip(microservice)
    context.health_check_response = []
    for ip in pod_ips:
        url = "http://" + ip + ":" + port + endpoint
        logging.info(f"url: {url}")
        health_check_response = api_requests.get(url)
        logging.info(f"HTTP response: {health_check_response}")
        context.health_check_response.append(health_check_response)


@then("an HTTP response status of '{expected_http_status_code:Number}' is received")
def step_impl(context, expected_http_status_code):
    assert context.health_check_response is not None
    for response in context.health_check_response:
        StatusCodeValidator.validate_status_code_response(response.status_code, expected_http_status_code)
