import json
import logging
import os
import random
from http import HTTPStatus

from behave import given, then, when

from classes import account, asserts, common, data_files, database, payload, polling, read_xmldata, tmf
from classes.api.requests import tmf_gateway
from classes.data_factory import countries_data_manager
from classes.delay import Delay
from classes.domain.account import Contact, UnityAccount
from classes.kafka import KafkaTopics, consumer_data, producer_data, utils
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload import ServiceOrderPayload, get_last_item
from classes.payload_generators.TMF import UnityAccountPayloadGenerator
from classes.payload_generators.TMF.payload_generator import Action
from classes.status_code_validator import StatusCodeValidator
from classes.utils import strtobool
from common_python import api_requests
from common_python.stub_accounts.stub_accounts import StubAccounts
from features.steps import flowHandler, validationHandler
from features.steps import kafkaHandler
from features.steps.databaseHandler import validate_state_in_rc_initial_order_request

MAX_NUM_LIMIT = read_xmldata.readxml("MAX_NUM_LIMIT", "test_inputdata", "num_prov")
MAX_NUM_LIMIT = int(MAX_NUM_LIMIT)
API_SERVER = os.environ.get("MIDDLEWARE_API_SERVER")
TMF_URL = read_xmldata.readxml("tmf_url", "tmf_testdata", "tmf_data")
TMF_BASE_URL = "http://" + read_xmldata.readxml("tmf_base_url", "tmf_testdata", "tmf_data")

logger = logging.getLogger("TMFHandler")
stub_accounts = StubAccounts()


# Atomic step definitions:
@given("payload is created for '{order_type}' request for '{product_type}' in '{market_code}'")
def create_payload_add_unity_account(context, order_type, product_type, market_code, generate_extension=False,
                                     extension_number=None):
    context.market_code = market_code
    context.initial_license = 1
    contact = Contact()
    if generate_extension:
        contact.set_extension_number()
    if extension_number:
        contact.set_extension_number(extension_number)
    op_co_customer_id = getattr(context, "op_co_customer_id", None)
    account = UnityAccount(market_code=market_code, product_type=product_type, contact=contact, op_co_customer_id=op_co_customer_id)
    context.unity_account = account
    context.payload = UnityAccountPayloadGenerator(account, Action.add, getattr(context, 'payload', None)).to_dict()
    context.opco_details_name = common.get_field(context.payload, "relatedParty.0.id")
    context.email = account.contact.email
    context.city = account.place.city
    context.postcode = account.place.postcode
    context.country_code = account.place.country_code
    context.street = account.place.hq_street_full
    context.product_type = account.product_type
    context.currency = account.currency
    context.mobile = account.mobile
    context.op_co_customer_id = account.op_co_customer_id
    context.main_number = account.main_number
    context.category = account.category.upper()
    context.ucas_provider = account.ucas_provider
    context.service_order = context.payload['serviceOrderItem']


#  Given customer wants to retrieve  Service order list by 'state_milestone_note' field with offset '1000' and limit '10'
@given(
    "customer wants to retrieve  Service order list by '{field_type}' field with offset '{offset_value}' and limit '{limit_value}'")
def retrieve_service_order_by_field_offset(context, field_type, offset_value, limit_value):
    context.field_type = field_type

    context.param = {'fields': field_type, 'offset': offset_value, 'limit': limit_value}
    if offset_value == 'is_omitted':
        del context.param['offset']
    elif limit_value == 'is_omitted':
        del context.param['limit']
    elif field_type == 'All':
        del context.param['fields']


# Then customer validates '10' service orders in response
@then("customer validates '{expected_list_values}' service orders in response")
def validate_expected_service_orders(context, expected_list_values):
    context.execute_steps(u"""Then user validates '206' response""")
    asserts.equals(len(context.response_payload), expected_list_values, "Response List length")
    field_list = context.field_type.split(',')
    if context.field_type != 'All':
        for i in range(int(expected_list_values)):
            asserts.equals(common.is_key_present("relatedParty", context.response_payload[i]), False,
                           "presence of field relatedParty")
            asserts.equals(common.is_key_present("externalReference", context.response_payload[i]), False,
                           "presence of field externalReference")
            # logging.info(f"for loop ---> {i}")
            for field in field_list:
                asserts.equals(common.is_key_present(field, context.response_payload[i]), True,
                               f"presence of field {field}")
            # logging.info(f"for loop ---> {j}")


@when("request is sent to create Service Order {with_success}")
@when("request is sent to create Service Order")
@given("request is sent to create Service Order")
def request_is_sent_to_create_service_order(context, with_success=None):
    context.response = tmf_gateway.Client().create_service_order(context.payload)
    context.response_payload = context.response.json()
    if context.response.status_code == 201:
        context.service_order_id = context.response_payload.get('id')
    if with_success:
        assert context.response.ok


@when("request to get Service Order by id")
def request_service_order_by_id(context):
    context.response = tmf_gateway.Client().get_service_order_by_id(context.service_order_id)
    context.response_payload = context.response.json()


@when("user sends a request to '{endpoint}'")
def send_request_to_endpoint(context, endpoint):
    service_order_url = TMF_BASE_URL + "/tmf" + TMF_URL + "/serviceOrder/"
    service_order_filter_url = TMF_BASE_URL + "/tmf" + TMF_URL + "/serviceOrder"
    cancel_service_order_url = TMF_BASE_URL + "/tmf" + TMF_URL + "/cancelServiceOrder/"
    hub_url = TMF_BASE_URL + "/tmf" + TMF_URL + "/hub/"
    _payload = {}
    service_order_id = "628357cf767d2124cc0b60c3"
    context.header = {
        'Authorization': context.access_token,
        'Content-Type': 'application/json'
    }

    if endpoint == "get_service_order_list":
        context.response = api_requests.get(
            service_order_filter_url, params=context.param, token=context.access_token)

    elif endpoint == "get_service_order_by_id":
        logging.info("Getting info about Service order with id: " + context.service_order_id)
        # Micro Service require sometimes to update that service order status. So we have to wait for some times
        read_xmldata.wait_to_connect(Delay.too_long)
        # sending response
        context.response = tmf_gateway.Client().get_service_order_by_id(context.service_order_id)
        # getting payload
        context.response_payload = context.response.json()

    elif endpoint == "update_service_order":
        context.header['Content-Type'] = 'application/json-patch+json'
        url = service_order_url + context.service_order_id
        logging.info(f"Patch Request URL :{url}")
        context.response = api_requests.patch(url, data=json.dumps(context.patch_payload), headers=context.header)
        logging.info(f"Response is: {context.response}")
        if "extra_response_payloads" not in context:
            context.extra_response_payloads = []
        context.extra_response_payloads.append(context.response.json())

    elif endpoint == "delete_service_order":
        context.response = api_requests.delete(
            service_order_url + service_order_id,
            headers=context.header)

    elif endpoint == "register_events_subscription":
        logging.debug(f"context.header: {context.header}")
        logging.debug(f"Notification URL: {hub_url}")
        logging.debug(f"Notification Payload: {context.subscription_payload}")
        context.response = api_requests.post(
            hub_url, data=json.dumps(context.subscription_payload),
            headers=context.header)
        if context.response.status_code == HTTPStatus.CREATED:
            context.subscription_exists = True

    elif endpoint == "unregister_events_subscription":
        _payload = "\n"
        logging.debug(f"Notification URL: {hub_url + context.subscription_id}")
        logging.debug(f"Notification Payload: {_payload}")
        context.response = api_requests.delete(
            hub_url + context.subscription_id, data=_payload,
            headers=context.header)
        if context.response.status_code == HTTPStatus.NO_CONTENT:
            if "subscription_exists" in context:
                del context.subscription_exists

    elif endpoint == "create_cancel_service_order":
        _payload = read_xmldata.read_jsonfile("cancel_service_order")
        context.response = api_requests.post(cancel_service_order_url, data=_payload, headers=context.header)

    elif endpoint == "get_cancel_service_order_list":
        context.response = api_requests.get(cancel_service_order_url, token=context.access_token)

    elif endpoint == "retrieve_cancel_service_order_Id":
        context.response = api_requests.get(
            cancel_service_order_url + service_order_id, token=context.access_token)

    ##############################Invalid Url steps####################

    elif endpoint == "create_service_order_with_invalid_url":
        context.response = api_requests.post(service_order_url + "/abcd/", data=_payload,
                                             headers=context.header)

    ##########Invalid method steps####################
    elif endpoint == "update_service_order_with_invalid_content_type":
        url = service_order_url + context.service_order_id
        logging.info(f"Patch Request URL :{url}")
        context.response = api_requests.patch(url, data=json.dumps(context.payload), headers=context.header)
        logging.info(f"Response of {endpoint} :")
    elif endpoint == "invalid_operation_for_create_service_order":
        _payload = read_xmldata.read_jsonfile("create_service_order")
        context.response = api_requests.get(
            service_order_url, data=_payload, token=context.access_token)
    elif endpoint == "invalid_operation_for_delete_service_order":
        context.response = api_requests.get(
            service_order_url + service_order_id, headers=context.header)
    elif endpoint == "invalid_operation_for_get_service_order":
        context.response = api_requests.patch(service_order_url, headers=context.header)

    elif endpoint == "invalid_operation_for_register_events_subscription":
        _payload = read_xmldata.read_jsonfile("hub_register")
        context.response = api_requests.get(
            hub_url, data=_payload, token=context.access_token)
    elif endpoint == "invalid_operation_for_create_cancel_service_order":
        _payload = read_xmldata.read_jsonfile("cancel_service_order")
        context.response = api_requests.get(
            cancel_service_order_url, data=_payload, token=context.access_token)
    else:
        raise NotImplementedError(f'{endpoint=} is not supported')

    # unregister_events_subscription returns No Content
    if endpoint != "unregister_events_subscription":
        logging.info(f"Response from {endpoint}:")
        context.response_payload = context.response.json()
        logging.info(json.dumps(context.response_payload, indent=3))
        logging.info("")
        logging.info("")


# Given user needs to 'create_service_order' request for 'FULL_STACK_STANDARD' with 'activateImmediately' as 'false'
@given(
    "user needs to '{order_type}' request for '{product_type}' in '{currency}' with '{flow_setting}' as '{fs_value}'")
@when("user needs to '{order_type}' request for '{product_type}' in '{currency}' with '{flow_setting}' as '{fs_value}'")
def request_product_in_currency_with_setting_value(context, order_type, product_type, currency, flow_setting, fs_value):
    create_payload_add_unity_account(context, None, product_type, currency)

    fs_value = bool(strtobool(fs_value))
    context.payload['serviceOrderItem'][0]['service']['serviceCharacteristic'][2]['value'][flow_setting] = fs_value
    context.activate_immediately = fs_value


# Given user needs to 'create_service_order' request for '<product_type>' in '<currency>'
@given("user needs to '{order_type}' request for '{product_type}' in '{currency}'")
@when("user needs to '{order_type}' request for '{product_type}' in '{currency}'")
def request_order_for_product_in_currency(context, order_type, product_type, currency):
    create_payload_add_unity_account(context, None, product_type, currency)


# Given user needs to 'create_service_order' request for '<product_type>' in '<currency>'  without AdminNumber
@given("user needs to '{order_type}' request for '{product_type}' in '{currency}' without AdminNumber")
@when("user needs to '{order_type}' request for '{product_type}' in '{currency}' without AdminNumber")
def request_order_for_product_in_currency_no_adminnumber(context, order_type, product_type, currency):
    create_payload_add_unity_account(context, None, product_type, currency)

    if order_type == 'create_service_order':
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["phoneNumber"] = ""
        context.mobile = ""


# Given user sends a request for 'create_service_order' with 'invalid' JWT
@when("user sends a request for '{endpoint}' with '{token_status}' JWT")
def request_endpoint_with_token_jwt(context, endpoint, token_status):
    context.execute_steps(u"""
                                Given it contains a '{token_status}' JWT Token
                                And payload is created for '{endpoint}' request for 'FULL_STACK_STANDARD' in 'GBP'
                                """.format(token_status=token_status, endpoint=endpoint))


# And user sends a request for 'get_service_order_by_id' to TMF Service Order Gateway Microservice
# When user sends a request for 'create_service_order' to TMF Service Order Gateway Microservice
@when("user sends a patch request for '{endpoint}' to TMF Service Order Gateway Microservice")
@when("user sends a request for '{endpoint}' to TMF Service Order Gateway Microservice")
def send_patch_request_tmf_service_order_gw(context, endpoint):
    send_request_to_endpoint(context, endpoint)


# And user validates 'partial_failed_add_number' response in 'get_service_order_by_id'
# And user validates 'partial_failed_add_main_number' response in 'get_service_order_by_id'
# And user validates 'failed_create_account_for_duplicate_opco' response in 'get_service_order_by_id'
# And user validates 'completed' response in 'get_service_order_by_id'
# And user validates 'partial_failed_confirm_account' response in 'get_service_order_by_id'
# And user validates 'failed_create_account' response in 'get_service_order_by_id'
@then("user validates '{outcome}' response in '{endpoint}'")
def validate_final_state(context, outcome, endpoint=None):
    # outcome variable rules:
    # first word is expected status of SO
    # if something wrong with add account part, SO is 'blocked' (should have this word in any place)
    # if it is SO without add account, put 'only' or 'soi_only' to the outcome:
    #   that would skip validation for JIRA milestones and notes
    # if it is a case with failure, make sure you have appropriate error in get_error() method

    # status check
    status = tmf.get_status(outcome)
    logging.debug(f"validating status: {status}")

    validationHandler.validate_order_status(context, status)
    validationHandler.validate_milestones_achieved(context, outcome)

    if payload.has_initial_order(context.payload):
        if outcome in ["completed",
                       "inprogress"] or "blocked_confirm_account" in outcome or "completed_unconfirmed_account" in outcome:
            validationHandler.validate_rc_id_status_in_serviceorderitem(context, status=outcome)

    if "failed" in outcome:
        tmf.validate_error_message(context, outcome)

    # validate notes for jira and patch
    if 'blocked' not in outcome:
        for item in context.response_payload['serviceOrderItem']:
            if outcome == 'partial_failed_2accounts' and item['id'] == "2":
                continue
            item = json.dumps(item)
            context.execute_steps("""
                            Then notes updated for '{item}'
                        """.format(item=item))

    if payload.has_add_number(context.payload):
        if not hasattr(context, "pool_type") or hasattr(context, "duplicated_numbers"):
            context.execute_steps("""Then notes updated for add numbers '{outcome}'""".format(outcome=outcome))


# Then user validates the response data for 'create_service_order' from TMF Service Order API Gateway
@then("user validates the response data for '{endpoint}' from TMF Service Order API Gateway")
def validate_response_data_from_tmf_service_order_api(context, endpoint):
    if endpoint == "create_service_order":
        context.execute_steps(u"""
                                                Then user validates '201' response
                                                """)
        context.service_order_id = context.response_payload["id"]
        if hasattr(context, 'patch_milestones'):
            del context.patch_milestones
    elif endpoint == "register_events_subscription":
        logging.info(f"context.response: {context.response}")
        context.subscription_id = context.response_payload["id"]
        logging.info(f"context.subsription_id: {context.subscription_id}")
    elif endpoint == "unregister_events_subscription":
        print(f"context.response: {context.response}")
        print("")
    elif endpoint == "get_service_order_list":
        count = len(context.response.json())
        print(f"Service orders count: {count}")
        if count <= 0:
            print("No service orders returned")
    else:
        assert 1 == 0, "We are not able to validate this event: {}".format(endpoint)


@then("user retrieves and validates data in '{topic_name}' topic with '{error_type}'")
def retrieve_data_in_topic_with_error(context, topic_name, error_type):
    context.execute_steps(u"""
                            Then user can retrieve payload from '{topic_name}'
                            Then user validates the information in '{topic_name}' with '{error_type}'
                            """.format(topic_name=topic_name, error_type=error_type))


# And user retrieves and validates data in 'ordermanagement_command_create_initialorder' topic
# And user retrieves and validates data in 'tmfmediator_command_create_initialorder' topic
# And user retrieves and validates data in 'tmfmediator_status_serviceorder' topic
# And user retrieves and validates data in 'tmfgateway_process_serviceorder' topic
@then("user retrieves and validates data in '{topic_name}' topic")
def retrieve_and_validate(context, topic_name):
    if topic_name == 'crfstub_process_resourceorder' and common.config.is_staging_env:
        logging.info(f'{topic_name} does not exist on staging')
        return
    if not common.config.is_crf_add_number_enabled and topic_name in utils.crf_topics_add_number:
        logging.info('CRF is not enabled, skip this step')
        return

    # context.consumer_payload = consumer_data.get_messages(context, topic_name)
    kafkaHandler.get_messages(context, topic_name)
    kafkaHandler.validate_topic(context, topic_name)


@given("not existing service_order_id is saved in context")
def set_service_order_id_if_non_existent(context):
    context.service_order_id = "7746253"


@then("validating the service order")
def validate_service_order(context):
    assert len(context.response.text) > 0, "Service order is empty"


# And user retrieves and validates 'error_message' from  'ordermanagement_event_order_completed'
@then("user retrieves and validates '{message_type}' from '{topic_name}'")
def retrieve_message_from_topic(context, message_type, topic_name):
    context.execute_steps(u"""
                            Then user can retrieve payload from '{topic_name}'
                            Then user validates '{message_type}' in '{topic_name}'
                            """.format(topic_name=topic_name, message_type=message_type))


# When user needs to 'create_service_order' request for 'FULL_STACK_PREMIUM' in 'GBP' with duplicate OpcoAccount ID and 'different' Market ID

@given(
    "user needs to '{order_type}' request for '{product_type}' in '{currency}' with duplicate OpcoAccount ID and '{field_type1}' Market ID")
@when(
    "user needs to '{order_type}' request for '{product_type}' in '{currency}' with duplicate OpcoAccount ID and '{field_type1}' Market ID")
def request_product_in_currency_with_duplicate_opcoaccount_id(context, order_type, product_type, currency, field_type1):
    create_payload_add_unity_account(context, None, product_type, currency)

    context.payload['externalReference'][0]['id'] = context.initial_opco_account_id
    context.op_co_customer_id = context.initial_opco_account_id
    if field_type1 == "same":
        context.payload['relatedParty'][0]['marketCode'] = context.market_code
    elif field_type1 == "different":
        context.market_code_2 = countries_data_manager.get_different_market_code(context.market_code)
        context.payload['relatedParty'][0]['id'] = context.market_code_2
        context.payload['relatedParty'][0]['marketCode'] = context.market_code_2

    else:
        assert 1 == 0, "Nothing is matched"
    context.opco_details_name = common.get_field(context.payload, "relatedParty.0.id")


# Given user creates and sends initial 'create_service_order' request for 'FULL_STACK_PREMIUM' in 'GBP'
@given("user creates and sends initial '{order_type}' request for '{product_type}' in '{currency}'")
def create_initial_request_for_product_in_currency(context, order_type, product_type, currency):
    create_payload_add_unity_account(context, None, product_type, currency)

    context.response = tmf_gateway.Client().create_service_order(context.payload)
    context.response_payload = context.response.json()

    context.execute_steps("""
                            Then user validates the response data for 'create_service_order' from TMF Service Order API Gateway
                            Then user validates payload is present in 'tmfgateway_process_serviceorder'

                            #create Account
                            Then user retrieves and validates data in 'tmfmediator_command_create_initialorder' topic
                            Then user retrieves and validates data in 'ordermanagement_command_create_initialorder' topic
                            Then user retrieves and validates data in 'ringcentral_event_initialorder_created' topic
                            Then user retrieves and validates data in 'ordermanagement_event_account_created' topic

                            Then user retrieves and validates data in 'tmfmediator_create_addnumbers' topic
                            Then user retrieves and validates data in 'numbermanagement_command_add_numbers' topic
                            Then user retrieves and validates data in 'ringcentral_event_numbers_added' topic
                 
                            Then user retrieves and validates data in 'numbermanagement_respond_numbersadded' topic
                            Then user retrieves and validates data in 'tmfmediator_command_update_accountstatus' topic

                            Then user retrieves and validates data in 'ordermanagement_command_update_accountstatus' topic
                            Then user retrieves and validates data in 'ringcentral_event_accountstatus_updated' topic
                            Then user retrieves and validates data in 'ordermanagement_event_order_completed' topic
                            """.format(order_type=order_type, product_type=product_type, currency=currency))
    # save opco_account_id into payload in order to use it as duplicate
    context.initial_opco_account_id = context.op_co_customer_id


# Given user needs to 'create_service_order' request with 'blank_related_party' for 'FULL_STACK_STANDARD' in 'GBP'
@given("user needs to '{order_type}' request with '{field_type}' for '{product_type}' in '{currency}'")
@when("user needs to '{order_type}' request with '{field_type}' for '{product_type}' in '{currency}'")
def request_order_with_field_for_product_in_currency(context, order_type, product_type, field_type, currency):
    create_payload_add_unity_account(context, None, product_type, currency)

    setting, error_type = None, None
    try:
        setting, error_type = field_type.split(':')
    except ValueError:
        pass

    so_payload = ServiceOrderPayload(context.payload)
    if field_type == "blank_related_party":
        context.payload["relatedParty"][0]["id"] = ""
        context.payload["relatedParty"][0]["@type"] = ""
        context.payload["relatedParty"][0]["@referredType"] = ""
        context.payload["relatedParty"][0]["role"] = ""
        context.payload["relatedParty"][0]["countryCode"] = ""
        context.payload["relatedParty"][0]["marketCode"] = ""

    elif field_type == "blank_external_reference_market_account_Id":
        so_payload.set_external_reference("MARKET_ACCOUNT_ID", "")

    elif field_type == "blank_billing_account_number":
        characteristic = so_payload.get_characteristic(name="TenantInfo")
        characteristic["value"]["billingAccountNumber"] = ""

    elif field_type == "blank_billing_service_reference":
        characteristic = so_payload.get_characteristic(name="TenantInfo")
        characteristic["value"]["billingServiceReference"] = ""

    elif field_type == "duplicate_external_reference_order_reference":
        ref = so_payload.get_external_reference("ORDER_REFERENCE")
        so_payload.add_external_reference(ref)

    elif field_type == "blank_external_reference_order_reference":
        so_payload.set_external_reference("ORDER_REFERENCE", "")

    elif field_type == "blank_opportunity_ID":
        characteristic = so_payload.get_characteristic(name="TenantInfo")
        characteristic["value"]["opportunityId"] = ""

    elif field_type == "service_order_item_not_present":
        del context.payload["serviceOrderItem"]

    elif field_type == "service_order_item_ID_not_present":
        del context.payload["serviceOrderItem"][0]["id"]

    elif field_type == "blank_service_order_item_action":
        context.payload["serviceOrderItem"][0]["action"] = ""

    elif field_type == "blank_service_order_item_service":
        del context.payload["serviceOrderItem"][0]["service"]

    elif field_type == "blank_service_order_item_service_type":
        context.payload["serviceOrderItem"][0]["service"]["serviceType"] = ""

    elif field_type == "blank_place":
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["@baseType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["@type"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["role"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["streetName"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["city"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["postcode"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["country"] = ""

    elif field_type == "blank_tenant_info":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["valueType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["@type"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["profile"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "mainNumber"] = ""

    elif field_type == "blank_tenant_admin_info":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["valueType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["@type"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"][
            "@schemaLocation"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["firstName"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["lastName"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["email"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"][
            "phoneNumber"] = ""

    elif field_type == "invalid_payload":
        context.payload["serviceOrderItem"][0] = ""

    elif field_type == "service_order_item_ID_not_unique":
        duplicate_item = context.payload["serviceOrderItem"][0]
        context.payload["serviceOrderItem"].append(duplicate_item)

    elif field_type == "invalid_profile_tenant_info":
        profile = context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["profile"]
        Final_profile = profile.replace("_", "  ")
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "profile"] = Final_profile

    elif 'extension' in field_type:
        lower_boundary = 5
        upper_boundary = 8
        code_dict = {
            'lower_boundary': lower_boundary,
            'upper_boundary': upper_boundary,
            'more_than': random.randrange(upper_boundary, upper_boundary + 10),
            'less_than': random.randrange(0, lower_boundary),
            'string': 'astring',
            'blank': ''
        }
        payload.update_payload_with_tenant_config(context, 'Extension', code_dict[error_type])

    elif 'sso' in field_type:
        code_dict = {
            'not_url': 'ftp://test',
            'wrong_http': 'http:/test.com',
            'http': 'http://test.com',
            'https': 'https://test.com',
            'blank': ''
        }
        payload.update_payload_with_tenant_config(context, 'SSO', code_dict[error_type])

    elif setting in payload.tenant_flow_settings:
        code_dict = {
            'string': 'test',
            'blank': ''
        }
        logging.info(context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0])
        # index is hardcoded fot that test
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][2]['value'][setting] = code_dict[
            error_type]

    else:
        raise NotImplementedError(f"{field_type} is not implemented")

    logging.info("Altered initial payload:")
    logging.info(json.dumps(context.payload, indent=3))


# Then user validates the response data for 'blank_related_party' from TMF Service Order API Gateway
@then("user validates the error response for '{invalid_fields}' from TMF Service Order API Gateway")
def validate_error_for_field_from_tmf_service_order_api(context, invalid_fields):
    StatusCodeValidator.validate_status_code_response(context.response.status_code, '400')

    # check if expected message exists in the YAML config
    expected_messages = data_files.read_config("tmf.yml", "TMF_gateway_error_messages")
    if error_message_expected := expected_messages.get(invalid_fields):
        split_error_message = error_message_expected.splitlines()
    else:
        # otherwise use the old XML config
        error_message_expected = read_xmldata.readxml(invalid_fields, "tmf_testdata",
                                                      "TMF_gateway_error_message")
        split_error_message = error_message_expected.split("|")
    logging.debug(f"Expected error message: {split_error_message}")
    logging.debug(f'Actual error message: {context.response_payload["message"]}')
    logging.info(f"Expected message: {split_error_message}")

    for single_message in split_error_message:
        logging.debug(single_message)
        assert single_message in context.response_payload[
            "message"], "message does not match. Actual value = {} and Expected Value = {}  ".format(
            context.response_payload["message"], single_message)


@given("customer orders '{action}' account for '{product_type}' in '{market_code}' market")
def order_account_for_product(context, action, product_type, market_code):
    payload.prepare_account_payload(context, action, product_type, market_code)


@given("customer orders '{action}' '{quantity}' '{items}' for '{sku_id}'")
def order_action_for_sku_id(context, action, quantity, items, sku_id):
    context.payload = payload.append_item_to_payload(context, items, action)
    context.payload = payload.refresh_ids(context.payload)

    logging.debug("Complex SO Item payload:")
    logging.debug(json.dumps(context.payload, indent=3))


@then("user validates '{count}' items in context")
def validate_item_in_context(context, count):
    logging.debug(context.service_order)
    asserts.equals(len(context.service_order), count, 'count of requested services')


@given("automation-fw saves first email and mobile to the context")
def save_first_email_and_mobile_to_context(context):
    context.email = context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["email"]
    context.mobile = context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"][
        "phoneNumber"]
    context.main_number = context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
        "mainNumber"]
    context.two_accounts = True


@given("customer does not want to activate account immediately")
def delay_account_activation(context):
    payload.update_payload_activate_immediately(context, False)


@given("GET for '{outcome}' is received")
def validate_get_outcome_received(context, outcome):
    context.response_payload = read_xmldata.read_jsonfile(f'GET_payloads/{outcome}')
    context.service_order_id = context.response_payload['id']
    context.payload = read_xmldata.read_jsonfile('GET_payloads/pool_internal_server_error_initialpayload')

    if 'NOK' in outcome:
        context.RC_ID = '88528765371'
        context.payload = read_xmldata.read_jsonfile('GET_payloads/pool_OK_NOK_initialpayload')

    context.ucas_provider = 'RINGCENTRAL'
    context.main_number = "+441155766373"
    context.number_type = outcome


@given("Service order is updated with '{config}'")
def update_service_order_config(context, config):
    context.tenant_config = config
    payload.update_payload_with_tenant_config(context, config)
    context.service_order_item_id = "1"


@when("operations team sets the operation to '{status}' state for '{config}'")
def support_topic_sent(context, status, config):
    logger.info(f"context.response_payload= \n{json.dumps(context.response_payload, indent=2)}")
    # by default, json payload contains "OPERATION_FAILED" for SSO
    if 'SSO' in config:
        operation_id = context.sso_operation_id
    elif 'MSOC' in config:
        number_item = get_last_item(context.response_payload)
        index = context.response_payload['serviceOrderItem'].index(number_item)
        context.service_order_item_id = context.response_payload['serviceOrderItem'][index]['id']
        if config == 'MSOC':
            poolType = context.response_payload["serviceOrderItem"][index]['service']['supportingResource'][0][
                'resourceCharacteristic'][0]['value']['@type']

        context.msoc_action = context.response_payload["serviceOrderItem"][index]['action']
        with database.open_database("tmf-mediator", "service_order_operation") as db:
            operation = "DELETE_MSOC_NUMBERS" if context.msoc_action == "delete" else "ADD_MSOC_NUMBERS"

            if 'CEASE_MSOC_CUSTOMER' in config:
                operation = 'DELETE_ALL_NUMBERS'

            document = polling.wait_until(
                lambda: db.collection.find({"serviceOrderId": context.service_order_id, "operation": operation}),
                'tmf mediator document')
            document = document[0]
            operation_id = str(document['_id'])
    elif 'SNOW' in config:
        operation_id = database.get_operation_id_by_service_order_operation('SNOW_ONBOARDING', context.service_order_id)
    elif 'TPM_NUMBERS' in config:
        operation_id = database.get_operation_id_by_service_order_operation(config, context.service_order_id)
    elif 'CEASE_TPM_CUSTOMER' in config:
        number_item = get_last_item(context.response_payload)
        index = context.response_payload['serviceOrderItem'].index(number_item)
        context.service_order_item_id = context.response_payload['serviceOrderItem'][index]['id']
        context.tpm_action = context.response_payload["serviceOrderItem"][index]['action']
        operation = 'DELETE_ALL_NUMBERS'
        operation_id = database.get_operation_id_by_service_order_operation(operation, context.service_order_id)
    else:
        operation_id = context.extension_operation_id
    topic_name = "support_command_update_suspended_operation"
    context.kafka_payload = read_xmldata.read_jsonfile(topic_name)
    context.kafka_payload['header']['middleware_correlation_id'] = context.middleware_correlation_id
    context.kafka_payload['header']['event_id'] = read_xmldata.gen_uuid()
    context.kafka_payload['header']['timestamp'] = read_xmldata.get_current_datetime()
    context.kafka_payload['tmf_service_order_operation']['operation_state'] = status
    context.kafka_payload['tmf_service_order_operation']['service_order_id'] = context.service_order_id
    context.kafka_payload['tmf_service_order_operation']['service_order_item_id'] = context.service_order_item_id
    context.kafka_payload['tmf_service_order_operation']['operation_id'] = operation_id
    if status == "OPERATION_FAILED":
        if "Extension" in config:
            context.kafka_payload['tmf_service_order_operation']['error']['error_message'] = \
                context.kafka_payload['tmf_service_order_operation'][
                    'note_text'] = f"Failed to change the extension limit for {context.ucas_provider} account"
        elif 'MSOC' == config:
            if context.msoc_action == "delete":
                error_message = "Failed to delete requested numbers from pool in CRF"
            else:
                error_message = "CRF Provisioning failed: One or more numbers could not be added in CRF"
            context.kafka_payload['tmf_service_order_operation']['error']['error_message'] = error_message
            if 'UccMsocNumberPoolRange' in poolType:
                msoc_poolType = 'poolRange'
            else:
                msoc_poolType = 'pool'
            context.kafka_payload['tmf_service_order_operation'][
                'note_text'] = f"Failed to {context.msoc_action} numbers from {msoc_poolType} {context.number_pool_list} in CRF"
        elif 'CEASE_MSOC_CUSTOMER' in config:
            if context.msoc_action == "delete":
                error_message = f" Failed to delete all numbers in CRF for account {context.op_co_customer_id} in market {context.market_code}"
            context.kafka_payload['tmf_service_order_operation']['error']['error_message'] = error_message
            context.kafka_payload['tmf_service_order_operation']['note_text'] = error_message
        elif 'CEASE_TPM_CUSTOMER' in config:
            if context.tpm_action == "delete":
                error_message = f"Failed to delete all numbers in TPM for account {context.op_co_customer_id} in market {context.market_code}"
            context.kafka_payload['tmf_service_order_operation']['error']['error_message'] = error_message
            context.kafka_payload['tmf_service_order_operation']['note_text'] = error_message
        elif 'SSO' in config:
            # keep original text
            pass
        else:
            context.kafka_payload['tmf_service_order_operation']['note_text'] = 'Some note text'
            context.kafka_payload['tmf_service_order_operation']['error']['error_message'] = 'Some error text'

    elif status == "OPERATION_COMPLETED":
        del context.kafka_payload['tmf_service_order_operation']['error']
        context.kafka_payload['tmf_service_order_operation'][
            'note_text'] = "SSO Configuration modified for RINGCENTRAL account"
        if "Extension" in config:
            context.kafka_payload['tmf_service_order_operation'][
                'note_text'] = f"Extension limit for RINGCENTRAL account modified to {context.max_extension_length}"
        elif "TPM" in config:
            context.kafka_payload['tmf_service_order_operation'][
                'note_text'] = f"Added numbers to pool {context.tpm_numbers.pool} in TPM".replace("'", "")
    elif status == "RETRY_TMF_OPERATION":
        context.kafka_payload['header']['event_type'] = status
        del context.kafka_payload['tmf_service_order_operation']['operation_state']
        del context.kafka_payload['tmf_service_order_operation']['note_text']
        del context.kafka_payload['tmf_service_order_operation']['error']
    context.kafka_send_message_response = producer_data.send_data(context.kafka_payload, topic_name)


@given("payload external reference '{name}' is set to '{value}'")
def set_external_payload_reference(context, name, value):
    ServiceOrderPayload(context.payload).set_external_reference(name, value)


@given("service order for '{market}' with '{state}' field")
def service_order_with_state_field(context, market: str, state: str):
    create_payload_add_unity_account(context, order_type=None, product_type='FULL_STACK_STANDARD', market_code=market)
    context.payload['externalReference'][0][
        'id'] = context.op_co_customer_id = f'SAVE{read_xmldata.gen_opco(marketplace="TMF")}'
    if market.startswith("MNC"):
        context.payload["relatedParty"][0].update({"id": "MNC", "marketCode": "MNC"})
    context.opco_details_name = common.get_field(context.payload, "relatedParty.0.id")
    context.market_code = common.get_field(context.payload, "relatedParty.0.marketCode")
    context.payload["serviceOrderItem"][0]["service"]["place"][0].update({"stateOrProvince": state})
    context.state = context.payload["serviceOrderItem"][0]["service"]["place"][0]["stateOrProvince"]
    context.action = context.payload["serviceOrderItem"][0]["action"]
    logging.info(f"Request Payload is : {context.payload}")


@given("Middleware receives and processes create account request from '{market}' for '{state}'")
def process_create_account_request_mw(context, market, state):
    service_order_with_state_field(context, market, state)
    request_is_sent_to_create_service_order(context)
    StatusCodeValidator.validate_status_code_response(context.response.status_code, 201)
    context.service_order_id = context.response.json()["id"]
    data_in_tmfgateway_process_serviceorder_topic_is_validated(context)


@given("Create service order request from '{market}' with '{state}'")
def create_service_order_request(context, market, state):
    service_order_with_state_field(context, market, state)
    if state.startswith("Blank"):
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["stateOrProvince"] = ""
    if state.startswith("missing"):
        del context.payload["serviceOrderItem"][0]["service"]["place"][0]["stateOrProvince"]
    logging.info(f"Updated payload :: {context.payload}")


@then('data in tmfgateway_process_serviceorder topic is validated')
def data_in_tmfgateway_process_serviceorder_topic_is_validated(context):
    topic_name = 'tmfgateway_process_serviceorder'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    context.middleware_correlation_id = context.consumer_payload["header"]["middlewareCorrelationId"]
    KafkaTopicValidator(context).validate_topic(topic_name)


@then('data in tmfmediator_command_create_initialorder topic is validated')
def data_in_tmfmediator_command_create_initialorder_topic_is_validated(context):
    topic_name = 'tmfmediator_command_create_initialorder'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    context.tmfmediator_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
    context.middleware_correlation_id = context.consumer_payload["header"]["middleware_correlation_id"]
    context.marketplaceEventID = context.consumer_payload["order"]["marketplace_event_id"]
    context.marketplace = context.consumer_payload["order"]["marketplace"]
    KafkaTopicValidator(context).validate_topic(topic_name)


@then('data in ordermanagement_command_create_initialorder topic is validated')
def data_in_ordermanagement_command_create_initialorder_topic_is_validated(context):
    topic_name = 'ordermanagement_command_create_initialorder'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    KafkaTopicValidator(context).validate_topic(topic_name)


@when("data is passed to RC successfully")
def data_is_passed_to_rc_successfully(context):
    data_in_tmfmediator_command_create_initialorder_topic_is_validated(context)
    data_in_ordermanagement_command_create_initialorder_topic_is_validated(context)
    validate_state_in_rc_initial_order_request(context)
    context.execute_steps("""
        Then user retrieves and validates data in 'ringcentral_event_initialorder_created' topic
        And user retrieves and validates data in 'ordermanagement_event_account_created' topic
        """)
    flowHandler.main_number_is_added(context)


@when("data is passed to CRF successfully")
@when("CRF updates the resource order with {state} state")
def data_is_passed_to_crf_successfully(context, state='completed'):
    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_command_add_crfnumber')
    KafkaTopicValidator(context).validate_topic('numbermanagement_command_add_crfnumber')

    context.execute_steps(f"""
    Then CRF id saved in DB
    And state of CRF request is 'acknowledged' in DB
    And user retrieves and validates data in 'crfstub_process_resourceorder' topic
    When CRF notification is sent with status '{state}'
    Then state of CRF request is '{state}' in DB
    """)
    error_type = "CRF_Error" if state == 'failed' else None
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_crfnumber_added')
    KafkaTopicValidator(context).validate_topic('crfgateway_event_crfnumber_added', error_type=error_type)


@then("account is created successfully")
def account_is_created_successfully(context):
    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_respond_numbersadded')
    KafkaTopicValidator(context).validate_topic('numbermanagement_respond_numbersadded')

    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_update_accountstatus')
    KafkaTopicValidator(context).validate_topic('tmfmediator_command_update_accountstatus')

    flowHandler.account_confirmed(context)


@when('data is passed to RC')
def data_is_passed_to_rc(context):
    data_in_tmfmediator_command_create_initialorder_topic_is_validated(context)
    data_in_ordermanagement_command_create_initialorder_topic_is_validated(context)
    context.execute_steps("""
            Then user retrieves error message from 'ringcentral_event_initialorder_created'""")


def validate_service_order_final_state(context, state='completed'):
    """ step for final step validation which includes the first call to GET service order by id"""
    context.response = tmf_gateway.Client().get_service_order_by_id(context.service_order_id)
    context.response_payload = context.response.json()
    validate_final_state(context, state)


@given("Service order is created for add account to fail with {error}")
def service_order_created_with_error(context, error):
    create_payload_add_unity_account(context, None, "FULL_STACK_STANDARD", "VFUK")
    update_service_order_with_error(context, error)


@when("Service order is updated with {error}")
def update_service_order_with_error(context, error):
    if hasattr(stub_accounts.rc, error):
        op_co_id = stub_accounts.rc.__getattribute__(error)
        context.op_co_customer_id = op_co_id + read_xmldata.gen_contact(4)
    else:
        raise NotImplementedError(f"Not implemented for {error}")

    common.create_or_update_key(context.payload, "externalReference[0].id", context.op_co_customer_id)


@then("Service order is {outcome} for initial order with {error}")
def initial_order_failed_with_error(context, outcome, error):
    retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    retrieve_and_validate(context, KafkaTopics.tmfmediator_command_create_initialorder.name)
    retrieve_and_validate(context, KafkaTopics.ordermanagement_command_create_initialorder.name)
    retrieve_data_in_topic_with_error(context, KafkaTopics.ringcentral_event_initialorder_created.name, error)
    retrieve_data_in_topic_with_error(context, KafkaTopics.ordermanagement_event_order_completed.name, error)
    state = "inProgress" if outcome == 'suspended' else outcome
    validationHandler.validate_order_status(context, state)
    if outcome == 'failed':
        tmf.validate_error_message(context, error)


@when("kafka message for topic tmfmediator_command_create_initialorder is sent with {parameter}")
def payload_created_sent_to_tmfmediator_command_create_initialorder(context, parameter=None):
    topic_name = "tmfmediator_command_create_initialorder"
    context.payload = read_xmldata.read_jsonfile(f"{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.marketplaceEventID = context.payload["order"]["marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.op_co_customer_id = context.payload["order"]["op_co_details"]["op_co_customer_id"] = read_xmldata.gen_opco(
        marketplace="TMF")

    path = 'order.op_co_details.'

    if parameter == "existing_customer_id":
        value = account.EXISTING_UNITY_ACCOUNT["account_number"]
    else:
        value = ""

    replace_data = {
        'blank_op_co_customer_id': f'{path}op_co_customer_id',
        'blank_op_co_name': f'{path}name',
        'blank_country': 'order.company.location.head_quarters_address.country',
        'existing_customer_id': f'{path}op_co_customer_id'
    }
    common.create_or_update_key(context.payload, replace_data[parameter], value)
    logging.info(f"{context.payload=}")
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)
