import errno
import logging

from fastapi import FastAPI, Body, Header, Request
from starlette.responses import JSONResponse
from classes import read_xmldata, data_files, database
import socket
import uvicorn
import json
import time
import os

from classes.delay import Delay

MAX_PORT_RANGE = 10

app = FastAPI(title="AppDirect Stub",
              openapi_tags=[{"name": "appdirect Token"}, {"name": "Initial Order API"}, {"name": "Change License API"}])


@app.middleware("http")
async def loginfo(request: Request, call_next):
    # start_time = time.time()
    # logger.info(request)
    # logger.info(f"API Request: {request.method}, {request.url} execution started at :{start_time}")
    # print("API Request URL is: {}".format(request.url))
    # print("API Request Query Param is: {}".format(request.query_params))
    # print("API Request header is: {}".format(request.headers))
    # print("API Request Path_params is: {}".format(request.path_params))
    # print("API request Body is : {}".format(request.body)) //print object
    response = await call_next(request)
    return response


@app.post("/appdirect/token", tags=["appdirect Token"])
async def appdirect_token(Authorization_Token: str = Header(default="")):
    # print(Authorization_Token)
    Authpayload = read_xmldata.read_jsonfile("AuthTokenResponse")
    return JSONResponse(content=Authpayload, status_code=200)


@app.get("/appdirect/{marketplace_eventID_initialorder}", tags=["Initial Order API"])
def full_stack_event(marketplace_eventID_initialorder: str, Content_Type: str = Header(default=""),
                     Authorization: str = Header(default="")):
    print(Authorization)
    print(Content_Type)
    print("UUID for InitialOrder : {}".format(marketplace_eventID_initialorder))
    product_type = read_xmldata.readxml("product_type", "test_inputdata", "appdirectinput")

    if product_type == "master device":
        appdirect_Payload = read_xmldata.read_jsonfile("Master_Device")
        print("Master device Payload sent to Webhook Ingester :", json.dumps(appdirect_Payload, indent=3))
        read_xmldata.update_xml("product_type", "")
        return JSONResponse(content=appdirect_Payload, status_code=200)

    elif product_type == "addon device":
        appdirect_Payload = read_xmldata.read_jsonfile("Addon_Device")
        print("Addon device Payload sent to Webhook Ingester :", json.dumps(appdirect_Payload, indent=3))
        read_xmldata.update_xml("product_type", "")
        return JSONResponse(content=appdirect_Payload, status_code=200)

    elif "bearer " in Authorization.lower():
        appdirect_Payload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        appdirect_Payload['creator']['uuid'] = read_xmldata.gen_uuid()
        appdirect_Payload["payload"]["configuration"]["subscriptionId"] = read_xmldata.gen_uuid()

        print(appdirect_Payload)
        # print("InitialOrder Payload sent to Webhook Ingester :", json.dumps(appdirect_Payload, indent=3))
        return JSONResponse(content=appdirect_Payload, status_code=200)
    else:
        appdirect_Payload = ""
        print("We are unable to send this payload")
        return JSONResponse(content=appdirect_Payload, status_code=200)
    # return JSONResponse(content=appdirect_Payload, status_code=200)


@app.post("/api/integration/v1/events/{marketplace_eventID}/result", tags=["appdirect Token"])
async def appdirect_error(marketplace_eventID: str, req: dict, Authorization: str = Header(default=""),
                          Content_Type: str = Header(default="")):
    # print(Authorization)
    # print(Content_Type)
    # print("API Request Details: {}".format(req))
    print("UUID for : {}".format(marketplace_eventID))
    # error_msg = req["message"]
    # read_xmldata.update_xml("error_msg", error_msg)
    responsePayload = req
    respo = read_xmldata.write_jsonfile("responder_error_payload", responsePayload)
    Authpayload = read_xmldata.read_jsonfile("AuthTokenResponse")
    return Authpayload


@app.get("/appdirect/change_license_event2/{marketplace_eventID_changelicense}", tags=["Change License API"])
async def changeLicense(marketplace_eventID_changelicense: str, Content_Type: str = Header(default=""),
                        Authorization: str = Header(default="")):
    # print(Authorization)
    # print(Content_Type)
    print("UUID for change_license: {}".format(marketplace_eventID_changelicense))
    if "Bearer " in Authorization:
        changeLicensepayload = read_xmldata.read_jsonfile("changeLicensepayload")
        # changeLicensepayload["payload"]["account"]["accountIdentifier"] = RC_ID
        # changeLicensepayload["payload"]["account"]["accountIdentifier"] = "130875004"
        print("ChangeLicense Payload sent to Webhook Ingester :", json.dumps(changeLicensepayload, indent=3))
        return JSONResponse(content=changeLicensepayload, status_code=200)


@app.get("/purchaseaddon/{marketplace_eventID_purchaseaddon}", tags=["addons API"])
async def changeaddons(marketplace_eventID_purchaseaddon: str, Content_Type: str = Header(default=""),
                       Authorization: str = Header(default="")):
    # print(Authorization)
    # print(Content_Type)
    print("UUID for purchaseaddon: {}".format(marketplace_eventID_purchaseaddon))
    if "Bearer " in Authorization:
        addonspayload = read_xmldata.read_jsonfile("AdditionalNumbers")
        print("Purchaseaddon Payload sent to Webhook Ingester :", json.dumps(addonspayload, indent=3))
        return JSONResponse(content=addonspayload, status_code=200)


@app.get("/changeaddonlic/{marketplace_eventID_changelicense}", tags=["change addons lic API"])
async def changeaddons(marketplace_eventID_changelicense: str, Content_Type: str = Header(default=""),
                       Authorization: str = Header(default="")):
    # print(Authorization)
    # print(Content_Type)
    time.sleep(Delay.too_long)
    print("UUID for change addonLic: {}".format(marketplace_eventID_changelicense))
    if "Bearer " in Authorization:
        addonspayload = read_xmldata.read_jsonfile("AddonChangeLicense")
        print("Change addon Lic Payload sent to Webhook Ingester :", json.dumps(addonspayload, indent=3))
        return JSONResponse(content=addonspayload, status_code=200)


@app.api_route("/endpoint/notification", methods=["POST", "PUT"], tags=["OperationStatus"])
async def operation_status(*, Authorization: str = Header(default=""), request: Request):
    payload = await request.json()
    logging.info(f"Stub req: {payload}")
    if "Bearer " in Authorization:
        data_files.write("OperationStatusEndNotification", payload)
    return JSONResponse(content={}, status_code=200)


@app.post("api/integration/v1/events/{responderid}/result", tags=["Initial Order API"])
async def appdirectresponder(*, responderid: str, Content_Type: str = Header(default=""),
                             Authorization: str = Header(default=""), request: Request):
    # print(Authorization)
    # print(Content_Type)
    print("UUID for InitialOrder : {}".format(responderid))
    responsePayload1 = await request.body()
    responsePayload = responsePayload1.decode("utf-8")
    print("Stub req: {}".format(responsePayload))
    if "Bearer " in Authorization:
        print("inside appdirectresponder API")
        error_msg = request["message"]
        read_xmldata.update_xml("error_msg", error_msg)
        # Fullstackpayload = read_xmldata.readjsonfile("FullStackOrderEventResponse")
        # print("InitialOrder Payload sent to Webhook Ingester :", json.dumps(Fullstackpayload, indent=3))
    return JSONResponse(content={}, status_code=200)


@app.post("/v1/customers/{vfid}")
def create_customer(vfid: str, response_payload: dict):
    print(f'data factory service call for /v1/customers/{vfid}')
    response_payload['endpoint'] = 'customers'
    print(response_payload)
    read_xmldata.write_jsonfile("datafactory_status", response_payload)
    return JSONResponse(content={}, status_code=201)


@app.post("/v1/customers/{vfid}/bucket")
async def create_bucket(vfid: str):
    print(f'data factory service call for /v1/customers/{vfid}/bucket')
    status = read_xmldata.read_jsonfile("datafactory_status")
    status['endpoint'] = 'bucket'
    print(status)
    read_xmldata.write_jsonfile("datafactory_status", status)
    return JSONResponse(content={}, status_code=201)


@app.post("/listener/serviceOrderCreateEvent")
def DXLNotificationPost(subscription_test_id: str | None = None, payload: dict = Body(), Authorization: str = Header(default="")):
    logging.debug("test for call")
    logging.debug(Authorization)
    payload['source'] = 'automation-fw'
    payload['is_authorized'] = Authorization
    payload['subscription_test_id'] = subscription_test_id
    logging.info(f"Saving notification to DB: {payload}")
    try:
        with database.open_database('automation-fw', 'tmf-notifications') as db:
            logging.debug('inserting document')
            output = db.save_document(payload)
            logging.debug(output.inserted_id)
    # whenever we encounter a specific mongo exception, except clause for that Exception should be added
    except Exception:
        return JSONResponse(content={'error': 'Failed to save notification'}, status_code=500)
    return JSONResponse(content={'response': 'SUCCESS'}, status_code=201)


def find_available_port(host_ip: str) -> int:
    port_base = int(os.environ["APPDIRECT_STUB_PORT"])
    for offset in range(MAX_PORT_RANGE):
        port = port_base + offset
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind((host_ip, port))
            logging.info(f"Port {port} is available")
            break
        except socket.error as e:
            if e.errno == errno.EADDRINUSE:
                logging.info(f"Port {port} is already in use")
    else:
        raise Exception("No port available")
    return port


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    hostname = socket.gethostname()
    host_ip = socket.gethostbyname(hostname)
    port = find_available_port(host_ip)
    pid = os.getpid()

    data = {"pid": pid, "host": host_ip, "port": port, "url": f"http://{host_ip}:{port}"}
    data_files.write("appdirect_stub_server", data)

    logging.info(f"Start appdirect stub: {hostname=}, {host_ip=}, {port=}, {pid=}")
    uvicorn.run(app, host=host_ip, port=port)
