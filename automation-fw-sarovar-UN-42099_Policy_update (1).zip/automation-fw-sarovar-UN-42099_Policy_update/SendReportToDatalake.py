#!/usr/bin/env python3
"""
Script sending behave reports to DataLake.

It will also add extra information to the reports.
"""
import argparse
import json
import os
import re
import time
from datetime import datetime, timezone

import google.auth.crypt
import google.auth.jwt
import requests
from kubernetes import client, config

# please change the below lines to reflect your requirements:
ENVIRONMENT_NAME = os.environ.get("ENVIRONMENT_NAME")
serviceaccount_keyfile = r"/var/secrets/DatalakeAuthkey.json"
serviceaccount_email = 'grouptesting@vf-grp-ucc-tst-data-01.iam.gserviceaccount.com'
audience = 'lake-data-ucc-vodafone-com-api-l2t6upeioa-ew.a.run.app'

endpoint_url = 'https://lake-data-ucc-vodafone-com-api-l2t6upeioa-ew.a.run.app/v1/customers/grouptesting'
THIS_DIR = os.path.dirname(os.path.abspath(__file__))


def get_cli_arguments() -> argparse.Namespace:
    """Get command line arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--tags', required=True, help="TC ID")
    parser.add_argument('--input-file', help="Input JSON report file")
    parser.add_argument('--output-file', help="Output JSON report file (default: overwrite input file)")
    parser.add_argument('--debug', action="store_true", help="Skip sending to Datalake")
    args = parser.parse_args()
    if not args.input_file:
        args.input_file = os.path.join(THIS_DIR, "report_" + args.tags + ".json")
    if not args.output_file:
        args.output_file = args.input_file
    return args


def main() -> None:
    args = get_cli_arguments()

    print(f"Read JSON report file: {args.input_file}")
    with open(args.input_file, "r") as f:
        report_data = json.load(f)

    augment_report_data(report_data, args.tags)

    print(f"Save modified JSON report file: {args.output_file}")
    with open(args.output_file, "w") as f:
        json.dump(report_data, f, sort_keys=True, indent=2)

    if args.debug:
        print("Dry run: Skip sending report to Datalake")
    else:
        print("Send report to Data Lake")
        jwt = generate_jwt()
        make_jwt_request(jwt, report_data)


def get_repo_versions(namespace: str = "middleware") -> dict:
    """Get repository version for each POD image."""
    PREFIX_SKIP_PODS = "test-"  # skip on-demand test PODS
    THIS_POD_NAME = os.getenv("HOSTNAME")  # POD where this script and tests run
    result = {"repos": {}, "test_runner": {}}
    config.load_incluster_config()

    if ENVIRONMENT_NAME == 'Unity-Middleware-Staging':
        namespace = 'middleware-test'
    pods = client.CoreV1Api().list_namespaced_pod(namespace=namespace).items

    # Find all PODs and group them by repository + version
    repos = {}
    for pod in pods:
        if pod.metadata.name.startswith(PREFIX_SKIP_PODS):
            continue
        for container in pod.spec.containers:
            if m := re.search(fr"-repo\.{namespace}\.(\S+):(\S+)", container.image):
                repo, version = m.groups()
                repos.setdefault(repo, {}).setdefault(version, set()).add(pod.metadata.name)
                if pod.metadata.name == THIS_POD_NAME:
                    result["test_runner"] = {
                        "pod": THIS_POD_NAME, "repo": repo, "version": version}

    # Report all repositories with their corresponding version(s)
    for repo, versions in repos.items():
        if repo == result["test_runner"].get("repo"):
            continue  # this repo is already reported separately

        # Report version(s) as CSV
        result["repos"][repo] = ",".join(sorted(versions.keys()))
        if len(versions) > 1:
            result.setdefault("notes", []).append(
                f"Multiple versions of '{repo}' exist in '{namespace}': {versions}")

    return result


def augment_report_data(report_data: list, tags: str) -> None:
    """Add extra information to behave's report."""

    versions = get_repo_versions()
    now = datetime.now(timezone.utc).isoformat()
    for feature in report_data:
        feature['Environment'] = ENVIRONMENT_NAME
        feature['Suite_Run'] = tags
        feature['Versions'] = versions

        feature_duration = 0
        # ensure 'elements' exists (on hook failure it can be missing)
        scenarios = feature.setdefault('elements', [])
        for scenario in scenarios:
            # ensure 'steps' exists (on hook failure it can be missing)
            steps = scenario.setdefault('steps', [])
            for step in steps:
                try:
                    step_duration = step['result']['duration']
                except KeyError:
                    step_duration = 0
                feature_duration += step_duration
        feature['feature_duration'] = feature_duration
        feature['datetime'] = now

# please do not edit anything below this line:

def generate_jwt(sa_keyfile=serviceaccount_keyfile,
                 sa_email=serviceaccount_email,
                 audience=audience,
                 expiry_length=3600):
    """Generates a signed JSON Web Token using a Google API Service Account."""

    now = int(time.time())

    # build payload
    payload = {
        'iat': now,
        # expires after 'expiry_length' seconds.
        "exp": now + expiry_length,
        # iss must match 'issuer' in the security configuration in your
        # swagger spec (e.g. service account email). It can be any string.
        'iss': sa_email,
        # aud must be either your Endpoints service name, or match the value
        # specified as the 'x-google-audience' in the OpenAPI document.
        'aud': audience,
        # sub and email should match the service account's email address
        'sub': sa_email,
        'email': sa_email,
    }

    # sign with keyfile
    signer = google.auth.crypt.RSASigner.from_service_account_file(sa_keyfile)
    jwt = google.auth.jwt.encode(signer, payload)

    return jwt


def make_jwt_request(jwt, json_body, url=endpoint_url):
    """Makes an authorized request to the endpoint"""

    headers = {
        'Authorization': 'Bearer {}'.format(jwt.decode('utf-8')),
        'content-type': 'application/json'
    }
    response = requests.post(url, headers=headers, json=json_body)
    print(response.status_code, response.content)
    response.raise_for_status()


if __name__ == '__main__':
    main()
