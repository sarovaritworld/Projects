from setuptools import setup
setup(name='UnityMiddlewareAutomation',
      version='1.0',
      description='Python BDD',
      author='gayatri bhamare',
      author_email='gayatri.bhamare@vodafone.com',
      url='https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware',
      packages=[
            'classes',
            'protobuf'
            'testdata',
            'report',
            'testdata'
      ],
     )
