#!/bin/bash

# Input arguments to tweak here
TAGS=$1
MAX_RUNS=1
RERUN=0
#DEBUG_OPT='--logging-level=INFO --capture --logcapture --capture-stderr'
DEBUG_OPT='--logging-level=DEBUG --no-capture --no-logcapture --no-capture-stderr'

export PYTHONPATH=.:$PYTHONPATH

perform_tests () {
  local RERUN_FILE=$1
  if [ -z "$RERUN_FILE" ]; then
    local EXTRA_OPTIONS="features --tags=$TAGS"
    local FILE_SUFFIX=$TAGS
    echo "=== Perform tests for tags: $TAGS"
  else
    local EXTRA_OPTIONS="@$RERUN_FILE"
    local FILE_SUFFIX=rerun__$TAGS
    echo "=== Perform re-run of failed tests only"
  fi
  behave $EXTRA_OPTIONS --no-color --no-skipped \
    $DEBUG_OPT \
    -f json.pretty_custom -o report__$FILE_SUFFIX.json \
    -f pretty_custom -o report__$FILE_SUFFIX.log \
    -f pretty_custom
}

echo "=== Cleanup everything from previous run"
rm -f report_*.{json,log,html} rerun_failing.features

echo "=== Start appdirect"
# NB: on STDOUT, we will have appdirect_stub + behave STDOUT
python appdirect_stub.py &
appdirect_stub_pid=$!
on_exit() {
  if [ -e /proc/$appdirect_stub_pid ]; then
    echo "=== kill appdirect_stub (behave has not killed it)"
    kill -9 $appdirect_stub_pid || true
  fi
}
trap on_exit EXIT
export KEEP_APPDIRECT_ALIVE=1


perform_tests

if [ -s ./rerun_failing.features ] && [ "$RERUN" = "1" ]; then
  perform_tests ./rerun_failing.features
fi

echo "Done: $(date +'%Y-%m-%d %H:%M:%S %Z')"
