## [1.186.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.185.0...1.186.0) (2025-05-27)


### :sparkles: Features

* Shell Script to update sub-module and protobuf files sequentially ([add51e6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/add51e6ed420b45aca2485ccc54442ec68cc1dcd))

## [1.185.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.184.0...1.185.0) (2025-05-26)


### :sparkles: Features

* UN-40597 ucc.unity.tenant MODIFY SSO Feature ([43cdb86](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/43cdb8657a92630883d8d610364bc390335aaeb4))

## [1.184.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.183.1...1.184.0) (2025-05-26)


### :sparkles: Features

* UN-41083 updating error codes and error messages in CRF gateway ([77339ee](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/77339eee07fd6057582b762234a491617595ae43))

## [1.183.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.183.0...1.183.1) (2025-05-23)


### :bug: Fixes

* update the error message for invalid policy for tmfgateway ([6b9ef6f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6b9ef6f525756dbdc776a5cb51805191ac84db2a))

## [1.183.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.182.0...1.183.0) (2025-05-23)


### :sparkles: Features

* UN-32132 filter by external reference ([253edb3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/253edb31db89238329ae286200237b953cd0acae))

## [1.182.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.10...1.182.0) (2025-05-23)


### :sparkles: Features

* update ringcentral gateway error codes ([f576948](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f5769486fd7529e1af16bcc811a011355f460b57))

## [1.181.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.9...1.181.10) (2025-05-22)


### :bug: Fixes

* UN-42031 fix for UN_21134_01 ([2c58373](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2c583735781e5c0f9af99e3d3ba8357fbb81bca8))

## [1.181.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.8...1.181.9) (2025-05-22)


### :bug: Fixes

* UN-42656 [Dev] Investigate and fix UN_32336_06_01 ([c9a01c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c9a01c13a9f421f0178dfb08240c0518e3d24e34))

## [1.181.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.7...1.181.8) (2025-05-21)


### :bug: Fixes

* Replace get_country_code with get_dep_market_code for MarketCode Validation. ([848524d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/848524d39b325e9d6346ffb271733878fd60d3a4))

## [1.181.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.6...1.181.7) (2025-05-21)


### :bug: Fixes

* descoping testcase UPUA_649_03_01 ([de04cba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/de04cbaf5593b687d5ef6a426377be422a851baa))

## [1.181.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.5...1.181.6) (2025-05-19)


### :bug: Fixes

* updated schema repo along with protobuf files ([1f633ad](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1f633ad9ce896e2a74c79f451478f4c7273da25d))

## [1.181.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.4...1.181.5) (2025-05-19)


### :bug: Fixes

* [UN-41166] & [UN-41165] error code in ID mapper ([9f3652b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9f3652bd887203bf8a4940c19a31c9deef6999d8))

## [1.181.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.3...1.181.4) (2025-05-16)


### :bug: Fixes

* update submodule and protobuf ([55ee440](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/55ee440a004e98fb60ffc08b698f709670569769))

## [1.181.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.2...1.181.3) (2025-05-14)


### :bug: Fixes

* quick fix for Delete TPM Numbers test cases ([c1a9e56](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c1a9e56676d94f74f2b66fb07f80f9f3b5779b6d))

## [1.181.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.1...1.181.2) (2025-05-13)


### :bug: Fixes

* fixing TPM failing test cases replacing countryCode by marketCode due to changes done in this feature... ([20fecfe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/20fecfe386a3be090d18b66fc791b5f4e3bba492))

## [1.181.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.181.0...1.181.1) (2025-05-13)


### :bug: Fixes

* UN-27959 decomission redundant topics and update the code what is their previously in automation-fw ([c39d76c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c39d76cae7e4fcd208e1c8bbe228afeb836b772e))

## [1.181.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.180.1...1.181.0) (2025-05-09)


### :sparkles: Features

* UN-41073 Error codes test design part-3 ([011c171](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/011c171af505d43d062e196c54d56e81bbb8295f))

## [1.180.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.180.0...1.180.1) (2025-05-08)


### :bug: Fixes

* UN-42382 increasing timeout for fetching crf order document. ([f42f128](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f42f128a31400108187439f24ad4ea9a19b3a5a9))

## [1.180.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.179.1...1.180.0) (2025-05-07)


### :sparkles: Features

* UN-41073 Error code test design part-2 ([37ee0ce](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/37ee0ceb623565e4ddb8f76d5d2ee34c2396f489))

## [1.179.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.179.0...1.179.1) (2025-05-07)


### :bug: Fixes

* UN-42466 fix idmapper TC's ([7580268](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7580268bd9ef44cec1decd48da5b512c29870622))

## [1.179.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.178.6...1.179.0) (2025-05-06)


### :sparkles: Features

* UN-40777 error codes test design part-1 ([ffd6ea2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ffd6ea23540bab859fad17fe947f3cc884725bb1))

## [1.178.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.178.5...1.178.6) (2025-05-06)


### :bug: Fixes

* fixing some test cases which block id-mapper-api pipeline ([e7e11fc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e7e11fc06a1e8e2e38e1a1b9aea1a1d1174b0151))

## [1.178.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.178.4...1.178.5) (2025-05-06)


### :repeat: Chore

* tagging wip to TC UN_14499_03 with known failure ([d027498](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d027498494054d826c54ec26dbdec5142d1d9b91))


### :bug: Fixes

* patch tests ([e7f3efe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e7f3efeb950a16450a1eba9752465645b3e08a7c))

## [1.178.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.178.3...1.178.4) (2025-04-30)


### :bug: Fixes

* update protobuf topic for tmf-mediator confirm account and tmf-mediator create initial order ([cad7710](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cad7710d7f525471018015efff3317c4d867a5dc))

## [1.178.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.178.2...1.178.3) (2025-04-25)


### :bug: Fixes

* update schema repo along with protobuf files ([0a01087](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0a010876ca19855095813335c2ca2d6c44b37568))

## [1.178.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.178.1...1.178.2) (2025-04-24)


### :bug: Fixes

* update protobuf topic for order-management order completed and order-management account created ([e10e0d4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e10e0d405fa955b936cc0c0b8dfc9a14bfbdc625))

## [1.178.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.178.0...1.178.1) (2025-04-24)


### :bug: Fixes

* protobuf migration of nm complete order and nm update number topic ([1b047f8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b047f8cde7d365912f17029b78e022840544594))

## [1.178.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.177.1...1.178.0) (2025-04-23)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-42223:** Change the service name ([e152ba2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e152ba2c929aa51ac8656e437e2b5e709028518f))

## [1.177.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.177.0...1.177.1) (2025-04-23)


### :bug: Fixes

* Adds logic to retry the email send ([c62b985](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c62b985efe3959a98208b1f1d8e0dc09ae42febc))

## [1.177.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.176.6...1.177.0) (2025-04-23)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-42223:** Add Datadog-APM to Automation-FW ([e92c494](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e92c494787fa65c3822a8ade525fc0108679d51d))

## [1.176.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.176.5...1.176.6) (2025-04-22)


### :bug: Fixes

* UPUA_2600_12 & UN_32338_07_01 updating error message ([e944132](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e9441321f9179846ff847b43c765ae9f2e21ff87))

## [1.176.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.176.4...1.176.5) (2025-04-22)


### :bug: Fixes

* Correcting sub-modules ([3613681](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/36136819322354012318df1537204a00cabee99b))

## [1.176.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.176.3...1.176.4) (2025-04-21)


### :bug: Fixes

* Revert last changes done to fix UN_510_15 ([1762c09](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1762c09cdcaf8be5476c20575f19c999200d1d1a))

## [1.176.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.176.2...1.176.3) (2025-04-21)


### :bug: Fixes

* update protobuf topic for ringcentral-gateway change account status and order management change account status ([b73456e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b73456eb43db438ffbbd9b6dde374cb3b8abb775))

## [1.176.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.176.1...1.176.2) (2025-04-21)


### :bug: Fixes

* Failing nightly scenario UN_510_15 ([0b09168](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0b091684b95b94835b0da9c35134851d51c6d7be))

## [1.176.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.176.0...1.176.1) (2025-04-17)


### :bug: Fixes

* UN_38839 numbermanagement_addnum_deletenum_topic_protobuf_migration ([94243ed](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/94243ed07b7974ff302a7ee3f6cf394f575d86d2))

## [1.176.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.9...1.176.0) (2025-04-15)


### :repeat: Chore

* UN-40997 Jira tickets status modification to done ([b4ebb7c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b4ebb7c38de060945341fe794265854936b51498))


### :sparkles: Features

* behave update keyword script ([85ccf40](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/85ccf40976936763506c60202ee52eed1d497064))

## [1.175.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.8...1.175.9) (2025-04-07)


### :bug: Fixes

* fix for UN_28164_06 from modify cac feature ([b97695c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b97695ccf081366da61eb43291bec985641f2a9c))
* update testing tools ([1aaf0f8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1aaf0f808230f12b5c296189f8418ced6ef6f385))

## [1.175.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.7...1.175.8) (2025-04-04)


### :bug: Fixes

* tmf-mediator failing pipeline ([b0b1e34](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b0b1e34b800ba51b8e403b6cb8ec119053082d48))

## [1.175.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.6...1.175.7) (2025-04-02)


### :bug: Fixes

* UN-38833_Enable protobuf messages for ringcentral-gateway add number response ([db4d7cb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/db4d7cb96176214a601df46cc46a75f013d6ecbd))

## [1.175.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.5...1.175.6) (2025-03-28)


### :bug: Fixes

* UN-39853 fix regression failures UN_16843_02_03, UN_16843_01_03 in TEST env ([731df52](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/731df523370f0b3c113a109f3dbc3253f81006c7))

## [1.175.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.4...1.175.5) (2025-03-28)


### :bug: Fixes

* UN-38834 updated protobuf topic for ringcentral-gateway delete number response ([21629b5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/21629b57bc85a7e8025f9f61decfe8536a4b6cc1))

## [1.175.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.3...1.175.4) (2025-03-28)


### :bug: Fixes

* default cac values ([586c8ba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/586c8bab55c9bc8b9ead992885ece24790494c16))

## [1.175.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.2...1.175.3) (2025-03-28)


### :bug: Fixes

* carrier id regression ([d024584](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d024584bf3ff11be09a04a64c5479afd1944188e))

## [1.175.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.1...1.175.2) (2025-03-28)


### :bug: Fixes

* https://jira.tools.aws.vodafone.com/browse/UN-40098 | Add one test in TPM SNOW off-boarding ([f5f7f83](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f5f7f8389d95d9d62cd1377e30a401202ef065ff))

## [1.175.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.175.0...1.175.1) (2025-03-27)


### :bug: Fixes

* update testing tools ([e36ff5a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e36ff5aa34d7d7b70aa32667b288b7a553509588))

## [1.175.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.174.0...1.175.0) (2025-03-27)


### :sparkles: Features

* remove pstnProvider from CRF API call TMF652 ([6a1e501](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6a1e5010f900c239c2e73d982f7006be834f901c))

## [1.174.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.173.1...1.174.0) (2025-03-27)


### :sparkles: Features

* UN-38361 Uplift ADD CAC flow ([7181e67](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7181e6740552a2edb323a531c646eea86c131d92))

## [1.173.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.173.0...1.173.1) (2025-03-27)


### :bug: Fixes

* replace error codes according to TEST env ([ffb0fb9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ffb0fb9099aea5089068c8a193af1d5673829c63))

## [1.173.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.172.5...1.173.0) (2025-03-26)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-28985 E2E scenarios for Modify Licenses Feature ([6a14973](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6a14973946f2e18311b05295005b57b4b95036bb))

## [1.172.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.172.4...1.172.5) (2025-03-25)


### :bug: Fixes

* UN-39506 fix cease TPM ([fe64b98](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fe64b980848f9872c4ed1ad1d67fa21d8d374187))

## [1.172.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.172.3...1.172.4) (2025-03-24)


### :bug: Fixes

* UN-39506 Cease TPM customer without numbers ([5c59cbc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5c59cbc586c63636910f51086c805456bfa9a10c))

## [1.172.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.172.2...1.172.3) (2025-03-21)


### :bug: Fixes

* UN-38835 update protobuf topic for ringcentral-gateway initial order response ([340d130](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/340d13012d83615774658910ad24823a2615805b))

## [1.172.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.172.1...1.172.2) (2025-03-21)


### :repeat: Chore

* fixing tagging issue for regression suite ([9060193](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/906019355c4e77ecd501351093b0ceb453581624))


### :bug: Fixes

* add exception for s3 connection ([f3f5256](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f3f5256cf448d3103870af5ce222bfce845f36c7))

## [1.172.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.172.0...1.172.1) (2025-03-19)


### :bug: Fixes

* UN_21135_01_01 and UN_29700_02 ([6ced116](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6ced116c94f6e0f759d46258bc4a416c4dd9ebab))

## [1.172.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.171.1...1.172.0) (2025-03-19)


### :sparkles: Features

* rollback msoc customer creation ([0bdffc0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0bdffc024ccd70990e3c9ed163544e785c6c5b3b))

## [1.171.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.171.0...1.171.1) (2025-03-19)


### :repeat: Chore

* fixing nightly tag issue ([08a6ce6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/08a6ce6ce3dccfb7115063517192011798855e60))


### :bug: Fixes

* adding Sarovar in the nightly result list ([08e2570](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/08e25709d36e52f01ead277780eafaba25d3d605))

## [1.171.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.170.0...1.171.0) (2025-03-17)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-39296 E2E scenarios for msoc full customer onboarding ([1e22862](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1e22862da12346598d031d8af96becabcd238f1a))

## [1.170.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.169.0...1.170.0) (2025-03-17)


### :sparkles: Features

* update error codes in TMF SO ([3d7ffd6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3d7ffd653e366d2f095c11d5ff446428160d3961))

## [1.169.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.168.0...1.169.0) (2025-03-17)


### :sparkles: Features

* UN-31979 [Unity] Change extension ID for admin user ([8dbb5df](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8dbb5df0f1b27b026dd1af2766ad7c29f5d0ec85))

## [1.168.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.167.0...1.168.0) (2025-03-17)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-28993 E2E scenarios for Delete Licenses feature ([71fa732](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/71fa73252368654b792a37cc5ed91d7586ef7049))

## [1.167.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.166.0...1.167.0) (2025-03-13)

### :sparkles: Features

* UN-39437 Number Management error code
  validation ([5999a8c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5999a8c469396293d34b331fe443050b54a4e949))

## [1.166.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.165.1...1.166.0) (2025-03-13)

### :sparkles: Features

* UN-39514 geo
  restrictions ([41fc220](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/41fc2207da01f1ed846534d634a6f90f2d582120))

## [1.165.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.165.0...1.165.1) (2025-03-12)

### :bug: Fixes

* fix stuck RC gateway
  pipeline ([f838e3b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f838e3ba9a3af35f30eb22b9de05dcecd9043d47))

## [1.165.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.164.1...1.165.0) (2025-03-12)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-28992 E2E scenarios for Add Licenses
  feature ([b714272](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b714272275813bcade8650649f1a37de4239d080))

## [1.164.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.164.0...1.164.1) (2025-03-11)


### :repeat: Chore

* changing TAGS value for rerun failing
  tests ([0ae21e6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0ae21e6512744d93b380439344cd4ade617e8fdc))

### :bug: Fixes

*
UN_19332_05 ([1f15dad](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1f15dad1d363823d0c5bc0e7fe6b22761e8431bc))

## [1.164.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.163.2...1.164.0) (2025-03-06)


### :sparkles: Features

* UN-28520 Monitor Delayed Orders - Check
  SLO ([4d08ce9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4d08ce9768ef3a4a082c780da252e091262aa06a))

## [1.163.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.163.1...1.163.2) (2025-03-06)


### :repeat: Chore

* change TAGS for rerun failing
  test ([90697eb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/90697eb7d36315a63880b331ad68e45738444d60))

### :bug: Fixes

* nightly run to send
  report ([34a7829](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/34a782962f77fed254ed1073a50866dbf858a7d4))

## [1.163.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.163.0...1.163.1) (2025-03-04)


### :bug: Fixes

* fixing TC UN-32339-06 for pipeline check
  support ([75a8017](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/75a8017c93b21b1f3839baf50603bc71061591d1))

## [1.163.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.162.2...1.163.0) (2025-03-04)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-39069 Test endpoint are responding in
  DEV ([dcd6b1b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dcd6b1b32520bade624187be101ec191f524431b))

## [1.162.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.162.1...1.162.2) (2025-03-03)


### :bug: Fixes

*
UN-40079-related-to-Msoc-remove-number ([1baaf66](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1baaf6635f1d48c485952fe2c6e51a05c0e21ad3))

## [1.162.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.162.0...1.162.1) (2025-03-03)


### :bug: Fixes

* UN-39860 fix
  tests ([fb623fa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb623fa0b1609167baafce06028a9c370e08d7f1))

## [1.162.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.161.0...1.162.0) (2025-03-03)


### :sparkles: Features

* update error codes for crf
  gateway ([94bad76](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/94bad7649f6e47906986b6ceb776e695c275a093))

## [1.161.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.160.2...1.161.0) (2025-03-03)


### :sparkles: Features

* UN_39435 Error codes validation from CRF_gw for
  TPM ([ff9387e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ff9387e31a78281b0c7cd56ffd1aa073bc04154c))

## [1.160.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.160.1...1.160.2) (2025-02-28)


### :bug: Fixes

* update error message for tmf-srv-order-gw in tmf.yml
  file ([242c099](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/242c0992479be1f334023d16dc4dcb4d8546b489))

## [1.160.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.160.0...1.160.1) (2025-02-28)


### :bug: Fixes

* adding Mahek in the nightly result
  list ([5f87dda](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5f87dda36cf47e97c3b6bc6c36c2303b6bbdf8ca))

## [1.160.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.159.2...1.160.0) (2025-02-27)


### :sparkles: Features

* remove report to gcp
  step ([1cbb10e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1cbb10eedcf0052e1e715672acc93022758f9ab9))

## [1.159.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.159.1...1.159.2) (2025-02-27)


### :bug: Fixes

* https://jira.tools.aws.vodafone.com/browse/UN-39440 | Modify the error codes returned by
  snow-gateway ([37dac20](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/37dac20a8ea012b45a060592ea69cace94564598))

## [1.159.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.159.0...1.159.1) (2025-02-25)


### :bug: Fixes

*
cronjob.yaml ([9922ee0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9922ee06f3ad00efb8bd99cd89a8027425031bc1))

## [1.159.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.158.0...1.159.0) (2025-02-25)


### :sparkles: Features

* read from tmf-svc-order-gw-api
  variables ([f9ade1a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f9ade1ad7e5cc5cb2b9d5b3d162050b96ba376c7))

## [1.158.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.157.5...1.158.0) (2025-02-24)


### :sparkles: Features

* UN-40302 Add health check for TMF Resource
  Inventory ([b132b8a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b132b8af8dc90d5987ff159036bd627999d1e215))

## [1.157.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.157.4...1.157.5) (2025-02-24)


### :bug: Fixes

* un 28994
  05 ([fa4916e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fa4916ed0f1c7ec918ad09dfba63e488f7d8de88))

## [1.157.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.157.3...1.157.4) (2025-02-20)


### :repeat: Chore

* update
  send_report_to_lab ([4e9aef4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4e9aef48201d633c7f70beb08d1ff391e85aecb4))

## [1.157.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.157.2...1.157.3) (2025-02-18)


### :bug: Fixes

* fix failing scenario
  21134_07 ([ab3cbcc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ab3cbcc6014adb86db717e3821f25fb234902fc7))

## [1.157.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.157.1...1.157.2) (2025-02-17)


### :bug: Fixes

* https://jira.tools.aws.vodafone.com/browse/UN-39954 | Modify the error codes returned by ringcentral-gateway for
  number provisioning
  APIs ([ca3b427](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ca3b427f73a5e7a9bf5dfa6cc4dd74ce4ff9f502))

## [1.157.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.157.0...1.157.1) (2025-02-14)


### :recycle: Refactor

* duplicate code for tpm operations(add customer and add
  number) ([5885209](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5885209009a39482b363604e2aa8faa801b97be6))

## [1.157.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.156.2...1.157.0) (2025-02-13)


### :sparkles: Features

* UN-39438 Order Management error codes
  validation ([619d823](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/619d8238f70c4263285be637f797faa0602a9342))

## [1.156.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.156.1...1.156.2) (2025-02-12)


### :bug: Fixes

* un
  14474_02_01 ([0187ea4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0187ea46df1d6371da67196d1d3d044413422312))

## [1.156.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.156.0...1.156.1) (2025-02-11)


### :bug: Fixes

* cac
  tests ([5ad7f2b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5ad7f2b120dccd1854776926e7259a92c9eeef32))

## [1.156.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.8...1.156.0) (2025-02-11)


### :sparkles: Features

* initial order and update main number error code validation
  TCs ([331617e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/331617ed1dee4e15845a8e9410b8046bdd2935ac))

## [1.155.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.7...1.155.8) (2025-02-11)


### :bug: Fixes

* https://jira.tools.aws.vodafone.com/browse/UN-39954 | Modify the error codes returned by ringcentral-gateway for
  SSO-Configuration API and Emergency Address
  API ([b4d437e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b4d437eebb1a8a1c466f838410c6b306932d1353))

## [1.155.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.6...1.155.7) (2025-02-10)


### :bug: Fixes

* Adding staging tag to Enhanced DEP CAC
  scenario ([10c227d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/10c227d8c1a13a1907e87392f8034f0ea92da135))

## [1.155.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.5...1.155.6) (2025-02-10)


### :bug: Fixes

* updated sub-module and
  protobuf ([0ff7fea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0ff7fea2d7f1f9569740d14c3cdeaa614badd2e6))

## [1.155.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.4...1.155.5) (2025-02-07)


### :bug: Fixes

* UN-39862 fix
  tests ([918e88e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/918e88eba4d2a0b6b36b9d22be41b53562268e4a))

## [1.155.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.3...1.155.4) (2025-02-06)


### :repeat: Chore

* tagging wip to TCs with known
  failures ([333fa52](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/333fa521748beeab063a2e13a6c64416757a194d))

## [1.155.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.2...1.155.3) (2025-02-06)


### :bug: Fixes

* allow behave run outside k8s pod and update testing
  tools ([d29a1d0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d29a1d08ee631447fc44acd197fae7082e3cf695))

## [1.155.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.1...1.155.2) (2025-02-04)


### :bug: Fixes

* updating sub-module and schema
  repo ([99afd82](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/99afd820768ed93e9dc9c2d5bbaf49c066c9eff6))

## [1.155.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.155.0...1.155.1) (2025-02-03)


### :bug: Fixes

* UN-39436 update error codes from ID
  mapper ([55ec916](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/55ec916bfa2df9120037e4f62ba4e98763a764e3))

## [1.155.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.154.0...1.155.0) (2025-02-03)


### :sparkles: Features

* Updated feature file for unity according to Suspend
  feature ([d4a488a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d4a488a2fa4342e9f3f0eb0af4a878a37eef113a))

## [1.154.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.153.0...1.154.0) (2025-01-31)


### :sparkles: Features

* feature DE accounts to go EMEA
  default ([5865a6a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5865a6a0f6c31ec673e56a76391798346333ad34))

## [1.153.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.152.0...1.153.0) (2025-01-31)


### :sparkles: Features

* add license
  generator ([260b975](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/260b9759b034a08fce130b57554899e2c1157423))

## [1.152.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.151.2...1.152.0) (2025-01-31)


### :sparkles: Features

* Update protobuf schema
  changes ([e281bfe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e281bfebabfbc01c01b0419d9a9fa9e3807bb5ec))

## [1.151.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.151.1...1.151.2) (2025-01-30)


### :bug: Fixes

* UN-38843 update protobuf topic for order management initial order
  request ([b57bf5b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b57bf5bf25a1dd70585230696d732776343cedfe))

## [1.151.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.151.0...1.151.1) (2025-01-29)


### :bug: Fixes

* fixing regression failures UN_497_05_03, UN_14474_09_01, UN_510_13, UN_29856_02_02,
  UPUA_68_01_09 ([b6da33c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b6da33c12ed77bd13020ced8d7ff049934d4423f))

## [1.151.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.150.3...1.151.0) (2025-01-29)


### :sparkles: Features

* UN-39473 changes in TPM feature
  file ([18b4b46](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/18b4b46e1f00ddf495ed40797794cec66dfcaf0d))

## [1.150.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.150.2...1.150.3) (2025-01-28)


### :bug: Fixes

* test
  UN_32338_01_03 ([b6bf59d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b6bf59d86a7e92e5cf23b325476c701fbf6a43ef))

## [1.150.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.150.1...1.150.2) (2025-01-27)


### :bug: Fixes

* comment
  send_report_to_lab ([f0db288](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f0db2888842633fceef1dbd6e143faf58ee6cd9b))

## [1.150.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.150.0...1.150.1) (2025-01-27)


### :bug: Fixes

* UN-39820removing TC's for add and delete licenses from
  automation-fw. ([dcd6613](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dcd66135eb2db662dc82761b28a4535605d1b5b7))

## [1.150.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.149.0...1.150.0) (2025-01-24)


### :sparkles: Features

* UN-30163 Enhanced DEP
  Validations ([852500b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/852500b95decc189d7d9531f417179179ad1f089))

## [1.149.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.148.1...1.149.0) (2025-01-23)


### :sparkles: Features

* add send_report_to_lab and adding temp_chart
  folder ([9d1affd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9d1affdb3bfbb770cc80a4638258baa6497bb567))

## [1.148.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.148.0...1.148.1) (2025-01-23)


### :bug: Fixes

* UN-39814 set emergency address for VFUK
  only ([f276142](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f276142fabe2730dd1e3ba3b85bce4d4f1315d7b))

## [1.148.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.14...1.148.0) (2025-01-22)


### :sparkles: Features

* UN-20240 RingCentral Gateway - Retry calls with a new JWT token if 401 is
  received ([11c9756](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/11c9756d3d78e64b5dae07e685873f184c3bc458))

## [1.147.14](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.13...1.147.14) (2025-01-21)


### :bug: Fixes

* update testing_tools to fix latest version of behavex
  4.0.9 ([a9dffd1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a9dffd196850ccb5aaaad1087523e2b5686da9c8))

## [1.147.13](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.12...1.147.13) (2025-01-20)


### :bug: Fixes

* adding new TC for add TPM numbers with serveral
  ranges ([b02f34c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b02f34c33ccfe2929f00442418a2875dea94eb7f))

## [1.147.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.11...1.147.12) (2025-01-20)


### :bug: Fixes

* fix 510
  16 ([ca8cf55](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ca8cf55420300ca6b490acf80e7259cd3bee0070))

## [1.147.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.10...1.147.11) (2025-01-17)


### :bug: Fixes

* downgrade confluent-kafka to latest stable
  version ([1ce83bd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1ce83bdb294374bcba7f8b753694801e79432bba))

## [1.147.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.9...1.147.10) (2025-01-16)


### :repeat: Chore

* bump
  dependencies ([19d756d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/19d756d0a69af602ced338fdedec70dcf15b084f))

## [1.147.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.8...1.147.9) (2025-01-07)


### :repeat: Chore

* Configure
  Renovate ([1eff7e2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1eff7e2f4b5ac6e30ce07930db62208c9b153df4))

## [1.147.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.7...1.147.8) (2025-01-02)


### :bug: Fixes

* Resolve TMF Mediator pipeline blockage due to test case
  UN_32339_06 ([31472d0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/31472d0be53a058f4a1d325b24326bcda578df34))

## [1.147.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.6...1.147.7) (2024-12-30)


### :bug: Fixes

* linter refactor for
  ceaseSNOWHandler ([55f9fcf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/55f9fcfa3de76de4c3b92358e09f32b175fba7d2))

## [1.147.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.5...1.147.6) (2024-12-30)


### :bug: Fixes

* add pod
  location ([9b959e3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9b959e33ad52c7f9c9e0ae896867eb2ad59988c1))

## [1.147.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.4...1.147.5) (2024-12-27)


### :bug: Fixes

* fix
  TpmDeleteNumberHandler.py ([6e47cf0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6e47cf06d19b433f59ccea74cf3608f2179c58a8))

## [1.147.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.3...1.147.4) (2024-12-26)


### :recycle: Refactor

* to use pool type in number
  generators ([a96b26c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a96b26c848ce7e52bef40bb55c4ab9f18db9e8ab))

## [1.147.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.2...1.147.3) (2024-12-24)


### :bug: Fixes

* UN_509 & UN_19334 feature failures from
  regression ([15d4589](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/15d4589143254ac75223d59cfabd736f24c1cfb4))

## [1.147.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.1...1.147.2) (2024-12-23)


### :bug: Fixes

* UN-38870 fix UN_32341 01 & UN_32341
  02 ([aae30f5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/aae30f53b19479559badbd94caf4da5e3d14b5a3))

## [1.147.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.147.0...1.147.1) (2024-12-23)


### :repeat: Chore

* undescope
  defect_UN-25506 ([7cea7ae](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7cea7aee5a44e9397896d10ba168f1a45af49c3e))

## [1.147.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.146.3...1.147.0) (2024-12-19)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-33234:** include pod location
  field ([4de8cba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4de8cba735e23444274c64125e3fbc14fe9f5b64))

## [1.146.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.146.2...1.146.3) (2024-12-19)


### :bug: Fixes

* UN-38240 update error
  code ([362fcc7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/362fcc796092faf7f225cbf5ac1e73a43afb8838))

## [1.146.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.146.1...1.146.2) (2024-12-17)


### :bug: Fixes

* fixing test
  UPUA_1364_17 ([0e8872e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0e8872eb63f13fe89394bb515c22c6f80b540e88))

## [1.146.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.146.0...1.146.1) (2024-12-16)


### :bug: Fixes

* fixed UN_32339_04 , UN_32339_01 , UN_32337_01_02 regression failing scenarios on staging
  env ([48ad4b4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/48ad4b4aa358e6ec17f1197c7774690ff96fe86c))

## [1.146.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.145.0...1.146.0) (2024-12-13)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-32341 | TPM/MSOC cease services in
  SNOW ([b4d3250](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b4d325032f498c127e10b9ecbc39cda6dd42be49))

## [1.145.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.144.4...1.145.0) (2024-12-13)


### :sparkles: Features

* UN-38025 Update regex used in
  ID-mapper-API ([1cc5c01](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1cc5c01220a8e49a5ab51631fc36653d652f8383))

## [1.144.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.144.3...1.144.4) (2024-12-12)


### :bug: Fixes

* fixed UN_32336_04 regression failing
  scenario ([59ce933](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/59ce933e5342022d89596abe794a3df046d44b29))

## [1.144.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.144.2...1.144.3) (2024-12-11)


### :bug: Fixes

* fix for failing scenarios from
  regression ([3f20ed6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3f20ed68a371db83d39bccdca3145978c3d8e77e))

## [1.144.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.144.1...1.144.2) (2024-12-10)


### :bug: Fixes

* fixing UN_32336_04,UN_21134_05,UN_32335_08 scenarios from regression
  failure ([c722c6c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c722c6c04d92a96893b7d2e6b6f63671e9037c24))

## [1.144.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.144.0...1.144.1) (2024-12-10)


### :bug: Fixes

* failing scenario
  UN_29690_02 ([205f6ee](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/205f6ee0f838d7f2150f3150c810956af609151d))

## [1.144.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.143.0...1.144.0) (2024-12-09)


### :sparkles: Features

* [TPM ] UCC Middleware API - Cease (Customer and Mobile
  Numbers) ([6e52f98](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6e52f98f0355accd3b43749498d07d3588df9148))

## [1.143.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.142.0...1.143.0) (2024-12-09)


### :sparkles: Features

* Onboarding of new local Vodafone markets within UCC
  MW ([d8aae94](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d8aae94de8a77ac96b9d0e6e841b4da238ccbc84))

## [1.142.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.7...1.142.0) (2024-12-05)


### :sparkles: Features

* UN-32528 TMF mediator processes request from
  RC ([30f8e06](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/30f8e067f677f5cce5fd6e638e7ff5f19e62ef77))

## [1.141.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.6...1.141.7) (2024-12-02)


### :bug: Fixes

* for jira ticket and msoc customer
  flakiness ([94892b0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/94892b072e3d346c53f95b04db4444362b094f8c))

## [1.141.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.5...1.141.6) (2024-12-02)


### :bug: Fixes

* cease UN_21134_04_01 TC for error
  message ([0b0cda4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0b0cda420169048425b0fb4dc3b720ddfaebe1ee))

## [1.141.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.4...1.141.5) (2024-11-29)


### :repeat: Chore

* update
  submodules ([8dc2ce4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8dc2ce4dab79b62db4415bad9aa54b8cf63259ad))

## [1.141.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.3...1.141.4) (2024-11-28)


### :bug: Fixes

* un 37638_08 and un 37638_10 scenarios in nightly
  run ([2af1515](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2af15151ae26885dcd23d97fef5c0508dcc8167e))

## [1.141.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.2...1.141.3) (2024-11-27)


### :bug: Fixes

* Added new members in mail list and removed regression tag from Cease TPM
  customer ([051c931](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/051c931334bba939c87fcef88fb74392fcd13b2c))

## [1.141.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.1...1.141.2) (2024-11-26)


### :bug: Fixes

* Updating the error message to fix
  UN_14499_02_07 ([ccb38c5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ccb38c53350d631d90ec7407d131d0e83122a653))

## [1.141.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.141.0...1.141.1) (2024-11-26)


### :bug: Fixes

* fix get_different_market_code
  function ([dc3187f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dc3187f0509de030635bf1bf994606aa6401d790))

## [1.141.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.140.0...1.141.0) (2024-11-26)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-33492 add Local Market Service Id to TPM
  Snow ([9a9c449](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9a9c449f3def838416a89702e4c0c4b92e33da31))

## [1.140.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.139.0...1.140.0) (2024-11-25)


### :sparkles: Features

* RC gateway validation for emergency
  address ([34c44de](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/34c44de8f688bf9b54b8e5886c6d0b26349f5ba4))

## [1.139.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.138.0...1.139.0) (2024-11-22)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-33651 | TPM/MSOC cease in SNOW
  south-bound ([caab4bb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/caab4bba01fddae8aeceecdf530dca9a8c8a21f8))

## [1.138.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.137.3...1.138.0) (2024-11-19)


### :sparkles: Features

* UN-34671 TMF Mediator process SET_EMERGENCY_ADDRESS
  operation ([7833558](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/78335582e8129243c53eb133f07d5519d19d7fcd))

## [1.137.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.137.2...1.137.3) (2024-11-18)


### :bug: Fixes

* added new condition to check doc in
  DB ([70759ca](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/70759ca0629776fef09e6a2577456417619cad47))

## [1.137.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.137.1...1.137.2) (2024-11-15)


### :recycle: Refactor

* countries data
  refactoring ([57521c7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/57521c7b8757f2e21495c95e40a4a05bfee48609))

## [1.137.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.137.0...1.137.1) (2024-11-13)


### :bug: Fixes

* UN-37504 add validation error in tmf.yml
  file ([9788836](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/97888368c5cf4e2d718192b106a808900260f22c))

## [1.137.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.136.1...1.137.0) (2024-11-11)


### :sparkles: Features

* sign off test
  environment ([56ce958](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/56ce9586ae49b84780624ea061bc6b168df268e7))

## [1.136.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.136.0...1.136.1) (2024-11-08)


### :bug: Fixes

* UN-36551 failing tests of 2600 feature on
  staging ([bfbd8c8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bfbd8c807da0b23aebd2ae5c7b77089c4ef7f008))

## [1.136.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.135.4...1.136.0) (2024-11-07)


### :sparkles: Features

* UN-34670 Validate TMF Mediator create operations for
  SET_EMERGENCY_ADDRESS ([fb22606](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb226060c38fcdf5e366df66e4391e978d004d26))

## [1.135.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.135.3...1.135.4) (2024-11-06)


### :repeat: Chore

* update submodules and schema
  files ([d56a7c7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d56a7c739bea0ebe89b3acd7c3a5af58530d2c08))

## [1.135.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.135.2...1.135.3) (2024-11-05)


### :bug: Fixes

* TMPAccountPayloadGenerator -
  TPMAccountPayloadGenerator ([e4b550d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e4b550d3a00e6b53c87bf66540e79ae1648427b7))

## [1.135.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.135.1...1.135.2) (2024-10-31)


### :repeat: Chore

* UN-37210 Update testing_tools
  submodule ([08a0b05](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/08a0b05725b61355ddf2d2eda11bd4e77fcdb258))

## [1.135.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.135.0...1.135.1) (2024-10-30)


### :bug: Fixes

* un 9408_01_01
  scenario ([f42acc5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f42acc5b555002c2783ce23829a606d6eb51a17c))

## [1.135.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.134.1...1.135.0) (2024-10-30)


### :sparkles: Features

* UN32340 - [TPM] Middleware Service Inventory Creation in
  SNOW ([af0fe49](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/af0fe49339aec968bf16873e39cd671d137a3855))

## [1.134.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.134.0...1.134.1) (2024-10-29)


### :bug: Fixes

* failing UN_510_15 test
  case ([644c544](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/644c544cb7ad1b619e1739096675455080588c84))

## [1.134.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.10...1.134.0) (2024-10-25)


### :sparkles: Features

*
UN-35654_feature_file_for_Emergency_address ([a90267c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a90267c05dda068fef0bc55ddf0ea7a802a22afa))

## [1.133.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.9...1.133.10) (2024-10-25)


### :bug: Fixes

* update namespace and fix some jira tests for new
  env ([ba8058d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ba8058d9a6becfd2a2ec2c4c6aa4102b1e67ee4c))

## [1.133.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.8...1.133.9) (2024-10-24)


### :bug: Fixes

* replace expected label 'staging' with '
  test' ([305d971](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/305d971162b2de8b224665df59e395056cdbe472))

## [1.133.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.7...1.133.8) (2024-10-24)


### :bug: Fixes

* fixing scripts for new Test
  environment ([405db32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/405db326a72ef5f8cc338d7c0e23dd7389a27db7))

## [1.133.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.6...1.133.7) (2024-10-22)


### :repeat: Chore

* update
  submodules ([54e502d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/54e502d1c23e4d89d348da7f573936448995aeea))

## [1.133.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.5...1.133.6) (2024-10-18)


### :repeat: Chore

* update
  schema-repository ([b440e59](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b440e59808e04b4d37a6cd6eeaa972c47a56f21e))

## [1.133.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.4...1.133.5) (2024-10-17)

### :recycle: Refactor

* change the search for field with
  wildcard ([1478c69](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1478c698b3cc4bb0477ae8deefda43bff31a2965))

## [1.133.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.3...1.133.4) (2024-10-16)

### :recycle: Refactor

* UN-36528 update usages of stub account according to new
  structure ([e4f1a1d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e4f1a1d02d0fa3824480c2967975ae586d441000))

## [1.133.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.2...1.133.3) (2024-10-14)


### :bug: Fixes

* UN_28994_03_02 change to
  502 ([459ef67](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/459ef674a8907e48d1c01f50bb4eb5393d781475))

## [1.133.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.1...1.133.2) (2024-10-10)


### :bug: Fixes

* merge 'UN_12090_02' into
  UN_12090_01 ([2a87ea4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2a87ea40aceb64d3378cfec7d8d2c0321e132999))

## [1.133.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.133.0...1.133.1) (2024-10-08)


### :recycle: Refactor

* improve assertion error
  message ([c38f452](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c38f45215294f34ede2e471143534109a04803fc))

## [1.133.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.132.0...1.133.0) (2024-10-04)


### :sparkles: Features

* UN-35046 call back for TPM add
  numbers ([8a53616](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8a536162c2f58acaf8cf3a660a6615732e76047d))

## [1.132.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.131.1...1.132.0) (2024-10-03)


### :sparkles: Features

* callbacks for Service
  Orders ([7d1fc15](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7d1fc15abe437afdbe1a5e2b4a57a023e128816c))

## [1.131.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.131.0...1.131.1) (2024-10-01)


### :bug: Fixes

* id mapper integration
  tests ([88f45ba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/88f45ba454e3cc6796b2c6e5bd8fa1dc9bd6a8e3))

## [1.131.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.130.0...1.131.0) (2024-09-26)


### :sparkles: Features

* UN-32335 TPM
  Enabler ([08e37a6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/08e37a6a46115934e2fbdca679793ac3aae8d693))

## [1.130.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.129.1...1.130.0) (2024-09-25)


### :sparkles: Features

*
UN-32337_TPM_ADD_NUMBERS ([5ab8db2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5ab8db2782b7c224570782cc9b1a8ddbae98590a))

## [1.129.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.129.0...1.129.1) (2024-09-10)


### :bug: Fixes

* removed failing regression tag from staging
  scenarios ([982a829](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/982a829ea938fb932dd988cb53a0b5c2ff3a64b8))

## [1.129.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.9...1.129.0) (2024-09-09)


### :sparkles: Features

* create TPM
  customer ([bad9df7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bad9df771c017aa829eb5bfc12583cd7504f1a05))

## [1.128.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.8...1.128.9) (2024-09-06)


### :repeat: Chore

* UN-34241 schema
  update ([45105f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/45105f78cce7589e53506a0a800dbfbefbe5c68a))

## [1.128.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.7...1.128.8) (2024-09-05)


### :bug: Fixes

* Fix failing test for Add & Modify CAC for invalid
  code ([8d69099](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8d690991f320990533ff07f6e4133eabed8c9766))

## [1.128.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.6...1.128.7) (2024-09-03)


### :bug: Fixes

* fix failing scenario UN_27954_01 and
  UN_27954_02 ([a8178c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a8178c1b3df889bfc31d10bbd34790982422d26c))

## [1.128.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.5...1.128.6) (2024-09-02)


### :bug: Fixes

* Adding carlos in the nightly report
  DL ([2662fa5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2662fa542bb12c1bb9bed26836a5fba86abe21da))

## [1.128.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.4...1.128.5) (2024-08-30)


### :bug: Fixes

* Regression
  failures ([565f2e7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/565f2e754a35a489995e04ac2652d927e9202e62))

## [1.128.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.3...1.128.4) (2024-08-30)


### :bug: Fixes

* updating crf notification state for Callback
  feature ([2c032f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2c032f7916abc7dcb62ed68eaf3494dd89846257))

## [1.128.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.2...1.128.3) (2024-08-29)


### :bug: Fixes

* Fixing failing pipeline and nightly run test
  cases ([feb92a3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/feb92a3d333a1e7a6ebfe43362cdb4c3a2247f5f))

## [1.128.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.1...1.128.2) (2024-08-29)


### :bug: Fixes

* regression
  failures ([e32eb07](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e32eb07be8098710c0eb23872ea4cf44edb9adac))

## [1.128.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.128.0...1.128.1) (2024-08-26)


### :bug: Fixes

* fix for UN_21134_07 on
  staging ([5c17950](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5c17950e2ce1b21b908576ff85051c8a75a5e7a4))

## [1.128.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.127.3...1.128.0) (2024-08-26)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-21134 UCC Middleware API -
  Cease ([757d4b9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/757d4b90510c7ecaef5525e899b290ad805b1681))

## [1.127.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.127.2...1.127.3) (2024-08-26)


### :repeat: Chore

* Sanity Suite
  optimization ([a143bec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a143bec0fc47989b8b6ca7a9c1c583c5758590cd))

## [1.127.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.127.1...1.127.2) (2024-08-23)


### :bug: Fixes

* add partner validation for related party for modify
  cac ([2efcba7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2efcba7844fe3542fd04544e39436fab944fbd70))

## [1.127.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.127.0...1.127.1) (2024-08-23)


### :bug: Fixes

* Corrected message spell for tmf-gateway
  pipeline ([ef0f0a4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ef0f0a4b4047e317e479b412b8ed77668620bc12))

## [1.127.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.126.4...1.127.0) (2024-08-23)


### :sparkles: Features

* add related party to modify cac request
  TMF652 ([48562cb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/48562cb9ea2f44da6a445c7fa90bd69bb7c21746))

## [1.126.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.126.3...1.126.4) (2024-08-20)


### :bug: Fixes

* descope old scope for RC
  gateway ([08bc338](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/08bc33835ab3d40148e601c8a82b1ea3cfa96fbf))

## [1.126.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.126.2...1.126.3) (2024-08-14)


### :bug: Fixes

* output file
  name ([b4f6cfa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b4f6cfa9c23844a5be71456a17afcebe818be7ed))

## [1.126.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.126.1...1.126.2) (2024-08-14)


### :bug: Fixes

* aws rds
  certificate ([aab3b46](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/aab3b46e5e2cfed64ed9f86f35d22b283a789e32))

## [1.126.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.126.0...1.126.1) (2024-08-14)


### :bug: Fixes

* corrected AWS RDS certificates
  link ([0bdb11c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0bdb11c5f0325979bb60f5636af2cd0d7244da82))

## [1.126.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.125.0...1.126.0) (2024-08-12)


### :sparkles: Features

* UN-32806 Update mapping of Resource Order states in
  crf-gateway ([ad4f164](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ad4f1647aa263bf1640639047ee9f9c46469e2ae))

## [1.125.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.124.1...1.125.0) (2024-08-12)


### :sparkles: Features

* update delete MSOC and UNITY resource order to use related
  party ([2bbc221](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2bbc22122884dddaa08083a81e3665e3396696a1))

## [1.124.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.124.0...1.124.1) (2024-08-12)


### :bug: Fixes

* updated database check for from inProgress to
  IN_PROGRESS ([2209914](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2209914366afdae9ddefcce12dab358130c894c5))

## [1.124.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.123.1...1.124.0) (2024-08-07)


### :sparkles: Features

* Adding new end points to appdirect webhook ingester
  microservice ([b0eef2f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b0eef2f8cb2e6550e42978394f6780a9b586231a))

## [1.123.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.123.0...1.123.1) (2024-08-06)


### :bug: Fixes

* add timeout for
  cac ([622fb8f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/622fb8f9b451855708591884982eae01d24f71ab))

## [1.123.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.122.4...1.123.0) (2024-08-05)


### :sparkles: Features

* UN-32801 TMF 652 resource order state
  values ([5ee49ce](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5ee49cef423ac517b9762246dfcb50065e461cf8))

## [1.122.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.122.3...1.122.4) (2024-08-01)


### :bug: Fixes

* setup logger in behave handlers with correct module
  name ([73bffea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/73bffea5a51fe9b3179c987e253457b5bb1ae664))

## [1.122.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.122.2...1.122.3) (2024-08-01)


### :repeat: Chore

* add tpm customer payload
  generator ([386c951](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/386c9511fbdb36d598d4828c14a789216b9f2770))

## [1.122.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.122.1...1.122.2) (2024-07-31)


### :recycle: Refactor

* create_or_update_key()
  usage ([69c3b1b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/69c3b1bb43a8ec9fe56a1bf19c7b4a061a37e438))

## [1.122.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.122.0...1.122.1) (2024-07-30)


### :bug: Fixes

* fixed failing scenario from nightly
  UN_19334_02_01 ([2370170](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2370170e31e773e4a7696313a0670d67bb5f7ea2))

## [1.122.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.121.3...1.122.0) (2024-07-29)


### :sparkles: Features

* E2E Modify CAC
  feature ([2d42e28](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2d42e289f22699751117b146a8bd6c6a20e63e65))

## [1.121.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.121.2...1.121.3) (2024-07-26)


### :bug: Fixes

* add staging
  condition ([438591b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/438591b4c9b622dd887c0b0f70aeb4e5df958c41))

## [1.121.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.121.1...1.121.2) (2024-07-26)


### :bug: Fixes

* after snow feature
  fixes ([44ce2aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/44ce2aad5a8c3fd821fc12b3d2ffa6692022bd6c))

## [1.121.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.121.0...1.121.1) (2024-07-25)


### :bug: Fixes

* removed unnecessary check from
  numbermanagement_complete_order ([dea684a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dea684a9d57e718b848469881715f7b32ebb070f))

## [1.121.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.120.0...1.121.0) (2024-07-24)


### :sparkles: Features

* snow onboarding
  process ([1663f26](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1663f2668223ee6df5e535f0a44f07363d879d27))

## [1.120.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.119.1...1.120.0) (2024-07-24)


### :sparkles: Features

* UN-15095 JWT
  scope ([8a37f51](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8a37f51b0ce22c8deac21a288ad4a0490e8b074a))

## [1.119.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.119.0...1.119.1) (2024-07-23)


### :bug: Fixes

* updating schema repository and pb2
  files ([796952c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/796952cf78f55a1c78af44f96acea7dc8755c73e))

## [1.119.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.118.2...1.119.0) (2024-07-19)


### :sparkles: Features

* update testing_tools
  version ([dd3afae](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dd3afaed2e0940fd57dc5f5f0e7b4db082fc19bf))

## [1.118.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.118.1...1.118.2) (2024-07-09)


### :recycle: Refactor

* replace one number management
  step ([3924f35](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3924f35333d34423353fd759835d483af1bfc089))

## [1.118.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.118.0...1.118.1) (2024-07-01)


### :bug: Fixes

* add new member in mail
  list ([51eed34](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/51eed344c10c9a2d913bf6ca1d10a8094e1e94f4))

## [1.118.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.117.4...1.118.0) (2024-07-01)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-27966:** Add
  CAC ([da9299c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da9299c5d449e53d21777120828e84fc6b9a249b))

## [1.117.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.117.3...1.117.4) (2024-06-28)


### :recycle: Refactor

* UN_32076 Rename handler file step
  definitions [4/4] ([2da5595](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2da55957babce679c05c27a993c433480bd79866))

## [1.117.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.117.2...1.117.3) (2024-06-28)


### :recycle: Refactor

* UN_32045 Rename handler file step
  definitions [3/4] ([38c5d3b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/38c5d3bd4a1644be2fd3a4bf941f51c2106147ca))

## [1.117.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.117.1...1.117.2) (2024-06-28)


### :recycle: Refactor

* UN_32044 Rename handler file step
  definitions [2/4] ([e4637e5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e4637e5f5900623478ad04039828f7d3f126dc1b))

## [1.117.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.117.0...1.117.1) (2024-06-28)


### :recycle: Refactor

* UN_32041 Rename handler file step
  definitions [1/4] ([56686ce](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/56686ceda0b0ce407b28a0c47a7e85bec1af7007))

## [1.117.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.116.0...1.117.0) (2024-06-28)


### :sparkles: Features

* UN-28994 Get Account information from
  NGIN ([800e758](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/800e758a350c420d983dcc96f2a2c82ea56f6cba))

## [1.116.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.115.0...1.116.0) (2024-06-28)


### :sparkles: Features

* UN-27958: kafka consumer to support pairs of JSON/protobuf
  topics ([95d2dd1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/95d2dd138234502b6203f5fdde5b69fa864fe684))

## [1.115.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.114.0...1.115.0) (2024-06-26)


### :sparkles: Features

* UN-18956: Use behavex for nightly
  runs ([85dcbac](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/85dcbac77789e5e69183b0dce00bd55d4ee1cc00))

## [1.114.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.113.0...1.114.0) (2024-06-25)


### :sparkles: Features

* UN-15120: added JWT scope for
  email-management-api ([136de2d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/136de2df3f172f301b7e2131441ded62a8fea1e1))

## [1.113.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.112.0...1.113.0) (2024-06-25)


### :sparkles: Features

* Update Carrier ID Options to support TATA and
  VCS-COMMS ([29e8e58](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/29e8e58de82505c5a614f32c76961589097cd8f1))

## [1.112.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.111.5...1.112.0) (2024-06-25)


### :sparkles: Features

* UN-18956: Add support for behavex in nightly
  run ([a4b0fd2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a4b0fd2103503fe80cab3137e0c6fbdf6563dceb))

## [1.111.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.111.4...1.111.5) (2024-06-24)


### :repeat: Chore

* UN-32071 Configurable camel case for
  protobuf ([06cc448](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/06cc4485f47e2ae163584b90a56fe9c2ce4157cf))

## [1.111.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.111.3...1.111.4) (2024-06-20)


### :bug: Fixes

* 404 decode
  flow ([571cfa0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/571cfa0e2d5c1ccbb8b0013b310dc7c24a41fd41))

## [1.111.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.111.2...1.111.3) (2024-06-20)


### :bug: Fixes

* Updating test cases to cater carrier ID for MNC
  market ([2d81912](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2d8191267044daf58371682a5904c05b24d95026))

## [1.111.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.111.1...1.111.2) (2024-06-19)


### :bug: Fixes

* change area code and added lookup function to NM
  client ([dbb979f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dbb979f13c554c73c68ca0cf3a2b9fb6b0741aaf))

## [1.111.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.111.0...1.111.1) (2024-06-18)


### :bug: Fixes

* fix number management
  url ([074ac8e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/074ac8eb716f8ef929f3d32538b7ec41ff8bbdbe))

## [1.111.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.110.0...1.111.0) (2024-06-14)


### :bug: Fixes

* update create maintenance stories
  script ([c64c72e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c64c72e39c0573b8ebf9d7847a93000fdea8df18))

### :sparkles: Features

* number generator for number management
  request ([5deabc8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5deabc8e84e1b673a816248d0e7dae69668e1f02))

## [1.110.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.109.2...1.110.0) (2024-06-12)


### :sparkles: Features

* UN-31071: legacy scope is obsolete for some
  MS ([4100ab8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4100ab89e5daae91593a183998ae15fd94962000))

## [1.109.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.109.1...1.109.2) (2024-06-10)


### :bug: Fixes

* UN_489_08 - fix account fetch and error
  message ([41767f0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/41767f0e6ba2eb8d05cecbf17b54b62208e5c8e1))

## [1.109.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.109.0...1.109.1) (2024-06-10)


### :bug: Fixes

* UN_
  29991_skip_DB_validation_for_state_in_staging ([16935f4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/16935f42022f01879a65e2d8d6381b02fb59dce7))

## [1.109.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.108.0...1.109.0) (2024-06-07)


### :sparkles: Features

* UN-31980: add jsonpath support to validation sets and
  get_field ([642e91b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/642e91b4e8df2605d20d69a1f72501cc202c0734))

## [1.108.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.107.0...1.108.0) (2024-06-07)


### :sparkles: Features

* UN-31551: ensure ucas_provider is always
  set ([42135cb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/42135cbaa17fcf355ea3db6029cafed93b055e8d))

## [1.107.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.106.0...1.107.0) (2024-06-06)


### :sparkles: Features

* UN-27081_Include state field on RC account
  creation ([bb8ea9c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bb8ea9ce461dbbcf269c23052a2c07f4699b8456))

## [1.106.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.105.2...1.106.0) (2024-06-05)


### :sparkles: Features

* UN-27955: move hardcoded kafka message search_path to config
  file ([da34640](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da346400da2f2e7c21b0e2752f4d31a9dec4a683))

## [1.105.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.105.1...1.105.2) (2024-06-04)


### :bug: Fixes

* UN-31810: update jwt scope
  test ([f07dad5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f07dad5d038b84b3d65b38d12819bffea9d36912))

## [1.105.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.105.0...1.105.1) (2024-06-03)


### :bug: Fixes

* UN-31309: fix missing
  milestone ([41c7bd2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/41c7bd285ab3c2c226974623fd0fda5f6e659284))

## [1.105.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.7...1.105.0) (2024-05-31)


### :sparkles: Features

* UN-31934: update DEP market
  codes ([7c5e4b2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7c5e4b27c95eb4ac51bcf8acc77c8116441f21fb))

## [1.104.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.6...1.104.7) (2024-05-31)


### :bug: Fixes

* update swagger for id
  mapper ([a92ae2d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a92ae2ded1622e0aae3b99248bf0748c80cd7771))

## [1.104.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.5...1.104.6) (2024-05-31)


### :bug: Fixes

* updated error message for
  UN_19701_02_02 ([8fef313](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8fef3137c1aed69bad55e7e2d78717b5ca2d9404))

## [1.104.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.4...1.104.5) (2024-05-30)


### :bug: Fixes

* updating the regression_staging
  tag ([d1798d8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d1798d893f620484254f38df05f59bb0953951fe))

## [1.104.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.3...1.104.4) (2024-05-30)


### :recycle: Refactor

* change the access to database to
  common_python/database.py ([daf3d3e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/daf3d3e147d4ea77ca416bcac408dc3026a32040))

## [1.104.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.2...1.104.3) (2024-05-29)


### :bug: Fixes

* Updated Payload Generator with new
  classes ([997bda3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/997bda3b644afce69c6f42095387f34b1db6e13f))

## [1.104.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.1...1.104.2) (2024-05-28)


### :repeat: Chore

* Updated mailing list for nightly
  report ([fb6d177](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb6d1774249252d7eb8327ac25f74a40e0041ac2))

## [1.104.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.104.0...1.104.1) (2024-05-23)


### :bug: Fixes

* UN-31627: updated old reusable
  accounts ([3a46c61](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3a46c61486bcdb69289ef6b2dcb44f0fb7764ec7))

## [1.104.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.103.2...1.104.0) (2024-05-23)


### :sparkles: Features

* add jsonpath custom functions to get and update key with dot notation
  address ([0a6399f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0a6399f1abd473e080a91f0226892ff485a9146f))

## [1.103.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.103.1...1.103.2) (2024-05-23)


### :bug: Fixes

* update sub-module and protobuf
  message ([201fa4b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/201fa4b9e89798fb1d3f1040307189a7c466cdc3))

## [1.103.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.103.0...1.103.1) (2024-05-21)


### :bug: Fixes

* UN-28919: configurable expected number of kafka
  messages ([e584c55](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e584c55643cff30b3f5ae62938d708b9468c49b2))

## [1.103.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.102.0...1.103.0) (2024-05-16)


### :sparkles: Features

* UN-29801: Update for new model in CRF Provisioning Delete
  Numbers ([9097ea2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9097ea23ebbde3f1650cf2bf930bd11875907ed2))

## [1.102.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.101.2...1.102.0) (2024-05-16)


### :sparkles: Features

* regenerate
  models ([92ba98a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/92ba98ab2da601dc4716103da35dcb5f8f110a45))

## [1.101.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.101.1...1.101.2) (2024-05-15)


### :bug: Fixes

* updating schema repository and
  sub-modules ([effc385](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/effc3850468448385ad2c081d21708e2cb49c6e0))

## [1.101.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.101.0...1.101.1) (2024-05-14)


### :bug: Fixes

* Revert "feat: use new version of testing_tools to create jira based on nightly
  run" ([62bf666](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/62bf666bc6dae9c6956e4a1246078285bc413460))

## [1.101.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.100.0...1.101.0) (2024-05-13)


### :sparkles: Features

* UN-29800: Update for new model in CRF Provisioning Add
  Numbers ([108c6f4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/108c6f47bdabb0a90ee2411082573f715b42c50d))

## [1.100.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.99.0...1.100.0) (2024-05-13)


### :white_check_mark: Tests

* Negative validation for main number's double plus in Country
  Code ([28f59e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/28f59e9768ec66783c0dbde88b4506523786ecee))

### :sparkles: Features

* use new version of testing_tools to create jira based on nightly
  run ([13abbb4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/13abbb42c3b4cf560f6a637cea559d988763a30a))

## [1.99.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.98.3...1.99.0) (2024-05-10)


### :sparkles: Features

* UN-26223: Updated API models for CRF
  Gateway ([4f3d3e0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4f3d3e0eb1be856f190cd1f85af585e6e11aba89))

## [1.98.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.98.2...1.98.3) (2024-05-09)


### :bug: Fixes

* **https://jira.tools.aws.vodafone.com/browse/UN-30952:** Fixing label, the boolean failed at the helm
  deployment ([ce4cbf4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ce4cbf429cd142be43a125fc303c4c16586f605e))

## [1.98.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.98.1...1.98.2) (2024-05-08)


### :repeat: Chore

* **https://jira.tools.aws.vodafone.com/browse/UN-30952:** Remove automation-fw logs from
  Kibana ([8006672](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8006672fa11f336397e7f61bb361becbd4f1a763))

## [1.98.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.98.0...1.98.1) (2024-05-06)


### :bug: Fixes

* uplift MSOC account generator + billing info service type
  generator ([a3406ca](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a3406ca64b347e8a98a652b0672398b827342306))

## [1.98.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.97.1...1.98.0) (2024-05-03)


### :sparkles: Features

* update protobuf
  schema ([17463ee](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/17463ee78f015acc36510f4f9ed3942f4979a0aa))

## [1.97.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.97.0...1.97.1) (2024-05-03)


### :bug: Fixes

* UN-30162 remove_ddi scenarios updated with order type as
  separate ([83e6481](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/83e6481718f90d2510c9f4c59f9ff7b10d108874))

## [1.97.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.96.3...1.97.0) (2024-05-03)


### :sparkles: Features

* UN-21123: Decommission old JWT scopes for ID
  Mapper ([b81cd77](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b81cd77c193218b116c32c0b85f2741ff2a1540f))

## [1.96.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.96.2...1.96.3) (2024-05-02)


### :repeat: Chore

* sort
  properties ([2b601a6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2b601a667fac27445dc31019989c68757d97828c))

## [1.96.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.96.1...1.96.2) (2024-05-02)


### :repeat: Chore

* Updated to schema repo cbd56e3b1 (
  2024-04-30) ([f50ffca](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f50ffca96b5d0b20f1c1de37dd8046dfaae651da))

## [1.96.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.96.0...1.96.1) (2024-05-01)


### :bug: Fixes

* UN-29007: fix tests with notification
  retry ([2248e87](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2248e877a36cea12e0089ce058d290528a345e82))

## [1.96.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.95.2...1.96.0) (2024-04-29)


### :sparkles: Features

* add numbers generator for tmf
  payloads ([11670ef](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/11670efaf8e53d1cfa8c192f7cfb009c1288a64f))

## [1.95.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.95.1...1.95.2) (2024-04-29)


### :bug: Fixes

* UN-29522 remove CRF fail negative scenario from staging
  regression ([2a8ac19](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2a8ac19041fc6dfe8d11013c66c7b312d4a4c13b))

## [1.95.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.95.0...1.95.1) (2024-04-29)


### :repeat: Chore

* Updating
  schema ([5659a23](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5659a23c9ef11d45dc786d1853f1f9fa88cfaec0))

## [1.95.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.94.3...1.95.0) (2024-04-23)


### :sparkles: Features

* UN-28396: billing_account configured from characteristics instead of external
  references ([dbd1fae](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dbd1faed9ac555dcdc85762ab655c2645ff5b54b))

## [1.94.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.94.2...1.94.3) (2024-04-19)


### :bug: Fixes

* fix fetching saved customer for SO with billing
  info ([5f4c410](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5f4c41079a6958bf82b22fae7b980daaa71d06aa))

## [1.94.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.94.1...1.94.2) (2024-04-18)


### :bug: Fixes

* UN-18316 Validation of Account Status Change
  Request ([e2fa228](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e2fa228046343d15ef82961eb0502cf7bea33656))

## [1.94.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.94.0...1.94.1) (2024-04-15)


### :repeat: Chore

* Organise 'classes/api' files into relevant
  directories ([96757be](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/96757befcdf5e9e77f113b6a56391faa9977623b))

## [1.94.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.93.5...1.94.0) (2024-04-15)


### :sparkles: Features

* Merge Remove DDI feature to
  Master ([a0f4fa5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a0f4fa5f047c9f11480c70073b44916019ea7ce2))

## [1.93.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.93.4...1.93.5) (2024-04-12)


### :bug: Fixes

* Retest defect UN-29532 TMF Mediator is throwing errors for msoc.numbers validation when the BillingAccountInfo is
  null ([3cf6cc2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3cf6cc295ad04eb2f0554294c79bfd811a61cbe8))

## [1.93.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.93.3...1.93.4) (2024-04-10)


### :recycle: Refactor

* rename market to
  market_code ([e141b57](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e141b574f1a803c9940106d730ca71978a694899))

## [1.93.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.93.2...1.93.3) (2024-04-05)


### :barber: Code-style

* Changed keywords [Given, When, Then] to
  lowercase ([a1c8f8e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a1c8f8e2af79295d9d9a78cbd603bb981aeaacfc))

### :bug: Fixes

* Added scenarios and validation for 'carrierId' for MSOC Add
  DDIs ([2f0c7f9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2f0c7f929684e0845bab46d4885fde3d1619f4fb))

## [1.93.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.93.1...1.93.2) (2024-04-05)


### :bug: Fixes

* fix assert messages in CRF
  handler ([c97493e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c97493ed3cdc17084f6bdd688092a8a774fe88a2))

## [1.93.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.93.0...1.93.1) (2024-04-03)


### :bug: Fixes

* explicitly identify category for not supported service
  order ([a3453ac](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a3453ac3f59d98dc20b8f8cfdb225f9ef141836a))

## [1.93.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.92.0...1.93.0) (2024-04-01)


### :sparkles: Features

* payload generator
  class ([da96bea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da96bea3be668146957efbcd9bf4d7ca81aafb3b))

## [1.92.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.91.2...1.92.0) (2024-03-29)


### :sparkles: Features

* E2E staging tests for get
  account ([ef17dbc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ef17dbcd5375c04373948e506f220e6599c69fb3))

## [1.91.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.91.1...1.91.2) (2024-03-29)


### :bug: Fixes

* fixing UN_19332_05
  scenario ([c7ae796](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c7ae7960164849e61ac9c493cd8cf94ed68bdbe8))

## [1.91.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.91.0...1.91.1) (2024-03-29)


### :bug: Fixes

* Fixing scenarios related to ADD DDIs
  feature ([cddc79c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cddc79cf435a9a2e7228f869d4a7d069cc9f9331))

## [1.91.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.90.0...1.91.0) (2024-03-29)


### :sparkles: Features

* UN-29508: remove unused query parameters for TMF SI API
  calls ([ce41936](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ce419365b11e6b9e9269fb78e2511bd07dd81978))

## [1.90.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.89.0...1.90.0) (2024-03-28)


### :repeat: Chore

* UN-21191 update protobuf schema to
  5d66bfa1 ([c50856f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c50856f8229c5cde637ab3f7e237acb59eac843b))

### :sparkles: Features

* UN-19333 UCC Middleware API - Add
  DDI ([4a500e7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4a500e74b18054f852109bc8680d5b9e90eeb618))

## [1.89.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.88.1...1.89.0) (2024-03-27)


### :sparkles: Features

* Allow account information to be retrieved from
  RC ([aed64ca](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/aed64ca5f4b064881cc290e3694485836ab50025))

## [1.88.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.88.0...1.88.1) (2024-03-26)


### :bug: Fixes

* UN-27956: remove wrong dependency to
  protobuf ([0c8c4fb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0c8c4fbde7be68a33c1b65516edd408b22cff99c))

## [1.88.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.12...1.88.0) (2024-03-25)


### :sparkles: Features

* script to create maintenance stories for
  PI ([4af97e7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4af97e7df7c3e6265320053fa5267e319dd8cc99))

## [1.87.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.11...1.87.12) (2024-03-21)


### :bug: Fixes

* remove archive
  folder ([f6ac0d6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f6ac0d6564288afc42bca4f78f82cb5938d4cba1))

## [1.87.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.10...1.87.11) (2024-03-20)


### :recycle: Refactor

* reuse existing account for number management tests
  p.2 ([cb8730a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cb8730ae4873736f95626253b0754f50946ac616))

## [1.87.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.9...1.87.10) (2024-03-20)


### :bug: Fixes

* Allow 'ringcentral_event_accountserviceinfo_updated' to consume multiple
  messages ([c1f1231](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c1f1231fcb7aeadc673c93f81311ef283ad3fcd4))

## [1.87.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.8...1.87.9) (2024-03-20)


### :bug: Fixes

* Added error type to None to avoid failures in
  regression ([46830a1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/46830a12144d5e88c6c0aa728939c469bf5385d9))

## [1.87.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.7...1.87.8) (2024-03-19)


### :bug: Fixes

* fixed missing self keyword issue in error.py
  file ([ca06a60](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ca06a60ffaad8b4fa9ce3da7a0e2ce1ab182a131))

## [1.87.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.6...1.87.7) (2024-03-18)


### :recycle: Refactor

* UN-28431: rename validation
  function ([1587cb5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1587cb5b41301d431455d6bfa1e571cb6c1aef81))

## [1.87.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.5...1.87.6) (2024-03-18)


### :bug: Fixes

* Added code to test account not found error when NM doesn't found account with
  IDmapper ([53f316b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/53f316b58b42d8774e7ac61770a763c8c28062fd))

## [1.87.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.4...1.87.5) (2024-03-18)


### :recycle: Refactor

* replace step with not parametrized
  step ([01914c5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/01914c55bb17a414518ad49260f9a2d4a7bfbe6b))

## [1.87.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.3...1.87.4) (2024-03-15)


### :bug: Fixes

* workaround crf
  step ([78ef804](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/78ef80489eef6b5af9360c2f09d74545953c9bc3))

## [1.87.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.2...1.87.3) (2024-03-14)


### :bug: Fixes

* updated the testing tools
  sub-version ([68a912f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/68a912fa6558ba94624799e2741a9bca436cfd01))

## [1.87.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.1...1.87.2) (2024-03-13)


### :bug: Fixes

* add tests for MSOC
  validation ([f28778f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f28778f92e5274b126157eee583d71bfd4ed9cd4))

## [1.87.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.87.0...1.87.1) (2024-03-11)


### :bug: Fixes

* reload
  event_pb2 ([13bfee5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/13bfee5f62a01ae6fbbd3dce1379c69d70c13640))

## [1.87.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.86.2...1.87.0) (2024-03-11)


### :sparkles: Features

* remove
  swap ([d03c31d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d03c31d0a8a2e569633487c05cd8594ccee328cb))

## [1.86.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.86.1...1.86.2) (2024-03-07)


### :bug: Fixes

* UN-26547 regression failure 16843 01 01 on
  staging ([469f0b6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/469f0b6041ece4783ca968873f1787e6a5a67771))

## [1.86.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.86.0...1.86.1) (2024-03-07)


### :bug: Fixes

* **https://jira.tools.aws.vodafone.com/browse/UN-28108:** update email id for inbound mails and fix
  UPUA_460_11 ([380e052](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/380e052f939c8dbeaf811cba38f585905c73041f))

## [1.86.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.85.2...1.86.0) (2024-03-07)


### :sparkles: Features

* UN-27982: added pydantic models for all
  APIs ([24dcbc6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/24dcbc6b4f2ccab9d05a4ce33f3ebd33b3baf12c))

## [1.85.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.85.1...1.85.2) (2024-03-06)


### :bug: Fixes

* **https://jira.tools.aws.vodafone.com/browse/UN-27848:** fixing and enabling staging email
  validation ([30bb69a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/30bb69a3773f25afb07e697ddd7da66e96fe9f8a))

## [1.85.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.85.0...1.85.1) (2024-03-06)


### :recycle: Refactor

* reuse account for NM scenarios
  p.1 ([23ad871](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/23ad871599eaf705e2a73433d019eb15bdca5bc7))

## [1.85.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.84.2...1.85.0) (2024-03-06)


### :sparkles: Features

* https://jira.tools.aws.vodafone.com/browse/UN-19332_MSOC_add_Billing_Identifiers ([f2b4ee2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f2b4ee24b219c32e201faee2d54bcf3277eeb04c))

## [1.84.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.84.1...1.84.2) (2024-03-05)


### :bug: Fixes

* UN-27281: validate all service order items instead of just the first
  one ([731a6d3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/731a6d3b497f0ad9f79efc8b35a78b610e2c696e))

## [1.84.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.84.0...1.84.1) (2024-03-05)


### :repeat: Chore

* Update
  schema-repo ([d047771](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d047771228b7be202e2393874ca463707981c25b))

## [1.84.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.83.0...1.84.0) (2024-03-04)


### :sparkles: Features

* use new commit of testing_tools to get improved nightly
  message ([530493a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/530493aa33fa39a15103d3e96b2e8bb6347cf84c))

## [1.83.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.82.1...1.83.0) (2024-03-04)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-27951:** retrieve pod logs for specific
  MS ([681afe5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/681afe5cb968d2e56c413fc2013913d43b7eb99c))

## [1.82.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.82.0...1.82.1) (2024-03-01)


### :repeat: Chore

* UN-26660 unify
  tags ([400ed40](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/400ed40b53f618d4ceee7f047976fe1423c5dd81))

## [1.82.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.11...1.82.0) (2024-02-22)


### :sparkles: Features

* Provide Access to MSOC Customer
  Information ([1a8ac86](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1a8ac86526bf6ff6cb71ddd5ac4ec8c8f93987bb))

## [1.81.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.10...1.81.11) (2024-02-22)


### :bug: Fixes

* updated ordermanagement_complete_order validation
  set ([4787220](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4787220906efed80a6d89744736ef3ee3149b1d4))

## [1.81.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.9...1.81.10) (2024-02-21)


### :bug: Fixes

* failing scenario UN_10300_07 over incorrect RC
  account ([0f577c0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0f577c03bbb8283bf5ad3b705a12795616eda9a7))

## [1.81.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.8...1.81.9) (2024-02-20)


### :bug: Fixes

* [https://jira.tools.aws.vodafone.com/browse/UN-26727] regression
  fix ([e23128d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e23128d4670b0e380bae84a392ae637af5ddb0f7))

## [1.81.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.7...1.81.8) (2024-02-19)


### :bug: Fixes

* UN-27169: fix phone number
  generation ([cbdae2a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cbdae2a1761111efd0a29f4794e81c092c6e3df6))

## [1.81.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.6...1.81.7) (2024-02-16)


### :bug: Fixes

* **https://jira.tools.aws.vodafone.com/browse/UN-27101:** UN_510_05
  flakiness ([ad54db4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ad54db472c332c9b7a43d6167e676776da505a8d))

## [1.81.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.5...1.81.6) (2024-02-15)


### :bug: Fixes

* Changing the status code for
  opstatus ([008090d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/008090df3f83452d30e0c584437871ecb5be64d5))

## [1.81.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.4...1.81.5) (2024-02-14)


### :repeat: Chore

* Updated schema-repository and
  common_python ([44beb6b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/44beb6b0eedb98e045d181a15f080dd34c5d9522))

## [1.81.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.3...1.81.4) (2024-02-14)


### :bug: Fixes

* fixed failing scenarios in nightly
  run ([0e0bdec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0e0bdec4e0e476c86520a920747531b6ce05b7fc))

## [1.81.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.2...1.81.3) (2024-02-13)


### :bug: Fixes

* remove invalid scenario of
  msoc ([ffc5bff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ffc5bff16c11f1acf41bac9b95328579f6e57d2d))

## [1.81.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.1...1.81.2) (2024-02-13)


### :bug: Fixes

* UN-27072 set the JWT scope explicitly for invalid
  URLs ([9a284b3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9a284b398133028cced55ec5f644f74164678602))

## [1.81.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.81.0...1.81.1) (2024-02-12)


### :bug: Fixes

* UN-26868:
  fix_expected_service_type ([47a9e86](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/47a9e86e22b20b715ce188ffec286cb6a8e0265e))

## [1.81.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.80.6...1.81.0) (2024-02-09)


### :sparkles: Features

* UN-15097 jwt scope for RC
  gateway ([123f42e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/123f42e5102c2653bc053be87bda88a24818a2f3))

## [1.80.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.80.5...1.80.6) (2024-02-09)


### :repeat: Chore

* Updated schema-repository to
  72b3683 ([f0f2083](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f0f2083310b47a10b47a6d3aa4458fa4a622c657))

## [1.80.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.80.4...1.80.5) (2024-02-08)


### :bug: Fixes

* UN-26917 updated gen_contact with correct
  file ([648e452](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/648e452c40bf132b3c1a933df87f1cef24cb67bc))

## [1.80.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.80.3...1.80.4) (2024-02-08)


### :bug: Fixes

* UN-20951 email validation for add numbers
  scenarios ([cccd8f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cccd8f7e0ad389ef190ec2d306cca8c7767d5003))

## [1.80.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.80.2...1.80.3) (2024-02-08)


### :bug: Fixes

* UN-26956: add timeout and retry for JIRA API
  connections ([bfec41b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bfec41b54a2fee5f16e3a85bc30fb738ceaf8e88))

## [1.80.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.80.1...1.80.2) (2024-02-07)


### :repeat: Chore

* tagged wip a test with known
  failure ([be50f5b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/be50f5bfb608763535c197bc8fda1b787381b757))

## [1.80.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.80.0...1.80.1) (2024-02-06)


### :repeat: Chore

* tagged wip a test with known
  failure ([00027a5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/00027a5c83542a0ff220a9131fe2d2d00ee4e1d5))

## [1.80.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.11...1.80.0) (2024-02-06)


### :sparkles: Features

* UN-26658: Add support for JWT scope
  msoc_account/read_extended ([e485ba2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e485ba22ac0659354730c2e13c216cca29ddc426))

## [1.79.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.10...1.79.11) (2024-02-05)


### :bug: Fixes

* UN-26861: updated invalid URL for
  ringcentral-gateway ([310846d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/310846dc9bdc05dcd3cb1483e1d29a60a46189c4))

## [1.79.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.9...1.79.10) (2024-02-05)


### :repeat: Chore

* UN-26862: update rerun reports with id tag and defect
  fields ([749a28a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/749a28a85a773ae33b883b6d72ebce2dcf36174d))

## [1.79.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.8...1.79.9) (2024-02-02)


### :bug: Fixes

* update main number
  tests ([471a3a5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/471a3a5ec762e7373382db0c1114099182425d20))

## [1.79.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.7...1.79.8) (2024-02-01)


### :repeat: Chore

* UN-26862: Update nightly run script to add id_tag and defects to json
  report ([5927f42](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5927f424ad77cdf691cd4e1c24871137291a4e6d))

## [1.79.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.6...1.79.7) (2024-02-01)


### :bug: Fixes

* UN-26865: fix expected error
  message ([a2d927d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a2d927df0f8a103c16b37836c56ead247b537075))

## [1.79.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.5...1.79.6) (2024-02-01)


### :bug: Fixes

* add update main number topics
  validations ([e7f0329](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e7f03299a65509df1d9b073deee8b84deac6732f))

## [1.79.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.4...1.79.5) (2024-02-01)


### :bug: Fixes

* UN-26861: fix test for wrong
  URL ([9128f8e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9128f8e48ec334877018241645837763ac8a6356))

## [1.79.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.3...1.79.4) (2024-02-01)


### :bug: Fixes

* UN-26781: error message for idmapper topic for msoc
  customer ([9c783d8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9c783d811b114232a56c03dce6b09fe0682c5124))

## [1.79.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.2...1.79.3) (2024-02-01)


### :bug: Fixes

* UN-26782: number validation to handle pool
  ranges ([51127f2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/51127f20e1666908ea16bb071097f6c135809bf5))

## [1.79.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.1...1.79.2) (2024-01-31)


### :recycle: Refactor

* move tmf gateway requests to a separate
  module ([4c464cf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4c464cff3b98c49fce52ddd1abefaeef3cd1e452))

## [1.79.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.79.0...1.79.1) (2024-01-31)


### :bug: Fixes

* refactor code calling to RC Gateway, fix test and add tags for
  ringcentral-gateway ([b7fd999](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b7fd99988ba8796899564d01caaaed077b2e6843))

## [1.79.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.9...1.79.0) (2024-01-31)


### :sparkles: Features

* UN25190 appdirect stub
  port ([6d2cd79](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6d2cd796563f92ac2e34f479f36798e0af865928))

## [1.78.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.8...1.78.9) (2024-01-30)


### :bug: Fixes

* missing error message for
  UN_489_18 ([18bf742](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/18bf74299554fa6c24e737571c1ef06cc2ec4622))

## [1.78.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.7...1.78.8) (2024-01-30)


### :bug: Fixes

* error
  location ([3a85f6c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3a85f6cea9694c740eae85a19180f03738898e00))

## [1.78.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.6...1.78.7) (2024-01-30)


### :bug: Fixes

* missing context
  value ([1b2ae54](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b2ae548a6f5be9ff0d26171fe56e1c1e076a987))

## [1.78.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.5...1.78.6) (2024-01-29)


### :bug: Fixes

* add missing error
  values ([4615317](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/461531774bd8060c93232df5aa4970ee0c5c87dd))

## [1.78.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.4...1.78.5) (2024-01-29)


### :bug: Fixes

* (https://jira.tools.aws.vodafone.com/browse/UN-26669) updated the condition for ordermanagement_complete_order
  topic ([fcf3e86](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fcf3e862de13c58fc8ec8c047226d4dc9b3282fb))

## [1.78.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.3...1.78.4) (2024-01-29)


### :bug: Fixes

* UN-26706: updated log MDC
  requirements ([a6ffbbc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a6ffbbc67aa4de1d32d34b511a2e460ee42bb105))

## [1.78.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.2...1.78.3) (2024-01-26)


### :repeat: Chore

* Updated schema
  repository ([a0faf11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a0faf112a8a0f8eb545127399c2c1034861933b7))

## [1.78.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.1...1.78.2) (2024-01-25)


### :bug: Fixes

* account confirmation
  validation ([e896555](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e8965556d494397e4ec4a1cb0498510ac7ad61c8))

## [1.78.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.78.0...1.78.1) (2024-01-24)


### :repeat: Chore

* UN-26663 dry
  run ([bac80f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bac80f7a4d7045355f75b99ef6724b1bbde9ecc4))

## [1.78.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.77.0...1.78.0) (2024-01-24)


### :sparkles: Features

* UN-26576: wait_until refactored to display last value before
  timeout ([7608b5b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7608b5bfc09d767fb39ed184fad07f88ba26ba4c))

## [1.77.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.76.0...1.77.0) (2024-01-24)


### :sparkles: Features

* Adding Middleware correlationID in request
  header ([2f8d2e5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2f8d2e523c02ac6d8875b45fd216d1119529f016))

## [1.76.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.75.4...1.76.0) (2024-01-23)


### :sparkles: Features

* send messages to Teams in nightly
  run ([44fc2b8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/44fc2b877db55f891ec475b1f564d7e6ca174a2f))

## [1.75.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.75.3...1.75.4) (2024-01-19)


### :bug: Fixes

* UN 16833 scenarios
  fix ([01cf491](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/01cf4910489c04e4431059e94bc51966524714db))

## [1.75.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.75.2...1.75.3) (2024-01-18)


### :bug: Fixes

* remove else for order
  management ([e78d98d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e78d98db4f6dd1521efed48be679273aecdaba97))

## [1.75.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.75.1...1.75.2) (2024-01-18)


### :bug: Fixes

* replace
  tags ([52f8008](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/52f8008e0c0ccf1f9fc04f48ccdd01be6b543b5e))

## [1.75.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.75.0...1.75.1) (2024-01-18)


### :bug: Fixes

* dummy
  commit ([6db5984](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6db5984d71365294b39383b18219e3cba9e7295d))

## [1.75.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.74.0...1.75.0) (2024-01-18)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-9626:** change all accountmanagement topics to
  ordermanagement ([64459f6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/64459f675e6f9bab4eff113beb18653bf32a9f50))

## [1.74.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.73.1...1.74.0) (2024-01-18)


### :sparkles: Features

* Updated nightly results email
  list ([c0923f5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c0923f5d7ad2bdde391cf71ccb3b38932200cc48))

## [1.73.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.73.0...1.73.1) (2024-01-17)


### :bug: Fixes

* replace
  method ([f1ce2f6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f1ce2f69c9d00af8c80c82c48a0cd3f76de27f1f))

## [1.73.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.72.2...1.73.0) (2024-01-17)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/un-19510:** adding health check url's for new ms
  tmf-svc-inventory-gw-api ([902c13e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/902c13ee35be32b7ccef29bd45c4c19e2f114c41))

## [1.72.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.72.1...1.72.2) (2024-01-17)


### :bug: Fixes

* change validation numbermanagement_create_deletenumber and ringcentral_respond_deletenumber for
  ranges ([1021467](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1021467938f2506d6b86dfc4d07427f0bfc4cf90))

## [1.72.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.72.0...1.72.1) (2024-01-15)


### :repeat: Chore

* UN-26272 ringcentral-api is deprecated so removing tag
  name [@ringcentral-api](https://gitlab-ucc.tools.aws.vodafone.com/ringcentral-api) from
  A-FW ([ba1ada4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ba1ada471b050a596f6b58756830df5489331851))

## [1.72.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.71.4...1.72.0) (2024-01-12)


### :sparkles: Features

* UN-15923: Added new JWT scope
  tests ([4601cea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4601ceab07aaed7b95a6b768581670f8a8bf57dc))

## [1.71.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.71.3...1.71.4) (2024-01-11)


### :bug: Fixes

* add logging for crf
  tests ([e5b52c4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e5b52c42b8b1ca2f3a06b6056b8bd8060f97cbdd))

## [1.71.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.71.2...1.71.3) (2024-01-11)


### :bug: Fixes

* UN-26252: update notification eventType to be
  valid ([ad7ee68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ad7ee68b59f03fcdbf42fc14bbe890f5008cedcd))

## [1.71.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.71.1...1.71.2) (2024-01-10)


### :bug: Fixes

* Adding missing errortypes into message validation
  set ([ad5d6b5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ad5d6b54264dcee77545aaacc84ff31dea177a97))

## [1.71.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.71.0...1.71.1) (2024-01-09)


### :repeat: Chore

* Removed unused files and fixed invalid
  characters ([093e7d9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/093e7d92ec8ca6782cc79f5326601d7d72cd670a))

## [1.71.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.70.2...1.71.0) (2024-01-09)


### :sparkles: Features

* new kafka class to hold
  topics ([caf21aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/caf21aa658449627c188459055e4f7cdabfbf7f5))

## [1.70.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.70.1...1.70.2) (2024-01-09)


### :bug: Fixes

* Adding missing errortypes in
  Kafka_msg_validation_set ([395614f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/395614fbd3bd7181ca949eaca8bf44be4a691dd2))

## [1.70.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.70.0...1.70.1) (2024-01-09)


### :bug: Fixes

* **https://jira.tools.aws.vodafone.com/browse/UN-25510:** UN-14474 reg
  fix ([9eee83b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9eee83bba6e2ae6ad7e002d61686f904877527ac))

## [1.70.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.69.4...1.70.0) (2024-01-05)


### :sparkles: Features

* UN-25190: Created YAML files for test
  parameters ([0742b25](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0742b25b5e663adb702ac67293be40ae28550350))

## [1.69.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.69.3...1.69.4) (2024-01-03)


### :bug: Fixes

* To fix failing tests of
  UPUA_4498 ([b204bea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b204bea5f1fda2f368c437722605890bd0ed46d1))

## [1.69.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.69.2...1.69.3) (2024-01-03)


### :bug: Fixes

* Update file
  cronjob.yaml ([32576b9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/32576b92a2e9428f82b9010676d6468b5c6b5947))

## [1.69.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.69.1...1.69.2) (2024-01-02)


### :bug: Fixes

* add datetime
  field ([00148e2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/00148e21df2e28d6232f9e93874a2703135d1b0f))

## [1.69.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.69.0...1.69.1) (2024-01-02)


### :bug: Fixes

* env vars for callback on
  staging ([c99968e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c99968e24b2525f19d343b9e85d27e12ddd31672))

## [1.69.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.68.0...1.69.0) (2023-12-26)


### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-16183:** MW | Call Back Status
  TMF652 ([fea84a4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fea84a4088c5e6f902e64036fa55136dd684bc90))

## [1.68.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.67.1...1.68.0) (2023-12-22)


### :sparkles: Features

* UN-19241 get service order list by
  filter ([2bd5d25](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2bd5d25fb3b0268404a7b473a3f2d928dbd4a8ca))

## [1.67.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.67.0...1.67.1) (2023-12-21)


### :bug: Fixes

* UN-25511 adding wip tags to pool_range tc's of UN_509 and
  UN_489 ([438cd87](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/438cd87713d6ca99e9ff165d427bfdc89bf308ea))

## [1.67.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.66.4...1.67.0) (2023-12-21)


### :sparkles: Features

* UN-15084: JWT scopes for number
  management ([d2ad4c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d2ad4c11013ee6fe348583c8e3333590898b6cd3))

## [1.66.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.66.3...1.66.4) (2023-12-20)


### :bug: Fixes

* Updated 'to' and 'from' value to send an email for Ringcentral to
  Middleware ([07e581f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/07e581f11f03966acac5964949f8a6bab19ea6cd))

## [1.66.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.66.2...1.66.3) (2023-12-20)


### :bug: Fixes

* Error Handling failing
  scenarios ([c57c3ff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c57c3fffd2a82b5c3a26c5bab5dd373cd671021c))

## [1.66.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.66.1...1.66.2) (2023-12-18)


### :bug: Fixes

* UN-19708 E2E MSOC account
  creation ([a8547a0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a8547a045e94c7c3d5472205dbce3c18297e61db))

## [1.66.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.66.0...1.66.1) (2023-12-18)


### :bug: Fixes

* email sender staging
  fix ([83b61de](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/83b61debaac7cf122040dcce95437d4eb9c24fac))

## [1.66.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.65.0...1.66.0) (2023-12-15)


### :sparkles: Features

* Updated python
  requirements ([9fa38e0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9fa38e022032fad9a936bdf0e6ff2d89a1eebc85))

## [1.65.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.64.6...1.65.0) (2023-12-15)


### :sparkles: Features

* MW Error Handling - Add/Remove Number failure scenario -
  RC ([8975669](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89756695b71385401c299d43ae09e5a344fedaa0))

## [1.64.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.64.5...1.64.6) (2023-12-13)


### :recycle: Refactor

* UN-24842 reuse account when unconfirmed account is
  needed ([c8ae785](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c8ae785c132e33cf4a27169d94a41e7cff2119ea))

## [1.64.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.64.4...1.64.5) (2023-12-13)


### :bug: Fixes

* Add Test Environment Integration
  tests ([6e2b566](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6e2b566af0e353f289d04e2ceeff54673a1f4974))

## [1.64.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.64.3...1.64.4) (2023-12-13)


### :bug: Fixes

* updated email sender api and automated email
  validation [https://jira.tools.aws.vodafone.com/browse/UN-24143] ([9323bf7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9323bf766564dd9a7eac109d56fb8389501ebd35))

## [1.64.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.64.2...1.64.3) (2023-12-12)


### :bug: Fixes

* UN-25205 CRF_Delete_numbers TC's failing in
  regression ([8eee508](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8eee508f3df16bf7a01e1a4a1bb36b5434e4dbe1))

## [1.64.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.64.1...1.64.2) (2023-12-11)


### :bug: Fixes

* Remove deprecated env
  variables ([8c01058](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8c01058e0e9765b49a6d46af5fc8900a9a13d414))

## [1.64.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.64.0...1.64.1) (2023-12-08)


### :bug: Fixes

* removing descoped scenarios from nightly regression
  suite ([02e66c8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/02e66c83d6ddaaf8dbfdd361f7ee8e19fe2c506a))

## [1.64.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.63.2...1.64.0) (2023-12-06)


### :sparkles: Features

* Updated
  schema_repository ([1cd107c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1cd107cc034f101985208562acbe546b4699c9ed))

## [1.63.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.63.1...1.63.2) (2023-12-06)


### :bug: Fixes

* UN-20970 changes in
  tags ([c25253e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c25253e43c3bc25090718f8debf81b046def40bc))

## [1.63.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.63.0...1.63.1) (2023-12-06)


### :bug: Fixes

* Change emailfilter to emailreceiver
  topic [https://jira.tools.aws.vodafone.com/browse/UN-20533] ([da899eb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da899ebcdb6a68b5b947134ad45d2ac7910b7553))

## [1.63.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.62.1...1.63.0) (2023-12-06)


### :sparkles: Features

* Enhance ID mapper to retrieve all accounts for a
  market ([07c9196](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/07c9196f26e80bb3e0545cb2285dfd5bd405267b))

## [1.62.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.62.0...1.62.1) (2023-12-06)


### :bug: Fixes

* UN-19705 create a Jira ticket after MSOC create
  operation ([cb876e8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cb876e890218b489bc534d756edd84ab35f8a776))

## [1.62.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.61.1...1.62.0) (2023-12-05)


### :sparkles: Features

* automated the delete presentation
  flow ([92d9411](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/92d9411bf8d262e147e02c2f9def02c01459b449))

## [1.61.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.61.0...1.61.1) (2023-12-01)


### :bug: Fixes

* MR to run
  pipeline ([7614988](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/76149888fc1615a181fa83e2fc9a568a622ef986))

## [1.61.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.12...1.61.0) (2023-12-01)


### :sparkles: Features

* UN-24889: exclude tests
  tagged [@wip](https://gitlab-ucc.tools.aws.vodafone.com/wip) ([30dd938](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/30dd938f27cc3439885ea2a89b3bfce4ea80c1b6))

## [1.60.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.11...1.60.12) (2023-12-01)


### :bug: Fixes

* UN-19699 validation for new fields in MSOC Service
  order ([86409aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/86409aac70a7b0e7d000d9b6ef2b23d23eb6996b))

## [1.60.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.10...1.60.11) (2023-11-30)


### :repeat: Chore

* Updated python version to
  3.12 ([582ceae](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/582ceae4d34051843e67c25aa79ef1fe4898924e))

## [1.60.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.9...1.60.10) (2023-11-30)


### :bug: Fixes

* use
  configmap ([b9865f4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b9865f40d425d01dca36742feb5be440728eecc3))

## [1.60.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.8...1.60.9) (2023-11-30)


### :bug: Fixes

* update
  yamls ([adaef81](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/adaef81b88859bbf7d8450cebe0d779e5d6e1e5e))

## [1.60.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.7...1.60.8) (2023-11-30)


### :bug: Fixes

* Update UPUA_2499 scenarios to use ordermanagement_complete_order topic for duplicate
  account ([060bb72](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/060bb72588f4818579646f83075957e858b11ba7))

## [1.60.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.6...1.60.7) (2023-11-28)


### :bug: Fixes

* UN-19700 tmf mediator sends new fields in MSOC create
  account ([5fdd6d2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5fdd6d2d0afe14a3b1b69da8730d3885b202ec0e))

## [1.60.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.5...1.60.6) (2023-11-27)


### :bug: Fixes

* Temporary tags removal to unblock Number Management API
  pipeline ([7d07628](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7d076289045d80d9f7815aa989d4ea54ed25bbce))

## [1.60.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.4...1.60.5) (2023-11-27)


### :bug: Fixes

* UN-21527: Fix behave pretty formatter overwriting last log
  lines ([3494085](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3494085e010c6e8ccf0aa38759e332b3cc02451c))

## [1.60.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.3...1.60.4) (2023-11-24)


### :bug: Fixes

* Added steps to create account for
  UN-9408 ([b5de960](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b5de960e7ca5c1209f0513bd0eb805633cdb5b70))

## [1.60.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.2...1.60.3) (2023-11-24)


### :bug: Fixes

* Chandrani/UN_19701_MSOC_new
  fields_added ([9cf1c54](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9cf1c5433a5219f6598c2544b8a9ba2d7f07a035))

## [1.60.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.1...1.60.2) (2023-11-23)


### :bug: Fixes

* failing tests UN_489_13 and
  UN_14474_08 ([91b9722](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/91b9722e501b5a0b530aeafd785da01a81a54b2b))

## [1.60.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.60.0...1.60.1) (2023-11-21)


### :recycle: Refactor

* UN-12777 reuse
  account ([aa1f839](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/aa1f83932a3c3dc858df2d0e8dd7274dbf771194))

## [1.60.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.59.0...1.60.0) (2023-11-20)

### :sparkles: Features

* UN-15072: added new scopes for ID mapper
  API ([3e94bda](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3e94bdaa7a8e6d9ab3eacc02d1076827d68a25f4))

## [1.59.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.58.2...1.59.0) (2023-11-16)

### :sparkles: Features

* UN-14825: validation of milestones using
  pydantic ([a47b684](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a47b684fcec8e9a6aa503252169177ff9955d8b9))

## [1.58.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.58.1...1.58.2) (2023-11-15)

### :bug: Fixes

* UN-14825: milestone validation with support for duplicated
  numbers ([3260bbb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3260bbb7ac5efeff8f30038c145954d714623834))

## [1.58.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.58.0...1.58.1) (2023-11-15)

### :bug: Fixes

* Chandrani/un 19712 adding new msoc
  fields ([418be0a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/418be0aa3ff567f3375ea1f062dffaeaadbc734a))

## [1.58.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.57.0...1.58.0) (2023-11-15)

### :sparkles: Features

* CRF Gateway to send ranges to
  dep ([6de4017](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6de4017833b9106992718ef1f9069651ec53612f))

## [1.57.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.56.2...1.57.0) (2023-11-15)

### :sparkles: Features

* UN-14825 milestone
  validation ([bae63d6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bae63d68c947997679a38923676271e713ac33e2))

## [1.56.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.56.1...1.56.2) (2023-11-10)

### :bug: Fixes

* dummy MR to restart the
  POD's ([b4a915b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b4a915be94d39f03931e16a706cf298c662eddce))

## [1.56.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.56.0...1.56.1) (2023-11-09)

### :bug: Fixes

* change cj api
  version ([2075446](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2075446062dc4130a2910976059f59fdcb2be0dc))

## [1.56.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.9...1.56.0) (2023-11-09)

### :sparkles: Features

* Process Main, Admin, Presentation number and list of numbers to de dupe before
  batching ([577ed34](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/577ed3429becdafad7e79deafb040c6bd069bec7))
* UN-16726 feature
  file ([69a3518](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/69a351820901287a9d471d4f5a2bfdbc93b3e6dc))
* validation of note for duplicate numbers in service
  order ([50a45d5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/50a45d505409465b0d2d464ecff021ba8c931216))

## [1.55.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.8...1.55.9) (2023-11-07)

### :bug: Fixes

* replace topic
  name https://jira.tools.aws.vodafone.com/browse/UN-18314 ([facb44f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/facb44f857ed7067bd17d9eb301718a7f5f4a4ee))

## [1.55.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.7...1.55.8) (2023-11-07)

### :bug: Fixes

* Outbound email notification
  validation ([b189486](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b1894863f0bba7f4d04e92702ffc08b71b92caa0))

## [1.55.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.6...1.55.7) (2023-11-06)

### :bug: Fixes

* fixing up after ringcentral_respond_addnumber
  refactoring ([86f3e6c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/86f3e6c3a1b0d65bb278d56b5a097621eded079d))

## [1.55.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.5...1.55.6) (2023-11-03)

### :bug: Fixes

* Updated the json of MSOC json
  schema ([ce088c4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ce088c46c9fbcf6b354b833e8ee45467ffad71ca))

## [1.55.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.4...1.55.5) (2023-11-02)

### :bug: Fixes

* UN-20470: Add delay until vodafone_id exists before creating
  users ([e3ec83e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e3ec83e16c4aba17638098cadf4009ff3101c6ef))

## [1.55.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.3...1.55.4) (2023-10-31)

### :bug: Fixes

* uncomment account creation
  steps ([e1a6f9f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e1a6f9fcd89ecd2dd214d7f71de710ce2cbb6c38))

## [1.55.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.2...1.55.3) (2023-10-31)

### :bug: Fixes

* validate unordered numbers for numbermanagement_create_addnumber and
  ringcentral_respond_addnumber ([827b266](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/827b266b59173249c001858e41a6bb6b3b2d5e01))

## [1.55.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.1...1.55.2) (2023-10-26)

### :repeat: Chore

* updating pb2
  files ([144534d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/144534d78370835a3dc6f4048b3e8eb9421692ce))

## [1.55.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.55.0...1.55.1) (2023-10-26)

### :bug: Fixes

* sort numbers before validation in crfstub_process_resourceorder
  topic ([f640c43](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f640c435ad9cb18d89a50987af9d5f7b639f7672))

## [1.55.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.10...1.55.0) (2023-10-23)

### :sparkles: Features

* Enhance Patch
  request ([ea31b2d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ea31b2d32e2a7bb1cba9ee39a3e06d983d5918ee))

## [1.54.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.9...1.54.10) (2023-10-16)

### :bug: Fixes

* **https://jira.tools.aws.vodafone.com/browse/UN-20065:** Changing way to search messages: removing hardcoded address
  and looking into all message
  values. ([19e9a88](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/19e9a8841cc7f3c6f9eadc66e6c3d46b0abfe864))

## [1.54.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.8...1.54.9) (2023-10-09)

### :recycle: Refactor

* UN-16894: Refactor
  idmapper ([38e37ac](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/38e37ac40b5db79cfbe5f776844f7c7e48732b3b))

## [1.54.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.7...1.54.8) (2023-10-06)

### :bug: Fixes

* UN-19726 fix failing
  scenarios ([477ef45](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/477ef45d5ad3702276678406806625f1a8e57d0c))

## [1.54.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.6...1.54.7) (2023-10-05)

### :recycle: Refactor

* UN-18447: Refactor asserts equal and
  field_equal ([9aae129](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9aae129a9bef84c01b4000b4053ec0e329b1981e))

## [1.54.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.5...1.54.6) (2023-10-04)

### :recycle: Refactor

* UN-15802 refactor status code
  validations ([f94ccb8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f94ccb8aec2ca2b7f92959d7ab86c24ebb34f0cf))

## [1.54.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.4...1.54.5) (2023-10-03)

### :bug: Fixes

* enable
  UN_14474_10_01 ([2e9d88c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2e9d88c8c87bb22d513638b20f35a7435d89cc73))

## [1.54.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.3...1.54.4) (2023-09-29)

### :recycle: Refactor

* UN-13663: Review the code and remove the hardcoded
  delay ([1e069fa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1e069fa7593838efaa404e3d2afb92a6e55bd506))

## [1.54.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.2...1.54.3) (2023-09-29)

### :bug: Fixes

* disable UN_14474_10_01 to unblock
  pipeline ([770392b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/770392b82e0d1a4bcddb2fcbeb047ca731f1f821))

## [1.54.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.1...1.54.2) (2023-09-29)

### :recycle: Refactor

* tmfmediator create addnumbers topic
  validation ([2e530fa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2e530fa8069587c2d4fee65fddd991c56abc4a47))

## [1.54.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.54.0...1.54.1) (2023-09-28)

### :bug: Fixes

* dummy
  commit ([25bd3f3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/25bd3f37a58d46eaa6f4885c043c5341026590a6))

## [1.54.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.53.0...1.54.0) (2023-09-27)

### :sparkles: Features

* add detailed logs for integration tests GCP
  report ([618f631](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/618f6313c3ac09a2c3a2999b6b1ff999eb16bfb9))

## [1.53.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.52.3...1.53.0) (2023-09-20)

### :sparkles: Features

* **https://jira.tools.aws.vodafone.com/browse/UN-18312:** replace accountmanagement_create_initialorder with
  ordermanagement_create_initialorder ([02f1fc7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/02f1fc7fa8007b7a7744c56c85eb53967d182f2e))

## [1.52.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.52.2...1.52.3) (2023-09-15)

### :bug: Fixes

* Updated script for defect UN-18687 and also fixed failing scenarios from regression for this
  defect ([54566f0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/54566f073acc1270f4dfbcad69c1d6719e1a623b))

## [1.52.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.52.1...1.52.2) (2023-09-14)

### :bug: Fixes

* Fix for msoc lookup failing scenarios on
  staging ([74e9735](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/74e97355758336ea4fd8d24614678add6693a1d4))

## [1.52.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.52.0...1.52.1) (2023-09-14)

### :bug: Fixes

* Added test case to cover defect
  UN-18753 ([9aaafce](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9aaafce94f6094724aa848d1dfaedc82434bd684))

## [1.52.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.51.0...1.52.0) (2023-09-14)

### :sparkles: Features

* UN-16132 allow tmf notifications to be manually
  retried ([e8bd6b8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e8bd6b89f25356bc856952c5ad0573893b4a5701))

## [1.51.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.50.0...1.51.0) (2023-09-12)

### :sparkles: Features

* Log refinement
  poc ([7d7d262](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7d7d262d27e0f2292ceaf61f4474dcacc6cc512a))

## [1.50.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.49.2...1.50.0) (2023-09-12)

### :sparkles: Features

* Fix version reported in JSON
  reports ([32a6865](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/32a6865106da9205fe15c67c240898bf2ddebcb9))

## [1.49.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.49.1...1.49.2) (2023-09-08)

### :recycle: Refactor

* UN-15953: update use of deprecated API methods get_unverified and
  post_unverified ([1f26c53](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1f26c5303ba0eadbd426dfc137e8f478a7c8a48d))

## [1.49.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.49.0...1.49.1) (2023-09-08)

### :bug: Fixes

* Add pod logs
  permissions ([62b6257](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/62b62571ef09e23df2227dad20c0d37887d395c8))

## [1.49.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.48.3...1.49.0) (2023-09-07)

### :sparkles: Features

* Added code to test feature for Billing Account IDs and Opportunity
  reference ([89fd1f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89fd1f7cee9cf311226676355ac50641b4833106))

## [1.48.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.48.2...1.48.3) (2023-09-06)

### :bug: Fixes

* added descoped tag for tmf gateway failing
  pipeline ([8ebfa90](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8ebfa90a20fe0520e3b31879399cf1902b8efbe1))

## [1.48.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.48.1...1.48.2) (2023-09-05)

### :bug: Fixes

* data factory
  pipeline ([8b32daa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8b32daa56a4e7277a939563bbffe347a5a5c7a56))

## [1.48.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.48.0...1.48.1) (2023-09-04)

### :bug: Fixes

* Chandrani staging sso
  fix ([a02377b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a02377b5e732be2fbcc9c903c8a0f13c60b1f6e7))

## [1.48.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.7...1.48.0) (2023-08-29)

### :sparkles: Features

* Added code to test carrierID
  feature ([41243f6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/41243f6cae8aca695ebdef392ec20a5f0b700de9))

## [1.47.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.6...1.47.7) (2023-08-29)

### :bug: Fixes

* Updated the logic to generate unique phone numbers every
  time ([01558b5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/01558b5be193f80430b9702db868cd111b711596))

## [1.47.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.5...1.47.6) (2023-08-24)

### :bug: Fixes

* UPUA_172_01 failing on
  regression ([b09a9f0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b09a9f08ae78827ac636dd8bd6262164b8ce9da1))

## [1.47.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.4...1.47.5) (2023-08-24)

### :bug: Fixes

* Customer name character limit test for CRF TMF652
  API ([35c41e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/35c41e9826383338aed2c87f7bffdbd51d55cd21))

## [1.47.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.3...1.47.4) (2023-08-21)

### :bug: Fixes

* UN_17265 rtag value on
  jwks ([dce7f3b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dce7f3b0506dc64c18413ced58b09c269e0e04f0))

## [1.47.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.2...1.47.3) (2023-08-18)

### :repeat: Chore

* Update
  schema-repository ([9ecd317](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9ecd317222aba1fe8b94633aeab5ead38207d8d3))

## [1.47.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.1...1.47.2) (2023-08-17)

### :bug: Fixes

* un 16130 updated step modified & added regression
  tag ([af1081d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/af1081d6e9a4c83d542fc41ca7d3c7c435dbd2d2))

## [1.47.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.47.0...1.47.1) (2023-08-17)

### :repeat: Chore

* updated test results mailing
  list ([c8a56f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c8a56f775466bd29de1f4edad19708e974e15da5))

## [1.47.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.46.1...1.47.0) (2023-08-16)

### :sparkles: Features

* UN-15558: fixed quotes on step
  arguments ([cd449ef](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cd449efaed74417a064424b3b6d51e205ade45fe))

## [1.46.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.46.0...1.46.1) (2023-08-11)

### :bug: Fixes

* Changing the extension
  length ([2d5dd68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2d5dd685dd27df0deabf25022887a889c4f009c4))

## [1.46.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.45.0...1.46.0) (2023-08-11)

### :sparkles: Features

* un 16130- Implement retries for Webclient calls in TMF Gateway
  Notifications ([93096fb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/93096fb740c37994b0d7b5cd2262ff35f4684e56))

## [1.45.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.44.1...1.45.0) (2023-08-11)

### :sparkles: Features

* Added code implementation to verify changes done in TMF652
  API_UN-17260 ([707f178](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/707f178905d8275c6c43e74c972df03c9f8aba2e))

## [1.44.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.44.0...1.44.1) (2023-08-10)

### :bug: Fixes

*
UPUA_4120_failing_tests ([8e94d61](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8e94d61f965af19166fef55acdf46814c8d06c77))

## [1.44.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.43.2...1.44.0) (2023-08-08)

### :sparkles: Features

*
UN_14369_SSO_Extention ([36645dc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/36645dc86169ad8f9051b64b37c517893bb0ae07))

## [1.43.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.43.1...1.43.2) (2023-08-08)

### :repeat: Chore

* Updated test results mailing
  list ([4281d6b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4281d6bb161d722b233af58050abdb8f1ff12b0c))

## [1.43.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.43.0...1.43.1) (2023-08-03)

### :repeat: Chore

* Update schema-repository to
  2fee0f6791 ([a8f153e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a8f153e9bfb06b7464e42588ff9863f2ae9907cd))

## [1.43.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.7...1.43.0) (2023-07-28)

### :sparkles: Features

* UN-16428: formatters report a cleaner exception name in failure
  cause ([8c5ddbb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8c5ddbbbfa3a5c089b6e8535e46a4186eec9c598))

## [1.42.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.6...1.42.7) (2023-07-25)

### :repeat: Chore

* Save augmented behave report to
  file ([9b53638](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9b536382cbaa2b661d2c6c452b191c8d33711f75))

## [1.42.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.5...1.42.6) (2023-07-25)

### Other Changes

* add new secret
  reading ([f9e0563](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f9e05633c0c26dd800999c19f407ae2457a936ad))

## [1.42.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.4...1.42.5) (2023-07-20)

## [1.42.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.3...1.42.4) (2023-07-20)

## [1.42.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.2...1.42.3) (2023-07-20)

## [1.42.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.1...1.42.2) (2023-07-19)

### Bug Fixes

* no response from email
  manager ([0f77a29](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0f77a29484daf7d5fffdf9dc7f961b00b3a4b1fe))

## [1.42.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.42.0...1.42.1) (2023-07-18)

### Bug Fixes

* **https://jira.tools.aws.vodafone.com/browse/UN-13110:** replace with
  NumbersConfirmation ([c34590b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c34590b4a99233203ee3702fab09cc1761308d3e))

# [1.42.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.41.1...1.42.0) (2023-07-17)

### Features

* **https://jira.tools.aws.vodafone.com/browse/UN-17236:** send report json to the test
  team ([8ec6f1d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8ec6f1d57dedd97c28f00ae4d47be7c10360229d))

## [1.41.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.41.0...1.41.1) (2023-07-14)

### Bug Fixes

* added staging integration tests tag for appdirect
  responder ([51cf2dd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/51cf2ddf6dfac8a7107a32a5689819d3405b1e6a))

# [1.41.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.40.0...1.41.0) (2023-07-11)

### Features

* UN-15868 convert behavex logs to
  behave ([c5fc952](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c5fc9524d76e26353a071a3d0a4098feb62da71c))

# [1.40.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.12...1.40.0) (2023-07-11)

### Features

* UN-17081: Add test version to
  reports ([281b5a0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/281b5a0053d64eeca9060f4004cd4a7d643d523c))

## [1.39.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.11...1.39.12) (2023-07-07)

### Bug Fixes

* Mansa/fix negative scenarios add numbers
  presentation ([69ac102](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/69ac1028e672bed8d0ba5e80401e5a109ea4b664))

## [1.39.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.10...1.39.11) (2023-07-07)

### Bug Fixes

*
UPUA_2470_01 ([d46e1bc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d46e1bc4e4b2f1ae808827428053fee94ca64f7a))

## [1.39.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.9...1.39.10) (2023-07-07)

### Bug Fixes

* missing context.kafka_topic_name with value from step
  parameter ([68019e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/68019e981864283a4da56f5ff07c57612184906d))

## [1.39.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.8...1.39.9) (2023-07-05)

## [1.39.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.7...1.39.8) (2023-07-05)

### Bug Fixes

* UN-16899: continue test execution when service order is still
  inProgress ([c810d04](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c810d04f2eb93c7cb0dbc19025c99d7015c2e7ae))

## [1.39.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.6...1.39.7) (2023-07-04)

### Bug Fixes

*
UPUA_149 ([00524c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/00524c1e057c1179e0bedf7893ba7b9798dfdf9c))

## [1.39.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.5...1.39.6) (2023-07-03)

### Bug Fixes

* added check to fix
  UN_509_06 ([9c4af38](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9c4af38a5d03f099fa082728661951f96ca6b487))

## [1.39.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.4...1.39.5) (2023-06-30)

### Bug Fixes

* UN-16427 added explicit wait before checking account creation
  result ([f43933f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f43933f6fc1e407640d75362f66071838fe70e70))

## [1.39.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.3...1.39.4) (2023-06-30)

### Bug Fixes

* create account on
  staging ([db7d202](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/db7d202003ea23978103870cc463ed339cc94e7e))

## [1.39.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.2...1.39.3) (2023-06-30)

### Bug Fixes

* Reverted deletion of some required attachment
  files ([4161e0d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4161e0d4ff59bb6a6456d5bdd07bc33179b57c13))

## [1.39.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.1...1.39.2) (2023-06-28)

## [1.39.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.39.0...1.39.1) (2023-06-28)

### Bug Fixes

* fix the failing scenarios in nightly
  run ([310591c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/310591c9bd14e3c2db3022a750b0153b6e4a4a05))

# [1.39.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.38.0...1.39.0) (2023-06-27)

### Features

* **https://jira.tools.aws.vodafone.com/browse/UN-509:** delete numbers in
  CRF ([3ee7907](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3ee7907c8632cb7c505d5ab514456b9b621d4991))

# [1.38.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.37.0...1.38.0) (2023-06-26)

### Features

* **https://jira.tools.aws.vodafone.com/browse/UN-13894:** Add Numbers -
  Presentation ([c72b1e2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c72b1e2cfb75cdc1afa2437cafba349e4ca79e40))

# [1.37.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.36.2...1.37.0) (2023-06-23)

### Features

* UN-16231 Make api_request exception message more
  generic ([7fc4bf5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7fc4bf566d82220bacbc960595fb1c6bc4d1f43b))

## [1.36.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.36.1...1.36.2) (2023-06-22)

## [1.36.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.36.0...1.36.1) (2023-06-20)

### Bug Fixes

* add wait until for
  crf ([19aab42](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/19aab42bac9598df934ee0c289ace18990e52753))

# [1.36.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.35.1...1.36.0) (2023-06-20)

### Features

* UN-15665: allow setting kafka multi-message minimum
  count ([2d41d47](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2d41d47186d0b34b7726784cca4858624da7c472))

## [1.35.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.35.0...1.35.1) (2023-06-15)

### Bug Fixes

* Updating BDD keywords for UPUA-2606_Provisioning_In_RC
  feature ([173b34a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/173b34a024b9bcf6c6567495a9e441f5aad1fc60))

# [1.35.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.34.2...1.35.0) (2023-06-15)

### Features

* UN-16141: updated formatter so that error reported is less specific and always a list of
  strings ([1b542c7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b542c7f67a2f5697b65b855eed724a7f40db72c))

## [1.34.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.34.1...1.34.2) (2023-06-14)

### Bug Fixes

* negative tcs for SSo and
  extension ([877849f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/877849f23adfb182112c559ebcff46220642be33))

## [1.34.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.34.0...1.34.1) (2023-06-13)

### Bug Fixes

* replace crf with high level
  step ([fd31453](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fd31453ad74da4ebe75c96eba4f9c288dd7590f9))

# [1.34.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.33.4...1.34.0) (2023-06-12)

### Features

* UN-15681: Added new formatter
  json.pretty_simple_custom ([9fec64b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9fec64b2ac8e73d73cbfa091f1969e6ce3d36e84))

## [1.33.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.33.3...1.33.4) (2023-06-09)

## [1.33.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.33.2...1.33.3) (2023-06-08)

### Bug Fixes

* adjust test for crf add number on
  staging ([2ad5b9e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2ad5b9e4b9ed394e009763c36ec059432224f310))

## [1.33.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.33.1...1.33.2) (2023-06-07)

### Bug Fixes

* hot fix number management and tmf mediator
  pipelines ([22cd3e0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/22cd3e078549e1861477cab9a6df4dea3aafb369))

## [1.33.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.33.0...1.33.1) (2023-06-07)

### Bug Fixes

* handle test flow using feature flag + fixing
  jira ([4aac3c6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4aac3c66232da3bad538c719062bd2b30ace7b82))

# [1.33.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.32.0...1.33.0) (2023-06-06)

### Features

* Final Submission of SSO Configuration and change extension length
  scripts ([d0d49b9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d0d49b99ae46beca250f9816122f6d7bd204b312))

# [1.32.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.31.2...1.32.0) (2023-05-31)

### Features

* UN-15026: use common_python auto authorization header for API
  calls ([0bd29b6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0bd29b67116fa354f1e43b2df89041db492379be))

## [1.31.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.31.1...1.31.2) (2023-05-31)

### Bug Fixes

* Added regression tag to the scenarios which are running in
  pipeline ([09fd5d3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/09fd5d3d3c032d727c9cf4d97d0e2f57999d9a18))

## [1.31.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.31.0...1.31.1) (2023-05-25)

### Bug Fixes

* un-13878 identify bdd keywords
  mr3 ([9d7da23](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9d7da23bdc10e9f7eeb34bc1b1e2f40de6a246cf))

# [1.31.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.30.1...1.31.0) (2023-05-24)

### Features

* UN-15570 Added requirements.in for
  pip-tools ([19ade06](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/19ade06bf7d5206f8797939a009e5876b41ef668))

## [1.30.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.30.0...1.30.1) (2023-05-23)

### Bug Fixes

* updating When keyword in UPUA-2499.feature & removing regression and sanity tag for swap number in
  UPUA-2606_Provisioning_In_RC.feature ([375f6ec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/375f6ecff04cb09a083f3385ef93db09d0b5393b))

# [1.30.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.13...1.30.0) (2023-05-17)

### Features

* UN-15180 Add support to read_xmldata to exclude files from previous
  tests ([1b5442b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b5442b48d8f9fa09b5d3b6c4a76b0ec57fb8154))

## [1.29.13](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.12...1.29.13) (2023-05-17)

### Bug Fixes

* step payload is sent to Kafka Topic
  {topic_name} ([25e5e45](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/25e5e456a696f9a198357f377ecb0b1a9c7f4c81))

## [1.29.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.11...1.29.12) (2023-05-16)

### Bug Fixes

* UN-13878 minor fix for 4 failing
  scenarios ([8e9a012](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8e9a0122210f1ee41a4d7f61c19d32d4d7447265))

## [1.29.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.10...1.29.11) (2023-05-09)

## [1.29.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.9...1.29.10) (2023-05-08)

## [1.29.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.8...1.29.9) (2023-05-05)

## [1.29.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.7...1.29.8) (2023-05-03)

## [1.29.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.6...1.29.7) (2023-05-03)

## [1.29.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.5...1.29.6) (2023-04-28)

### Bug Fixes

* UN-15317 Fixing Then
  steps ([c0dd245](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c0dd245f899d17e366612e78281ee575ea851cee))

## [1.29.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.4...1.29.5) (2023-04-28)

### Bug Fixes

* Erik/un-15200 Fix
  UPUA_3524_01_01 ([3c6254a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3c6254a281dbe35042c656eb7e1287cdde6b16ec))

## [1.29.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.3...1.29.4) (2023-04-27)

## [1.29.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.2...1.29.3) (2023-04-25)

## [1.29.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.1...1.29.2) (2023-04-24)

### Bug Fixes

* un 15036 accept partial ros
  crf ([d26b5e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d26b5e9f87340651ac1d0e8ce90f7a3b7a0c1f67))

## [1.29.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.29.0...1.29.1) (2023-04-21)

### Bug Fixes

*
UN-14858_fix_2606_regression ([24d039e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/24d039e6a5a043b6a0ed5491c428fac9a909ec42))

# [1.29.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.28.1...1.29.0) (2023-04-21)

### Features

* UN-14629 Add timestamp check for received
  messages ([8cf82dc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8cf82dc636bcb0d55f2434678b867c3120da1210))

## [1.28.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.28.0...1.28.1) (2023-04-19)

### Bug Fixes

* Updating the scripts to fix the failing testcases related to PUT notification under
  2606 ([864a130](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/864a1300a7ca9ab4e614bba90c035a08f7760a6e))

# [1.28.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.27.4...1.28.0) (2023-04-17)

### Features

* introduce using fixture for account creation
  prerequisite ([c05182a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c05182aaacbeb92044668d0654765e7267f1b87d))

## [1.27.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.27.3...1.27.4) (2023-04-14)

### Bug Fixes

* erik/un_15012 fix upua_4550_09
  test ([2ec5e2c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2ec5e2c132855499808a300e2273ccadd5e64570))

## [1.27.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.27.2...1.27.3) (2023-04-13)

### Bug Fixes

* Updated the method type for swap and fixed failing scenario UPUA_1364_11 and
  UPUA_1364_17 ([c0d4bdb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c0d4bdb37a71ea405883d32aa07c8a3c90ed40eb))

## [1.27.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.27.1...1.27.2) (2023-04-11)

### Bug Fixes

* un 14224 code improvement for step
  def ([87efea0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/87efea04a1cdaf0759cfa525730c39d4ae2387d6))

## [1.27.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.27.0...1.27.1) (2023-04-11)

### Bug Fixes

* un 14805 fixing undefined
  variable ([bb58d7b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bb58d7bfd148cbb7da016291c63c6488869b243e))

# [1.27.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.10...1.27.0) (2023-04-11)

### Features

* UN-14784 Log version of
  automation-fw ([5cafa60](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5cafa602f2f3a0341a05f06fbadd3ed1826302fc))

## [1.26.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.9...1.26.10) (2023-04-10)

### Bug Fixes

* UN-13467: Create TMF Handler validation set to store
  data ([e57cd29](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e57cd29f3c5af253a8de9adae631cbcc5eee1c0d))

## [1.26.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.8...1.26.9) (2023-04-03)

### Bug Fixes

* UN-9348 adding new script to rerun suites without sending reports to
  GCP ([9d7f2cf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9d7f2cf86e7becd353fab0ad85a66ed485f3f0c4))

## [1.26.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.7...1.26.8) (2023-04-03)

### Bug Fixes

* UN 14657 updating scripts to start appdirect_stub for
  rerun ([f52411f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f52411f881aee52dfee48f98f250318fd16b06cd))

## [1.26.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.6...1.26.7) (2023-04-03)

### Bug Fixes

* Updating the jira validation method to support feature
  UPUA_4498 ([895dcd5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/895dcd54258a407841c7e9ff3b6e7c68b68afbba))

## [1.26.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.5...1.26.6) (2023-04-03)

### Bug Fixes

* limit data downloaded from JIRA
  server ([9db9fe4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9db9fe4cdc8d5d5b029d475c96b95fd38c394ef7))

## [1.26.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.4...1.26.5) (2023-03-31)

### Bug Fixes

* Fixed failure scenario of
  UN_497 ([437b6c7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/437b6c755ee57a939a7425811afff4c672439855))

## [1.26.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.3...1.26.4) (2023-03-31)

### Bug Fixes

* validation step for
  DataFactory ([2d5b840](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2d5b84019aa6a7e663f4460a16189ce2f2cab03e))

## [1.26.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.2...1.26.3) (2023-03-30)

### Bug Fixes

* Added support for Blank JWT with & without
  bearer ([8b6ceb8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8b6ceb81d845504404b9c9668f365870d703e593))

## [1.26.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.1...1.26.2) (2023-03-30)

### Bug Fixes

* un-14532 port issue
  fix ([342e4c4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/342e4c432645f1f54317cf1e706eac48c082e452))

## [1.26.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.26.0...1.26.1) (2023-03-30)

### Bug Fixes

* un-10735 appdirect parallel
  run ([9206bc9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9206bc9c442ca7bb354f71c2fedae02af95988a6))

# [1.26.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.25.0...1.26.0) (2023-03-29)

### Features

* Adding feature file for
  email_notification [https://jira.tools.aws.vodafone.com/browse/UN-10670] ([4b6ae66](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4b6ae66614f2a009eda9e75886dd22689fb7a4d4))

# [1.25.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.24.2...1.25.0) (2023-03-28)

### Features

* Delete-Numbers - NumberManagement needs to propagate FW_Pool if PoolType is
  Presentation ([7ca1be0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7ca1be08e8d6b7287b2398c361d4a5ddb2f4468e))

## [1.24.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.24.1...1.24.2) (2023-03-28)

### Bug Fixes

* Remove the redundant code for JWT token creation and use the single step def for whole
  project ([3480286](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3480286c359c56d4d4628c73fac6799346b8d7d5))

## [1.24.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.24.0...1.24.1) (2023-03-27)

# [1.24.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.23.2...1.24.0) (2023-03-24)

### Features

* added Script to Add Presentation
  number [https://jira.tools.aws.vodafone.com/browse/UN-9622] ([4d32c32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4d32c3242dfc669a5ead4ff07a47839099495e32))

## [1.23.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.23.1...1.23.2) (2023-03-22)

### Bug Fixes

* UN-13988 tmf gw validates complex number of
  ranges ([029695e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/029695eb54e986ce9a2a78897324a7ea72151a30))

## [1.23.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.23.0...1.23.1) (2023-03-22)

### Bug Fixes

* update commit for common
  python ([8163c9e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8163c9ef94ee25fbc025ce2e18e81a53ae973e68))

# [1.23.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.8...1.23.0) (2023-03-21)

### Features

* **https://jira.tools.aws.vodafone.com/browse/UN-14070:** adding
  email-sender-api-health-check ([dfcf9c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dfcf9c1fae7a999b1acd0a5fd9e767ddc27a6a6e))

## [1.22.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.7...1.22.8) (2023-03-21)

### Bug Fixes

* space in
  address ([02f92e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/02f92e9462dd1c50f067b610eae183d14d39d409))

## [1.22.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.6...1.22.7) (2023-03-21)

### Bug Fixes

* un-12968: kafka topic validation
  mr2 ([b9a29d3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b9a29d304559c152de0f7fb6ca511fcae596ab25))

## [1.22.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.5...1.22.6) (2023-03-17)

## [1.22.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.4...1.22.5) (2023-03-15)

### Bug Fixes

* change ACKNOWLEDGED to
  NONE ([f492a63](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f492a636207ef916d72f1fdd7d7deb823fe31028))

## [1.22.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.3...1.22.4) (2023-03-10)

### Bug Fixes

* UN-13895 Change from Bad Request to 400 in night failed
  tests ([ea45ab0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ea45ab05608a924188cf89a2ef89b8302f400b65))

## [1.22.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.2...1.22.3) (2023-03-09)

### Bug Fixes

* Correcting status code of number Management API to 404 to 400 which got changed in Erik's
  branch ([9f59cec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9f59cec9b17bb3c4efcfa5d93e3e5280b463df88))

## [1.22.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.1...1.22.2) (2023-03-09)

### Bug Fixes

* remove reports
  folder ([d9903b9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d9903b998ba04a14be64c858d8cca80c9d7d931a))

## [1.22.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.22.0...1.22.1) (2023-03-09)

### Bug Fixes

* UN-12775: Update status
  code ([3143d24](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3143d2498b1b66ef7622595e2860db68f2cbe80e))

# [1.22.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.21.2...1.22.0) (2023-03-07)

### Features

* UN-13643 refactored API
  client ([61250b9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/61250b9a064a1a776a6082f9b4587829b670cca0))

## [1.21.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.21.1...1.21.2) (2023-03-06)

### Bug Fixes

* validation of crf
  request ([d3661a6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d3661a66e7093887939e095ed740ffdd02220dfa))

## [1.21.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.21.0...1.21.1) (2023-03-06)

### Bug Fixes

* UN-9623 - Delete-Numbers - Mediator needs to raise a Jira Ticket if PoolType is "FMC" or "
  Mobile" ([808b972](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/808b9724fa929140878f2e64cb99e87458fbd1c0))

# [1.21.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.20.3...1.21.0) (2023-03-02)

### Features

* UN-11734 formatter with cleaner
  traceback ([e432171](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e43217113d69209b0aeb3d0d1b1b2025ba2a404e))

## [1.20.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.20.2...1.20.3) (2023-03-02)

### Bug Fixes

* adding additional scenarios for VFIT
  market (https://jira.tools.aws.vodafone.com/browse/UN-13073) ([77ec22c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/77ec22ce7c7d01b0bec321ee0435e45bf84624a5))

## [1.20.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.20.1...1.20.2) (2023-02-27)

### Bug Fixes

* un-12968 kafka topic
  validation ([072028f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/072028fcd776ca09fd924bc94f729ba2d7800e1b))

## [1.20.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.20.0...1.20.1) (2023-02-23)

### Bug Fixes

* un 12545 fix num sanity tcs with
  crf ([3aa0b93](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3aa0b930872055ac7f28326c2ae86f1ce38c2911))

# [1.20.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.19.1...1.20.0) (2023-02-22)

### Features

* Allow TMF 641 notifications provided by Middleware to support OAuth2 Client
  Credentials ([9f90711](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9f90711fe5ba38eb3870a047a6a46c38c532562e))

## [1.19.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.19.0...1.19.1) (2023-02-22)

### Bug Fixes

* Request to merge Story UN-9391 - Add-Numbers - Mediator needs to raise a Jira Ticket if PoolType is "FMC" or "
  Mobile" ([cb70b43](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cb70b439ce5bab49ddc7764a5270d2bb40d74403))

# [1.19.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.18.2...1.19.0) (2023-02-21)

### Features

* UN-995 and UN-1016 get and delete
  handlers ([8aa3456](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8aa34561a55ea3dab4830eaf9746970ecd43addf))

## [1.18.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.18.1...1.18.2) (2023-02-16)

### Bug Fixes

* UN-13105: fixing method for getting user from
  idmapper ([ed2d6d5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ed2d6d5f5e8a3db170ec653682727f6ba442971e))

## [1.18.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.18.0...1.18.1) (2023-02-16)

### Bug Fixes

* UN-13062 updated
  requirements ([e493425](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e493425f83bcae46245917ebe5560016c27efb1a))

# [1.18.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.17.0...1.18.0) (2023-02-14)

### Features

* complete CRF add numbers suite for
  DEV ([468280c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/468280ce483fccb1ead58023847a07ce54b6b41e))

# [1.17.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.16.2...1.17.0) (2023-02-09)

### Features

* UN-984 Overlay POST
  handler ([c1d5811](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c1d581117be635ec57d408a93a10b08385c731cb))

## [1.16.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.16.1...1.16.2) (2023-02-06)

### Bug Fixes

* Farida/fix jira
  pipeline ([94e91b9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/94e91b9ee563243ba9e512c8fccea1f548098825))

## [1.16.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.16.0...1.16.1) (2023-02-02)

### Bug Fixes

* Farida/fix jira
  pipeline ([227d80c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/227d80c79332a29f79d112941c2ffe5dc2469dfe))

# [1.16.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.15.0...1.16.0) (2023-01-31)

### Features

* Adding health check urls for order-management
  microservice ([1e440f8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1e440f82f190a197ddd82f85cb31b4180ab5588c))

# [1.15.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.14.5...1.15.0) (2023-01-30)

### Features

* Adding health check urls for new ms
  jwks-gateway ([c9d8e92](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c9d8e92d2168d0b3e72176c89a73e484ced6d995))

## [1.14.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.14.4...1.14.5) (2023-01-26)

### Bug Fixes

* un 12617 add rerun to ms
  pipeline ([0e10387](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0e1038707d1af0d5120bb78cd7d1f5eb75621919))

## [1.14.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.14.3...1.14.4) (2023-01-26)

### Bug Fixes

* UN-12617 add rerun to ms
  pipeline ([92057dc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/92057dc50b4bdcc54ea15d871ab890277ccf77f9))

## [1.14.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.14.2...1.14.3) (2023-01-26)

### Bug Fixes

*
Hotfix/protobuf ([5133ad1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5133ad1fdfc5647091b167077882f365190b872b))

## [1.14.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.14.1...1.14.2) (2023-01-26)

### Bug Fixes

* update
  pb2 ([97f9123](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/97f9123a43c345f2e596a3ca4f8c086781b4f127))

## [1.14.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.14.0...1.14.1) (2023-01-26)

### Bug Fixes

* update
  pb2 ([6aa6ef9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6aa6ef9c9bdce037e44d05697f43ed5a3b8139b7))

# [1.14.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.13.4...1.14.0) (2023-01-25)

### Features

* CRF account provisioning account
  uplift ([84f55f9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/84f55f9637d513da58a25f8a99666689ff46ca12))

## [1.13.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.13.3...1.13.4) (2023-01-18)

### Bug Fixes

* adding checks and
  suffix ([ba5747d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ba5747d60d6e24969cc36977f9f00ebdf64f0f4e))

## [1.13.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.13.2...1.13.3) (2023-01-12)

### Bug Fixes

* rerun
  issue ([b0fef75](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b0fef75a89893c86e88126860f072efde8b43f30))

## [1.13.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.13.1...1.13.2) (2023-01-12)

### Bug Fixes

* remove version of
  protobuf ([54fb119](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/54fb119568933dee8cbbb0b55181e3f493590450))

## [1.13.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.13.0...1.13.1) (2023-01-12)

### Bug Fixes

* add behave.ini file as it was
  missing ([b19db7a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b19db7a3788b5a28d24e24af3caa5f6f10090c93))

# [1.13.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.19...1.13.0) (2023-01-11)

### Features

* added the feature to do rerun after nightly suite is
  done ([68a3c59](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/68a3c59e048ea7c2e03b0c0be43864ec057faa7e))

## [1.12.19](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.18...1.12.19) (2022-12-23)

### Bug Fixes

* validate 400 response instead of 404 in num_mgmt
  scenario ([bb632cf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bb632cf139e44a214640f07362debd5fdeabfddc))

## [1.12.18](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.17...1.12.18) (2022-12-21)

### Bug Fixes

* remove rc stub prerequisite
  step ([3fbf678](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3fbf678b38d09076eddc3e03d90930a9dd294ce5))

## [1.12.17](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.16...1.12.17) (2022-12-19)

### Bug Fixes

* Farida/un 11807 fix
  staging ([d8cb979](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d8cb9799650508408138f679caa9704dd1b18713))

## [1.12.16](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.15...1.12.16) (2022-12-16)

### Bug Fixes

* updating ringcentral microservice
  tag ([cee09e3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cee09e35cbe5509125b9f486bc8e8cd903941a59))

## [1.12.15](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.14...1.12.15) (2022-12-15)

### Bug Fixes

* Feature/un 10300 testing rc gateway
  api ([e0cd12f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e0cd12fa493269d678a494f85f08b879484e23ca))

## [1.12.14](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.13...1.12.14) (2022-12-09)

### Bug Fixes

* updating ringcentral_respond topics validation according to the changes in
  UN-9627 ([8ce9de0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8ce9de0e73b9764b51cf9d8bbbc06d6674bd30a6))

## [1.12.13](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.12...1.12.13) (2022-11-29)

### Bug Fixes

* updating appdirect
  ports ([89c45c3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89c45c30489775589b572be5398f9005dbe483e7))

## [1.12.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.11...1.12.12) (2022-11-29)

### Bug Fixes

* aftab/un 11696 fix upua 2597
  02 ([5f443fe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5f443fe93b8b38026e6c0b8fa43a485741460f27))

## [1.12.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.10...1.12.11) (2022-11-25)

### Bug Fixes

* update the actuator
  ports ([85a801a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/85a801ab3e73b613e5361708d82f0f35a80c516d))

## [1.12.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.9...1.12.10) (2022-11-25)

### Bug Fixes

* Hotfix numbermgnt remove kafka retrive
  step ([3d31d45](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3d31d45d92bf366deb055c9fa83fde674d497c99))

## [1.12.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.8...1.12.9) (2022-11-22)

### Bug Fixes

* Feature/un 10120 support overlay profiles
  updated ([e90629c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e90629c4bf5a84ae419519f5bc0a00a84fe9f76c))

## [1.12.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.7...1.12.8) (2022-11-22)

### Bug Fixes

* adding delete numbers scenarios as part of our regression
  suites ([61155e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/61155e9ce2309c43843dade145e7e4f18a8cd0b1))

## [1.12.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.6...1.12.7) (2022-11-22)

### Bug Fixes

* aftab/un 10711 script issue
  upua2599 ([a87ac9c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a87ac9ce33b1cf41ef2605f64ee97f48bedc8811))

## [1.12.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.5...1.12.6) (2022-11-22)

### Bug Fixes

* Update the code for UPUA_2556_01 and
  UPUA_2556_07 ([76bb78a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/76bb78adee6ec270774ccf63d63490924e53ceb4))

## [1.12.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.4...1.12.5) (2022-11-21)

### Bug Fixes

* Hotfix/mediator
  pipeline ([f179549](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f179549f5a4039704835fea1ff875967b555e0dc))

## [1.12.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.3...1.12.4) (2022-11-21)

### Bug Fixes

* updating values.yaml after fixing
  helm-release ([086391b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/086391bead92d497a923426fb751c11a8b5913cd))

## [1.12.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.2...1.12.3) (2022-11-17)

### Bug Fixes

* UN-1062 updating automation-fw according to new healtchecks
  port ([869f519](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/869f519425810a2964d593b2c175b72da2e75254))

## [1.12.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.1...1.12.2) (2022-11-17)

### Bug Fixes

* number management negative
  scenarios ([cbc2088](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cbc2088d88042a7c9578b7516afbd66783516e43))

## [1.12.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.12.0...1.12.1) (2022-11-17)

### Bug Fixes

* remove regression and MS tags and replace with defect
  tag ([76d92ab](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/76d92ab9f9b57aede0aa116e3cfae072ad7fa5a8))

# [1.12.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.11.0...1.12.0) (2022-11-16)

### Features

* Support overlay
  profiles ([8adb58e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8adb58e60d133940f14e2a4078d21bf7ff560159))

# [1.11.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.10.0...1.11.0) (2022-11-07)

### Features

* adding health
  checks ([e1eb4b6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e1eb4b60d4665f2a39674ea443058bd1cd87ec54))

# [1.10.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.9.0...1.10.0) (2022-11-03)

### Features

* UN-5118
  RC_ID_Validation_Get_response ([2df1fb5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2df1fb5b0acefcb31239dd0146a71e731f245cf3))

# [1.9.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.8.0...1.9.0) (2022-11-03)

### Features

* UN-5268-List Service Order should filter results based on pagination query
  parameters ([a3ab982](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a3ab9821de54599f2ffa9e35243621592e73fcea))

# [1.8.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.7...1.8.0) (2022-11-02)

### Features

* test tmfgateway against invalid values for delete
  numbers ([3048d51](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3048d514b6e02ffcf387363bcbd5557cac2d94de))

## [1.7.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.6...1.7.7) (2022-10-28)

### Bug Fixes

* follow-up
  changes ([62b6a52](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/62b6a528e855707b823bec5ac03136d3d1a7df17))

## [1.7.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.5...1.7.6) (2022-10-26)

### Bug Fixes

* minor change just to deploy the new master
  version ([63d364e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/63d364e43269f8e179abcb5c9db368f409cab973))

## [1.7.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.4...1.7.5) (2022-10-20)

### Bug Fixes

* from test to
  master ([4bdeb0f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4bdeb0f81f0caf0dfdd91978b287ebdfd3390374))

## [1.7.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.3...1.7.4) (2022-10-18)

### Bug Fixes

* updating scripts to fix changeLicense
  scenarios ([66e625f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/66e625fad2f317b6747df6ad2111703c65ccd74a))

## [1.7.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.2...1.7.3) (2022-10-17)

### Bug Fixes

* update event name according to
  UN-9352 ([8d6b9d3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8d6b9d3935db13e40908121784a112baa2222906))

## [1.7.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.1...1.7.2) (2022-10-13)

### Bug Fixes

* remove regression tag for purchase
  device ([80ee34c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/80ee34ca26095f575b4d06e97e8497baa2efbd1e))

## [1.7.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.7.0...1.7.1) (2022-10-11)

### Bug Fixes

* :wrench: Update properties to connect to number management
  database ([338a50d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/338a50d9144a6b0697a8f86045adc1553a93c802))

# [1.7.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.6.3...1.7.0) (2022-10-06)

### Features

* merge to master
  PI6SP5 ([9f7c0d8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9f7c0d8a3717eb8ada9f42456083b59e270e9099))

## [1.6.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.6.2...1.6.3) (2022-10-05)

### Bug Fixes

* Adding as part of regression suite the disabled number-mngt-api integration
  tests ([6e29fae](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6e29faed39cfc068db579a8f9a3e40bb3bab6c14))

## [1.6.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.6.1...1.6.2) (2022-10-05)

### Bug Fixes

* Disabling some number-mngt-api integration
  tests ([4ec7f5d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4ec7f5dd382e0afc515f72038ee7de3ae77fbf74))

## [1.6.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.6.0...1.6.1) (2022-10-03)

### Bug Fixes

* Update
  classes/kafka.py ([79b5e12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/79b5e12936ae9d976a278abf4bde9d1bbc6460d2))

# [1.6.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.5.5...1.6.0) (2022-10-03)

### Features

* MSK
  migration ([50956a5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/50956a507dbb5d70e709a789024befcce3594909))

## [1.5.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.5.4...1.5.5) (2022-09-30)

### Bug Fixes

* fixing Integration tests for TMF
  Gateway ([5883d68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5883d684ff4f726753614c467b3491f2e8a07d82))

## [1.5.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.5.3...1.5.4) (2022-09-23)

### Bug Fixes

* Gayatri/update RC stub
  API ([fad6f50](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fad6f5072e7c664f320605cb0b1eff7b2faed443))

## [1.5.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.5.2...1.5.3) (2022-09-21)

### Bug Fixes

* Resolving Change License
  Issue ([5210287](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/52102875578883574af3931895edcba07c66c2c0))

## [1.5.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.5.1...1.5.2) (2022-09-15)

### Bug Fixes

* Gayatri/hotfix add number mgnt
  tag ([b641b30](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b641b30e45a2828903cf34d82ae794ea2fe52567))

## [1.5.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.5.0...1.5.1) (2022-09-06)

### Bug Fixes

* Create Jira Ticket from MW
  tests ([270da40](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/270da40c56d3c07151200f3f81232c60029f6209))

# [1.5.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.4.0...1.5.0) (2022-09-02)

### Features

* add number initial draft for
  UN-5191 ([7fe3b1d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7fe3b1d0db21f7eb675ede0d9b50ef01436305f9))

# [1.4.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.12...1.4.0) (2022-08-25)

### Features

* from test to
  master ([3d409b8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3d409b8914d07bfc520b2cc226359388e4a8873e))

## [1.3.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.11...1.3.12) (2022-08-24)

### Bug Fixes

* resolve Some Staging
  TCs ([3a060b4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3a060b4cd1ab0bb1709e8c4961eb9c4f9aaab6e5))

## [1.3.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.10...1.3.11) (2022-08-12)

### Bug Fixes

* Update number mgnt
  tag ([21ef428](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/21ef428a5f8dd5b8c5de80d3e632ee91d02335c2))

## [1.3.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.9...1.3.10) (2022-08-11)

### Bug Fixes

* Update
  README.md ([9c05b79](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9c05b794dc00e3f510c2f0df370bb54e35c90d31))

## [1.3.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.8...1.3.9) (2022-08-10)

### Bug Fixes

* fixing some number-mngt-api integration tests and removing some regression tests from
  staging ([b41004f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b41004f025055263a6c10ba37b0a137158704d01))

## [1.3.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.7...1.3.8) (2022-08-09)

### Bug Fixes

* UN-5371 updating number of digits according to
  UN-2949 ([89bff20](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89bff205e999fde57439f6d548c4918355162271))

## [1.3.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.6...1.3.7) (2022-08-05)

### Bug Fixes

* hotfix for the test
  upua_4550_04 ([77a749b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/77a749be94cedbb77a50170a182c09237367da90))

## [1.3.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.5...1.3.6) (2022-08-01)

### Bug Fixes

* Add TCs for modify
  account ([da20d7a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da20d7a10cb363f8ad5a1e96e3c029833a433a2b))

## [1.3.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.4...1.3.5) (2022-07-28)

### Bug Fixes

* Update tests to use new place role HQ rather than HQAddress (
  UPUA-4902) ([af0e620](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/af0e620c07e0faa967a3abb36568f7bb40d420c6))

## [1.3.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.3...1.3.4) (2022-07-27)

### Bug Fixes

* add a tag to TMF e2e
  suite ([2a6eaea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2a6eaea7ae33adf41660a8026e51093442dee813))

## [1.3.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.2...1.3.3) (2022-07-21)

### Bug Fixes

* kafka and appdirect webhook
  address ([de691c0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/de691c0336374f75f1bc625aaaf4d8ed2ca1419f))

## [1.3.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.1...1.3.2) (2022-07-20)

### Bug Fixes

* :art: Use try/finally to ensure Kafka resources are cleaned
  up ([0f20b97](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0f20b97b3319d1d5c7d35263c336aeb7c50b2af8))

## [1.3.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.3.0...1.3.1) (2022-07-19)

### Bug Fixes

* UPUA-5557 fixing scenario UPUA_2607_13 failing in Dev
  environment ([220f771](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/220f771a9a81abe8f1551e17c17da6216be0a196))

# [1.3.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.2.6...1.3.0) (2022-07-14)

### Features

* merging test into master at the end of
  PI5 ([8337407](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8337407142b9264cea70725bb38f7d79a6a02508))

## [1.2.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.2.5...1.2.6) (2022-07-12)

### Bug Fixes

* hotfix in number-management-api
  2600_03 ([66cd58b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/66cd58b2fe2a7987ca8c0b34a0442ca89e5667e0))

## [1.2.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.2.4...1.2.5) (2022-07-07)

### Bug Fixes

* hotfix in number-management-api scenarios due to spring security
  changes ([d4bdd3b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d4bdd3b9a5405d645544f9846f6950fbe481d563))

## [1.2.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.2.3...1.2.4) (2022-06-23)

### Bug Fixes

* UPUA-4855 updating scenarios for id-mapper-api after
  UPUA-5358 ([e84b5cd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e84b5cd649bde047b7f98e4c83d68de89b5bfb8c))

## [1.2.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.2.2...1.2.3) (2022-06-23)

### Bug Fixes

* Gayatri bhamare/hotfix email
  filter ([8544274](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8544274878cf80651af3653859d0997884dcfb8d))

## [1.2.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.2.1...1.2.2) (2022-06-20)

### Bug Fixes

* Hotfixes for gateway
  pipeline ([f58069a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f58069ae7845e8cff37022fab370f9fb1836a3e8))

## [1.2.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.2.0...1.2.1) (2022-06-15)

### Bug Fixes

*
UPUA-4967_update_RC_api_repsonse ([7730783](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/773078398792414e16f02a4005e347a8292e1150))

# [1.2.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.1.2...1.2.0) (2022-06-15)

### Features

* add feature duration to
  report ([e963394](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e963394207d9d4189e052006b9f869a9483b0e66))

## [1.1.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.1.1...1.1.2) (2022-06-09)

### Bug Fixes

* Update
  README.md ([4981be5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4981be5f623d25a8ba3a60f42d35ed84107c8bb8))

## [1.1.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.1.0...1.1.1) (2022-05-24)

### Bug Fixes

* CICD issue fixed for UPUA_3524 (
  TMF-Mediator) ([4982e72](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4982e72cb941ef76f9c50f8b9e3a43d9ba418252))

# [1.1.0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.142...1.1.0) (2022-05-17)

### Features

* adding new scripts after PI5
  S2 ([4880f79](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4880f79d247b90a348a8962da6c8651e112b32f6))

## [1.0.142](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.141...1.0.142) (2022-05-05)

### Bug Fixes

* add code to fix some sanity
  TCs ([bd3a820](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bd3a8202fe0f9cb3dd216ad2a30afe3bd8ebc844))

## [1.0.141](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.140...1.0.141) (2022-05-03)

### Bug Fixes

* trying to fix the 'chart'
  issue ([891b377](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/891b377017b8ea3f4158e40ad24d55465168291d))

## [1.0.140](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.139...1.0.140) (2022-05-03)

### Bug Fixes

* :art: Rename helm chart directory to standard "
  chart" ([d46afa6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d46afa6220559e0cd421c003f37b9a99f40165fc))
* CICD issues in
  number-management ([d540430](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d54043029017990a6d7847043ff14120a58ae9d1))

## [1.0.139](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.138...1.0.139) (2022-04-28)

### Bug Fixes

* adding regression tag for some sanity
  test ([e1e7efb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e1e7efb991fce5183485fa50cfff96b29ea743b6))

## [1.0.138](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.137...1.0.138) (2022-04-28)

### Bug Fixes

* changes related to RC stub and update the number mgnt
  tags ([0570bba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0570bba05847dd730d2bb6a05bc93370f830d724))

## [1.0.137](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.136...1.0.137) (2022-04-26)

### Bug Fixes

* adding new regression tag for staging
  environment ([349407a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/349407ab1f9b1269d4c7f75c6bf0734988d66831))

## [1.0.136](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.135...1.0.136) (2022-04-11)

### Bug Fixes

* changes related to RCStub and env
  variable ([c0be409](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c0be40979596e45d8250b9766ed0f0a86212a1be))

## [1.0.135](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.134...1.0.135) (2022-04-06)

### Bug Fixes

* changes related to UPUA_2606 Add number
  provision ([75d9e32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/75d9e32e2b56e1c0f524760b171608312015e927))
*
Test ([6873a1c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6873a1c82e3645d3c07c0350445170ae57294d63))
*
upua_2606_addnumberAPI ([500f00b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/500f00b4b30426e4b54a4a4907b5f16ee4e8a340))
*
UPUA2606_AddNumber ([3eb76ea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3eb76ea88b90b77cfc01e514bce51a1b33066053))

## [1.0.134](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.133...1.0.134) (2022-03-16)

### Bug Fixes

*
CICD_issue_number-management-api ([11b22e3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/11b22e380806d278c2e40593c2d6e17f593e41a5))

## [1.0.133](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.132...1.0.133) (2022-03-16)

### Bug Fixes

* changing secret name according to the latest changes in
  infra ([615bd47](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/615bd470b9f47176ca6ff6e026af33559429df89))

## [1.0.132](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.131...1.0.132) (2022-03-15)

### Bug Fixes

* adding gcp
  secret ([991346f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/991346fc2133eea6b22449ea531bce3f31439ee5))

## [1.0.131](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.130...1.0.131) (2022-03-11)

### Bug Fixes

* Change Mem and CPU for
  pods ([1f7a072](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1f7a0723bbbc7f2e4180b105e582f176f849afed))

## [1.0.130](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.129...1.0.130) (2022-03-09)

### Bug Fixes

* Update
  Dockerfile ([eeea7ff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/eeea7ff489475d7a25703e0bd163deeebec61b9d))

## [1.0.129](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.128...1.0.129) (2022-03-03)

### Bug Fixes

* merge test to
  master ([018b913](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/018b91357c04356b501aa3c802fed46736c75c82))

## [1.0.128](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.127...1.0.128) (2022-03-02)

### Bug Fixes

* code changes for
  number-management ([30c605a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/30c605a6d874d4630f56ad94dd8ad90cde169dad))

## [1.0.127](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.126...1.0.127) (2022-02-23)

### Bug Fixes

* upua 3924 integration tests
  failing ([465effd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/465effdae2db3f134a7964ca30a6210bf2c1da4a))

## [1.0.126](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.125...1.0.126) (2022-02-18)

### Bug Fixes

* number-management-api CICD TCs and
  UPUA2600 ([15cce4e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/15cce4e144762b2e1be268655dc939c1c16233fc))

## [1.0.125](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.124...1.0.125) (2022-02-16)

### Performance Improvements

* UPUA-3519 flow settings for Account
  Management ([1a72957](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1a729575e934a7c489077eec35b65b76fe8c6f52))

## [1.0.124](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.123...1.0.124) (2022-02-16)

### Bug Fixes

* Maintenance tasks after updating python
  version ([dc158f0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dc158f077fcfeeddbbd44edd22c0a4b41a3a2a69))

## [1.0.123](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.122...1.0.123) (2022-02-10)

### Bug Fixes

* :bug: Refactor consumer and producer to use confluent kafka
  library ([f6fcf5f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f6fcf5f111ebf8d2f4fdce904d2b5eb02944872c))

## [1.0.122](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.121...1.0.122) (2022-02-09)

### Bug Fixes

* Test gayatri.bhamare/resolved producer kafka
  code ([b670786](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b670786c54b4033ff2730d89efdd4bf7ab66699b))

## [1.0.121](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.120...1.0.121) (2022-02-09)

### Bug Fixes

* Test gayatri.bhamare/remove some
  files ([023e112](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/023e1126ced5608db5bc5e2a9d56ea7787c826e2))

## [1.0.120](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.119...1.0.120) (2022-02-09)

### Bug Fixes

* python
  version ([39e4013](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/39e40133582a7c4eb97483175d863704c34d77b6))

## [1.0.119](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.118...1.0.119) (2022-02-08)

### Bug Fixes

* update python to
  3.9 ([0f0d5f5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0f0d5f5d31630651e81347d83cd7040a0ee38b44))

## [1.0.118](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.117...1.0.118) (2022-02-08)

### Bug Fixes

* adding kubernetes
  library ([b0001ff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b0001ff37111f0d311de2a62e4b61a7f14b31d65))

## [1.0.117](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.116...1.0.117) (2022-02-03)

### Bug Fixes

* conflict
  error ([02dd41e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/02dd41e78bb745c7fcf4899936b3e5c1ba6d3a5d))

## [1.0.116](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.115...1.0.116) (2022-02-03)

### Bug Fixes

* :wrench: Try again to fix the
  versioin ([522d337](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/522d33717aaab4c2a4bf86a248939b155b1cfc56))

## [1.0.115](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.114...1.0.115) (2022-02-03)

### Bug Fixes

* :wrench: Sync chart
  version ([c7650c6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c7650c607d1f52c2682d5a9088e792b86a80eb1a))

## [1.0.114](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.113...1.0.114) (2022-02-03)

### Bug Fixes

* Add new
  file ([d9b4ee2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d9b4ee2afe4a795df4b32f8becee24337c62619f))
* Add new
  file ([0dd022c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0dd022cbe58a138a095cecbc1bffec6e2334b617))
* added delete pool number
  code ([cbcf492](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cbcf492a83f2325550e0078931ed0d1dd9d2dddb))
* added environment name to json file for each
  feature ([0fbc20c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0fbc20c9f7639742195fda8e48e780cc1a13575a))
* adding pending response validation for add
  operation ([2481b8a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2481b8a5f4189ff3889d298ac88e99ed5995f359))
* adding pending status TC for
  UPUA_2606_Provisioning_In_RC.feature ([26ec611](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/26ec6112e44e510f6e10da481a5df2f6cc8773a5))
* adding put request for delete pool
  number ([b724050](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b724050c057b40ff20443759ce7db0e480cfa7fe))
* Adding Scripts for
  UPUA-2606 ([2752ad9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2752ad98d13171931ce41253dd13b5c12c4b8b19))
* code for delete pool
  number ([271b438](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/271b438c2202943f167b34cd3f70ab328a84e61f))
* code to delete the
  poolnumber ([4691359](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4691359dd73aa2c4467e5f5f38432abdea6d1f4d))
* Indentation error in
  numberProvisionStatus.py ([b694aea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b694aea11bd2e8aa14edd1754518e2c0e328fd34))
* Indentation error in
  numProvisionHandler.py ([512a9d4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/512a9d4e631b7408292bd4b0f089b4672cf1e31b))
* Indentation error in
  numProvisionHandler.py ([ecc2d78](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ecc2d788e3e287f014e6eb729cfa0f848391d4e3))
* iterative kafka retrieval for create
  account ([eac6d34](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/eac6d340e1bc646ab89074b5052cb6f7a4e1bcbf))
* Removed /home/automation folder names hope it still work in cron
  jobs ([5791ad0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5791ad093d5ae48437344ee5a72fda356eb277d7))
* Test gayatribhamare/upua 2606
  deletenumber ([59180c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/59180c1f973a63705b5570429d49e8eca1a94a6e))
* Test gayatribhamare/upua 2606
  deletenumber ([4cb7f91](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4cb7f91998d1c7f5b2c980e4d427e4b5cdba2c9d))
* Update
  numberProvisionStatus.py ([f86c7f1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f86c7f1d103c8187d1426d3faa99cc486706eb76))
* Update
  numberProvisionStatus.py ([11a565b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/11a565b5e9ed5e90c4afe265951d2f7f2707876e))
* Update
  numberProvisionStatus.py ([a6e7a49](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a6e7a49fd338994cbd28931f161c3dd2afc31320))
* Update
  numberProvisionStatus.py ([bc00b83](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bc00b83cf847fe2d191b4850c9f2a06f6d515c9c))
* Update
  numberProvisionStatus.py ([9e4b0a7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9e4b0a7aaf87f0e02cfe9e354ed8936f9f418ff4))
* Update
  numberProvisionStatus.py ([33c68e7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/33c68e746a4cc4a5174227abedea68bc331ec7e2))
* Update
  numberProvisionStatus.py ([03a4c03](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/03a4c0389c1e9cb210dce11951c9617b74b56ab0))
* Update
  numberProvisionStatus.py ([a9a08ac](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a9a08ac4c8cc1bfe96815f0c6ce66c7f9ab6f32e))
* Update
  numProvisionHandler.py ([0288620](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0288620b8fc5826499a998e9da21d158e6178f06))
* Update
  numProvisionHandler.py ([dc3b29d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dc3b29d8000ba9957aa4dee892b823bc786bf51e))
* Update
  numProvisionHandler.py ([16ab313](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/16ab3135701d2290a5e1aa9e7a7e798fe2389033))
* Update
  numProvisionHandler.py ([30e1e18](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/30e1e18e2331a1470486e27d9c7902b692eceede))
* Update
  numProvisionHandler.py ([01165c8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/01165c8b5ad31bce54c2faf2e596bc4a4bf1f11d))
* Update
  numProvisionHandler.py ([f8747e6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f8747e6237e9611a36241f33a2da21825f66086e))
* Update
  numProvisionHandler.py ([82821a4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/82821a4e73c9257713a2baa645f9bbe16384606f))
* Update
  numProvisionHandler.py ([f462e8f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f462e8f51601009c7ed1a89f81d05fd763aaf39b))
* Update
  numProvisionHandler.py ([c39a106](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c39a106e4f03988635777bcaaf348354ad311db6))
* Update
  numProvisionHandler.py ([871b9aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/871b9aaac0df913b8eea35f9723bffe0e12d2057))
* Update
  numProvisionHandler.py ([cdae774](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cdae7745cadba38a8c12c7b9bdaec2c0427bd498))
* Update
  numProvisionHandler.py ([a2cd87c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a2cd87c6c82b518b95e1abaebbdf88ac9c9eec50))
* Update
  numProvisionHandler.py ([de5c681](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/de5c6810d66d6379f483e8485149ad9ba4fbd487))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([de7389a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/de7389a682f682ffb326ce2b23f4e42fa203665a))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([20e56f3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/20e56f3daed953d0aa22a05e6d0cae4b65ffe038))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([7ad054e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7ad054e3a5a59d68d6e9239b1ed07542f625c75c))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([d79c3e1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d79c3e1b2b49f02ca42b3a018a47980a885070da))
* Update
  UPUA73_InboundEmailComms.feature ([b479712](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b479712d518080651758751f351b94a34c63ccfb))
* Updating
  numberProvisionStatus.py ([9232017](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9232017d0430c973e77d78b29e288a48dee89dcf))
* Updating error message in
  test_inputdata.xml ([eba47d5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/eba47d51a61b81c50dd13c0e6b204d614c93e9a1))
* Updating Number pool criteria in
  numberProvisionStatus.py ([4a7d238](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4a7d2383e3fb9db53ac03040561e6c57c7289dab))
* Updating
  numberProvisionStatus.py ([0e322cd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0e322cd5686612d8cf91b31bca650c57938b437e))
* Updating
  UPUA_2606_Provisioning_In_RC.feature ([ee966f9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ee966f91ee065e40cb63808bf7777af454264906))
* Updating
  UPUA_2606_Provisioning_In_RC.feature ([49eb9b3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/49eb9b3ff977b01acdf9fcad390c777ea3fd42f6))
* Updating
  UPUA_2606_Provisioning_In_RC.feature ([5a5bc50](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5a5bc5049d24564fab5523346d41498124596c82))

## [1.0.112](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.111...1.0.112) (2022-02-01)

### Bug Fixes

* demo
  changes ([0053df6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0053df6c9a0af8dd2307c4ad343c4ad53ca7cf03))

## [1.0.111](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.110...1.0.111) (2022-01-28)

### Bug Fixes

* Merge to
  master ([184a842](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/184a842e3a5e7c16f7874a9c746f1d84828c7249))

## [1.0.110](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.109...1.0.110) (2022-01-19)

### Bug Fixes

* CITags and number mgnt
  TCS ([e7e54a0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e7e54a0296db02ada6065c0e05acc2c3c0e094bf))

## [1.0.109](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.108...1.0.109) (2022-01-17)

### Bug Fixes

* UPUA_2499_swap
  defect ([fab3f32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fab3f320ea31ceaaeebff23b2e772abea22faa46))

## [1.0.108](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.107...1.0.108) (2022-01-14)

### Bug Fixes

* updating DataLake account
  details ([cb285f9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cb285f9aca1ee999ed1bccca8d2f225d4d80e0fb))

## [1.0.107](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.106...1.0.107) (2022-01-13)

### Bug Fixes

* Add new
  file ([bdcd61a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bdcd61a520539e2b26ba670d0e7cf1a19adfde21))
* Add new
  file ([b9f256d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b9f256d7946211ed3d9e4663f028c609447251db))
* Add new
  file ([d0a24b5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d0a24b5d471b5d77c54bf8df86af6f8b755bddb8))
* Add new
  file ([14cdfd3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/14cdfd31e4db8a2a6f37039cfb42dbee387b5350))
* Add new file for update patch
  request ([0e2644c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0e2644c5626e36b402f09480f86ceaa187d7edb7))
* added function to updateRcSTUB
  API ([4877833](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/48778332739d5dc0f11adb6cabe952aab0bf6189))
* Added new file for update
  RCStub ([8f84887](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8f848872dc8492e846229160aa4189caa1d8b877))
* added one extra function to get UID from number
  mgnt ([89103dd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89103dd6cb918446096344fc2b8451025b861810))
* added static
  value ([047dfec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/047dfecfd117adbcc74ebc3bab73c40de233a88c))
* Adding step function for initial order with error
  status ([31b5b80](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/31b5b80064f2ea067af959b3aa191119680e8a94))
* adding check loop for change license
  kafka ([2c7c9e7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2c7c9e7ff001ad207b4429da0042cc5406b56d55))
* Adding Error Handling Scripts for Complete order
  topic ([e3791aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e3791aa909a7490ee88bc071ce9e055786d0a8dc))
* Adding error message in
  test_inputdata.xml ([48e2d4b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/48e2d4b5f3281c676360f9d8907bccc1328c0d9f))
* adding error validation for duplicate event of initial
  order ([8a53e32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8a53e3297fc3a98b2aa84d990aca391ee9fb3a46))
* adding initial order RC
  ID ([6e73c36](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6e73c36bb6b8edb0dc0a4d599972b4872becdd4b))
* adding JWT for RC Stub in
  test_inputdata.xml ([4b91459](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4b91459b0298a1b4f2dff66d36490bcc06e81545))
* adding kafka buffer time in
  test_inputdata.xml ([4f547c6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4f547c691581434dc11a6fe6535538f3b954af6c))
* adding parameter for
  connection ([75d98e5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/75d98e5e55fdd3dfe3d70924f6b8d5ac2347a208))
* Adding Proper error message in Put
  request ([4356943](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/435694389d6b5ca661975637b4d22062c18a3b17))
* Adding put request after error message in
  RC_stub ([01177fd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/01177fd4832ef3ff2ae0c2facbff0d6eb02fc027))
* adding put request for error status in
  kafkaHandler.py ([78b8e4a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/78b8e4a24bedf9ebd4b50c1f6b2a62a3b85e9caf))
* Adding Put request in Step
  function ([5ddbd68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5ddbd68693482ac49c967c6b5f9238f80ad376ef))
* Adding Put request in Step
  function ([ffdc3a1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ffdc3a12017e45b4136e40498fe49f38e0099004))
* Adding response body in put
  request ([7ca1317](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7ca1317c422cbafd3b0230cf4865a30c71348754))
* Adding step function for duplicate event of full stack
  product ([11a4cc8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/11a4cc8cc2813c48b7772f3835a79ba94c1d1021))
* changed PATCH req
  position ([463941a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/463941ab9c1be4bda19a0ee1dc561be7da3449db))
* converting time_slice from string to
  integer ([670e614](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/670e6142e35ff81112937c1bcd0e9f56dbb419b6))
* getting time slice from
  xml ([7621702](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7621702e6dc04a58801d27613647c7d32886a4c4))
* importing Random lib in
  kafkaHandler.py ([13b5288](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/13b52886861192a07e9028f1269b9a6491072415))
* reading user_name and pwd from secret json files for Account_mgmt and
  Number_mgmt. ([ecb3fe7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ecb3fe7c99ebaa9957ca6a18c19ecddabe293b3a))
* remove int syntax
  error ([a785fd2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a785fd2965397a86635a26b820724b8f880c65d7))
* remove timer
  wait ([d100e75](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d100e7523023e975da53514350ca1d7f951d2a39))
* remove white
  spaces ([f2a7ce7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f2a7ce7c661ca4d9b3683282f127615a08757936))
* removed blank else
  part ([0f6d158](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0f6d1584e7b94e4b6b6e4c03a8b76c103425bc4b))
* removed header
  field ([921b46b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/921b46b5b16cebe4f8fc6d2bd2d7eecca9183258))
* Replacing put request code by it's step definition in
  kafkaHandler.py ([e0f02f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e0f02f769533a190d50d3efc1827fbc3455e0f5e))
* Update
  accountmanagement_complete_order_initial_error.json ([ec04671](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ec04671ba29f03293d6780f2b7ba67f7ac731b7b))
* Update
  accountmanagement_complete_order_initial_error.json ([30d0bb5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/30d0bb597d3b542bfe0743b00b7dc1b8fe4117a4))
* Update
  consumer_data.py ([316f417](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/316f417e5437dbb70749be4f9822169996145c85))
* Update
  database.py ([96feba7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/96feba7eeda530c0a3e1f7493bc6786b6bd6e1ae))
* Update
  databaseHandler.py ([eb5e90a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/eb5e90a91802d663155b3745e418a0dc5cbb93b0))
* update int Update
  stubHandler.py ([e0a79b6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e0a79b615892fb62b7a190188ef8468aa58cb37f))
* Update
  kafkaHandler.py ([83b731c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/83b731c6b142fcf70607b7ee6d9f9eabb5166b64))
* Update
  kafkaHandler.py ([86b357d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/86b357dec256e265ce914c54ffe5954411be38a9))
* Update
  kafkaHandler.py ([9369cbe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9369cbef8bc69e337a19ea01240438877004d52b))
* Update
  list_of_license.json ([831c247](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/831c2476aeb4ea24298e066feb9a4fc2b7b5aeaa))
* Update
  numberProvisionStatus.py ([327a1e2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/327a1e2874f05424b692644916b56640b2fac7b5))
* Update
  numberProvisionStatus.py ([99ac36d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/99ac36da2dbbfd8a2b59863a2c6ceba2facdfcd6))
* Update
  numberProvisionStatus.py ([35ad82f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/35ad82fbfac6f7b4a780eae5a48bb221986d7f6d))
* Update
  numberProvisionStatus.py ([eb14d01](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/eb14d01d4c39f1cc78c6453fe8bde43829bbd32b))
* Update
  numberProvisionStatus.py ([003ea7b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/003ea7b0310e1e311c3af1c97757526d6e7370bb))
* Update
  numberProvisionStatus.py ([bd11928](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bd11928aa7a77dea8ed2ceedc4828d83b717f21f))
* Update
  numberProvisionStatus.py ([9703e8b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9703e8b969263fcc69f0a740b96cd1cba48892c8))
* Update
  numberProvisionStatus.py ([c3f9ddd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c3f9ddd1e9a74d85236deb17a2258b820be97023))
* Update
  numberProvisionStatus.py ([a3be977](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a3be977c7b7b44941a57b6b932c63d307388fb2f))
* Update
  numberProvisionStatus.py ([1672cbe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1672cbe6f638232aef92363d5b63e635054b1e35))
* Update
  numberProvisionStatus.py ([fb3c5a7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb3c5a79fecd6dfbdb6c43794e6d6140ef4824fd))
* Update
  numProvisionHandler.py ([72cf5f7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/72cf5f764760d7b8ef32533012db154e2bdbae08))
* Update
  numProvisionHandler.py ([821b37d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/821b37d087cdf8a9dccefebb14c2b95784c4c233))
* Update
  numProvisionHandler.py ([e4cf33b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e4cf33bd478c52e1c4af677bd5e9dc0fd717b847))
* Update
  numProvisionHandler.py ([c207c17](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c207c173f98dca57cec6558cd183b42f587e6dc9))
* Update
  numProvisionHandler.py ([7a951f4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7a951f4a7d4ad5ff72d7ee386896640b9550eae6))
* Update
  numProvisionHandler.py ([3fc85ea](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3fc85eac640254691f65c0b25311624dd0bed8d1))
* Update
  numProvisionHandler.py ([4ff3dbf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4ff3dbfb928198a5fa60da47c40c6e4a1be8c466))
* Update
  numProvisionHandler.py ([29a8173](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/29a81731c9afd03a07be71ab3ab138e6aa607907))
* Update
  numProvisionHandler.py ([5bc1bb4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5bc1bb4bac4cc7d4d1ffa771d9c7bdb094f73a68))
* Update
  numProvisionHandler.py ([8f0ae07](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8f0ae07b3078d547df36a8620935271355d46ee3))
* Update
  patch_request_for_add_number_new.json ([30e9a13](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/30e9a13cbfcba36a16d1982f2b892e8fa0dc1814))
* Update
  patch_request_for_add_number_new.json ([414be6c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/414be6c6eb5bdcb29e46edaa22b59293bc6919d4))
* Update
  patch_request_for_add_number_new.json ([cb0d8b0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cb0d8b0ae6746b205764ab117e6927aa1073d11e))
* Update
  RCStubHandler.py ([a90a445](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a90a44578a01a2a8a507f9165dd3a9977ab7b12e))
* Update
  RCStubHandler.py ([9733227](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9733227817159022c93455c9bcd9ec5895eb3c4e))
* Update
  RCStubHandler.py ([a2738f2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a2738f2bd5428b79784609e9ed2617db92a5704a))
* Update
  RCStubHandler.py ([bbb79e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bbb79e96f5e7b1d057e4574795450ff25fdf6410))
* Update
  RCStubHandler.py ([7f8944a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7f8944a809bf4c65612b4682764ee2721e463db1))
* Update
  RCStubHandler.py ([8afe31f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8afe31f3cde3559a508a48a3535fe4f27c3c5508))
* Update
  RCStubHandler.py ([009f45c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/009f45c236c926caea01d5af8e42276209a1ac56))
* Update
  RCStubHandler.py ([e584bde](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e584bde1034712fb8b5fc085f620eef45c7fcc01))
* Update
  RCStubHandler.py ([35f789a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/35f789ab73f1b1e8d263051ad27f146480f34e83))
* Update
  RCStubHandler.py ([96db7fc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/96db7fcc88a1adba5e5b09e38161637e2e419944))
* Update
  RCStubHandler.py ([c1ba552](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c1ba552636772be5257d98b4fe0bd496ba0311cc))
* Update
  RCStubHandler.py ([c18fb8e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c18fb8e09dd2f7b71424ed9305a240dc1bcb7955))
* Update
  RCStubHandler.py ([197f51d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/197f51ddfa3b1edc1e894dc205eed581c7af803c))
* Update
  RCStubHandler.py ([6657117](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/66571178f662e53c4d081deb9ccb332cc8207d04))
* Update
  RCStubHandler.py ([182aa95](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/182aa95cd19b05912c94ad0c5b630be63aae85b9))
* Update
  RCStubHandler.py ([346f84f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/346f84f4b783714e859803498c47f2671f80cb4c))
* Update
  RCStubHandler.py ([40a0447](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/40a0447930e05b212f4d437cd9dc1e5a27feeae7))
* Update
  RCStubHandler.py ([056092f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/056092f2688068189d086a9c07811072f94b8219))
* Update
  RCStubHandler.py ([6506f42](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6506f427a91782e738bd57fa461e54596ab0ba6a))
* Update
  rest_api_request.py ([9bfbe33](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9bfbe3352dbc413f8c53f3e2b6c676c241099680))
* Update
  stubHandler.py ([1ec69be](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1ec69be5fc0a2821dccb9285ca3e477ecd93b324))
* Update
  stubHandler.py ([d71569c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d71569c4447baeff2d6ecae0817005489c802738))
* Update
  stubHandler.py ([c0936b6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c0936b64f71542f27c1a02c5128051a0e48577b1))
* Update
  stubHandler.py ([487fb38](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/487fb38c896a1087013189a1fb02072d062b64f2))
* Update
  stubHandler.py ([87a2136](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/87a21369e0314dd8dfd67d17e6bf9c32039829f7))
* Update
  stubHandler.py ([6d5ac89](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6d5ac895bb436f97022bd3a0e978cb4c2da12a00))
* Update
  stubHandler.py ([7b5041d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7b5041dd648b22882680141bc803295017e1c204))
* Update
  stubHandler.py ([5b8b7a2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5b8b7a2ad25e6a92e08b6306bd19fe1a0fdda634))
* Update
  test_inputdata.xml ([d5b4607](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d5b460703a21c99ce6a36f836870699af988eb47))
* Update
  test111.py ([e7ca40e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e7ca40e0f3820abf26392533773e569d10bbe729))
* Update
  update.py ([6ba787f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6ba787f967996dbf0e73eb9a62adb903933ccaba))
* Update
  update.py ([86090a5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/86090a5834db3fc9c5f00dd6265f562039b2ea18))
* Update
  update.py ([7aa1fa1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7aa1fa1fbc4ccc38da149e9662e852d76a73d1a4))
* Update
  update.py ([7178796](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/71787962521ecd47140164adb23dad8d7e0304e8))
* Update
  update.py ([239b893](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/239b8933d0bfb84bd02ac8617caa03f98530a317))
* Update
  update.py ([47d6e1b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/47d6e1b86f9c792765fdb9d31451020815198e42))
* Update
  updateRCStub.py ([fbb4d4c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fbb4d4cba693d2483a3eccf3ac15466db8ab3775))
* Update
  updateRCStub.py ([7f17a92](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7f17a92bfc4d44480061d4ec14ddfdef128fc65c))
* Update
  updateRCStub.py ([c25359c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c25359cbeadce62a19f26a4a99043366236c18db))
* Update
  UPUA_2256_Add&Remove_addons.feature ([508a481](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/508a4819258245290b2a1599a08135b727784caa))
* Update
  UPUA_2470_ErrorHandling.feature ([f874358](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f874358eee1bf25aefaac837eb655133d11a33ea))
* Update
  UPUA_2499.feature ([4082bf5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4082bf56da492cb5e0478de09914132aeb307703))
* Update
  UPUA_2499.feature ([0c3cc41](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0c3cc41f836beafa5220b2b8728d9af388c20015))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([6728fd6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6728fd6d4de58f592547ca0764c4e94eddfdd0f9))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([2b956ab](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2b956abbed54cf17005abf68f22d8664681284a3))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([0bcc5e6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0bcc5e6ba0c345276f2dc9c87b92ebb3f069af77))
* Update variabl;e
  name ([c15ede2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c15ede23bd52e1024e5cf51edcce3767ba7db24a))
* Updated code for update RCAPI put
  request ([9b763de](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9b763de077fffeba9446889b2bfdcbb4487f551c))
* Updated some missing
  values ([dbf7b20](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dbf7b20c27d04edf6f786d538f3aaf8f0adab701))
* Updating
  UPUA_2499.feature ([5d58ef1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5d58ef17335a26d7713a8708203f875df469517f))
* Updating FullStackOrderEventResponse.json
  file ([ea3064a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ea3064ac73150ef318e93675129c2648415e4403))
* Updating Json for Complete order
  topic ([5012176](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5012176535291f2d5eb65683aeaacb41462c39bc))
* updating json values for complete order
  topic ([a3c2173](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a3c217374d6089770c576d75106f8b0743e6eb88))
* Updating new json for Change License Error in
  accountmanagement_complete_order_addlicense_error.json ([1d4c326](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1d4c326c19ee129700ce39b18389f093236372a7))
* Updating put request URL for new account in
  test_inputdata.xml ([334b570](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/334b57029031ebdfee02029bad3dee5df56f5420))
* Updating scripts for Change License and Initial order
  event ([7cc1305](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7cc13050d0f06b09a2f73b2f8fb0e03eb8ee5b44))
* Updating status code in
  kafkaHandler.py ([13d920c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/13d920c09f184940dce858ab58c2354affafb621))
* Updating
  UPUA_2499.feature ([fe031e8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fe031e83b0edc9ab2569d178b78d10017fba6eb1))

## [1.0.106](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.105...1.0.106) (2022-01-06)

### Bug Fixes

* added missing
  value ([f599caa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f599caa1601142129272d3a845b2010e623b53cb))
* another
  attempt ([560b420](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/560b42005db5ca486dfbbceeaadf5d5f91fa2baf))
* hope I fixed the yaml
  issue ([3f77a32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3f77a3205d27809b999f7545f81b075dd2502130))
* if not working now I dont
  know ([48b1071](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/48b1071a5631dbe6f99aac5acae239a2598f8c18))
* lets try
  this ([1a49118](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1a49118a72bc3270817a1d6aca77055470d1d079))
* remove empty
  line ([e2c7de1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e2c7de17a65d19c757c3f2aa464ffe6e32a7adc3))
* try if this
  works ([5f4df51](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5f4df51fbab6c20412d604b9d0221601a18dd417))

## [1.0.105](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.104...1.0.105) (2022-01-06)

### Bug Fixes

* changed config for mounting in
  cronjob ([523a42e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/523a42e38b39dd31b74beb55992dd1b442895ad6))

## [1.0.104](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.103...1.0.104) (2022-01-05)

### Bug Fixes

* add mounting of secret drive to
  cronjob ([55f3f8e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/55f3f8e481e7b3747d8140aa88cb412d4bad3fd4))

## [1.0.103](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.102...1.0.103) (2022-01-04)

### Bug Fixes

* Resolving Pipeline
  issues ([b2cf44b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b2cf44ba967948da8dd68038ad827d8e83c17573))

## [1.0.102](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.101...1.0.102) (2022-01-03)

### Bug Fixes

* Adding Bulk number request for RC
  stub ([01c1132](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/01c1132f5891ca1487271ab76cb366b692f3c552))

## [1.0.101](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.100...1.0.101) (2021-12-23)

### Bug Fixes

* Updated Scripts for CI
  TCs ([98fbf81](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/98fbf81bf7e6732032f643fd0e1cc5b97880ba81))

## [1.0.100](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.99...1.0.100) (2021-12-21)

### Bug Fixes

* Updating Scripts for Add/remove Addons and Responder CI Test
  Cases ([f319f0e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f319f0edee46cea16f532488f3e7e458cfca2d02))

## [1.0.99](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.98...1.0.99) (2021-12-17)

### Bug Fixes

*
Test ([a6aa2e2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a6aa2e29d56ec648abd4954c61be3f3f401b2a57))

## [1.0.98](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.97...1.0.98) (2021-12-16)

### Bug Fixes

*
Test ([a30acee](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a30aceeed51453e02327e6c89c614fafa084f5f6))

## [1.0.97](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.96...1.0.97) (2021-12-15)

### Bug Fixes

*
Test ([2860cf7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2860cf7fc93a52adecbc74b03691d0938984fb68))

## [1.0.96](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.95...1.0.96) (2021-12-15)

### Bug Fixes

* :bug: By default do not create a service account (this prevents the automation tests creating one) and use the service
  account name automation-fw rather than the dynamic chart
  name ([53812a5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/53812a5fc4d2d7dd405351ed13487592d730a743))

## [1.0.95](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.94...1.0.95) (2021-12-14)

### Bug Fixes

* add missing IAM Role annotation to default
  values.yaml ([7b75466](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7b7546686bc2d3962f8ce0761a7c9e52da9808e7))

## [1.0.94](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.93...1.0.94) (2021-12-14)

### Bug Fixes

* 🐛 fix in updates total number of
  licenses ([84ff995](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/84ff99550e80b8545a8e840aeaeb00119e441887))
* 🔨 fix in variable
  casting ([2a640ba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2a640ba7a4d29c0c10917e0b9d78135e5319dd40))
* Add new
  file ([0d29a32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0d29a32a29b34534f24553d8e7260017e3c3cf6f))
* Add new
  file ([ac74132](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ac74132bb5d34f88d1c6e249a3f90c0e49eb38af))
* Add new
  file ([a30972c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a30972c803e9475d074cfdbfcdfbf8ef25439dc4))
* adding CI Testcases and regression tags in
  UPUA_2607_Purchase_Device.feature ([5725b78](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5725b782615b0c1e70e3c46944d8a2be77b606ce))
* Update
  kafkaHandler.py ([37eb3d7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/37eb3d72a1aeb13b2fa7b10fa0b3ba4002fb002f))
* Update
  kafkaHandler.py ([ac31034](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ac31034efd4c0cd17552665d7676378893429f56))
* Update
  kafkaHandler.py ([8def07d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8def07da7759d2853f69fbe7b39cc0367e5473db))
* Update
  kafkaHandler.py ([17fbea4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/17fbea42e55de9bb2f58e4dcb9caf642c2547aa6))
* Update
  kafkaHandler.py ([5c971f9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5c971f9721533b48990da458760ea11dc1c86038))
* Update
  numberProvisionStatus.py ([11e1e3f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/11e1e3f2a32dec19a84a3e2ce4adad9f5d694ed7))
* Update
  numberProvisionStatus.py ([c218652](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c218652a3d3714453b13e4633409add86defac4a))
* Update
  numberProvisionStatus.py ([cf8b527](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cf8b5271ed3a52182c0e4515bd0969baa0392e9e))
* Update
  numberProvisionStatus.py ([cdb9c9b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cdb9c9b0e4c4d9cbd628ef85e829d52c63f9da38))
* Update
  numberProvisionStatus.py ([7f8ce8b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7f8ce8b51e533eeeb83bb5b35b61097cd0fbf9b2))
* Update
  numProvisionHandler.py ([2cb4ca3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2cb4ca3e6e8c589b265fb7de7ea17766e0f3725d))
* Update
  numProvisionHandler.py ([f152402](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f152402dee602bcfe52418ae5c3472cbe8343e41))
* Update
  RCStubHandler.py ([23a497d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/23a497d2efcf8b5bb31dd8156801d71456217a43))
* Update
  RCStubHandler.py ([5327f49](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5327f4971908966a25c4c0f439b96db0e9cbbe96))
* Update
  RCStubHandler.py ([6fb4639](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6fb463998ab8edb68cd1c28d3ec01a8fd52ce8b7))
* Update
  stubHandler.py ([f637865](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f637865f6e7088ef6c60db13b44c1e2d9a123332))
* Update
  stubHandler.py ([d0ce6f4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d0ce6f46cb4f5ef94e6c002df47f8d6553e11a19))
* Update
  stubHandler.py ([cdae2c0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cdae2c09b3786b0bc542de3110ab79eff774600b))
* Update
  stubHandler.py ([dbe409b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dbe409b0f2a7da2c6eadeda98b647c77c50a30bc))
* Update
  stubHandler.py ([25e45df](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/25e45df02ceb51d969c58c23b210ca392063ea56))
* Update
  UPUA_2256_Add&Remove_addons.feature ([54e4e52](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/54e4e52cc541e5ac5d092c148f5ce416672c52fd))
* Update
  UPUA_2256_Add&Remove_addons.feature ([bfbafbc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bfbafbcc34c70bf5bd4e263fe9753ef77bf25296))
* Update
  UPUA_2256_Add&Remove_addons.feature ([6fc0007](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6fc000749c65c9a90ec13f68f8dccf99ef81ac9d))
* Update
  UPUA_2256_Add&Remove_addons.feature ([8869796](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/886979617551b3e6d5665b0c1ce7d8a17fc14e24))
* Update
  UPUA_2256_Add&Remove_addons.feature ([506b4d0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/506b4d0f96dd798c0f53ef75125c8d4dc7f84906))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([7e3aeaf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7e3aeaf848af9a252e03aa70478b3787f7ae7e97))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([58b185d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/58b185d506ef65e30e7eec143a899b1120850f1b))
* Update
  UPUA_2606_Provisioning_In_RC.feature ([1c046bc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1c046bca9ee90fa3a1620cb9b2f6f6c66e096465))
* Update
  UPUA_2607_Purchase_Device.feature ([e9f404c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e9f404cf68dea16b2fae18e2b1a46fd0c68da746))
* Update
  UPUA_2607_Purchase_Device.feature ([946db41](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/946db41069d85be6d374818df3ea32cb5991643f))
* Update
  UPUA_2607_Purchase_Device.feature ([57e0ad4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/57e0ad481bc94f965c516174450c1c0c2c8b7465))
* Update
  UPUA498_Purchase_Addons.feature ([dce8639](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dce8639c478b86c8bd192894b921acc4f20eaa24))
* Update
  UPUA498_Purchase_Addons.feature ([c6d4818](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c6d481830fb66e758914849db7511dd5cf7f2778))

### Features

* ✨ validate count for addons with RCstub update
  added ([c4fd04d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c4fd04d5e985d4b0fac3d505dd164d37944d9e2b))
* 🔨 updates total number of licenses in Ringcentral Stub method
  modified ([f3b35eb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f3b35eb30f8c1edb63f2537a179685b37dddf144))

## [1.0.93](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.92...1.0.93) (2021-12-09)

## [1.0.92](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.91...1.0.92) (2021-12-09)

### Bug Fixes

*
Test ([c8e63b4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c8e63b4c194cebf1540776ec65c7a24d65340af1))

## [1.0.91](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.90...1.0.91) (2021-12-06)

### Bug Fixes

*
Test ([316c8cb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/316c8cbf5649a930e10aaf8b302c3e8510443894))

## [1.0.90](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.89...1.0.90) (2021-11-26)

## [1.0.89](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.88...1.0.89) (2021-11-25)

## [1.0.88](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.87...1.0.88) (2021-11-17)

### Bug Fixes

*
Test ([81f2bc1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/81f2bc18500021b06fd881bd7c6c8b93ccb71c66))

## [1.0.87](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.86...1.0.87) (2021-11-12)

### Bug Fixes

*
Test ([4c9ce5a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4c9ce5adbac79d005e165bc28902b11b18f342a8))

## [1.0.86](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.85...1.0.86) (2021-11-12)

### Bug Fixes

* New
  test ([68418b4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/68418b4d6b0789bd36671ef672c5befc8505ae19))

## [1.0.85](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.84...1.0.85) (2021-11-11)

### Bug Fixes

* Av
  test ([a807a2d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a807a2d1545e8b9fd2b9e83d13f4150a1df90e6d))

## [1.0.84](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.83...1.0.84) (2021-11-09)

### Bug Fixes

* make sure templates truncate K8s object names
  appropiately ([22aef4e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/22aef4e1aea2d058b90097b57d6bc21d722540a6))

## [1.0.83](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.82...1.0.83) (2021-11-09)

### Bug Fixes

* Allow to truncate cornjob name to 52 char
  instead ([7ae04a4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7ae04a479a97ecfd0d8cb43b7d4e1c741dd2ae54))

## [1.0.82](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.81...1.0.82) (2021-11-08)

### Bug Fixes

*
Test ([4559c6b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4559c6b3bc2e62b7b32257dd28547bb743a873e3))

## [1.0.81](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.80...1.0.81) (2021-11-05)

### Bug Fixes

* add test results
  summery ([4e8f0db](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4e8f0db13170b5e99fa4e590e993adc97e6f2208))

## [1.0.80](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.79...1.0.80) (2021-11-04)

### Bug Fixes

* improve
  reporting ([c69b313](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c69b313f1d725e813252f7c654636fc7edb13301))

## [1.0.79](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.78...1.0.79) (2021-11-04)

### Bug Fixes

* Change privs and add
  execution ([ad9d43c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ad9d43c5eea505dc680e0826c98f3c1976ca07c4))

## [1.0.78](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.77...1.0.78) (2021-11-04)

### Bug Fixes

* add absolute path for
  script ([ea1d857](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ea1d85765556f870c0e7159c2f0076baca2ee621))

## [1.0.77](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.76...1.0.77) (2021-11-03)

### Bug Fixes

* removed
  spaces ([e04cfa3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e04cfa3c2d1daadcf4ea8518b64fb6f289fc0dd2))

## [1.0.76](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.75...1.0.76) (2021-11-02)

### Bug Fixes

* Update
  RCStubHandler.py ([3234a07](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3234a0747522920647b501670d194a63e1107247))

## [1.0.75](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.74...1.0.75) (2021-11-02)

### Bug Fixes

*
Test ([97990e1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/97990e180a35d11112931e1a7c1317ba0a3060ec))

## [1.0.74](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.73...1.0.74) (2021-11-01)

## [1.0.73](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.72...1.0.73) (2021-11-01)

## [1.0.72](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.71...1.0.72) (2021-11-01)

### Bug Fixes

* add
  beta ([a408b6f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a408b6fe87d00b46dbe70f346165e5a27a046a14))

## [1.0.71](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.70...1.0.71) (2021-11-01)

### Bug Fixes

* add missing fullName local definition to
  cronjon ([329a74a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/329a74a0090129691fd497c874aa4d2aab4ef3e7))

### Features

* added shell script to be executed for cron
  job ([9fab84e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9fab84e9079fd38e284f054d2d45cd0b8b249867))

## [1.0.70](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.69...1.0.70) (2021-10-29)

### Bug Fixes

*
Test ([b9da073](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b9da07342a52b56e2d279ec66d55151ae7477f6b))

## [1.0.69](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.68...1.0.69) (2021-10-29)

### Bug Fixes

*
Test ([89c663d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89c663d5f5b1758fc305f3f2e97fc2fabd168b95))

## [1.0.68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.67...1.0.68) (2021-10-28)

### Bug Fixes

*
Test ([53789ff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/53789ff26715fe226a22f376fc6ea65aaac794e4))

## [1.0.67](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.66...1.0.67) (2021-10-20)

### Bug Fixes

*
Test ([4aaf81d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4aaf81d9b741452647fb121271f50655f2502b4c))

## [1.0.66](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.65...1.0.66) (2021-10-14)

## [1.0.65](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.64...1.0.65) (2021-10-07)

### Bug Fixes

*
Test ([c26302b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c26302b7f816b50b5782a230d54ee8d49b7498bb))

## [1.0.64](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.63...1.0.64) (2021-10-07)

### Bug Fixes

*
Test ([230af60](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/230af60c59ab79a13eeac875f40ff6f55b502edf))

## [1.0.63](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.62...1.0.63) (2021-10-04)

## [1.0.62](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.61...1.0.62) (2021-10-01)

### Bug Fixes

*
Test ([d1218a4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d1218a405b4fa6a84a932921767b020b67150040))

## [1.0.61](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.60...1.0.61) (2021-10-01)

### Bug Fixes

* Add new file
  numbermanagement_complete_order.json ([2c2ceb2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2c2ceb2275378ba017c3aded47a8ac620244fb97))
* Update
  accountmanagement_complete_initialorder.json ([49b7971](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/49b7971609f9a54a222fa3c9307b3361ad79eb0f))
* Update
  ordermanagement_create_initialorder.json ([0de84c7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0de84c77281dbf3bcf559e5ba9d1aa0cfb5fbdce))
* Update
  appdirect_create_initialorder.json ([54f85a9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/54f85a9a783ad09a1d73e8e57d9b78cd866c8db8))
* Update
  consumer_data.py ([763819c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/763819cae810bd5fba27e79ff8cae23afc3a5714))
* Update
  kafkaHandler.py ([0bfafff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0bfafff963580099375e52defea83dc8c421aab6))
* Update
  stubHandler.py ([60ef4a7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/60ef4a76e6d363095d08d0051b1aabf7b6f78f1c))
* Update
  stubHandler.py ([756f065](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/756f06547100f973dbd1c6a5bb7b814ce1005783))
* Update
  stubHandler.py ([d560552](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d5605523211e45368283c979e928ebd541fe29f0))
* Update
  stubHandler.py ([0c0f278](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0c0f278684494a421c52ec24d6e172b311122a95))
* Update
  stubHandler.py ([bbe2b82](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bbe2b826fe17e9bba7b120f7cffc484d05426f83))
* Update
  stubHandler.py ([7d3b772](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7d3b77242a2906e276feab50c4ebca2e3b813ea1))
* Update
  UPUA1_AccountCreationwithStub.feature ([3b2ca8a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3b2ca8a545675a882fec73823a5b11538afd3ff2))
* Update
  UPUA1_AccountCreationwithStub.feature ([cdcfdd2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cdcfdd214eb628e3c605712e40b330263af115f5))
* Update
  UPUA1_AccountCreationwithStub.feature ([003f22d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/003f22d498e97ae9ef4a4093e418ef25e07f57fb))
* Update
  UPUA1_AccountCreationwithStub.feature ([fb5d545](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb5d545ecdeb9312a8e2c37ffe024fb1d2e17195))
* Update
  UPUA1_AccountCreationwithStub.feature ([fa09524](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fa09524ad5cb309de0aee313800f0f12951b0b00))
* Update
  UPUA1_AccountCreationwithStub.feature ([916a44d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/916a44d0a0c2c1e2207da8e07f6b62ab2ca02124))
* Update
  UPUA1_AccountCreationwithStub.feature ([6cf480b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6cf480b6f516955ee713826902aba62c1057a5b9))
* Update
  UPUA1_AccountCreationwithStub.feature ([b06e852](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b06e852dadf66276c35aa80161232d42335aa4cf))
* Update
  UPUA1_AccountCreationwithStub.feature ([72d25e2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/72d25e20897dec77101deffa20bfc0be33a8c5a2))
* Update
  UPUA498_Purchase_Addons.feature ([287acdf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/287acdf7946561713f5bec7c60e3724a7f970531))

## [1.0.60](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.59...1.0.60) (2021-10-01)

### Bug Fixes

* Update
  UPUA1_AccountCreationwithStub.feature ([e4baafa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e4baafa75127abd5eac29566423903382a26ce41))

## [1.0.59](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.58...1.0.59) (2021-10-01)

## [1.0.58](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.57...1.0.58) (2021-09-30)

### Bug Fixes

* Update
  UPUA1_AccountCreationwithStub.feature ([20aa316](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/20aa3165a5fb267bf3321578c626228de2bc2172))

## [1.0.57](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.56...1.0.57) (2021-09-30)

### Bug Fixes

* Bump automation-fw to fix release
  process ([f5c245c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f5c245c615112115db42636d0c644c6e4e11ed9f))

## [1.0.56](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.55...1.0.56) (2021-09-30)

### Bug Fixes

* Update
  setup.py ([eb469d4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/eb469d4d2f5329c41d04ca0b056800261f4a0bdb))

## [1.0.55](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.54...1.0.55) (2021-09-30)

### Bug Fixes

* Add new
  file ([8e444f3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8e444f3dd852fcbeb75bb9c9dd0deca2e8e1b22d))
* Add new
  file ([205faa8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/205faa813099be1570d5bc773e3af6bace489c80))
* Adding regression tag in
  UPUA78_IDMapping.feature ([b2612c4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b2612c4dbf7ef0edaa7c71eedfda3503043d046b))
* enhanced scripts of
  kafkaHandler.py ([1e9eb1f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1e9eb1f421f9d9016f2cf65f3bbe0ccc62653f45))
*
report ([3d5e5ba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3d5e5ba88dc9330874740d447b9f920a8158e260))
*
report ([0627960](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/06279608ca4aabd874b59a7ef26890bb0a87e228))
* Update
  appdirect_stub.py ([5fdeb65](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5fdeb65e401cabd085f778fd3c493d6214c3d70f))
* Update
  appdirectRunner.py ([deaccd3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/deaccd3313a7100f265b1f622d1535bde3199592))
* Update
  appdirectRunner.py ([4faeb0f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4faeb0f7352026640e761caeb1477e1f374f9f7d))
* Update
  appdirectRunner.py ([301c922](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/301c9228b4be76b504cf35a75f78f571cdfeeb50))
* Update
  FullStackOrderEventResponse.json ([f12c896](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f12c896e33537c804dfe1edd1f142228604503e2))
* Update
  kafkaHandler.py ([0e50bef](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0e50bef0d525c7769f95b0388d6dfd540ea75ccd))
* Update
  kafkaHandler.py ([0237057](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0237057ffc5d27d950a704d60f9fdaf29e11530c))
* Update
  numberProvisionStatus.py ([57844ee](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/57844ee9a6602fc29b4253b6908c76bbe48705f3))
* Update
  numberProvisionStatus.py ([dda44f1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dda44f1ca0bd7821769e6ed9c80bc3558e4bbec6))
* Update
  numberProvisionStatus.py ([1b25554](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b2555436882b50614a42cf47c5e6ba50eb2bac0))
* Update
  numberProvisionStatus.py ([404af16](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/404af169feccf5e154a9caf231496c7ee581c569))
* Update
  numProvisionHandler.py ([d5db61c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d5db61c8e80e61ce750d8772048bd12df2870f5b))
* Update
  report_generator.py ([035b37e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/035b37e70a4c9de0bd54ac4b2a44f9c878800fa2))
* Update
  stubHandler.py ([b7504de](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b7504dec76db973a5d6fbbdff7ad28f486d1c8f4))
* Update
  stubHandler.py ([17e6769](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/17e67695611521b654393b15e05e0728b419b96e))
* Update
  stubHandler.py ([430bee8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/430bee84e5d3bd3a9648978b7f760275e788003f))
* Update
  UPUA_68_WIP.feature ([534353c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/534353c27c2fef850de73ccae03d1c3f34e0bbbb))
* Update
  UPUA1_AccountCreationwithStub.feature ([001744e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/001744ed993898c54cd7e19af53e31e94be5c3b2))
* Update
  UPUA1_AccountCreationwithStub.feature ([780e078](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/780e0786aea925d3959ce0f3413c69f6bf9a5746))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([1b8a113](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b8a113ae44a3b78c391371af1e5fd426bcd6d95))
* Update
  UPUA68_NumberProvisioningStatus.feature ([8f82bde](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8f82bde3e5907a4b18c2c2dd28906f01f29c588c))
* Update
  UPUA68_NumberProvisioningStatus.feature ([4f1ef7c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4f1ef7ccda8d5e2451e4672ab81f497c95dc5bc4))
* Update
  WIP_Notification.py ([2ba05a7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2ba05a78b002682c990c79790cb11af220b21872))

## [1.0.54](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.53...1.0.54) (2021-09-29)

### Bug Fixes

* Added giltlabci
  file ([7d08746](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7d087460462729bf2f281b32181f2343b79ce4c8))

## [1.0.53](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.52...1.0.53) (2021-09-27)

### Bug Fixes

*
Test ([b8ae0b6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b8ae0b6d1d0c5dbbc3c5c45c4e45ef147475be26))

## [1.0.52](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.51...1.0.52) (2021-09-27)

### Bug Fixes

*
Test ([75c618b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/75c618babbde4f1af1e64192e1a838866d4fbb4d))

## [1.0.51](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.50...1.0.51) (2021-09-24)

### Bug Fixes

* adding complete order scripts in
  consumer_data.py ([c47928c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c47928cbd666dce29d3e689afc83a14c98ca5166))
* adding RC ID in
  kafkaHandler.py ([fcbd307](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fcbd30705e104d92d3b9f54f00f7aa512cceee4b))
* adding ringCentral respond account status in
  kafkaHandler.py ([087dbf1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/087dbf179b76c50ce9e9351fed22af2f0a1df044))
* adding update status in
  consumer_data.py ([5efc81c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5efc81cd7cc020ab13826a3527f27d1527b7f5a6))
* All CSV
  Validations ([0816ab0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0816ab06706c778bd2728e11e1c140cf744cb909))
* CSV
  Validations ([921458a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/921458ab16928825bf98e7d88444855abb400ae0))
* CSV
  Validations ([73e5ebc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/73e5ebc888898c79b9e92f95ac51569e80326cd1))
* Delete
  report_last3.json ([cae4842](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cae48423d01a5484ccd6842075a4e1f412dba1f3))
* Delete
  report_UPUA_460_07.json ([8ab87b8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8ab87b8ec7476ad62ea7886343a68c487ad847e9))
* Delete
  report_UPUA_460_08.json ([b990b45](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b990b45356de01790c458e6b36ed02e93e5639da))
* Delete
  report_UPUA_460_09.json ([da1f22c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da1f22c1973f70cbbc0200ae402395743ba0f410))
* Latest CSV
  Validations ([12a1665](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/12a1665036c83ca9f03ac5b2f3fcc98e697a19e5))
* Middleware
  Provisioning ([06e1cd7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/06e1cd7cc2ffe846fda5e67eef3ea42c74f200f1))
* Swap CSV
  Changes ([4b18504](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4b185048defcba7af322779f0964b329612c73a0))
* Update
  appdirect_stub.py ([4981be1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4981be18c1b356fdeda52fc1f0a8787a36ba805b))
* Update
  appdirect_stub.py ([b3d5fc3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b3d5fc3a0c2d75794b4a3d60cefb104279c91781))
* Update
  appdirect_stub.py ([51d088d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/51d088dbb15379bd28ef99c066dfccfe69435618))
* Update
  appdirect_stub.py ([01a883e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/01a883ef874b63c2bfcbd5e286e1f5bcd7118496))
* Update
  appdirectRunner.py ([4037a59](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4037a59930d98caf209d30599fce2ef4cf292b6c))
* Update
  consumer_data.py ([6f93daa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6f93daac8c9deea813bbc125c6b8ad7302ba1966))
* Update
  kafkaHandler.py ([40ab55f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/40ab55fb778f70ca532e95da4b8c1d244de175a7))
* Update
  numberProvisionStatus.py ([c1b9c52](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c1b9c52334fde9f92b0f79d87bff833f3da3563a))
* Update
  numberProvisionStatus.py ([dbb8166](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dbb81669ab78c3a0a79c7ebf337071c621706646))
* Update
  numberProvisionStatus.py ([34743ae](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/34743ae843c69d2db16483ebbf7fdb8070912751))
* Update
  numberProvisionStatus.py ([cfb878d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cfb878d657865745637af380b5175d483c6a5481))
* Update
  numberProvisionStatus.py ([ba63a33](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ba63a33904f8fc1480304e69049755c7443e3dd8))
* Update
  numberProvisionStatus.py ([80cf474](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/80cf474dd807bb55d7e5a4dc39032abf2182b291))
* Update
  numberProvisionStatus.py ([7ef6c92](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7ef6c92c613469541dbea7b93aca0e9085c31e1b))
* Update
  numberProvisionStatus.py ([f595f62](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f595f625fe8bdac7bb32b538623c1315cb20b930))
* Update
  numberProvisionStatus.py ([5c29506](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5c295063b683ccb489373aeee800df03939188fd))
* Update
  numberProvisionStatus.py ([5c28310](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5c283105c852aeb76a5333b82c870beb1b493fa9))
* Update
  numberProvisionStatus.py ([b4a1cb3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b4a1cb30356afc7d573576e50c0256ea6e061b9e))
* Update
  numberProvisionStatus.py ([f12e7d9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f12e7d9a387f86bb2852b5415a7401d9271732c7))
* Update
  numberProvisionStatus.py ([27b98aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/27b98aa132cd5b0192f03db957f97606851d9e1b))
* Update
  numberProvisionStatus.py ([9976975](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/99769759b7fe584c003998c56eaf3e1d6223bfb6))
* Update
  numberProvisionStatus.py ([dff5519](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dff5519c49a4249934d7d1dd0ef8bbbc5513393b))
* Update numberProvisionStatus.py
  CSV ([e02dfd4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e02dfd455d855e1be5acfd0ead9f68d24697de8d))
* Update numberProvisionStatus.py
  CSV ([d731096](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d7310963c596d4ae5bb12647ae723f1f27c06a7f))
* Update numberProvisionStatus.py CSV
  Comparisons ([a5bd97e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a5bd97e6e8662076072bd3db90e4ccbb188de348))
* Update numberProvisionStatus.py
  SWAP ([a3c3c85](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a3c3c85e0fed544183dfcdd0269c57001ec0ee18))
* Update
  numProvisionHandler.py ([2c5dd44](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2c5dd44dc722decdf3f383ff62761d3da472e6a3))
* Update
  numProvisionHandler.py ([acfaf7b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/acfaf7bb841bba67170a0eaf27102d9946da948f))
* Update
  numProvisionHandler.py ([412cede](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/412cede2e5b5d191e515a140a5413fc29176903a))
* Update
  numProvisionHandler.py ([7d3b5e5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7d3b5e5e110ed96b35062e254e1516b0238445bf))
* Update
  numProvisionHandler.py ([0941fa4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0941fa4ce1b4e43ff65f5ab75cc8aee46c8ae978))
* Update
  numProvisionHandler.py ([11da3e3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/11da3e3f3f1aea4083db465674412b557d669691))
* Update
  numProvisionHandler.py ([34562c2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/34562c2a67c76543eb7eae2976ab3cc8ca9640fa))
* Update numProvisionHandler.py SWAP
  TO ([228ad1f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/228ad1fd768e814f1562f959c49aa0f46c5b6411))
* Update
  putRequest_OperationStatus.json ([32f156e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/32f156e214583b79df5666c8d0ef10c8c1d205bf))
* Update
  putRequest_OperationStatus.json ([9cf49e0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9cf49e08f1531102ef07a65f9039503ed8344c7e))
* Update
  rest_api_request.py ([d9d20ff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d9d20ffe5c8f24cecbcc28662f379900fd8d8e44))
* Update
  rest_api_request.py ([cc6778c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cc6778cbc8035df77ed8334d827feb2fd56d042f))
* Update
  test_inputdata.xml ([20f84f1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/20f84f1dcb53e010ea94e05e03890df6595c4f7b))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([7ae8386](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7ae83866db36d111398aa91c8a276eb2d9263967))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([1128a2b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1128a2b8ec2b807bbae1388fc55163aef5688a8d))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([e5ebd84](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e5ebd84db8408704db294cb4008cd55e496b0925))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([664b2cb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/664b2cba10cf361d9ffcf82b5ebd43358cb8b569))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([155bd5f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/155bd5f7c66a9fc17cf9aa9a223ff2da2049eed0))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([78e5f40](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/78e5f4031bf154f6ae4315191a5db6d0b37ca16f))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([b3b7043](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b3b7043348613835bbe7fae7c9ab8aa804732a48))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([935fb51](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/935fb51eb23d88eb14f72643e39b91704ba4a732))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([f230dfd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f230dfd2014fdc00ddf915e173bb258e6b6c2e4e))
* Update
  UPUA73_InboundEmailComms.feature ([1766fa4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1766fa44dfe964d1f8b648ac2c78f62b405aa0a0))
* Update
  UPUA73_InboundEmailComms.feature ([3d1563b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3d1563b0b250c5297f247f5d0b8d4ea1b39af89c))
* Update
  UPUA73_InboundEmailComms.feature ([dd99cbb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dd99cbb8b89550234dd5a469c6037055c115a317))
* Update
  UPUA73_InboundEmailComms.feature ([29f854b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/29f854b37a78e1bed895ff8e1d3088a58c42303f))
* Update
  UPUA73_InboundEmailComms.feature ([cb2e60b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cb2e60b475e8196ee2bfbcedcac42eec96744e16))
* Update
  UPUA73_InboundEmailComms.feature ([e2d2e55](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e2d2e5593bd741c432adedd33571a675932d1ebc))
* Update
  UPUA73_InboundEmailComms.feature ([ee56247](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ee56247414bf584eddb76e0bc32225021d95bd99))
* Update
  UPUA73_InboundEmailComms.feature ([145f010](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/145f0102da24371080614ffe355010a5222262d6))
* Update
  UPUA73_InboundEmailComms.feature ([d9093c3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d9093c30ca0f78bcf90f01b7f12b3ef7a26e3ada))
* Update
  UPUA73_InboundEmailComms.feature ([3916440](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/391644004a9e649ebf1a00108efec86926eadada))
* Updated CSV
  Validations ([470aa84](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/470aa84d6e74633ad8cd8f167cfe188bde477477))

## [1.0.50](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.49...1.0.50) (2021-09-23)

### Bug Fixes

* Update
  putRequest_OperationStatus.json ([8da5e95](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8da5e95a555938d94c07c658840f07ac3146ad7b))

## [1.0.49](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.48...1.0.49) (2021-09-22)

### Bug Fixes

* Add podManagementPolicy to helm
  chart ([1ab8dcf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1ab8dcf2ff36e09e7c63bdc5ec211e3435efa1ff))

## [1.0.48](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.47...1.0.48) (2021-09-21)

### Bug Fixes

* Add new
  file ([6781a67](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6781a672521525a447ce1835713a2ffb519b0e10))
* adding 21.1 Step's payload scripts
  consumer_data.py ([279ee40](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/279ee40d6e69ebc46ddd77e11fe51f428f8fa9f5))
* Adding account status topic in
  test_inputdata.xml ([6d02af8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6d02af8ce0057b2d3bb0c678b0a1b7f79ecef5c9))
* Adding Scripts for account Status payload in
  kafkaHandler.py ([840a2e2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/840a2e2b3dfa10f46318fd83bdfa158cd80ea018))
*
rename ([ab5bba2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ab5bba27fa0f12f92da362f6143f9e30551aad0d))
* Update
  appdirect_stub.py ([fd4aedc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fd4aedc38cba1eee7f8068a3777f5fd9791d64fe))
* Update
  appdirect_stub.py ([4d6f76d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4d6f76df4703ac412569a74c78f519811464b6db))
* Update
  appdirect_stub.py ([46fd193](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/46fd1931833ab79fefb65dbe2fd3a627f23abb91))
* Update
  consumer_data.py ([8618aec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8618aec581fc060933654dbfde12fda88acf6425))
* Update
  consumer_data.py ([d72e89d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d72e89dbad7ccc1b7e5e1efafebc959002e03961))
* Update
  emailHandler.py ([ff368eb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ff368eb2843bcee77343b5753e5ead05cca384ad))
* Update
  numberProvisionStatus.py ([ac94d00](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ac94d0023855a0bf5c642f586d6beb1f26a32225))
* Update
  numberProvisionStatus.py ([175cda3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/175cda39f9789438c4be507f47466b02eccb9b8d))
* Update
  numberProvisionStatus.py ([9c6ccf5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9c6ccf56ef1c05447c88f64a8b1b76e2f41adeeb))
* Update
  numberProvisionStatus.py ([e64bd70](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e64bd70bc6b834b76542d2b99f5921bfb1feb465))
* Update
  numberProvisionStatus.py ([3d2f447](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3d2f44745930ae17b10689d429ea744be1b86b66))
* Update
  numberProvisionStatus.py ([6bf76d5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6bf76d55bd951c61e44df95c3abcc0f059d12d56))
* Update
  numberProvisionStatus.py ([a65ad5e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a65ad5e687733da79c575e1d85481e796adbdda9))
* Update
  numberProvisionStatus.py ([53cce9d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/53cce9d0ed6a4e22f0ac5bfa581446a67c6e57e5))
* Update
  numberProvisionStatus.py ([f2d72be](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f2d72bed231c650feff1ec424c72d62bf0f25721))
* Update
  numberProvisionStatus.py ([f8dc1ad](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f8dc1ad089daf3f5b76867a46e6d32f43bf6bdce))
* Update
  numberProvisionStatus.py ([dbf6ed5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dbf6ed5e4da017325be14d39e60c9509a88970ec))
* Update
  numberProvisionStatus.py ([e489d89](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e489d894496083e171c3f9d38404bc5a0e62530d))
* Update
  numberProvisionStatus.py ([e03e839](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e03e83912848edcb5c5378f07b5ede41b60988e7))
* Update
  numberProvisionStatus.py ([38a2822](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/38a2822cd93a3820bde8b3c01cdd961c5f88c744))
* Update
  numberProvisionStatus.py ([70c002b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/70c002ba547ee7135aa223264e90b6018b3a74fe))
* Update
  numberProvisionStatus.py ([9913b1c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9913b1c4332c0ad862a3b9e98d0107fcacf058f4))
* Update
  numberProvisionStatus.py ([8bd4b48](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8bd4b4829540fb2ea1e6a61c10c194e4ff309a41))
* Update
  numberProvisionStatus.py ([aff2635](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/aff2635c47d918e39708cefeebe703de4f950957))
* Update
  numberProvisionStatus.py ([5a35817](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5a358173acd82bf18ea5efd457890914336fdb79))
* Update
  numberProvisionStatus.py ([6f47390](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6f47390110bd4c12a78ce213e7c4f2f6c0abc346))
* Update
  numberProvisionStatus.py ([5099c33](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5099c3314e36b248c1ca6bd6bf04b8a8b9fa4031))
* Update
  numberProvisionStatus.py ([23a2b9d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/23a2b9d16575269c7099afa5a216a14a9935ae86))
* Update
  numberProvisionStatus.py ([4530f77](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4530f77c99bb450e22779e422e0116844fd5567b))
* Update
  numberProvisionStatus.py ([85c952e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/85c952ee6336c24a964b4efdeeebf37d13802b47))
* Update
  numberProvisionStatus.py ([985f47a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/985f47a7945e1aea50ca25eeaee2aee06196df2a))
* Update
  numberProvisionStatus.py ([2f3c37e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2f3c37e9721b6a384f8864cf1709f391b8665588))
* Update numberProvisionStatus.py with CSV
  Validation ([95aac7c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/95aac7c117038592db95931034a7406e7b80e1db))
* Update
  numProvisionHandler.py ([648d066](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/648d066b91a055d6423867274d0d643fb3d97426))
* Update
  numProvisionHandler.py ([25e5cc5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/25e5cc59b2f0661ec725712bc95fccb64d398a06))
* Update
  numProvisionHandler.py ([eca63da](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/eca63da3520906d9580b6ac1557986f2832a0d55))
* Update
  numProvisionHandler.py ([9369820](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/93698202f6effce95cfad394df762b7736e256c0))
* Update
  numProvisionHandler.py ([2bf4a69](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2bf4a69249cc0da58c9fd26aeb5b74713ee200ea))
* Update
  numProvisionHandler.py ([8b96300](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8b963001adb34791d042d933c1dcd77f977cc1ca))
* Update
  putRequest_OperationStatus.json ([ca8d308](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ca8d308447c984161e911212bdddfc27f77f4da2))
* Update
  rest_api_request.py ([7cd1434](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7cd1434cc88ad580e349348e166d74d7fa20e775))
* Update
  rest_api_request.py ([1ef3908](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1ef3908c0300da045d611bb9d149e5a61b6bdffc))
* Update
  stubHandler.py ([1b41c66](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b41c6608f6c3f59be1b1b9c4330325331b913d7))
* Update
  test_inputdata.xml ([290bb6e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/290bb6e261e34ea90e9e6be988a5802e50bad017))
* Update
  UPUA73_InboundEmailComms.feature ([7e8561e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7e8561e0ddab4dfd9ede725d11dfe90dc5b4c024))
* Update
  UPUA73_InboundEmailComms.feature ([8c791bc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8c791bc01c14291f897ed865a2b14c5832d32350))
* Update
  UPUA73_InboundEmailComms.feature ([1e5d9a8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1e5d9a8988daf1f6fa0c633e473cf6f409a1fbbc))
* Update
  UPUA73_InboundEmailComms.feature ([3455b84](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3455b847b9a5b4c193e3033c05596d5cff469668))
* Update
  UPUA73_InboundEmailComms.feature ([4c6304a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4c6304a78c35d5ad3aa02d3751098c171101373c))
* Update
  UPUA73_InboundEmailComms.feature ([166f2e9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/166f2e965120fa5f608bc8e4f573d7fb65a0e770))
* Update
  UPUA73_InboundEmailComms.feature ([147dc5b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/147dc5bd686932f09a9206fc5e1c79d0746d595e))
* Updated CSV
  Validation ([776f5a3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/776f5a35ff6461431d45412060ac01fef33383bb))

## [1.0.47](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.46...1.0.47) (2021-09-17)

### Bug Fixes

* Adding tags in
  UPUA498_Purchase_Addons.feature ([64371e7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/64371e70d6cfa1f3eeec4adb4fef7f0abc91d99c))
* Add new
  file ([6401341](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6401341bac7ac9ca2b7e43c8f88a7c57ce52f93f))
* added
  tags ([f69ed12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f69ed1294acfacc85e826d53fcb848aa91a2af31))
* added updated opco_id
  idmapperHandler.py ([1bf1364](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1bf136403577fdee88b626b2025fdf110d825cd0))
* adding complete order script in
  kafkaHandler.py ([dad6d68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dad6d68f0b7eea06e877225c1a8db9ee988a462a))
* adding Complete Order scripts Updated in
  consumer_data.py ([e67c5a7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e67c5a7f987bada20685ffa635a794d88126a316))
* Adding complete order steps in
  UPUA73_InboundEmailComms.feature ([2244352](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2244352781dd6367c827ff886c7fde672c9bf2ba))
* adding Dummy Tc to check create order payload in
  UPUA_68_73.feature ([c8324ce](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c8324ce7c2508001b1db703e746d636ae0f66a64))
* adding middleware with topic name in
  test_inputdata.xml ([025807d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/025807d39975fe9e2acaacc26143e4a36504d83c))
* Adding ring-central tags with +ve scenarios in
  UPUA1_AccountCreationwithStub.feature ([500a1d3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/500a1d3a8e94a427430e0a07f0bed495634c5d96))
* Adding steps from step-1 to
  UPUA78_IDMapping.feature ([cf0e1f2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cf0e1f276274032202a34fc0bc72bf5ef0be844b))
* Adding tags in
  UPUA479_AddlicensewithStub.feature ([aa378c9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/aa378c9c9703be9e8dc41119ead05b8522e8085a))
* Email UUID is added in
  consumer_data.py ([f836e12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f836e124a5946055a1227dd8ec5438517856e0b8))
* RC _ID added in email_filter kafka in
  kafkaHandler.py ([5b2c16f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5b2c16f7c2f2bb20c717e8c26a2de859e5e798ff))
*
tags ([7055c08](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7055c08b43e327bc31c6ea3e7876290c15302223))
* Update
  consumer_data.py ([76a380c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/76a380caf5fd48f5dddcba12b7fa939957ecd060))
* Update
  consumer_data.py ([72f8ab9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/72f8ab91b16519dfe3777317e22122afd933810f))
* Update
  consumer_data.py ([3c4ba07](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3c4ba071646c87d1dfdabd24a5c4bc2a7306874a))
* Update
  emailHandler.py ([c9c0448](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c9c0448c6566dbf5a630052cb65db979e888d4e9))
* Update
  emailHandler.py ([989ab64](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/989ab649cf2c18d13fa19a003fc4cd663bb52df3))
* Update
  idmapperHandler.py ([9a88698](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9a88698cddd5fbdf6763953ef5fdfcafa17b37b8))
* Update
  kafkaHandler.py ([408e605](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/408e605c36742d40f2811b20112f5abb4754ffc6))
* Update
  kafkaHandler.py ([4124ae0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4124ae0946b945721c7c3af795c544ddc1f5e0a8))
* Update
  kafkaHandler.py ([a6964f8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a6964f87291979dab79d33765f4bb7819c637cef))
* Update
  numberProvisionStatus.py ([5abce2b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5abce2b63885adae78593b80b74b9ea1858c4d05))
* Update
  numberProvisionStatus.py ([77389e0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/77389e08a32cbe3a62108e69981b6ba0a71fe98f))
* Update
  numberProvisionStatus.py ([bd05c2a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bd05c2ac0deb2c56450ff7a163d69822cbe78fed))
* Update
  numProvisionHandler.py ([2cc9b8d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2cc9b8d7c9875f37c3991af2e707926da0cfa6d6))
* Update
  numProvisionHandler.py ([716d36c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/716d36cbbf6f040e0669882f9a06b9c9560991db))
* Update
  numProvisionHandler.py ([baa7b04](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/baa7b0434103d24cc67df15c1fb588a344a48977))
* Update
  numProvisionHandler.py ([a4be78d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a4be78d71e8a8499561e9786bbf9d3b24701e7f4))
* Update
  UPUA_68_73.feature ([9cf3424](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9cf3424b2594c2d64a4b329b6f126d46f8faebb2))
* Update
  UPUA_68_73.feature ([068562d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/068562d1ff198c37cac35a2c2693cd9f4415a983))
* Update
  UPUA68_NumberProvisioningInMiddleware.feature ([864dfeb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/864dfebb6186cc36b829bf97c4de8c7da7cb88e1))
* Update
  UPUA68_NumberProvisioningStatus.feature ([c0c8a5d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c0c8a5da40571e63f4c6d1bcb42641a5e0f1dcef))
* Update
  UPUA68_NumberProvisioningStatus.feature ([21ba328](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/21ba328b02fb95a04d70eac2beafcc828f0e3e88))
* Update
  UPUA78_IDMapping.feature ([871f751](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/871f751ace2ba3039254c8d8b34fd6213b3c02fe))
* Update
  UPUA78_IDMapping.feature ([760b965](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/760b965ba658cb9b96141a279133c8b8cf2f415f))

## [1.0.46](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.45...1.0.46) (2021-09-15)

## [1.0.45](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.44...1.0.45) (2021-09-15)

### Bug Fixes

* rename to
  .py ([5e6b8ba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5e6b8ba44c5f3bf2c6779326b51d674a28da93c0))

## [1.0.44](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.43...1.0.44) (2021-09-15)

### Bug Fixes

* temp
  fix ([453dc8c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/453dc8ccee0ec62233696943652eabf8eb510174))

## [1.0.43](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.42...1.0.43) (2021-09-15)

### Bug Fixes

* syntax
  error ([46c03fe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/46c03fe94d5c9b6da5d8556e87bada47944edca4))

## [1.0.42](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.41...1.0.42) (2021-09-15)

### Bug Fixes

* Add sending reports to
  datalake ([5b5681e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5b5681e7d549bc2b0d8d29fbd3f96afbbe1311bb))

## [1.0.41](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.40...1.0.41) (2021-09-15)

### Bug Fixes

* add send data to
  datalake ([c1a8e57](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c1a8e57a82892c6fdff5da71440e00cce749cb10))

## [1.0.40](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.39...1.0.40) (2021-09-14)

### Bug Fixes

* removed > /dev/null 2>
  &1 ([49134a3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/49134a35598c4db5a6138c8b964d8a0fb13b7875))

## [1.0.39](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.38...1.0.39) (2021-09-10)

### Bug Fixes

* just
  added & ([dd5ac78](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dd5ac78193e6aa21adcce00522e95cc23e4322bb))

## [1.0.38](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.37...1.0.38) (2021-09-10)

### Bug Fixes

* hash out kill
  process ([236ad41](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/236ad41c79f27048b07c65b1f4dfd81a7bb56756))

## [1.0.37](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.36...1.0.37) (2021-09-10)

### Bug Fixes

* removed kill
  process ([fb9475f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb9475fbe42177f483b2217f445fd634d5b788b7))

## [1.0.36](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.35...1.0.36) (2021-09-09)

### Bug Fixes

*
update ([4c6f1df](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4c6f1dfd5c5d035bef2c4fdbd2aa4d209c84812d))

## [1.0.35](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.34...1.0.35) (2021-09-09)

### Bug Fixes

*
Test ([8a03140](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8a03140f4ca60ba3f69df067c189ee18f5130b15))

## [1.0.34](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.33...1.0.34) (2021-09-08)

### Bug Fixes

* Update
  emailHandler.py ([65818c8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/65818c8180e55caaf7defee20b032694689366ae))

## [1.0.33](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.32...1.0.33) (2021-09-03)

### Bug Fixes

*
Test ([26ccfb0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/26ccfb0b87a6d14099d0d41e0feb061363e7afd7))

## [1.0.32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.31...1.0.32) (2021-09-02)

### Bug Fixes

* Stub
  automation ([cd09e0d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cd09e0d776af4d3c8fb232709cbd855712a3e0ea))

## [1.0.31](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.30...1.0.31) (2021-09-02)

### Bug Fixes

* Update
  Dockerfile ([ede2c28](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ede2c2881a8eeedb16debfa434ffadd512af9758))

## [1.0.30](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.29...1.0.30) (2021-09-01)

### Bug Fixes

* Update
  Dockerfile ([5ae62ec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5ae62eccdeeda32e5ca318169a53aa6cfe9380ef))

## [1.0.29](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.28...1.0.29) (2021-09-01)

### Bug Fixes

* Add new
  file ([2ec7daa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2ec7daa956f3bbf242cb1f72bed94858996264f6))
* Add new
  file ([636c4f6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/636c4f606e9c3696d98acbef500220e083056cc5))
* Add new
  file ([3e120a1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3e120a142d71c6efa5f247e4acab221e1e68dfa5))
* Add new
  file ([5cb474d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5cb474d162d19dee043f2f87ce296c4863675225))
* Add new
  file ([3eed2cf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3eed2cf1fb5138761e8798b7d05a745b61fbc4d7))
* added Mongo DB cert
  file ([317c121](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/317c121d798e18649bf5685f3f127cc8404922c7))
* added new function with
  param ([d695603](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d6956036cf31e153e275234dfff3aeecc3aacd5e))
* added one if
  condition ([24fa8cb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/24fa8cb5807a40e033307f8ec21791561b90efa6))
*
APPDIRECT_STUB_PORT ([73a9ced](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/73a9cedf25bea1fac82db2c95f1ab21c4f28b537))
*
appdirectinput ([1cd49d7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1cd49d7c90a5ed1dd3d4f18d3cf7960d85809dee))
*
editiontype ([3743e51](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3743e5178ecfba4da95748a36e0aa3b034ee517d))
*
emailline533 ([ed1de85](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ed1de859b4e1f327630f7a79794fde996e3d850c))
*
error ([78f4c35](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/78f4c351b284f909e49fd5aeb34a89fc17c39880))
*
error ([ac4ef0a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ac4ef0a55f0b3e4f46ea0fea2a7f007a3f462651))
* error
  xml ([4f1a770](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4f1a77013f126afdd18d6f282706d8555b9dc3ea))
*
ifcondition ([272c9b8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/272c9b85d056ba82d099f902153569e2432974b9))
*
invalid ([af16ff1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/af16ff1de32c833a4c49b52ec62a54a03ab52ca5))
* invalid scenario for add
  license ([8345359](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8345359e79a9b4ebe4db22090d9c66775e4881d5))
* kafka
  topic ([c58986e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c58986e8d6f0793438dd681035842a688eee46a3))
* marketplace
  ID ([bfa90dc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bfa90dc1bae9f81142769921be2423df41049345))
*
marketplace_eventID_changelicense ([8460ee3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8460ee3d55969ada907a89b1e5ad9a49d490d3e6))
*
middlewareCorrelationID ([bf891bf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bf891bfc44e6b3dad1cc9262bdd2e8bf2cb50b4b))
* new stub
  file ([5051ddd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5051dddcf2d692ac46d49290f2b948dce32319b8))
* Print
  statement ([7f91ed3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7f91ed36de806fb0ef623ae849feb2b77bbc381c))
*
ringCentralAPI ([5262215](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5262215de76c8d8ccd48499ce68b8cb1e843a75e))
* suite
  report ([f7e50de](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f7e50de02d69f74a07028435a846dfcc8ca5e988))
* syntax
  error ([de96ad8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/de96ad8658ef593d3b3e9ef14c225cd75b09fca8))
* syntax
  error533 ([bc796c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bc796c106e0ac5f2a685d133d2d1751f604c8fa5))
*
tags ([1f63f32](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1f63f323252a9b11c664e8fa112bf7055b287458))
*
TC8_9 ([9cd8f45](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9cd8f45371312093fb5ce5c31d107ff9ab356db3))
* Update
  addoneventjson.json ([6398cdf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6398cdf23d54ffb0edacc0ad764ec55bf63ba478))
* Update
  appdirect_browser.py ([8f0fb1f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8f0fb1f8186aa8a4d75f3a5527f45bfcfa70e645))
* Update
  appdirect_stub.feature ([5e412e5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5e412e5e6e9b0eeb8f58f52dfa8b2a4cc41b15c6))
* Update
  appdirect_stub.py ([d53ef57](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d53ef57871930d904491e6ebd7d21e52c59191f5))
* Update
  appdirect_stub.py ([300fdfe](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/300fdfed2c9bb56adf2d46e724302c52486b1dc2))
* Update
  appdirect_stub.py ([8ebb4aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8ebb4aaedcf9795d6a3c3b788bc689bb58750386))
* Update
  appdirect_stub.py ([7e0c14d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7e0c14d7965612b16b079647a6fd811bdd8ada7f))
* Update
  appdirect_stub.py ([e675966](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e675966842dfd90f338428060c59826b5b8a5b38))
* Update
  appdirect_stub.py ([242e602](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/242e60216c8ac94296f0a2e6ac27f1b0a9a255b0))
* Update
  appdirect_stub.py ([4a32f8e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4a32f8e883966be6e10ebe8fa60ea3ee4d987d97))
* Update
  appdirect_stub.py ([dde831e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dde831e6e7e89884b5c1c0d75ced2e035761d478))
* Update
  appdirect_stub.py ([2f9533e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2f9533e55449224aa4308b5a73dee175e0659e92))
* Update
  appdirect_stub.py ([b3b1955](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b3b1955d3da1a6e536d3d6136d8520f37d07a54f))
* Update
  appdirect_stub.py ([cefcc51](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cefcc518f38f0a4e859b659ec8d1d613026c5614))
* Update
  appdirect_stub.py ([8d42517](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8d42517efd5a002a4ae21f085fef69002f4f3f65))
* Update
  appdirect_stub.py ([706b2d0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/706b2d0786f56f466d45cf33e03344ba24dc2d67))
* Update
  appdirect_stub.py ([b33617d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b33617d570e46fa006fdbe964e850aacf303e10b))
* Update
  appdirect_stub.py ([4db087b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4db087b76b8b97afb2533881e627a1973fa6e836))
* Update
  appdirect_stub.py ([c963b0c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c963b0c5753ab569d3dfb1de6589bdcb1182deee))
* Update
  appdirect_stub.py ([8d0148f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8d0148f6e0a0715d1c3c175893564954ee621d98))
* Update
  appdirect_stub.py ([fbd4622](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fbd46226f304154bba7b659f420194373fa8fbe7))
* Update
  appdirect_stub.py ([f5cca1e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f5cca1e25d980a97ea8828381deabcb3700b303b))
* Update
  appdirect_stub.py ([e234ee7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e234ee7a34b35b00eddf5a19e2d3e1d4114f086d))
* Update
  appdirect_stub.py ([fb05d76](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb05d76adc9fe015b4f184cd2ac12961372fa14e))
* Update
  appdirect_stub.py ([231b7c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/231b7c121e6433f0e747f66f61bb7d553b9ceb75))
* Update
  appdirect_stub.py ([7bce7c4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7bce7c4d1d7ed22ec7fce8c6bbc42f307e06e3ee))
* Update
  appdirect_stub.py ([03998e8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/03998e81fb10af94600808a649788f006f1988f7))
* Update
  appdirect_stub.py ([3465f50](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3465f5049a305f7802aa78738607037e2fc64f80))
* Update
  appdirect_stub.py ([9bc6b77](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9bc6b772e76c06a8e6e1a24fc019d88e3cadfee4))
* Update
  appdirect_stub.py ([92ebe5c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/92ebe5c0d5d2b98c7789bd44c646d71329d4f719))
* Update
  appdirect_stub.py ([8dc3c15](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8dc3c1501d317f07769043da8e9a328a03d8eec1))
* Update
  appdirect_stub.py ([27b745d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/27b745deb24ad68aa3dcaefecf57ac2cd8aa4f96))
* Update
  appdirect_stub.py ([05b85aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/05b85aa13cfb97778f8fe12b11ba6aa6e84013e8))
* Update
  appdirect_stub.py ([397617c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/397617c266d508d6d0d83301c808badc1df5629c))
* Update
  appdirect_stub.py ([da4c057](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da4c05709d5a8810c1c90059496f93cf717b697f))
* Update
  appdirect_stub.py ([3b8a014](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3b8a01460526ba14d0d242fa942947de8d40eab1))
* Update
  appdirect_stub.py ([b10b0c6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b10b0c60f8862a3216650ed458752dac81c20d1d))
* Update
  appdirect_stub.py ([a00673a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a00673afd155cce3778f4c1414c7dd14ed6ed02f))
* Update
  appdirect_stub.py ([ad2e7fd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ad2e7fdea5aff7f8585fb69696b36db1a10dd2c4))
* Update
  appdirect_stub.py ([65ddafd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/65ddafdb52449df3a6f0c8b029f9580c85ed4a40))
* Update
  appdirect_stub.py ([0d21c74](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0d21c740ebf272a33632f1482503a1fde0825e65))
* Update
  appdirect_stub.py ([224a96b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/224a96bddb1fe1e688d554584cfa97cd9dd37b54))
* Update
  appdirect_stub.py ([afa44bd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/afa44bd70e4af61b642006ce2fd6f401347aa64a))
* Update
  appdirect_stub.py ([0df7bd8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0df7bd8a956c313e6b7535d3feff0c3291f188ed))
* Update
  appdirect_stub.py ([e4e2ce2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e4e2ce2127d01e6f5b02d161581598067136c1d3))
* Update
  appdirect_stub.py ([0766a2f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0766a2fe6d99fa567167fe9e3784962fac1b27e8))
* Update
  appdirect_stub.py ([f52ba6b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f52ba6b7e64c9b814bc752e25ba07220efb76e40))
* Update
  appdirect_stub.py ([f841d81](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f841d81292415d6cf2d030b3a757df1ae6403b54))
* Update
  appdirect_stub.py ([e9f44d1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e9f44d1d683a60fcdd3600f79b3afa9a4a9fe1de))
* Update
  appdirect_stub.py ([2af3bf9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2af3bf986b031cd3f7f7d332d8128143548f0ac9))
* Update
  appdirect_stub.py ([2e2ef7a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2e2ef7ac36bdb3938b98685f15474850d4a4ebb1))
* Update
  appdirect_stub.py ([296aeaa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/296aeaaef13d0cd2caa1686f4d5ed1812b46559e))
* Update
  appdirect_stub.py ([4e22a0b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4e22a0b2b65bfc2cbf0d116b91d7d5370cc13cf2))
* Update
  appdirect_stub.py ([e3d86ba](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e3d86ba1f73e17905a53e0abe3da0d46586736c4))
* Update
  appdirect_stub.py ([55d6287](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/55d62875f98d6aca584ee2da9dfb05422769e3ca))
* Update
  appdirect_stub.py ([92e5fb9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/92e5fb9043baa863d309354b1c0fa17e0e8af177))
* Update
  appdirect_stub.py ([4484ef0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4484ef03a155a40cfed001f3e2bd03ce41cae0ae))
* Update
  appdirect_stub.py ([6d7854e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6d7854e2e36d12f93a6881e4412afe18ff14323d))
* Update
  appdirect_stub.py ([2ef747b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2ef747b4c11333d9fdc2bb10c05ca372e116388f))
* Update
  appdirect_stub.py ([468d05e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/468d05e285cd6c012587e616ff2824b4b7ecc3ef))
* Update
  appdirect_stub.py ([89dc55f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89dc55f05417f97a4c781c7bc13d966266a8690e))
* Update
  appdirect_stub.py ([8f5475d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8f5475d042d18a942e2448a6ebcf8e863189bd4a))
* Update
  appdirect_stub.py ([770c7c5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/770c7c5d0f38121bfbdb6051e87f94540b0642ee))
* Update
  appdirect_stub.py ([3f8d092](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3f8d0923449f6d7e2d34ba5b7d703cd4c29c7622))
* Update
  appdirect_stub.py ([06bda84](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/06bda847fafd41e32b126a2e2e6e09b34171e680))
* Update
  appdirect_stub.py ([a97e424](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a97e424d59f0f487b4d84d83c9cf36462d5bd866))
* Update
  appdirect_stub.py ([1b2a663](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1b2a663d5dd6ae6c385ad97ea22abfc8ec23b3b6))
* Update
  appdirect_stub.py ([7f41823](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7f418234c638def8234c1d911115a6d8b75e203c))
* Update
  appdirect_stub.py ([9a1d662](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9a1d66221db6f543a7a9b759838982df7459b50c))
* Update
  appdirect_stub.py ([fb14fce](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fb14fce5a5a07c387aee1653f91427b583c6d39c))
* Update
  appdirect_stub.py ([8035bc2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8035bc27c77b88d44c3bbe744c7e2a77d31c3847))
* Update
  appdirect_stub.py ([f59aa3e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f59aa3e5a4357831c1730e878f2221ef2f29cec4))
* Update
  appdirect_stub.py ([3c8207e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3c8207ebda77d8c8da36da10d071ee2dbf0a482a))
* Update
  appdirect_stub.py ([ffcfc68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ffcfc68559198c9b5140535acae6e3d21a642e62))
* Update
  appdirect_stub.py ([d5c3ed6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d5c3ed68df3a00a2c6f941ea907ca39360b4989f))
* Update
  appdirect_stub.py ([f450d4d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f450d4de2327d4ee805e3bf71c4d2ccbd6d068fb))
* Update
  appdirect_stub.py ([d1af395](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d1af395eeb5d3ea9fc65b64b06e2b671b86f0001))
* Update
  appdirect_stub.py ([559c248](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/559c24806e390d1a8383cfb582bb49066f31c371))
* Update
  appdirect_stub.py ([cc3a869](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cc3a8694afb08f450117323cbb241282b572e96a))
* Update
  appdirect_stub.py ([b7ea9d3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b7ea9d3c20a786b302d99a5e9b0cac821f1e9be5))
* Update
  appdirect_stub.py ([c4a07fa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c4a07fa60739673b8b45fc619e8bd54415a934d4))
* Update
  appdirect_stub.py ([7a65c4a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7a65c4ad8e0439a024a81613b0125831c858a831))
* Update
  appdirect_stub.py ([e58d692](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e58d692f71d09cab560e02955fc63a8b08f5f54b))
* Update
  appdirect_stub.py ([6d25f27](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6d25f2709a8a9fcb09c6579d1bfa9510a730787f))
* Update
  appdirect_stub.py ([3ffd638](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3ffd63820cedb601d551a26a6c5ba10c2cfce3c9))
* Update
  appdirect_stub.py ([00aa588](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/00aa588409dc7ce53a7c7417c495ca6fa4b71298))
* Update
  appdirect_stub.py ([6bd1d85](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6bd1d85682b8d8692214cc225f2a1b9f1b563324))
* Update
  appdirect_stub.py ([da3efd5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da3efd52b570cd2daac17b060f78c2a0c44ed130))
* Update
  appdirect_stub.py ([875c8b0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/875c8b0e514e53bf8def5567bdde335559d18397))
* Update
  appdirect_stub.py ([ad7ca7d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ad7ca7da1d4ef76b40fb5d0ef0d7e7079c7152c2))
* Update
  appdirect_stub.py ([3691a90](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3691a90b3b30f9718270b273aedf0be38510598b))
* Update
  appdirect_stub.py ([c3c430c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c3c430c339afcae6da274e5db298483ff9fb106f))
* Update
  appdirect_stub.py ([9c6ce13](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9c6ce13483194fbb29eb02d2468215a88a72748b))
* Update
  appdirect_stub.py ([a63ea6f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a63ea6f11256b106b5e9ec149b9149bcf241d6e3))
* Update
  appdirect_stub.py ([89d0575](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/89d0575e65b96b4bdc9526692ec401ad7a595c2b))
* Update
  appdirect_stub.py ([e6f188f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e6f188fc26a63c7838097aa0ff2411c209f97a79))
* Update
  appdirect_stub.py ([7bb2e30](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7bb2e301a704310d63128f6d66f8cbb13507d93a))
* Update
  appdirect_stub.py ([108bd34](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/108bd34d3dda8bdb3cbc30fba61d0c7179e4336d))
* Update
  appdirect_stub.py ([7e997af](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7e997afa019e03689c01acd163aceaa3245ec3c6))
* Update
  appdirect_stub.py ([e156585](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e1565857eb46f9a9517fb605199c5cfa73730496))
* Update
  appdirect_stub.py ([3de4160](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3de4160cf88d18046adbf4ea506120fefdbc73ed))
* Update
  appdirect_stub.py ([4686409](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4686409e9395f8c248217fcd753c1ebe47210100))
* Update
  appdirect_stub.py ([e9e5055](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e9e50555b8f059a4dcdfecd8b4c8acce842aca4a))
* Update
  appdirect_stub.py ([c67d30d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c67d30d81dc3344ce7a455c81447584886d02ddd))
* Update
  appdirect_stub.py ([0fd472a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0fd472a4a8b6d75b74396d4b2611fff96a2ca299))
* Update
  appdirect_stub.py ([842f3ec](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/842f3ec7ec8af0d6e4e9676553163a476336757e))
* Update
  appdirect_stub.py ([ea3095c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ea3095cea68803cdcb2a7b545fc30f4eeeaf6a4f))
* Update
  appdirect_stub.py ([688f81b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/688f81bba00813ece2bb20c9cc67a03e90488e1e))
* Update
  appdirect_stub.py ([cd15af0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cd15af0fd73f24a27fd749b033db4d4f16868eaf))
* Update
  appdirect_stub.py ([c90a4a9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c90a4a941e349c7a498d0ab462b42597703b6773))
* Update
  appdirect_stub.py ([d87c96b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d87c96bd4eac0d4b7711ccd35cdf9937eed1092d))
* Update
  appdirect_stub.py ([60e51eb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/60e51eba3534b1f26ca9e1bec1e2bfe7280f3283))
* Update
  appdirect.py ([42454c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/42454c134f15e8809196c44b5b24134265d8ae05))
* Update
  appdirect.py ([9040082](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/90400827a56b867589a2940af85842b2caaefb87))
* Update
  appdirect.py ([204cffd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/204cffd6ccba9dd9f8d5e1076bc2a77d2dfc0e44))
* Update
  appdirect.py ([b9cc3d7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b9cc3d7cf037fc3c7fb52fee111480422440c8c6))
* Update
  appdirect.py ([61054c3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/61054c3f84c44a1e704aafcff01a3f45180e04a3))
* Update
  appdirect.py ([76dd4b9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/76dd4b9a8f8a255decbe3e74bd7419793d1f98a1))
* Update
  appdirect.py ([b4fa580](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b4fa580e8c579ce621af19d561ba1c440d0a3b37))
* Update
  appdirectAPI_Stub.py ([1ac7d9d](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1ac7d9d1fc1db2344627bb8e9cc5ca7719756139))
* Update
  appdirectRunner.py ([05aff33](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/05aff339463a90d872126668d2fcb89a8fbb2e36))
* Update
  appdirectRunner.py ([b38ff55](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b38ff55f4f01c6700f022037b726a1d2724df711))
* Update
  appdirectRunner.py ([71c8571](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/71c8571206d87c7f3f1005cef9a392df5ed6fdac))
* Update
  appdirectRunner.py ([0ed7644](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0ed76449e1ae29bdfd63591fb5c1d3a50997a73f))
* Update
  appdirectRunner.py ([521b7b0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/521b7b07117059e87492892c83b8f43aed5add75))
* Update
  appdirectRunner.py ([918468f](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/918468fb771eb3d74245bc4dda17e6158faae27a))
* Update
  appdirectRunner.py ([3336ea3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3336ea317f2418711414322081275c754f362ff7))
* Update
  appdirectRunner.py ([ffd87f8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ffd87f876245132f54fe5404ca283fd94aea9534))
* Update
  appdirectRunner.py ([8782e44](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8782e440fc27e73cce9f37d4f191bfe0bc85fca4))
* Update
  appdirectRunner.py ([76fc978](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/76fc97869c7c6a1a8c8d5343a77a72556e8da40e))
* Update
  appdirectRunner.py ([3ca4227](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3ca4227903e8b49e28204587806e38a0dccba886))
* Update
  appdirectRunner.py ([69f9872](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/69f987283d29fda2d607cb327eaa55bbe2a7d75c))
* Update
  ChangeLicense.json ([d757a26](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d757a26b20ceea66cee8c66599a7a7e126cbcc9a))
* Update
  ChangeLicense.json ([7194665](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7194665a5d5ddb3a8c83241575a2a65a3b437508))
* Update
  ChangeLicense.json ([45987ca](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/45987cac6d89ca362f087c649902ba6070e1ceaa))
* Update
  changeLicensepayload.json ([2de1bb5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2de1bb5323c67e6b61abb5cb3d33bd7645231551))
* Update
  changeLicensepayload.json ([c112692](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c1126925f862b3b6aedac12c77032d6a8ade311a))
* Update
  consumer_data.py ([a2c6e37](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a2c6e37f3ad4d85197d286fba87d1045e49074e1))
* Update
  consumer_data.py ([74c61ad](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/74c61ad51c8f08a11965a9c6ab92cd46acf852bc))
* Update
  FullStackOrderEventResponse.json ([0808da9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0808da96ccde3f482dcfafda8d6b1ce5f1bf5134))
* update
  ID ([bd8969b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bd8969bc6c4158d07cb81361e93ce9bd374c696b))
* Update new
  function ([f294e57](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/f294e570f3a9aa36311f63d9cf41ee574cf1e558))
* Update
  read_xmldata.py ([af8ed59](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/af8ed5937e20e7ee9969eec31f5b3921a9bccfa9))
* Update
  read_xmldata.py ([0de9ac6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/0de9ac6c80298e7926f1cd5ff2f5849044a2d7dc))
* Update
  requirements.txt ([738a711](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/738a71124ae3b1bd06394dc49e4539b1c4bbb130))
* Update
  requirements.txt ([70a21c8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/70a21c8fd7c29621286c2b94e40516ffbe00920b))
* Update
  ringCentralAPI.py ([d598712](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d598712221fba399be817e69adf9878f5d68a832))
* Update
  ringCentralAPI.py ([3b074b8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3b074b8cf0b17c164df9b9a787ecdd34247c48c9))
* Update
  ringCentralAPI.py ([b01ee57](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b01ee57c4c9cfc27058a86ca055e77a347ddc588))
* Update
  ringCentralAPI.py ([d2a4b2e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d2a4b2e5e0cf9cdaacedc547028ffd7b4012c01f))
* Update
  ringCentralAPI.py ([6a66b5c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6a66b5c64fc451d44cc7d01b7672a5b597296832))
* Update
  ringCentralAPI.py ([304ff16](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/304ff16f499b02fa0750e1f6138a3b1145301b11))
* Update
  ringCentralAPI.py ([7a1d909](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7a1d90962c238be42042ff4b09403ff3ccc3ac26))
* Update
  ringCentralAPI.py ([5760284](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/576028403c2c5d6a15a4184366d9357dcd7cf9c1))
* Update
  ringCentralAPI.py ([562aeb1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/562aeb1017469e2fa0ba77561a880b675d5fcdbc))
* Update
  ringCentralAPI.py ([fd25b64](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fd25b64add91e3e34c4399bc164b7d4d62e8d984))
* Update
  ringCentralAPI.py ([dd8cb76](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/dd8cb76b51c3cfb563052e0cebd96ad2dec48820))
* Update
  test_inputdata.xml ([2f490fa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2f490fa789ecf9ea142bccc22fb5080b8fd5a874))
* Update
  test_inputdata.xml ([42c2b26](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/42c2b26e5418d73ef0555e55d64514a8c1bdadd7))
* Update
  test_inputdata.xml ([c07faf5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c07faf5afe6d59ba54de757f67184bb2edafe20c))
* Update
  test_inputdata.xml ([e13386c](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e13386c3d3b4baa9014d6fd6a116c69ee3ff3703))
* Update
  test_inputdata.xml ([55abf10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/55abf1003e95b059ffa4d09f9bd173c6aacc7ab5))
* Update
  test_inputdata.xml ([ffc882e](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ffc882ee0a8ffa6203584c68bec40fd26b2fe3c1))
* Update
  test_inputdata.xml ([9b0857b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9b0857bc248ee3134575abb7b4d6c0a3f3a040c6))
* Update
  test_inputdata.xml ([9859371](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9859371c08731078a5baa8ab0bc56e58d92af6e1))
* Update
  test_inputdata.xml ([1de3af0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1de3af0d8680200f85e93919777c48a33db38a26))
* Update
  test_inputdata.xml ([bc1caa6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bc1caa6c17255aa911c5ccdf0fbc078d1b79ea67))
* update the
  functionname ([64fd097](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/64fd097cc9ec3f9a9083e6462f61b9f5ad293545))
* Update
  UPUA_1128_Add_Addons.feature ([1c8dfdc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1c8dfdcdf4188e9ca40846e1e5ba53bb40dbc0aa))
* Update
  UPUA_1128_Add_Addons.feature ([cd23026](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/cd23026c212237e6e2c971347da3d0bd454686fe))
* Update
  UPUA_1128_Add_Addons.feature ([2650849](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2650849f5ca02634c938ec655d10f2514ca3b457))
* Update
  UPUA_1128_Add_Addons.feature ([a0975dc](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a0975dc4ffec568b7ed5f2c37992769a16df50b3))
* Update
  UPUA_1128_Add_Addons.feature ([e954965](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e9549653e04b4db1a35c7ed991b2172487624cc3))
* Update
  UPUA_1128_Add_Addons.feature ([7edfd86](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7edfd86de0815b88285c955a69ec32374de9d3ee))
* Update
  UPUA_1128_Add_Addons.feature ([3f449f4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3f449f4abea231e362598e1b1b4660fb481716db))
* Update
  UPUA_1128_Add_Addons.feature ([ec15cb1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ec15cb13ac774020ac855ee208d6f3a119e942ad))
* Update
  UPUA_498_Purchase_Addons.feature ([23b0581](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/23b058199657fa5fb44300d0661fe4b345550acc))
* Update
  UPUA_498_Purchase_Addons.feature ([a01bdd1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/a01bdd1bf2133b4950e9095a5b05a4e59d0902d4))
* Update
  UPUA_498_Purchase_Addons.feature ([4c76de3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4c76de3f67d76a6d8f718e5ca4232c76c2baa00c))
* Update
  UPUA1_appD_MW_AccountCreation.feature ([3c5d353](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3c5d3538d58de35086255af2d5173434f2b2e056))
* Update
  UPUA1_appD_MW_AccountCreationwithStub.feature ([7bedf28](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/7bedf28d29b98ad5325f97fba509509fd866ed7e))
* Update
  UPUA1_appD_MW_AccountCreationwithStub.feature ([08497c8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/08497c8e411ac7fb8032b47a019379d26e69a13a))
* Update
  UPUA1_appD_MW_AccountCreationwithStub.feature ([8bbfb18](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8bbfb189f654e36ff7e3cf30cc50acf33fc389ec))
* Update
  UPUA1_appD_MW_AccountCreationwithStub.feature ([5da742a](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5da742ab07eb3e2fa1e1610432da6677df997e27))
* Update
  UPUA1_appD_MW_AccountCreationwithStub.feature ([822baff](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/822baff5ed9287abd5ad2865041ca9829e201f31))
* Update
  UPUA1_appD_MW_AccountCreationwithStub.feature ([17ef1f4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/17ef1f450b440a821d32a81582908b8bbcd1cf41))
* Update
  UPUA479_AddlicensewithStub.feature ([256170b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/256170bcdb2f4b6e857ab1a937f104f526ccd432))
* Update
  UPUA479_AddlicensewithStub.feature ([c4bae68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c4bae68f9ee58308bd2f9d7f40c2f5e85b8f0045))
* Update
  UPUA479_AddlicensewithStub.feature ([97f86b3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/97f86b361d9e91f1f61d99a96d40c4ba67d62f77))
* Update
  UPUA479_AddlicensewithStub.feature ([8ad5165](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8ad51652cb1bf4c71fbaa3a788ff0bec7b9fe993))
* Update
  UPUA479_AddlicensewithStub.feature ([6d984a1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/6d984a13b5ee1c5d04aaae6d1e5d5728cc30e030))
* Update
  UPUA479_AddlicensewithStub.feature ([779c3aa](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/779c3aa0dea727aa74b6df6d4a28ff3398dd8740))
* Update
  UPUA479_AddlicensewithStub.feature ([289fdd0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/289fdd06d52fefd0a8117493a7e79f41dfba3ae0))
* Update
  UPUA479_AddlicensewithStub.feature ([51fadf0](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/51fadf0554760edafc069ab0a1502a36c1cefa12))
* Update
  UPUA479_AddlicensewithStub.feature ([2fbbb29](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/2fbbb294114ba2e4d78a5efc48080a5a188a6864))
* Update
  UPUA479_AddlicensewithStub.feature ([bf84ed3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bf84ed35131ffbb70a6c6cb01f592b5b73624610))

## [1.0.28](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.27...1.0.28) (2021-08-20)

### Features

* ✨ try to Align
  versions ([9768cf5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/9768cf5ff3f665ee042fcc6d07514482faa9b162))

## [1.0.27](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.26...1.0.27) (2021-08-20)

### Features

* ✨ Try to trigger a new
  release ([90e5736](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/90e5736da72239c4a1fc8ef0e795ef623b7d5621))

## [1.0.26](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.25...1.0.26) (2021-08-12)

### Features

* :hammer: Align helm chart version with
  appVersion ([bb6d744](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bb6d74492b6bc9113e56a1704b5d386c3b570ffa))

## [1.0.25](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.24...1.0.25) (2021-08-09)

### Features

* :sparkles: Replace deployment for a statefulset with pod
  identity ([fd1b35b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fd1b35bf8743432726bc353fc466bb6a3911212f))

## [1.0.24](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.23...1.0.24) (2021-08-02)

### Bug Fixes

* :sparkles
  UPUA77 ([fa97860](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/fa9786073bd797fc8633497d1402f6f00262b827))

## [1.0.23](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.22...1.0.23) (2021-07-29)

### Bug Fixes

* added [@id-mapper-api](https://gitlab-ucc.tools.aws.vodafone.com/id-mapper-api) to test
  cases ([29d89c1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/29d89c1ea8b5813f9cc1d5dd04495e7f8f5a0c9c))

## [1.0.22](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.21...1.0.22) (2021-07-29)

### Bug Fixes

* added id-mapper to
  url ([79b4a1b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/79b4a1bd0eae92fd4049750760528411eb9b1f3d))

## [1.0.21](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.20...1.0.21) (2021-07-28)

## [1.0.20](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.19...1.0.20) (2021-07-28)

### Bug Fixes

* 🚑 Hotfix - Rename default ECR name to be
  account/environment-agnostic ([b6fecf6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/b6fecf6ff9a4b7f49a1e0f08844cee2f6f5382e0))

## [1.0.19](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.18...1.0.19) (2021-07-28)

## [1.0.18](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.17...1.0.18) (2021-07-27)

### Bug Fixes

* Update UPUA73_OutboundEmailComms.feature removed more
  mailhog ([1260c54](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1260c5438379885f93dd6a1278d4e8d6360c4906))

## [1.0.17](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.16...1.0.17) (2021-07-27)

### Bug Fixes

* Update
  emailRestAPI.py ([c14a861](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/c14a8616c582bd76cc870db17f4fc4d686be98ff))

## [1.0.16](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.15...1.0.16) (2021-07-27)

### Bug Fixes

*
Email ([ce7ec3b](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/ce7ec3bd6eacce5819bf815533292ec1da3f9bf8))

## [1.0.15](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.14...1.0.15) (2021-07-27)

### Bug Fixes

* update EMAIL_API_SERVER
  info ([8d9b6b5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8d9b6b5edf175884b6219acf8ab8ee943cd852ef))

## [1.0.14](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.13...1.0.14) (2021-07-27)

### Bug Fixes

*
Suite ([1350a37](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1350a37a33a6269e7416bdb49825cafb6cb0ad2c))

## [1.0.13](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.12...1.0.13) (2021-07-21)

### Bug Fixes

*
Test ([77d0b76](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/77d0b766a449c6aa50ad49ebe7ae27d3cfd9653a))

## [1.0.12](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.11...1.0.12) (2021-07-21)

## [1.0.11](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.10...1.0.11) (2021-07-20)

### Bug Fixes

*
Tags ([7833997](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/78339979b5452e34fbd8c27b6f50e1c418d338d2))

## [1.0.10](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.9...1.0.10) (2021-07-16)

### Bug Fixes

* Update
  appdirect.py ([4a6ee68](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/4a6ee685aaa4aafc01954a735c91b27693860985))

## [1.0.9](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.8...1.0.9) (2021-07-16)

### Bug Fixes

*
Tag ([3b8fdeb](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/3b8fdeb7976b73bc55b73b688fdb8b23d18ee562))

## [1.0.8](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.7...1.0.8) (2021-07-16)

### Bug Fixes

*
Test ([d5072fd](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d5072fd7fe5556da727cf7c374096eba7fca511e))

## [1.0.7](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.6...1.0.7) (2021-07-15)

### Bug Fixes

* Test automation
  upua77&amp;upua1 ([82d8130](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/82d8130198a9be7a357a3ab0d9880f5b214829a7))

## [1.0.6](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.5...1.0.6) (2021-07-15)

### Bug Fixes

* latest
  JSON ([da70187](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/da70187c43b90a7630021c0adb77a6c3e4b0a16e))

## [1.0.5](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.4...1.0.5) (2021-07-15)

### Bug Fixes

* Update
  ordermanagement_create_initialorder_1.json ([8753fde](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/8753fde87e4226659f45fce01024c99592bd24b5))

## [1.0.4](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.3...1.0.4) (2021-07-09)

### Bug Fixes

*
minorchanges ([1305b74](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/1305b74ec8627eacb50f760a0f8416de028bea9a))

## [1.0.3](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.2...1.0.3) (2021-07-09)

### Bug Fixes

* A test
  MR ([5e13797](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5e13797e8127ccc2b076fdb2516edce5136c8078))

## [1.0.2](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.1...1.0.2) (2021-07-07)

### Bug Fixes

* :fire: changes in UPUA1 and
  UPUA77 ([46e9116](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/46e91168a2c084d4d327d204d3110785478fdb27))

## [1.0.1](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/compare/1.0.0...1.0.1) (2021-07-01)

### Bug Fixes

* :fire: Get rid of hardcoded
  version ([bad9127](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/bad91277f797a5e997d85761213e79d8abb437f2))

# 1.0.0 (2021-07-01)

### Bug Fixes

* :bug: Ensure the automation FW stays up and running in the
  background ([5f26191](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/5f26191e3573fb973f8ec6fad5ea88d2d97d6346))
* :fire: Get rid of .gitkeep in the helmcharts
  dir ([e639ecf](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/e639ecf06e568f6be9f673426f9f93d768bc8d9e))
* :rocket: Fix CPU utilization in Docker
  container ([d2ba7af](https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/automation-fw/commit/d2ba7af52f572df163e33e02a84092d7418ecb05))
