import logging
import sys
import time

logger = logging.getLogger(__name__)


class Delay:
    """
    Delay times in second
    """
    short = 1
    medium = 3
    long = 5
    too_long = 10
    get_operation_status = 20
    validate_error_operation_status = 15
    validate_response_operation_status = 20
    get_provisioning_status = 10
    end_notification_number_management = 25
    number_management_notification = 20
    consumer_data = 6
    email_handler_read_data = 7


class Timeout:
    """
    Timeouts in second
    """
    create_account = 10


def wait_with_progress_bar(wait_seconds: int):
    """
    Wait for 'wait_seconds' seconds with a text based progress bar
    :param wait_seconds:
    :return:
    """
    logger.info(f"Waiting for {wait_seconds} seconds")
    # logger configuration redirects output from stdout to a different StringIO stream
    # Get the control of sys.stdout temporarily
    configured_std = sys.stdout
    sys.stdout = sys.__stdout__
    progress_bar_length = 120
    interval = wait_seconds / 100
    for i in range(100):
        time.sleep(interval)
        progress = (i + 1) / 100
        block = int(round(progress_bar_length * progress))
        text = f"\r[{'#' * block + '-' * (progress_bar_length - block)}] {progress * 100:.2f}%"
        sys.stdout.write(text)
        sys.stdout.flush()
    # revert back the stdout configuration
    sys.stdout = configured_std
    logger.info(f"\nWait for {wait_seconds} seconds complete")
