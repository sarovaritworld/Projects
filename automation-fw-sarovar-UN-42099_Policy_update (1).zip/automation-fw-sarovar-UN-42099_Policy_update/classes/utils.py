import json
import logging
import re
from datetime import datetime

import cron_descriptor
from bson.objectid import ObjectId

logger = logging.getLogger(__name__)


def strtobool(val):
    """Convert a string representation of truth to true (1) or false (0).

    True values are 'y', 'yes', 't', 'true', 'on', and '1'; false values
    are 'n', 'no', 'f', 'false', 'off', and '0'.  Raises ValueError if
    'val' is anything else.
    """
    val = val.lower()
    if val in ('y', 'yes', 't', 'true', 'on', '1'):
        return 1
    elif val in ('n', 'no', 'f', 'false', 'off', '0'):
        return 0
    else:
        raise ValueError("invalid truth value {!r}".format(val))


class JSONEncoderExtended(json.JSONEncoder):
    """Encoder handling extra types (not supported by the default encoded)."""

    def default(self, obj):
        if isinstance(obj, ObjectId):  # handle Pymongo IDs
            return f"ObjectId({obj})"
        elif isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)


def to_json(data: dict | list, format: str = "pretty") -> str:
    """Convert to JSON (in a consistent way for logging)."""
    match format:
        case "pretty":
            indent = 2
        case "oneline":
            indent = None
        case "items":
            lines = [to_json(item, "oneline") for item in data]
            return "\n  - ".join([""] + lines)
        case _:
            raise NotImplementedError(f"{format=}")
    return json.dumps(data, indent=indent, sort_keys=True, cls=JSONEncoderExtended)


def cron_to_frequency(cron_expr) -> int:
    """
    Converts a cron expression to a frequency in minutes.

    :param cron_expr: The cron expression to be converted.
    :returns: The frequency in minutes.
    :raises IncorrectCronException: If the frequency is not in minutes or if the cron expression is too complex.

    Notes:
        - If the cron expression is None or empty, a default frequency of 1 minute is returned.
        - The function assumes that the testing system only works with minute-based frequencies.
        - The function uses `cron_descriptor` to get a human-readable description of the cron expression.
        - The function logs warnings and information using `logger`.

    Example:
        >>> cron_to_frequency("*/5 * * * *")
        5
    """
    if cron_expr is None or len(str(cron_expr).strip()) == 0:
        logger.warning(f"{cron_expr=}, return default frequency")
        return 1
    frequency = cron_descriptor.get_description(cron_expr)
    logger.info(f'{frequency=}')
    # in testing system we assume only working with minutes
    if not frequency.find('minute'):
        raise IncorrectCronException('Frequency is not in minutes, please check cron expression!')
    number = re.findall(r'\d+', frequency)
    if len(number) > 1:
        raise IncorrectCronException('Frequency is more complex than a simple one, please check cron expression!')
    return int(number[0])


class IncorrectCronException(Exception):
    pass
