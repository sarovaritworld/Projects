import logging
from copy import deepcopy
from dataclasses import dataclass
from typing import Callable

from classes import common, jira_helper, msoc_numbers
from classes import numbers, payload
from classes.payload import type_of_soi
from classes.utils import to_json
from common_python.parser.data_parser import Parser
from .msg_validation_set import KafkaMsgValidationSet

logger = logging.getLogger(__name__)


class KafkaTopicValidator:
    """
    How to create new validation function:
    Create new private function with logic inside. Check that if you want to create new validation_set you need to
    call to KafkaMsgValidationSet.function()...
    Then, add the name of function in validate_topic function dict with key and function.

    Example:
        If you want to validate new topic with name new_validation_topic first of all you need to create new function
        called _new_validation_topic (with underscore). Then you need to go to validate_topic function and add it. Key
        must be without underscore and function value with that.

        topic_dict = {
            "tmfgateway_process_serviceorder": self._tmfgateway_process_serviceorder,
            "tmfmediator_update_serviceorder": self._tmfmediator_update_serviceorder,
            ...
            "new_validation_topic": self._new_validation_topic
        }

    """

    def __init__(self, context=None):
        self._context = context

    @classmethod
    def is_topic_supported(cls, topic_name: str) -> bool:
        """Check whether the validation of a topic is supported by this class."""
        return hasattr(cls, f'_{topic_name}') or hasattr(cls, topic_name)

    def validate_topic(self, topic_name: str, error_type: str = None, **kwargs):
        logger.info(f"Validating {topic_name} topic")

        if error_type:
            logger.info(f"Error type: {error_type}")

        fct = getattr(self, f'_{topic_name}', None)
        if not fct:
            fct = getattr(self, topic_name, None)
        if not fct:
            raise NotImplementedError(f"Topic validation not implemented for {topic_name=}")

        try:
            fct(error_type, **kwargs)
        except Exception as e:
            logger.error(e)
            raise

    @staticmethod
    def _validate_numbers(message, numbers_list):
        for number in numbers_list:
            common.is_value_present(message, number)

    def _tmfgateway_process_serviceorder(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfgateway_process_service_order()
        common.validate_message(self._context.consumer_payload, validation_set)

        self._context.service_order = self._context.payload['serviceOrderItem']

        for item in self._context.service_order:
            logger.debug(f"Validating service order item '{item}' under tmfgateway_process_serviceorder")

            soi_id = int(item['id']) - 1
            validation_set = {
                f"tmfServiceOrder.serviceOrderItem.{soi_id}.action": item['action'].upper(),
                f"tmfServiceOrder.serviceOrderItem.{soi_id}.state": "ACKNOWLEDGED",
                f"tmfServiceOrder.serviceOrderItem.{soi_id}.service.serviceType": type_of_soi(item)
            }
            common.validate_message(self._context.consumer_payload, validation_set)

        # self._context.middleware_correlation_id = self._context.consumer_payload['header']['middleware_correlation_id']

    def tmfmediator_update_serviceorder(self, error_type: str = None,
                                        milestone=None,
                                        service_characteristic=None,
                                        item_id=None,
                                        state=None,
                                        use_last_message=False
                                        ):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_update_serviceorder(error_type,
                                                                                              milestone,
                                                                                              service_characteristic,
                                                                                              item_id,
                                                                                              state)
        if hasattr(self._context, "activate_immediately") and not self._context.activate_immediately:
            validation_set["completed_order.status"] = True
            validation_set.pop("completed_order.error.error_code")
            validation_set.pop("completed_order.error.error_message")
        if use_last_message:
            self._context.consumer_payload = self._context.consumer_payload[-1]
        common.validate_message(self._context.consumer_payload, validation_set)

    def _tmfmediator_command_create_initialorder(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_create_initialorder()
        self._context.marketplace = 'TMF'

        if 'activate_immediately' in self._context.consumer_payload['order']['tenant_flow_settings']:
            validation_set.update({"order.tenant_flow_settings.activate_immediately": True})
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_create_addnumbers(self, number_type='pool', item=None, consumer_message=None, category=None):
        """
        Kafka topic validator for 'tmfmediator_create_addnumbers'
        In tmfmediator_create_addnumbers topic we receive total amount of numbers, hence amount of messages == amount of number order items
        :param number_type: can be mainNumber, pool and pool_range
        :param item: service order item to validate
        :param consumer_message: corresponding message to validate
        :param category: UNITY/MSOC/TPM
        """
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_create_addnumbers(item, number_type, category)
        logger.info(f'{validation_set=}')
        common.validate_message(consumer_message, validation_set)

    def _tmfmediator_create_deletenumbers(self, error_type: str = None):
        """
        Kafka topic validator for 'tmfmediator_create_deletenumbers'
        :param number_type: pool or pool_range
        :param item: service order item to validate
        :param consumer_message: corresponding message to validate
        """
        item = payload.get_item_by_type_and_action(self._context.payload, 'ucc.unity.numbers',
                                                   action='delete') or payload.get_item_by_type_and_action(
            self._context.payload, 'ucc.msoc.numbers', action='delete') or payload.get_item_by_type_and_action(
            self._context.payload, 'ucc.tpm.numbers', action='delete')

        category = payload.ServiceOrderPayload(self._context.payload).get_category()

        if isinstance(self._context.consumer_payload, list):
            self._context.consumer_payload = self._context.consumer_payload[-1]

        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_create_deletenumbers(item, category=category)
        common.validate_message(self._context.consumer_payload, validation_set)

    def numbermanagement_command_add_numbers(self, usage_type, expected_numbers: list, consumer_message):
        """
        Validates 'numbermanagement_command_add_numbers' topic message details
        Works with single message and list of numbers
        :param usage_type: Inventory or Presentation
        :param expected_numbers: list of numbers to validate
        :param consumer_message: single message
        :return: If some extra numbers has been passed, it returns the rest
        """
        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_command_add_numbers()
        common.validate_message(consumer_message, validation_set)

        expected_numbers = set(expected_numbers)
        phone_numbers_details = consumer_message["phone_numbers"]["phone_number_details"]
        for number in phone_numbers_details:
            assert number["usage_type"] == usage_type
            assert number['phone_number'] in expected_numbers
            expected_numbers.discard(number['phone_number'])
        logger.debug(f'numbers left from input list, not validated: \n {expected_numbers}')
        return expected_numbers

    def _ringcentral_event_numbers_added(self, error_type=None):
        if error_type is not None:
            validation_set = KafkaMsgValidationSet(self._context).ringcentral_respond_number(
                'ringcentral_event_numbers_added', error_type)
            logger.debug(f'{validation_set=}')
            common.validate_message(self._context.consumer_payload, validation_set)

    def ringcentral_event_numbers_added(self, usage_type='Inventory', expected_numbers: list = None,
                                        consumer_message=None, error_type=None):
        """
        Validates 'ringcentral_event_numbers_added' topic message details
        Works with single message and list of numbers
        :param usage_type: Inventory or Presentation
        :param expected_numbers: list of numbers to validate
        :param consumer_message: single message
        :return: If some extra numbers has been passed, it returns the rest
        """
        if error_type is not None:
            self._ringcentral_event_numbers_added(error_type)
            return
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_numbers_added()
        logger.debug(f'{validation_set=}')
        common.validate_message(consumer_message, validation_set)

        expected_numbers = set(expected_numbers)
        phone_numbers_details = consumer_message["phone_numbers"]["phone_number_details"]
        for number in phone_numbers_details:
            assert number["usage_type"] == usage_type
            assert number['phone_number'] in expected_numbers
            if not error_type:
                assert number.get('id') is not None
            expected_numbers.discard(number['phone_number'])
        logger.debug(f'numbers left from input list, not validated: \n {expected_numbers}')
        return expected_numbers

    def _numbermanagement_respond_numbersadded(self, error_type: str = None, state: str = "COMPLETED_PROVISIONING",
                                               number_type: str = None):

        # Sorting the payload based on 'marketplaceEventId' for validation, here the order of the id is the order of the service order item sent in the request.
        sorted_consumer_payload = sorted(self._context.consumer_payload,
                                         key=lambda x: x['numbersConfirmation']['marketplaceEventId'])
        actual_message = self._context.consumer_payload[-1]
        logger.debug(f'{sorted_consumer_payload=}')
        if hasattr(self._context, "kafka_payload"):
            validation_set = KafkaMsgValidationSet(self._context).numbermanagement_respond_numbers_added(
                error_type=error_type, state=state, number_type=number_type)
            common.validate_message(actual_message, validation_set)
            return
        if not hasattr(self._context, 'service_order'):
            self._context.service_order = self._context.payload['serviceOrderItem']

        expected_service_order_items = sorted(self._context.service_order, key=lambda soi: soi['id'])
        logger.debug(f'{expected_service_order_items=}')

        if number_type == 'Main_Number':
            for message in sorted_consumer_payload:
                if message['numbersConfirmation']['data'][0]['action'] == 'A' and 'type' in \
                        message['numbersConfirmation']['data'][0].keys():
                    actual_message = message

        elif number_type == 'Fixed':
            for message in sorted_consumer_payload:
                if message['numbersConfirmation']['data'][0]['action'] == 'A' and 'type' not in \
                        message['numbersConfirmation']['data'][0].keys():
                    actual_message = message
                    self._context.pool = numbers.get_numbers_from_payload_based_on_pooltype(
                        expected_service_order_items, 'add', number_type)

        elif number_type == 'Mobile':
            for message in sorted_consumer_payload:
                if message['numbersConfirmation']['data'][0]['action'] == 'A':
                    actual_message = message
                    actual_message['numbersConfirmation']['data'] = sorted(
                        actual_message['numbersConfirmation']['data'], key=lambda x: x['e164'])
                    self._context.pool = numbers.get_numbers_from_payload_based_on_pooltype(
                        expected_service_order_items, 'add', number_type)

        elif number_type == 'Presentation':
            # The presentation numnbers in staging env are not sequential on bulk execution, hence sorting the payload based on numbers
            for message in sorted_consumer_payload:
                message = deepcopy(message)
                message['numbersConfirmation']['data'] = [item for item in message['numbersConfirmation']['data'] if
                                                          item["action"] == "AF"]
                message['numbersConfirmation']['data'].sort(key=lambda x: int(x["e164"]))
                actual_message = message
                self._context.pool = numbers.get_numbers_from_payload_based_on_pooltype(expected_service_order_items,
                                                                                        'add', number_type)

        elif number_type in numbers.negative_numbers:
            actual_message = self._context.consumer_payload[-1]

        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_respond_numbers_added(
            error_type=error_type, state=state, number_type=number_type)
        logger.info(f'{validation_set=}')
        logger.info(f'{actual_message=}')
        common.validate_message(actual_message, validation_set)

    def numbermanagement_command_delete_numbers(self, expected_numbers: list, consumer_message):
        """
Validates 'numbermanagement_command_delete_numbers' topic message details
Works with single message and list of numbers
        :param expected_numbers: list of numbers to validate
        :param consumer_message: single message
        :return: If some extra numbers has been passed, it returns the rest
        """
        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_command_delete_numbers()
        common.validate_message(consumer_message, validation_set)

        expected_numbers = set(expected_numbers)
        phone_numbers_details = consumer_message["phone_numbers"]["phone_number_details"]
        for number in phone_numbers_details:
            assert number['phone_number'] in expected_numbers
            expected_numbers.discard(number['phone_number'])
        logger.debug(f'numbers left from input list, not validated: \n {expected_numbers}')
        return expected_numbers

    def ringcentral_event_numbers_deleted(self, expected_numbers, consumer_message):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_numbers_deleted()
        common.validate_message(consumer_message, validation_set)
        expected_numbers = set(expected_numbers)
        phone_numbers_details = consumer_message["phone_numbers"]["phone_number_details"]
        for number in phone_numbers_details:
            assert number['phone_number'] in expected_numbers
            assert number.get('id') is not None
            expected_numbers.discard(number['phone_number'])
        logger.debug(f'numbers left from input list, not validated: \n {expected_numbers}')
        return expected_numbers

    def _ringcentral_event_ssoconfig_updated(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_ssoconfig_updated(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def _ringcentral_event_accountserviceinfo_updated(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_accountserviceinfo_updated(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def _ringcentral_event_initialorder_created(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_initialorder_created(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)
        if not error_type:
            common.update_RC_ID(self._context)
        common.update_ucas_provider(self._context)
        common.update_middleware_correlation_id(self._context)

    def ringcentral_event_extension_set(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_extension_set(
            error_type=error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def _tmfmediator_create_jiraticket(self, error_type: str = None):
        # to use this validation you should be confident that it contains a proper
        # context.service_order collection.
        if not error_type:
            if not hasattr(self._context, 'service_order'):
                self._context.service_order = self._context.payload['serviceOrderItem']

            expected_service_order_items = sorted(self._context.service_order, key=lambda soi: soi['id'])
            current_service_order_items = sorted(self._context.consumer_payload,
                                                 key=lambda payl: payl['jiraTicketRequested']['customFields'][
                                                     'customfield_20901'])
            logger.info("All Service Order Items: " + to_json(expected_service_order_items, format="items"))
            logger.info("Received Service Order Items: " + to_json(current_service_order_items, format="items"))

            sois = ServiceOrderItemFilter(self._context).tmfmediator_create_jiraticket(expected_service_order_items)
            assert len(current_service_order_items) >= sois.num_received_messages, \
                "Number of received Service Order Items"
            for index_expected, index_received in zip(sois.expected_indexes, sois.received_indexes):
                item = expected_service_order_items[index_expected]
                payl = current_service_order_items[index_received]
                logger.debug(f"Validating the service order item: {item}")
                validation_set = KafkaMsgValidationSet(self._context).tmf_mediator_create_jira_ticket(item)
                common.validate_message(payl, validation_set)
                if self._context.middleware_correlation_id != payl['header']['middlewareCorrelationId']:
                    logger.info(
                        f"middleware_correlation_id has been changed "
                        f"old value {self._context.middleware_correlation_id}"
                        f"new value {payl['header']['middlewareCorrelationId']}"
                    )
                    self._context.middleware_correlation_id = payl['header']['middlewareCorrelationId']
                    self._context.middleware_correlation_id_changed = True


        else:
            assert False, f"Error type {error_type} validation is not implemented"
        logging.info(f'payload {self._context.payload}')

    def _jiraticketmediator_respond_jiraticket(self, error_type: str = None):
        if not error_type:
            if not hasattr(self._context, 'service_order'):
                self._context.service_order = self._context.payload['serviceOrderItem']

            expected_service_order_items = sorted(self._context.service_order, key=lambda soi: soi['id'])
            current_service_order_items = sorted(self._context.consumer_payload,
                                                 key=lambda payl: payl['jiraTicketCreated']['clientReference'][
                                                     'marketplace_event_id'])
            logger.info("All Service Order Items: " + to_json(expected_service_order_items, format="items"))
            logger.info("Received Service Order Items: " + to_json(current_service_order_items, format="items"))

            sois = ServiceOrderItemFilter(self._context).jiraticketmediator_respond_jiraticket(
                expected_service_order_items)
            assert len(current_service_order_items) >= sois.num_received_messages, \
                "Number of received Service Order Items"
            for index_expected, index_received in zip(sois.expected_indexes, sois.received_indexes):
                item = expected_service_order_items[index_expected]
                payl = current_service_order_items[index_received]
                logger.debug(f"Validating the service order item: {item}")
                validation_set = KafkaMsgValidationSet(self._context).jira_ticket_mediator_respond_jira_ticket()
                logger.info(f"getting ticket for key {payl['jiraTicketCreated']['ticketKey']}")
                current_ticket = jira_helper.get_ticket_by_key(payl['jiraTicketCreated']['ticketKey'])
                logger.debug(f'ticket found {current_ticket}')
                validation_set.update({
                    "jiraTicketCreated.clientReference.marketplace_event_id": self._context.service_order_id + "/" + str(
                        item['id']),
                    "jiraTicketCreated.ticketId": current_ticket['id'],
                    "jiraTicketCreated.ticketKey": current_ticket['key']}
                )
                common.validate_message(payl, validation_set)
                jira_helper.validate_issue(item, current_ticket, self._context.service_order_id)

            logger.info(f"{self._context.service_order=}")

        else:
            assert False, f"Error type {error_type} validation is not implemented"
        logging.info(f'payload {self._context.payload}')

    def _crfgateway_event_crfnumber_added(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).crfgateway_event_crfnumber_added(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

        if error_type:
            confirmation = self._context.consumer_payload.get("crfConfirmation", {})
            pool = confirmation.get("pool", [])

            assert ("error" in confirmation or (pool and "numberError" in pool[0])), "confirmation should contain an error"

    def _crfgateway_event_crfnumber_deleted(self,
                                            error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).crfgateway_event_crfnumber_deleted(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

        if error_type:
            confirmation = self._context.consumer_payload.get("crfConfirmation", {})
            pool = confirmation.get("pool", [])

            assert ("error" in confirmation or (
                        pool and "numberError" in pool[0])), "confirmation should contain an error"

    def _numbermanagement_command_add_crfnumber(self, error_type: str = None):
        if isinstance(self._context.consumer_payload, list):
            self._context.consumer_payload = self._context.consumer_payload[-1]
        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_command_add_crfnumber()
        logger.debug(f'validation_set --> {validation_set=}')
        logger.debug(f'self._context.consumer_payload --> {self._context.consumer_payload=}')
        common.validate_message(self._context.consumer_payload, validation_set)
        numbers.validate_number_in_crf_request(self._context)

    def _numbermanagement_command_delete_crfnumber(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_command_delete_crfnumber()
        common.validate_message(self._context.consumer_payload, validation_set)
        match error_type:
            case 'additional_range':
                pool_range = Parser(self._context.consumer_payload).find_first('$.crfNumberRequest.poolRange')
                assert len(pool_range) == 2
            case _:
                numbers.validate_number_in_crf_request(self._context)

    def _ringcentral_event_numbers_deleted(self, error_type: str = None,
                                           topic_name: str = 'ringcentral_event_numbers_deleted'):
        if hasattr(self._context, 'main_number'):
            self._context.consumer_payload = numbers.remove_main_number_from_consumer_payload(
                self._context.consumer_payload,
                self._context.main_number)
        self._context.consumer_payload = payload.get_last_message(self._context.consumer_payload)

        validation_set = KafkaMsgValidationSet(self._context).ringcentral_respond_number(topic_name, error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def ringcentral_event_numbers_updated(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_numbers_updated(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def ringcentral_event_emergencyaddress_set(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_emergencyaddress_set(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def ringcentral_event_unitylicense_deleted(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_unitylicense_deleted(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def _ordermanagement_event_order_completed(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ordermanagement_event_order_completed(error_type)
        if hasattr(self._context, "activate_immediately") and not self._context.activate_immediately:
            validation_set["completed_order.status"] = True

        common.validate_message(self._context.consumer_payload, validation_set)

    def _tmfmediator_command_set_ssoconfig(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_set_ssoconfig()
        common.validate_message(self._context.consumer_payload, validation_set)

    def _tmfmediator_command_set_accountserviceinfo(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_set_accountserviceinfo()
        common.validate_message(self._context.consumer_payload, validation_set)

    def _idmapper_event_msoccustomer_created(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).idmapper_event_msoccustomer_created(error_type=error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def idmapper_event_account_deleted(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).idmapper_event_account_deleted(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def _tmfmediator_command_create_msoccustomer(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_create_msoccustomer(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def numbermanagement_command_update_numbers(self):
        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_command_update_numbers()
        common.validate_message(self._context.consumer_payload, validation_set)

    def idmapper_event_msoccountrybilling_added(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).idmapper_event_msoccountrybilling_added(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_add_msoccountrybilling(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_add_msoccountrybilling(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_delete_unitylicense(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_delete_unitylicense()
        common.validate_message(self._context.consumer_payload, validation_set)

    def numbermanagement_event_numbers_deleted(self, error_type: str = None, state: str = "COMPLETED_PROVISIONING"):
        if hasattr(self._context, "category") and self._context.category == "TPM":

            sorted_consumer_payload = sorted(self._context.consumer_payload,
                                             key=lambda x: x['numbersConfirmation']['marketplaceEventId'])
            actual_message = self._context.consumer_payload[-1]

            for message in sorted_consumer_payload:
                actual_message = message
                actual_message['numbersConfirmation']['data'] = sorted(
                    actual_message['numbersConfirmation']['data'], key=lambda x: x['e164'])
            self._context.tpm_numbers.pool = sorted(self._context.tpm_numbers.pool)
            validation_set = KafkaMsgValidationSet(self._context).numbermanagement_event_numbers_deleted(
                error_type=error_type, state=state)
            logger.info(f'{validation_set=}')
            logger.info(f'{actual_message=}')
            common.validate_message(actual_message, validation_set)
        else:
            validation_set = KafkaMsgValidationSet(self._context).numbermanagement_event_numbers_deleted(
                error_type=error_type, state=state)
            common.validate_message(self._context.consumer_payload[-1], validation_set)

    def numbermanagement_event_all_numbers_deleted(self, error_type=None):
        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_event_all_numbers_deleted(
            error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def ordermanagement_command_update_accountstatus(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ordermanagement_command_update_accountstatus()
        common.validate_message(self._context.consumer_payload, validation_set)

    def snowgateway_event_snowcustomer_created(self, error_type=None, account_provisioned=True):
        validation_set = KafkaMsgValidationSet(self._context).snowgateway_event_snowcustomer_created(error_type,
                                                                                                     account_provisioned)
        common.validate_message(self._context.consumer_payload[-1], validation_set)

    def tmfmediator_command_create_snowcustomer(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_create_snowcustomer()
        common.validate_message(self._context.consumer_payload[-1], validation_set)

    def ordermanagement_command_create_initialorder(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ordermanagement_command_create_initialorder()
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_update_accountstatus(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_update_accountstatus()
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_delete_all_numbers(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_delete_all_numbers()
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_delete_account(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_delete_account()
        common.validate_message(self._context.consumer_payload, validation_set)

    def numbermanagement_command_delete_all_crf_numbers(self):
        validation_set = KafkaMsgValidationSet(self._context).numbermanagement_command_delete_all_crf_numbers()
        common.validate_message(self._context.consumer_payload, validation_set)

    def crfgateway_event_all_crf_numbers_deleted(self, error_type=None):
        validation_set = KafkaMsgValidationSet(self._context).crfgateway_event_all_crf_numbers_deleted(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_add_msoccustomercac(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_add_msoccustomercac()
        common.validate_message(self._context.consumer_payload, validation_set)

    def idmapper_event_msoccustomercac_added(self, error_type=None):
        validation_set = KafkaMsgValidationSet(self._context).idmapper_event_msoccustomercac_added(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_apply_cacconfiguration(self, error_type=None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_apply_cacconfiguration()
        common.validate_message(self._context.consumer_payload, validation_set)

    def crfgateway_event_cacconfiguration_applied(self, error_type=None, outcome=None):
        validation_set = KafkaMsgValidationSet(self._context).crfgateway_event_cacconfiguration_applied(outcome,
                                                                                                        error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfgateway_update_serviceorder(self, item_id, state):
        validation_set = KafkaMsgValidationSet(self._context).tmfgateway_update_serviceorder(item_id, state)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_create_tpmcustomer(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_create_tpmcustomer()
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_set_emergencyaddress(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_set_emergencyaddress()
        common.validate_message(self._context.consumer_payload, validation_set)

    def idmapper_event_tpmcustomer_created(self, error_type=None):
        validation_set = KafkaMsgValidationSet(self._context).idmapper_event_tpmcustomer_created(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def _crfstub_process_resourceorder(self, error_type, action: str, pool: str, account_category: str):
        validation_set = KafkaMsgValidationSet(self._context).crfstub_process_resourceorder(
            action,
            pool,
            account_category
        )
        common.validate_message(self._context.consumer_payload, validation_set)

    def idmapper_event_tpmnotification_sent(self, error=None, email_status=None):
        validation_set = KafkaMsgValidationSet(self._context).idmapper_event_tpmnotification_sent(error=error,
                                                                                                  email_status=email_status)
        common.validate_message(self._context.consumer_payload, validation_set)

    def _tmfmediator_command_send_tpmnotification(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_send_tpmnotification()
        common.validate_message(self._context.consumer_payload, validation_set)

    def snowgateway_event_snowcustomer_deleted(self, deprovisioned=None):
        validation_set = KafkaMsgValidationSet(self._context).snowgateway_event_snowcustomer_deleted(deprovisioned)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_delete_snowcustomer(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_delete_snowcustomer()
        common.validate_message(self._context.consumer_payload, validation_set)

    def _tmfmediator_command_set_extension(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_set_extension()
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_add_unitylicense(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_add_unitylicense()
        common.validate_message(self._context.consumer_payload, validation_set)

    def ringcentral_event_unitylicense_added(self, error=None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_unitylicense_added(error=error)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_set_policy_access(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_set_policy_access()
        common.validate_message(self._context.consumer_payload, validation_set)

    def ringcentral_event_policy_access_set(self, error_type: str = None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_policy_access_set(error_type)
        common.validate_message(self._context.consumer_payload, validation_set)

    def tmfmediator_command_change_unitylicense(self):
        validation_set = KafkaMsgValidationSet(self._context).tmfmediator_command_change_unitylicense()
        common.validate_message(self._context.consumer_payload, validation_set)

    def ringcentral_event_unitylicense_changed(self, error=None):
        validation_set = KafkaMsgValidationSet(self._context).ringcentral_event_unitylicense_changed(error)
        common.validate_message(self._context.consumer_payload, validation_set)


@dataclass
class ServiceOrderItems:
    """Index of SOIs used for comparison."""
    expected_indexes: list[int]
    received_indexes: list[int]
    num_received_messages: int


class ServiceOrderItemFilter:
    """Filter Service Order Items that should be received and validated."""

    def __init__(self, context) -> None:
        self._context = context

    def get_filter_fct(self, topic: str) -> Callable[[list[dict]], ServiceOrderItems] | None:
        """Get the filter method for a specific topic."""
        return getattr(self, topic, None)

    def tmfmediator_create_jiraticket(self, all_service_order_items: list[dict]) -> ServiceOrderItems:
        expected = []
        received = []
        num_received_messages = 0
        for index, item in enumerate(all_service_order_items):

            # Check whether we expect a corresponding SOI to be received
            if jira_helper.skip_jira(self._context, item):
                continue
            num_received_messages += 1

            # Check whether this SOI needs validation
            if payload.item_is_add_account(item) and hasattr(self._context, 'add_account_validated'):
                logging.info("item is add account and it has already been validated >> skip")
                continue
            elif payload.item_is_add_msoc_account(item) and hasattr(self._context, 'msoc_add_customer_jira_validated'):
                logging.info("item is add msoc customer and it has already been validated >> skip")
                continue
            elif payload.item_is_add_msoc_country_biiling(item) and hasattr(self._context,
                                                                            'msoc_add_billing_jira_validated'):
                logging.info("item is add msoc billing and it has already been validated >> skip")
                continue
            elif msoc_numbers.item_is_add_msoc_number(item):
                logging.info("item is add msoc number and no jira is created >> skip")
                continue
            elif payload.item_is_add_cac_configuration(item):
                logging.info("item is add CAC and no jira is created >> skip")
                continue
            expected.append(index)
            received.append(num_received_messages - 1)

        return ServiceOrderItems(
            expected_indexes=expected, received_indexes=received,
            num_received_messages=num_received_messages)

    def jiraticketmediator_respond_jiraticket(self, all_service_order_items: list[dict]) -> ServiceOrderItems:
        expected = []
        received = []
        num_received_messages = 0
        for index, item in enumerate(all_service_order_items):

            # Check whether we expect a corresponding SOI to be received
            if jira_helper.skip_jira(self._context, item):
                continue
            elif payload.item_is_add_msoc_account(item) and hasattr(self._context, 'msoc_add_customer_jira_validated'):
                logging.info(f"item is add msoc customer and it has already been validated >> skip")
                continue
            elif payload.item_is_add_msoc_country_biiling(item) and hasattr(self._context,
                                                                            'msoc_add_billing_jira_validated'):
                logging.info(f"item is add msoc billing and no jira is created >> skip")
                continue
            num_received_messages += 1

            # Check whether this SOI needs validation
            if payload.item_is_add_account(item) and hasattr(self._context, 'add_account_validated'):
                logging.info(f"item is add account and it has already been validated >> skip")
                continue
            elif msoc_numbers.item_is_add_msoc_number(item):
                logging.info(f"item is add msoc number and it has already been validated >> skip")
                continue
            expected.append(index)
            received.append(num_received_messages - 1)

        return ServiceOrderItems(
            expected_indexes=expected, received_indexes=received,
            num_received_messages=num_received_messages)
