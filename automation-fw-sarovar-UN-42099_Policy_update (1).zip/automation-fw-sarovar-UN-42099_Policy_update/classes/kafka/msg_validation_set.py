import logging
import re
from typing import Any, Dict

import camel_converter

import classes.errors
from classes import account, asserts, common, data_files, errors, license, numbers, payload, read_xmldata, tpm
from classes.data_factory import countries_data_manager
from classes.errors import DEPErrors, ErrorCodes, NMErrorType, OrderManagementErrorCodes, RCErrorType, \
    SetExtensionErrorCodes
from classes.exceptions import NotFoundError
from classes.snow import SNOWError

logger = logging.getLogger(__name__)


class KafkaMsgValidationSet:

    def __init__(self, context: Any = None):
        self._context = context

    def tmfmediator_update_serviceorder(self,
                                        error=None,
                                        milestone=None,
                                        service_characteristic=None,
                                        item_id=None,
                                        state=None):
        """
https://confluence.tools.aws.vodafone.com/display/UCP/Common+Processing+Activities#CommonProcessingActivities-UpdatingtheServiceOrderwithOperationResults

This topic can be updated with only state, service characteristic, error, milestone (error and milestone usually go with notes)
        :param error:
        :param milestone:
        :param service_characteristic:
        :param item_id:
        :param state:
        :return:
        """
        service_order_item_id = payload.service_order_item_id if not hasattr(self._context,
                                                                             "service_order_item_id") else self._context.service_order_item_id

        # basic validation set should contain fields that come with every message
        # (add state field there and updated usages to pass required state)
        validation_set = {
            "header.eventType": "UPDATE_TMF_SERVICE_ORDER",
            "serviceOrderUpdate.serviceOrderId": self._context.service_order_id,
            # "serviceOrderUpdate.serviceOrderItemId": service_order_item_id,
        }
        # condition of any context should be outside the validation set handled by validator
        # in this case depending on the status tmfmediator_update_serviceorder()
        # should receive either milestone or error
        if 'cac_provisioning_status' in self._context:
            cac_id = self._context.cac_id
            if self._context.cac_provisioning_status == "CAC_PROVISIONING_COMPLETE":
                msg = f"CAC Configuration with ID {cac_id} has been applied to CRF"
                validation_set.update({
                    "serviceOrderUpdate.notes.0.text": msg,
                    "serviceOrderUpdate.milestones.0.message": msg,
                    "serviceOrderUpdate.milestones.0.status": "COMPLETED",
                    "serviceOrderUpdate.serviceOrderItemState": "COMPLETED",
                })
            elif self._context.cac_provisioning_status == "CAC_PROVISIONING_PENDING":
                msg = f"CAC Configuration with ID {cac_id} will be applied to CRF when the next numbers with CAC are provisioned"
                validation_set.update({
                    "serviceOrderUpdate.notes.0.text": msg,
                    "serviceOrderUpdate.milestones.0.message": msg,
                    "serviceOrderUpdate.milestones.0.status": "COMPLETED",
                    "serviceOrderUpdate.serviceOrderItemState": "COMPLETED",
                })
            elif self._context.cac_provisioning_status == "CAC_PROVISIONING_ERROR":
                msg = f"CAC Configuration with ID {cac_id} could not be applied to CRF"
                validation_set.update({
                    "serviceOrderUpdate.notes.0.text": msg,
                    "serviceOrderUpdate.errorMessages.0.message": msg,
                    "serviceOrderUpdate.errorMessages.0.reason": self._context.cac_provisioning_error_message,
                    "serviceOrderUpdate.serviceOrderItemState": "FAILED",
                })
            else:
                raise NotImplementedError(f"{self._context.cac_provisioning_status=}")

        if milestone:
            validation_set.update({
                'serviceOrderUpdate.milestones.0.description': milestone.description,
                'serviceOrderUpdate.notes.0.text': milestone.message,
                "serviceOrderUpdate.serviceOrderItemState": "COMPLETED"
            })
        elif error:
            validation_set.update({
                'serviceOrderUpdate.error_messages.0.message': error.message,
                'serviceOrderUpdate.error_messages.0.code': error.code,
                'serviceOrderUpdate.error_messages.0.reason': error.reason,
                'serviceOrderUpdate.notes.0.text': error.message,
                "serviceOrderUpdate.serviceOrderItemState": "IN_PROGRESS",
                "serviceOrderUpdate.serviceOrderItemId": '3',
            })
        elif service_characteristic:
            raise NotImplementedError(f'{service_characteristic=} is not supported')

        return validation_set

    def tmfmediator_command_update_accountstatus(self):
        """
        Return validation set related to tmf mediator confirm account

        Returns:
            validation set dict representation
        """

        return {
            "header.event_type": "ACCOUNT_CONFIRMATION_REQUESTED",
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "account.marketplace": self._context.marketplace,
            "account.marketplace_event_id": self._context.marketplaceEventID,
            "account.op_co_details.name": self._context.opco_details_name,
            "account.op_co_details.op_co_customer_id": self._context.op_co_customer_id,

        }

    def crfgateway_event_crfnumber_added(self, error_type: str = None):
        """
        Return validation set related to crf confirmation

        Args:
            error_type: Error type

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.eventType": "CRF_CONFIRMATION"
        }

        if not error_type:
            # Successful scenario
            validation_set["crfConfirmation.resourceOrderId"] = self._context.crf_request_id
            validation_set["crfConfirmation.success"] = True
        elif error_type == "CRF_error":
            error_message = "One or more numbers could not be provisioned in CRF"
            if self._context.category == "TPM":
                error_message = "Service Order Item error\\nUnknown error"

            validation_set["crfConfirmation.error.errorCode"] = "SERVICE_PROVIDER_ERROR"
            validation_set["crfConfirmation.error.errorMessage"] = error_message
        elif errors.CRFErrorCodes.is_error_present(error_type):
            validation_set.update({"crfConfirmation.error.errorCode": errors.CRFErrorCodes.error_code(error_type),
                                   "crfConfirmation.error.errorMessage": errors.CRFErrorCodes.error_message(
                                       error_type)})
        elif error_type == "FAILED_SERVICE_ORDER":
            validation_set.update({"crfConfirmation.error.errorCode": ErrorCodes.SERVICE_PROVIDER_ERROR,
                                   "crfConfirmation.error.errorMessage": DEPErrors.get_error_message(error_type)})
        elif errors.DEPErrors.is_error_present(error_type):
            error_code = getattr(ErrorCodes, error_type, None)
            error_message = DEPErrors.get_error_message(error_type)
            for i, number in enumerate(self._context.consumer_payload.get("crfConfirmation", {}).get("pool", [])):
                validation_set.update({f"crfConfirmation.pool.{i}.numberError.errorCode": error_code,
                                  f"crfConfirmation.pool.{i}.numberError.errorMessage": error_message})

        else:
            logger.warning(f"No handing for {error_type=} for validating topic 'crfgateway_event_crfnumber_added'")

        return validation_set

    def crfgateway_event_crfnumber_deleted(self, error_type: str = None):
        """
        Return validation set related to crf confirmation

        Args:
            error_type: Error type

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.eventType": "CRF_CONFIRMATION"
        }
        if error_type:

            if error_type == "failed_dep_notification" or error_type == "partial_dep_notification":
                validation_set.update({"crfConfirmation.error.errorCode": ErrorCodes.SERVICE_PROVIDER_ERROR,
                                       "crfConfirmation.error.errorMessage": "No error information provided in DEP Service Order"})
            elif errors.CRFErrorCodes.is_error_present(error_type):
                validation_set.update({"crfConfirmation.error.errorCode": errors.CRFErrorCodes.error_code(error_type),
                                       "crfConfirmation.error.errorMessage": errors.CRFErrorCodes.error_message(
                                           error_type)})
            elif errors.DEPErrors.is_error_present(error_type):
                error_code = getattr(ErrorCodes, error_type, None)
                error_message = DEPErrors.get_error_message(error_type)
                if error_type == "MISSING_MARKET_CONFIGURATIONS":
                    error_message = "Deleting telephone numbers is not supported for market"
                for i, number in enumerate(self._context.consumer_payload.get("crfConfirmation", {}).get("pool", [])):
                    validation_set.update({f"crfConfirmation.pool.{i}.numberError.errorCode": error_code,
                                           f"crfConfirmation.pool.{i}.numberError.errorMessage": error_message})
            else:
                raise NotImplementedError(f"No handing for {error_type=} to validate topic "
                                          f"'crfgateway_event_crfnumber_deleted'")
        else:
            validation_set["crfConfirmation.resourceOrderId"] = self._context.crf_request_id
            validation_set["crfConfirmation.success"] = True
        logging.debug(f'{validation_set=}')
        return validation_set

    def numbermanagement_command_add_crfnumber(self):
        """
        Return validation set related to add crf number requested


        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.eventType": "ADD_CRF_NUMBER_REQUESTED",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "crfNumberRequest.opCoDetails.opCoCustomerId": self._context.op_co_customer_id
        }

        if hasattr(self._context, "service_order_type"):
            if self._context.service_order_type == "add_tenant" and hasattr(self._context, "carrier_id"):
                validation_set.update({"crfNumberRequest.carrierId": self._context.carrier_id})

            elif self._context.service_order_type == "add_number" and self._context.number_type == "pool" and hasattr(
                    self._context,
                    "carrier_id"):
                validation_set.update({"crfNumberRequest.carrierId": self._context.carrier_id})

            elif self._context.service_order_type == "add_number" and self._context.number_type == "pool_range" and hasattr(
                    self._context, "carrier_id"):
                validation_set.update({"crfNumberRequest.carrierId": self._context.carrier_id})

        if hasattr(self._context, "category"):
            validation_set.update({"crfNumberRequest.opCoDetails.name": self._context.market_code})
            if self._context.category == "UNITY":
                validation_set.update({"crfNumberRequest.ucasProvider": "RINGCENTRAL"})
            else:
                validation_set.update({"crfNumberRequest.ucasProvider": self._context.category})

        if hasattr(self._context, "number_cac_id"):
            validation_set.update({"crfNumberRequest.cacId": self._context.number_cac_id})
            logging.info(f'{validation_set}')

        return validation_set

    def numbermanagement_command_delete_crfnumber(self):
        """
        Returns validation set related to delete crf number requested

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.eventType": "DELETE_CRF_NUMBER_REQUESTED",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "crfNumberRequest.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
            "crfNumberRequest.opCoDetails.name": self._context.market_code
        }

        if hasattr(self._context, "category") and self._context.category in ('MSOC', 'TPM'):
            validation_set.update(
                {"crfNumberRequest.ucasProvider": self._context.category}

            )

        logging.info(f'{validation_set}')

        return validation_set

    def numbermanagement_command_delete_all_crf_numbers(self):
        validation_set = {
            "header.event_type": "DELETE_ALL_NUMBERS_REQUESTED",
            "delete_all_numbers.client_reference.marketplace": "TMF",
            "delete_all_numbers.op_co_details.name": self._context.market_code,
            "delete_all_numbers.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "delete_all_numbers.ucas_provider": self._context.category
        }

        return validation_set

    def numbermanagement_respond_numbers_added(self, error_type: str = None, state: str = 'COMPLETED_PROVISIONING',
                                               number_type=None):
        """
        Return validation set related to numbers added confirmation

        Args:
            error_type: Error type parameter
            state: State parameter can be COMPLETED_PROVISIONING, PARTIAL_PROVISIONING, FAILED_PROVISIONING

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.eventType": "NUMBERS_ADDED_CONFIRMATION",
            "numbersConfirmation.state": state
            # "numbersConfirmation.marketplace": "TMF",
        }

        if hasattr(self._context, "invalid_E164_Number"):
            validation_set.update["header.middlewareCorrelationId": self._context.middleware_correlation_id],
            validation_set.update[
            "numbersConfirmation.errorMessage": read_xmldata.readxml("invalid_164_main_number", "test_inputdata",
                                                                     "num_prov")],
            validation_set.update["numbersConfirmation.marketplaceEventId": self._context.marketplace_event_id]

        if hasattr(self._context, "category") and self._context.category == "TPM":
            validation_set["numbersConfirmation.ucasProvider"] = self._context.category
            if state == "FAILED_PROVISIONING":
                if error_type in ("bad_request", "FAILED_SERVICE_ORDER"):
                    validation_set["numbersConfirmation.error.errorCode"] = errors.ErrorCodes.SYSTEM_ERROR
                else:
                    validation_set["numbersConfirmation.error.errorCode"] = errors.ErrorCodes.INVALID_REQUEST
            else:
                for i in range(int(self._context.tpm_numbers.quantity)):
                    validation_set[f"numbersConfirmation.data.{i}.action"] = 'A'
                    validation_set[f"numbersConfirmation.data.{i}.e164"] = self._context.tpm_numbers.pool[i]

        if hasattr(self._context, "category") and self._context.category == "MSOC":
            validation_set["numbersConfirmation.ucasProvider"] = self._context.category
            if state == "FAILED_PROVISIONING":
                validation_set["numbersConfirmation.error.errorCode"] = errors.ErrorCodes.SYSTEM_ERROR

        if error_type == "failed_add_number":
            validation_set[
                "numbersConfirmation.errorMessage"] = "Error with Phone Numbers (see Phone Number Details for more information)"
            validation_set[
                "numbersConfirmation.data.0.message"] = f'errorCode: PRT-102, message: {read_xmldata.readxml("NOK_Add_Number_1", "RC_inputdata", "RC_errors")}'

        elif error_type == "failed_add_main_number":
            validation_set["numbersConfirmation.data.0.ringCentralUUID"] = self._context.RC_ID
            validation_set["numbersConfirmation.data.0.action"] = "A"

        elif number_type == "Presentation":
            for i in range(int(self._context.quantity)):
                validation_set[f"numbersConfirmation.data.{i}.ringCentralUUID"] = self._context.RC_ID
                validation_set[f"numbersConfirmation.data.{i}.action"] = 'AF'
                validation_set[f"numbersConfirmation.data.{i}.e164"] = self._context.pool[i]
                validation_set[f"numbersConfirmation.data.{i}.status"] = 'OK'

        elif number_type == "pool_OK_NOK":
            validation_set[f"numbersConfirmation.errorMessage"] = numbers.add_number_errors['errorMessage1']
            validation_set[f"numbersConfirmation.data.0.status"] = 'OK'
            validation_set[f"numbersConfirmation.data.0.e164"] = self._context.numbers[0][0]

            for item in self._context.numbers:
                for j in range(1, len(item)):
                    validation_set[f"numbersConfirmation.data.{j}.status"] = 'NOK'
                    validation_set[f"numbersConfirmation.data.{j}.e164"] = item[j]
                    validation_set[f"numbersConfirmation.data.{j}.message"] = numbers.add_number_errors[
                        'errorMessage2']

        elif number_type == "pool_NOK_OK":
            validation_set["numbersConfirmation.errorMessage"] = numbers.add_number_errors['errorMessage1']
            validation_set["numbersConfirmation.data.0.status"] = 'NOK'
            validation_set["numbersConfirmation.data.0.e164"] = self._context.numbers[0][0]
            validation_set["numbersConfirmation.data.0.message"] = numbers.add_number_errors['errorMessage2']

            for item in self._context.numbers:
                for j in range(1, len(item)):
                    validation_set[f"numbersConfirmation.data.{j}.status"] = 'OK'
                    validation_set[f"numbersConfirmation.data.{j}.e164"] = item[j]

        elif number_type == "pool_all_NOK":
            validation_set["numbersConfirmation.errorMessage"] = numbers.add_number_errors['errorMessage1']
            for item in self._context.numbers:
                for j in range(0, len(item)):
                    validation_set[f"numbersConfirmation.data.{j}.status"] = 'NOK'
                    validation_set[f"numbersConfirmation.data.{j}.e164"] = item[j]
                    validation_set[f"numbersConfirmation.data.{j}.message"] = numbers.add_number_errors[
                        'errorMessage2']

        elif number_type == "pool_Bad_Request":
            validation_set["numbersConfirmation.errorMessage"] = numbers.add_number_errors['errorMessage1']
            validation_set["numbersConfirmation.data.0.status"] = 'NOK'
            validation_set["numbersConfirmation.data.0.message"] = "Bad Request"

        elif number_type == "Pool_Number":
            for i in range(int(self._context.quantity)):
                validation_set[f"numbersConfirmation.data.{i}.ringCentralUUID"] = self._context.RC_ID
                validation_set[f"numbersConfirmation.data.{i}.action"] = 'A'
                validation_set[f"numbersConfirmation.data.{i}.e164"] = self._context.pool[i]
                validation_set[f"numbersConfirmation.data.{i}.status"] = 'OK'

        elif number_type == "Main_Number":
            validation_set["numbersConfirmation.data.0.type"] = "M"
            validation_set["numbersConfirmation.data.0.action"] = "A"
            validation_set["numbersConfirmation.data.0.status"] = "OK"
            validation_set["numbersConfirmation.data.0.e164"] = self._context.main_number

        elif error_type == 'account_not_found':
            validation_set.update(NMErrorType.get_error_data(error_type=error_type))

        return validation_set

    def numbermanagement_event_numbers_deleted(self, state: str, error_type=None):
        """
        Return validation set related to numbers deleted confirmation
        Args:
            state: State parameter

        Returns:
            validation set dict representation
        """
        validation_set = {
            "header.eventType": "NUMBERS_DELETED_CONFIRMATION",
            "numbersConfirmation.state": state
        }

        if hasattr(self._context, "category") and self._context.category == "TPM":
            validation_set["numbersConfirmation.ucasProvider"] = self._context.category
            if state == "FAILED_PROVISIONING":
                if 'dep_notification' in error_type:
                    validation_set["numbersConfirmation.error.errorCode"] = errors.ErrorCodes.SYSTEM_ERROR
                elif error_type in ("CUSTOMER_MAPPING_NOT_OWNED_BY_CUSTOMER", "CUSTOMER_MAPPING_NOT_FOUND"):
                    validation_set["numbersConfirmation.error.errorCode"] = errors.ErrorCodes.INVALID_REQUEST
                else:
                    error = numbers.delete_number_errors.get(error_type, numbers.delete_number_errors["default"])
                    validation_set["numbersConfirmation.errorMessage"] = error
            else:
                for i, number in enumerate(self._context.tpm_numbers.pool):
                    validation_set[f"numbersConfirmation.data.{i}.action"] = 'D'
                    validation_set[f"numbersConfirmation.data.{i}.e164"] = number

        elif error_type == 'account_not_found':
            validation_set.update(NMErrorType.get_error_data(error_type=error_type))

        return validation_set

    def numbermanagement_event_all_numbers_deleted(self, error_type=None):
        validation_set = {
            "header.event_type": "ALL_NUMBERS_DELETED_CONFIRMATION",
            "delete_all_numbers.client_reference.marketplace": "TMF",
            "delete_all_numbers.op_co_details.name": self._context.market_code,
            "delete_all_numbers.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "delete_all_numbers.ucas_provider": self._context.category
        }
        if error_type == 'tpm_bad_request' or error_type == 'tpm_server_error':
            validation_set.update({"delete_all_numbers.error.error_code": ErrorCodes.SERVICE_PROVIDER_ERROR})
            validation_set.update(
                {"delete_all_numbers.error.error_message": classes.errors.GLOBAL_ERROR})
        elif error_type is not None:
            if payload.has_cease_msoc_account(self._context.payload):
                error_message = "One or more numbers could not be deleted in CRF" if error_type == "partial" else "Failed to delete all numbers from CRF"
            else:
                error_message = "Service Order Item error\\nUnknown error"
            validation_set.update(
                {"delete_all_numbers.error.error_code": ErrorCodes.SERVICE_PROVIDER_ERROR,
                 "delete_all_numbers.error.error_message": error_message})
        else:
            validation_set.update({"delete_all_numbers.success": True})

        return validation_set

    def numbermanagement_command_complete_order(self):
        """
        Return validation set related to number management complete order

        Returns:
            validation set dict representation
        """

        return {
            "header.event_type": "ACCOUNT_CONFIRMATION_REQUESTED",
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "account.ucas_account_id": self._context.RC_ID
        }

    def ordermanagement_event_order_completed(self, scenario: str = None):
        """
        Args:
            scenario: validation case, might be error or any other not standard scenario

        Returns:
            validation set dict representation
        """
        validation_set = {
            "header.event_type": "ORDER_COMPLETED",
            "header.middleware_correlation_id": self._context.middleware_correlation_id
        }

        match scenario:
            case "duplicate_account_error_message":
                validation_set.update({"completed_order.error.error_code": "INVALID_REQUEST",
                                       "completed_order.error.error_message": f"Marketplace Account has already been "
                                                                              f"on-boarded: APPDIRECT/{self._context.marketplaceAccountID}"})
            case 'unconfirmed_account':
                validation_set.update({'completed_order.account.account_status': 'UNCONFIRMED'})
            case 'Unconfirmed_error_message':
                validation_set.update({'completed_order.account.account_status': 'UNCONFIRMED',
                                       'completed_order.marketplace': 'TMF',
                                       'completed_order.marketplace_event_id': self._context.service_order_id + "/" + payload.service_order_item_id,
                                       'completed_order.account.ucas_account_id': self._context.RC_ID})
            case "success_message":
                validation_set.update({'completed_order.status': True})
            case "JWT_error_message":
                validation_set.update({"completed_order.error.error_code": "UNKNOWN_ERROR",
                                       "completed_order.error.error_message": "JwtToken is not present in token from "
                                                                              "RingCentral API"})
            case "error_message":
                validation_set.update({"completed_order.error.error_code": self._context.RC_error_code,
                                       "completed_order.error.error_message": self._context.RC_error_message})
            case "previous_error_message":
                validation_set.update({"completed_order.error.error_code": "UCAS_PROVIDER_ERROR",
                                       "completed_order.error.error_message": "Parameter [status] is invalid. Unable "
                                                                              "to create account with status ["
                                                                              "Disabled]."})
            case "Quantity must be more than existing licences in RingCentral":
                validation_set.update({"completed_order.error.error_code": "UNKNOWN_ERROR",
                                       "completed_order.error.error_message": "Cannot remove licences."})
            case "invalid_contact_info":
                validation_set.update({"completed_order.error.error_code": ErrorCodes.INVALID_ACCOUNT_FIELD})
            case "invalid_primary_contact":
                validation_set.update({"completed_order.error.error_code": ErrorCodes.INVALID_PRIMARY_CONTACT_NUMBER,
                                       "completed_order.error.error_message": RCErrorType.get_error_message(scenario)})
            case "invalid_external_id" | "failed_create_account":
                validation_set.update({"completed_order.error.error_code": RCErrorType.RC_SYSTEM_ERROR_CODE,
                                       "completed_order.error.error_message": RCErrorType.get_error_message(scenario)})
            case "blank_country" | "blank_op_co_name" | "blank_op_co_customer_id" | "existing_customer_id":
                validation_set.update({
                    "completed_order.error.error_code": OrderManagementErrorCodes.error_code(scenario),
                    "completed_order.error.error_message": OrderManagementErrorCodes.error_message(scenario)
                })

            case None:
                validation_set.update({'completed_order.account.ucas_account_id': self._context.RC_ID,
                                       'completed_order.account.op_co_details.op_co_customer_id': self._context.op_co_customer_id,
                                       'completed_order.account.account_status': 'CONFIRMED'})
            case _:
                raise NotImplementedError(
                    f"Validation for {scenario} is not implemented in ordermanagement_event_order_completed")

        return validation_set

    def invalid_request(self, error_type: str):
        """
        Return validation set related to invalid request

        Args:
            error_type: Error type

        Returns:
            validation set dict representation
        """

        validation_set = {
            "code": "INVALID_REQUEST",
            "reason": "InvalidRequestData"
        }

        if error_type == "invalid_request":
            self._context.execute_steps("Then user validates '400' response")
            validation_set["message"] = "The patch request is not valid, check request body"

        elif error_type == "invalid_status_request":
            self._context.execute_steps("Then user validates '400' response")
            validation_set["message"] = "Invalid state change [ACKNOWLEDGED] to [COMPLETED] for serviceOrderItemId [2]"

        elif error_type == "invalid_order_state_request":
            self._context.execute_steps(
                "Then user validates the error response for 'invalid_order_state_request' from TMF Service Order API Gateway")
            validation_set[
                "message"] = "The patch request must adhere to the following criteria:\n   Only milestone, note, " \
                             "errorMessage can be added to service order.\n   only errorMessage can be added and " \
                             "state can be updated for service order item. "

        elif error_type == "data_not_found":
            self._context.execute_steps("Then user validates '404' response")
            validation_set["code"] = "DATA_NOT_FOUND"
            validation_set["reason"] = "Data Not found"
            validation_set["message"] = f"ServiceOrder not found for id: {self._context.service_order_id}"

        elif error_type == "invalid_media":
            self._context.execute_steps("Then user validates '415' response")
            validation_set["code"] = "INVALID_SERVICE_ORDER"
            validation_set["reason"] = "InvalidRequestData"
            validation_set["message"] = "Content-type application/json-patch+json is the only supported format."

        elif error_type == 'invalid_service_order':
            self._context.execute_steps("Then user validates '400' response")
            validation_set["code"] = "INVALID_SERVICE_ORDER"
            validation_set["reason"] = "InvalidRequestData"

        else:
            raise NotImplementedError(f"Validation for {error_type} is not implemented")

        return validation_set

    def ringcentral_gateway_account(self) -> dict:
        """
        Return validation set related to account information from ringcentral gateway

        Returns:
            validation set dict representation
        """

        validation = {
            "ucasAccountId": self._context.RC_ID,
            "market": self._context.market_code,
            "companyName": read_xmldata.readxml("companyName", "appdirect_inputdata", "AppdirectUI"),
            "companyAddress.street": read_xmldata.readxml("address_line_1", "appdirect_inputdata", "AppdirectUI"),
            "companyAddress.city": countries_data_manager.get_city(self._context.market_code),
            "companyAddress.country": countries_data_manager.get_country_code(self._context.market_code),
            "companyAddress.state": read_xmldata.readxml("state", "appdirect_inputdata", "AppdirectUI")
        }
        if hasattr(self._context, "include_all_data") and self._context.include_all_data == "true":
            if common.config.is_dev_env:
                # additional data returned by RC stub
                expected = data_files.read_config("additional_data.yml")
                validation.update({
                    "additionalData.billingAccountNumber": expected["billingId1"],
                    "additionalData.billingServiceReference": expected["billingId2"],
                    "additionalData.opportunityId": expected["opportunityId"],
                })

        return validation

    def ringcentral_respond_number(self, topic_name: str, error_type: str = None):
        """
        Return validation set related to ring central respond add number

        Args:
            topic_name: Topic name
            error_type: Error type

        Returns:
            validation set dict representation
        """
        logging.debug(topic_name)
        validation_set = {
            "0.header.event_type": common.event_per_topic_name[topic_name],
            "0.header.middleware_correlation_id": self._context.middleware_correlation_id,
            "0.phone_numbers.ucas_account_id": self._context.RC_ID
        }

        match error_type:

            case RCErrorType.bad_request | RCErrorType.internal_server_error | RCErrorType.presentation_server_error | RCErrorType.server_not_found | RCErrorType.too_many_requests:
                validation_set["0.phone_numbers.error.error_code"] = RCErrorType.get_system_error()
                validation_set["0.phone_numbers.error.error_message"] = RCErrorType.get_error_message(error_type)

            case RCErrorType.different_account:
                validation_set[
                    "0.phone_numbers.phone_number_details.0.errors.0.error_code"] = ErrorCodes.TEL_NUMBER_ALREADY_IN_USE
                validation_set[
                    "0.phone_numbers.phone_number_details.0.errors.0.error_message"] = RCErrorType.get_error_message(
                    error_type)

            case RCErrorType.pool_all_NOK | RCErrorType.invalid_phone_number:
                error_code = ErrorCodes.TEL_NUMBER_PROVISIONING_ERROR if "delete" not in topic_name else ErrorCodes.TEL_NUMBER_DEPROVISIONING_ERROR
                for j in range(int(self._context.quantity)):
                    validation_set[f"0.phone_numbers.phone_number_details.{j}.phone_number"] = self._context.pool[j]
                    validation_set[
                        f"0.phone_numbers.phone_number_details.{j}.errors.0.error_code"] = error_code

            case RCErrorType.pool_OK_NOK:
                error_code = ErrorCodes.TEL_NUMBER_PROVISIONING_ERROR if "delete" not in topic_name else ErrorCodes.TEL_NUMBER_DEPROVISIONING_ERROR
                for i in range(1):
                    validation_set[f"0.phone_numbers.phone_number_details.{i}.phone_number"] = self._context.pool[i]

                for j in range(1, int(self._context.quantity)):
                    validation_set[f"0.phone_numbers.phone_number_details.{j}.phone_number"] = self._context.pool[j]
                    validation_set[
                        f"0.phone_numbers.phone_number_details.{j}.errors.0.error_code"] = error_code

            case RCErrorType.success | RCErrorType.inventory | RCErrorType.presentation | RCErrorType.JWT_retry:
                validation_set["0.phone_numbers.success"] = True
            case RCErrorType.same_account_partial_presentation:
                if hasattr(self._context, "error_type") and self._context.error_type == "same_account_presentation":
                    validation_set["0.phone_numbers.phone_number_details.0.errors.0.error_code"] = ErrorCodes.TEL_NUMBER_ALREADY_IN_USE
                    validation_set[
                        "0.phone_numbers.phone_number_details.0.errors.0.error_message"] = RCErrorType.get_error_message(
                        'different_account')
                else:
                    validation_set["0.phone_numbers.success"] = True
            case RCErrorType.same_account_inventory | RCErrorType.same_account_presentation:
                if hasattr(self._context, "usage_type") and self._context.usage_type in ("ForwardedNumber", "PhoneLine"):
                    validation_set[
                        "0.phone_numbers.phone_number_details.0.errors.0.error_code"] = ErrorCodes.TEL_NUMBER_CONFLICTING_USAGE_TYPE
                    validation_set[
                        "0.phone_numbers.phone_number_details.0.errors.0.error_message"] = RCErrorType.get_error_message(
                        'different_usage_type').replace('*', self._context.usage_type)
                else:
                    validation_set["0.phone_numbers.success"] = True

            case RCErrorType.same_account_partial_inventory:
                validation_set["0.phone_numbers.success"] = True
                if getattr(self._context, 'usage_type', None) != 'AdditionalCompanyNumber':
                    validation_set[
                        "0.phone_numbers.phone_number_details.0.errors.0.error_code"] = ErrorCodes.TEL_NUMBER_ALREADY_IN_USE

            case RCErrorType.incompatible_usage_type | RCErrorType.number_in_use:
                for j in range(int(self._context.quantity)):
                    validation_set[
                        f"0.phone_numbers.phone_number_details.{j}.errors.0.error_code"] = RCErrorType.get_client_error()

            case RCErrorType.pool_NOK | RCErrorType.pool_NOK_Inventory | RCErrorType.all_NOK:
                error_code = ErrorCodes.TEL_NUMBER_PROVISIONING_ERROR if "delete" not in topic_name else ErrorCodes.TEL_NUMBER_DEPROVISIONING_ERROR
                if self._context.number_type == RCErrorType.pool_OK_NOK:
                    for i in range(1, int(self._context.quantity)):
                        validation_set[
                            f"0.phone_numbers.phone_number_details.{i}.errors.0.error_code"] = error_code
                        validation_set[
                            f"0.phone_numbers.phone_number_details.{i}.errors.0.error_message"] = RCErrorType.get_error_message(
                            error_type)
                else:
                    validation_set[
                        f"0.phone_numbers.phone_number_details.0.errors.0.error_code"] = RCErrorType.get_client_error()
                    validation_set[
                        f"0.phone_numbers.phone_number_details.0.errors.0.error_message"] = error_code

            case RCErrorType.main_number_exists_in_rc:
                validation_set.update({"0.phone_numbers.phone_number_details.0.errors.0.error_code": ErrorCodes.TEL_NUMBER_ALREADY_IN_USE,
                                       "0.phone_numbers.phone_number_details.0.errors.0.error_message": RCErrorType.get_error_message(error_type)})

            case RCErrorType.main_number_exists_in_rc_diff_usage:
                validation_set.update({"0.phone_numbers.phone_number_details.0.errors.0.error_code": ErrorCodes.TEL_NUMBER_CONFLICTING_USAGE_TYPE,
                                       "0.phone_numbers.phone_number_details.0.errors.0.error_message": RCErrorType.get_error_message(error_type)})

            case "pool_different_usage":
                validation_set.update(
                    {"0.phone_numbers.phone_number_details.0.errors.0.error_code": ErrorCodes.TEL_NUMBER_CANNOT_BE_REMOVED,
                     "0.phone_numbers.phone_number_details.0.errors.0.error_message": RCErrorType.get_error_message(
                         error_type)})
            case _:
                raise NotFoundError(f"{error_type}= is not found in error type")

        return validation_set

    def ringcentral_event_numbers_updated(self, error_type: str = None):
        """
        Return validation set related to ringcentral_event_numbers_updated

        Args:
            error_type: Error type

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.event_type": common.event_per_topic_name['ringcentral_event_numbers_updated'],
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "phone_numbers.ucas_account_id": self._context.RC_ID,
            "phone_numbers.phone_number_details.0.id": self._context.main_number_id,
            "phone_numbers.success": True
        }

        if error_type in ["internal_server_error", "too_many_requests"]:
            del validation_set["phone_numbers.success"]
            validation_set["phone_numbers.phone_number_details.0.errors.0.error_message"] = read_xmldata.readxml(
                error_type, "RC_inputdata", "RC_errors")
            validation_set["phone_numbers.phone_number_details.0.errors.0.error_code"] = "SERVICE_PROVIDER_ERROR"

        elif error_type and error_type != 'success':
            raise NotFoundError(f"{error_type} = is not found in error type")

        return validation_set

    def ringcentral_event_emergencyaddress_set(self, error_type: str = None):
        validation_set = {
            "header.event_type": "SET_EMERGENCY_ADDRESS_CONFIRMATION",
            "header.middleware_correlation_id": self._context.middleware_correlation_id
        }
        error_mapping = {
            "invalid_data": {"emergency_address_confirmation.error.error_code": "INVALID_REQUEST"},
            "unity_invalid_data": {
                "emergency_address_confirmation.error.error_code": "SERVICE_PROVIDER_ERROR",
                "emergency_address_confirmation.error.error_message": "EME-345 Specified emergency address already exists."
            },
            "unity_server_error": {
                "emergency_address_confirmation.error.error_code": "SERVICE_PROVIDER_ERROR",
                "emergency_address_confirmation.error.error_message": "CMN-201 Service Temporary Unavailable"
            }
        }
        if error_type in error_mapping:
            validation_set.update(error_mapping[error_type])
        else:
            validation_set.update({
                "emergency_address_confirmation.success": True,
                "emergency_address_confirmation.ucas_account_id": self._context.RC_ID,
                "emergency_address_confirmation.ucas_provider": self._context.ucas_provider,
                "emergency_address_confirmation.company.location.emergency_address.street": self._context.street,
                "emergency_address_confirmation.company.location.emergency_address.city": self._context.city,
                "emergency_address_confirmation.company.location.emergency_address.zip": self._context.postcode,
                "emergency_address_confirmation.company.location.emergency_address.country": self._context.country_code
            })
        return validation_set

    def tmfgateway_process_service_order(self):
        # this message is duplicating the payload as we send it almost 100%,
        # so we need to come up with some solution to validate it 1-1
        """
        Return validation set related to process tmf service order

        Returns:
            validation set dict representation
        """
        validation_set = {
            "header.eventType": "PROCESS_TMF_SERVICE_ORDER",
            "tmfServiceOrder.id": self._context.service_order_id,
            "tmfServiceOrder.state": "ACKNOWLEDGED",
            "tmfServiceOrder.category": self._context.category,
            "tmfServiceOrder.relatedParty.0.marketCode": self._context.payload["relatedParty"][0]["marketCode"],
            "tmfServiceOrder.externalReference.0.id": self._context.payload["externalReference"][0]["id"],
            "tmfServiceOrder.externalReference.1.id": payload.OPCO_OR
        }
        if 'unity_account' in self._context and hasattr(self._context, 'initial_license'):
            logging.info(f'{self._context.unity_account=}')
            unity_account = self._context.unity_account
            if unity_account.idp_entity_id:
                validation_set.update({
                    "tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.0.tenantConfig.idpEntityId": unity_account.idp_entity_id})
                return validation_set
            validation_set.update({
                "tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.0.tenantInfo.billingAccountNumber": unity_account.billing_account_number,
                "tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.0.tenantInfo.billingServiceReference": unity_account.billing_service_reference,
                "tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.0.tenantInfo.opportunityId": unity_account.opportunity_id,
                "tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.0.tenantInfo.podLocation": unity_account.pod_location

            })
        if hasattr(self._context, "state"):
            validation_set.update({
                "tmfServiceOrder.serviceOrderItem.0.service.place.0.stateOrProvince": self._context.state})

        # TODO: common key here is 'carrier_id' which is either for main number, pool or pool_range. it can be better
        if hasattr(self._context, "service_order_type"):
            if self._context.service_order_type == "add_tenant" and hasattr(self._context, "carrier_id"):
                validation_set.update({
                    "tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.0.tenantInfo.carrierId": self._context.carrier_id})

            elif self._context.service_order_type == "add_number" and self._context.number_type == "pool" and hasattr(
                    self._context,
                    "carrier_id"):
                validation_set.update({
                    "tmfServiceOrder.serviceOrderItem.0.service.supportingResource.0.resourceCharacteristic.0.uccTenantPool.carrierId": self._context.carrier_id})

            elif self._context.service_order_type == "add_number" and self._context.number_type == "pool_range" and hasattr(
                    self._context, "carrier_id"):
                validation_set.update({
                    "tmfServiceOrder.serviceOrderItem.0.service.supportingResource.0.resourceCharacteristic.0.uccTenantPoolRange.carrierId": self._context.carrier_id})

        if hasattr(self._context, 'index') and self._context.category == 'MSOC':
            get_last_index = str(self._context.index)
            if self._context.action == 'add':
                validation_set.update({
                    "tmfServiceOrder.serviceOrderItem." + get_last_index + ".service.supportingResource.0.resourceCharacteristic.0." + self._context.msoc_number_type + ".usageType": camel_converter.to_snake(
                        self._context.usage_type).upper(),
                    "tmfServiceOrder.serviceOrderItem." + get_last_index + ".service.supportingResource.0.resourceCharacteristic.0." + self._context.msoc_number_type + ".capability": camel_converter.to_snake(
                        self._context.capability).upper() + '_CAPABILITY',
                    "tmfServiceOrder.serviceOrderItem." + get_last_index + ".service.supportingResource.0.resourceCharacteristic.0." + self._context.msoc_number_type + ".emergencyAddressLocationId": self._context.emergency_address_location_id
                })
            validation_set.update({
                "tmfServiceOrder.serviceOrderItem." + get_last_index + ".service.supportingResource.0.resourceCharacteristic.0.name": self._context.name,
                "tmfServiceOrder.serviceOrderItem." + get_last_index + ".service.supportingResource.0.resourceCharacteristic.0.valueType": self._context.value_type,
                "tmfServiceOrder.category": self._context.category
            })
            if hasattr(self._context, "number_cac_id"):
                validation_set.update({f"tmfServiceOrder.serviceOrderItem.{self._context.index}"
                                       f".service.supportingResource.0.resourceCharacteristic.0.{self._context.msoc_number_type}.cacId": self._context.number_cac_id})
        if hasattr(self._context, "msoc_cac_configuration") and payload.has_msoc_cac_configuration(
                self._context.payload):
            cac_index, item = payload.get_item_by_type(self._context.payload, "ucc.msoc.cac-configuration")
            if payload.has_modify_msoc_cac_configuration(self._context.payload):
                validation_set.update({
                    f"tmfServiceOrder.serviceOrderItem.{cac_index}.service.serviceCharacteristic.0.msocCacConfiguration.burstMarginIn": self._context.burst_margin_in,
                    f"tmfServiceOrder.serviceOrderItem.{cac_index}.service.serviceCharacteristic.0.msocCacConfiguration.burstMarginOut": self._context.burst_margin_out,
                    f"tmfServiceOrder.serviceOrderItem.{cac_index}.service.serviceCharacteristic.0.msocCacConfiguration.burstMarginAll": self._context.burst_margin_all
                })
            validation_set.update({
                f"tmfServiceOrder.serviceOrderItem.{cac_index}.service.serviceCharacteristic.0.msocCacConfiguration.cacId": self._context.cac_id,
                f"tmfServiceOrder.serviceOrderItem.{cac_index}.service.serviceCharacteristic.0.msocCacConfiguration.marginIn": self._context.margin_in,
                f"tmfServiceOrder.serviceOrderItem.{cac_index}.service.serviceCharacteristic.0.msocCacConfiguration.marginOut": self._context.margin_out,
                f"tmfServiceOrder.serviceOrderItem.{cac_index}.service.serviceCharacteristic.0.msocCacConfiguration.marginAll": self._context.margin_all
            })
            logging.info(f'{validation_set}')

        if (hasattr(self._context, 'msoc_account') or hasattr(self._context, 'tpm_account')) and not hasattr(
                self._context,
                'pool_type') and hasattr(self._context, 'snow_onboarding'):
            number = 2 if hasattr(self._context, 'msoc_account') else 1
            contract_start_date = self._context.msoc_account.itsm_provisioning.contract_start_date if hasattr(
                self._context, 'msoc_account') else self._context.tpm_account.itsm_provisioning.contract_start_date
            contract_end_date = self._context.msoc_account.itsm_provisioning.contract_end_date if hasattr(self._context,
                                                                                                          'msoc_account') else self._context.tpm_account.itsm_provisioning.contract_end_date
            validation_set.update({
                f"tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.{number}.itsmProvisioning.contractEndDate": contract_end_date,
                f"tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.{number}.itsmProvisioning.contractStartDate": contract_start_date,
            })
            if hasattr(self._context,
                       'msoc_account') and self._context.msoc_account.itsm_provisioning.enable_provisioning:
                validation_set.update({
                    f"tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.{number}.itsmProvisioning.enableProvisioning": self._context.msoc_account.itsm_provisioning.enable_provisioning,
                    f"tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.{number}.itsmProvisioning.linkServiceToFullyOnboardedCustomer": self._context.msoc_account.itsm_provisioning.link_service_to_fully_onboarded_customer,
                })
            elif hasattr(self._context,
                         'tpm_account') and self._context.tpm_account.itsm_provisioning.enable_provisioning:
                validation_set.update({
                    f"tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.{number}.itsmProvisioning.enableProvisioning": self._context.tpm_account.itsm_provisioning.enable_provisioning
                })
                if self._context.market_code == "VFUK":
                    validation_set.update({
                        f"tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.{number}.itsmProvisioning.localMarketServiceId": self._context.tpm_account.itsm_provisioning.local_market_service_id
                    })
            logging.info('itsm validation completed')

        if "tpm_account" in self._context and payload.has_tpm_create_account(
                self._context.payload):
            tpm_service_characteristic_prefix = "tmfServiceOrder.serviceOrderItem.0.service.serviceCharacteristic.0"
            validation_set.update({
                f"{tpm_service_characteristic_prefix}.tpmCustomerInfo.name": self._context.tpm_account.name,
                f"{tpm_service_characteristic_prefix}.tpmCustomerInfo.tenantId": self._context.tpm_account.tenant_id,
            })
        if hasattr(self._context, "tpm_account") and payload.has_tpm_add_numbers(
                self._context.payload):
            tpm_number_index, item = payload.get_item_by_type(self._context.payload, "ucc.tpm.numbers")
            validation_set.update({
                f"tmfServiceOrder.serviceOrderItem.{tpm_number_index}.service.supportingResource.0.resourceCharacteristic.0.name": 'TpmPool'
            })
        if hasattr(self._context, 'unity_license'):
            license_index, item = payload.get_item_by_type(self._context.payload, "ucc.unity.license")
            validation_set.update({
                f"tmfServiceOrder.serviceOrderItem.{license_index}.service.serviceCharacteristic.0.quantity": self._context.unity_license.quantity,
                f"tmfServiceOrder.serviceOrderItem.{license_index}.service.supportingResource.0.id": self._context.unity_license.id})

        return validation_set

    def tmfmediator_command_create_initialorder(self):
        """
        Return validation set related to initial order requested

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.event_type": "INITIAL_ORDER_REQUESTED",
            "order.marketplace": "TMF",
            "order.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
            "order.company.name":
                self._context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["name"],
            "order.company.location.head_quarters_address.street": f"{payload.streetNr} {payload.streetName}",
            "order.company.location.head_quarters_address.city": self._context.city,
            "order.company.location.head_quarters_address.zip": self._context.postcode,
            "order.company.location.head_quarters_address.country": self._context.country_code,
            "order.primary_contact_details.first_name": payload.firstName,
            "order.primary_contact_details.last_name": payload.lastName,
            "order.primary_contact_details.email":
                self._context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["email"],
            "order.primary_contact_details.contact_phone":
                self._context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"][
                    "phoneNumber"],
            "order.order_details.quantity": 1,
            "order.order_details.sku_id": payload.sku_id,
            "order.order_details.package_id": payload.profile_package[self._context.product_type][
                self._context.currency],
            "order.op_co_details.name": self._context.payload["relatedParty"][0]["marketCode"],
            "order.op_co_details.op_co_customer_id": self._context.payload["externalReference"][0]["id"],
            "order.op_co_details.op_co_order_reference": payload.OPCO_OR,
            "order.op_co_details.iso_country_code": self._context.country_code,
            "order.tenant_flow_settings.send_welcome_email":
                self._context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][2]["value"][
                    "sendWelcomeEmail"],
            "order.tenant_flow_settings.send_confirmation_email":
                self._context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][2]["value"][
                    "sendConfirmationEmail"]
        }
        if 'unity_account' in self._context:
            unity_account = self._context.unity_account
            validation_set.update({
                "order.op_co_details.op_co_billing_account_number": unity_account.billing_account_number,
                "order.op_co_details.op_co_billing_service_reference": unity_account.billing_service_reference,
                "order.op_co_details.op_co_opportunity_id": unity_account.opportunity_id,
                "order.pod_location": unity_account.pod_location

            })
        else:
            validation_set.update({
                "order.op_co_details.op_co_billing_account_number": payload.OPCO_BAN,
                "order.op_co_details.op_co_billing_service_reference": payload.OPCO_BSR,
                "order.op_co_details.op_co_opportunity_id": payload.OPCO_OI,
            })
        if 'activate_immediately' in self._context.consumer_payload['order']['tenant_flow_settings']:
            validation_set.update({"order.tenant_flow_settings.activate_immediately": True})

        if hasattr(self._context, "state"):
            validation_set.update({
                "order.company.location.head_quarters_address.state": self._context.state})

        return validation_set

    def ringcentral_event_ssoconfig_updated(self, error_type: str = None):
        """
        Return validation set related to ssoconfig

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.eventType": "SET_SSO_CONFIG_CONFIRMATION",
            "ssoConfigConfirmation.clientReference.marketplace": "TMF",
            "ssoConfigConfirmation.clientReference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
            "ssoConfigConfirmation.ssoConfig.ssoEnabled": True,
            "ssoConfigConfirmation.ssoConfig.idpEntityId": self._context.idp_entity_id,
            "ssoConfigConfirmation.ssoConfig.enforceSsoLogin": True,
            # "ssoConfigConfirmation.ssoConfig.hideSsoDescriptionWelcomeEmail": True,
            # "ssoConfigConfirmation.ssoConfig.userSsoCredentialEnabled": True
        }
        if error_type in ("error_message", "modify_sso_system_error") :
            validation_set.update({"ssoConfigConfirmation.error.errorCode": "SERVICE_PROVIDER_ERROR",
                                   "ssoConfigConfirmation.error.errorMessage": f"CMN-201 Parameter {self._context.idp_entity_id} is in use"
                                   })
        elif error_type == "invalid_sso_id":
            validation_set.update({"ssoConfigConfirmation.error.errorCode": ErrorCodes.INVALID_IDP_ENTITY_ID,
                                   "ssoConfigConfirmation.error.errorMessage": RCErrorType.get_error_message(error_type)
                                   })
        else:
            validation_set.update({"ssoConfigConfirmation.success": True})
        return validation_set

    def ringcentral_event_accountserviceinfo_updated(self, error_type: str = None):
        """
            Return validation set related to extension length

            Returns:
                validation set dict representation
            """

        validation_set = {
            "header.eventType": "SET_ACCOUNT_SERVICE_INFO_CONFIRMATION",
            "setAccountServiceInfoConfirmation.clientReference.marketplace": "TMF",
            "setAccountServiceInfoConfirmation.clientReference.marketplace_event_id": f"{self._context.service_order_id}/{self._context.service_order_item_id}"
        }
        if error_type == "error_message":
            validation_set.update({"setAccountServiceInfoConfirmation.error.errorCode": "SERVICE_PROVIDER_ERROR",
                                   "setAccountServiceInfoConfirmation.error.errorMessage": f"CMN-101 Parameter {self._context.RC_ID} does not exist"
                                   })
        else:
            validation_set.update({"setAccountServiceInfoConfirmation.success": True,
                                   "setAccountServiceInfoConfirmation.limits.maxExtensionLimitLength": self._context.max_extension_length})
        return validation_set

    def ringcentral_event_initialorder_created(self, error_type: str = None):
        validation = {"header.event_type": "INITIAL_ORDER_COMPLETED",
                      "header.middleware_correlation_id": self._context.middleware_correlation_id,
                      "completed_order.marketplace": self._context.marketplace,
                      "completed_order.marketplace_event_id": self._context.marketplaceEventID,
                      }
        match error_type:
            case "invalid_contact_info":
                validation.update({"completed_order.error.error_code": ErrorCodes.INVALID_ACCOUNT_FIELD})
            case "invalid_primary_contact":
                validation.update({"completed_order.error.error_code": ErrorCodes.INVALID_PRIMARY_CONTACT_NUMBER,
                                   "completed_order.error.error_message": RCErrorType.get_error_message(error_type)})
            case "invalid_external_id" | "failed_create_account":
                validation.update({"completed_order.error.error_code": RCErrorType.RC_SYSTEM_ERROR_CODE,
                                   "completed_order.error.error_message": RCErrorType.get_error_message(error_type)})
            case None:
                validation.update({"completed_order.status": True})
            case _:
                raise NotImplementedError(f"Validation for {error_type} is not implemented")
        return validation

    def tmfmediator_create_addnumbers(self, item: Dict, number_type: str, category=None):
        """
        Return validation set related to tmfmediator_create_addnumbers
        Based on the initial service order item and context values

        Returns:
            validation set dict representation
            :param item: initial order item
            :param number_type: can be mainNumber, pool or pool_range
            :param category: UNITY/MSOC/TPM
            :return:
        """
        logging.info(f'{item=}')
        # TODO: make validation to work with item_id
        validation_set = {
            "header.eventType": "ADD_NUMBER_REQUESTED",
            "addNumbers.marketplace": "TMF",
            # "addNumbers.marketplaceEventId": f"{self._context.service_order_id}/{item['id']}",
            "addNumbers.opCoDetails.name": self._context.payload["relatedParty"][0]["marketCode"],
            "addNumbers.opCoDetails.opCoCustomerId": self._context.op_co_customer_id
        }
        pool_category = 'msocPool' if category == 'MSOC' else 'pool'

        if category == "MSOC":
            if 'msoc_account' in self._context:
                # validation for new generators case
                validation_set.update({'addNumbers.ucasProvider': self._context.msoc_account.category.upper(),
                                       f'addNumbers.{pool_category}.usageType': camel_converter.to_snake(
                                           self._context.requested_numbers.usage_type).upper(),
                                       f'addNumbers.{pool_category}.capability': camel_converter.to_snake(
                                           self._context.requested_numbers.capability).upper() + '_CAPABILITY',
                                       f'addNumbers.{pool_category}.emergencyAddressLocationId':
                                           self._context.requested_numbers.emergency_address_location_id})
            else:
                validation_set.update({'addNumbers.ucasProvider': self._context.category,
                                       f'addNumbers.{pool_category}.usageType': camel_converter.to_snake(
                                           self._context.usage_type).upper(),
                                       f'addNumbers.{pool_category}.capability': camel_converter.to_snake(
                                           self._context.capability).upper() + '_CAPABILITY',
                                       f'addNumbers.{pool_category}.emergencyAddressLocationId':
                                           self._context.emergency_address_location_id})
            if hasattr(self._context, 'carrier_id'):
                validation_set.update({'addNumbers.carrierId': str(self._context.carrier_id).replace("-", "_")})

        elif hasattr(self._context, "category") and self._context.category == "TPM":
            pool_category = 'tpmPool'
            validation_set.update({'addNumbers.ucasProvider': self._context.tpm_account.category.upper(),
                                   f'addNumbers.{pool_category}.poolType': self._context.tpm_numbers.pool_type})
        else:
            validation_set.update({'addNumbers.ucasProvider': "RINGCENTRAL"})

        if number_type == 'mainNumber':
            validation_set.update({
                'addNumbers.mainNumber': numbers.get_main_number(item)
            })
        elif numbers.is_pool(item):
            validation_set.update({
                f'addNumbers.{pool_category}.poolType': numbers.get_numbers_pooltype(item).upper(),
                f'addNumbers.{pool_category}.pool': numbers.get_pool(item)})

        elif numbers.is_range(item):
            pool_from_values = numbers.get_pool_range_from(item)
            pool_to_values = numbers.get_pool_range_to(item)
            pool_type = numbers.get_numbers_pooltype(item).upper()

            if not isinstance(pool_from_values, list):
                pool_from_values = [pool_from_values]
            if not isinstance(pool_to_values, list):
                pool_to_values = [pool_to_values]
            asserts.equals(len(pool_from_values), len(pool_to_values), "length of pool range (from & to) values")
            for i, (from_value, to_value) in enumerate(zip(pool_from_values, pool_to_values)):
                validation_set.update({
                    f'addNumbers.{pool_category}.poolType': pool_type,
                    f'addNumbers.{pool_category}.poolRange.{i}.from': from_value,
                    f'addNumbers.{pool_category}.poolRange.{i}.to': to_value
                })

        elif hasattr(self._context, 'number_cac_id'):
            validation_set.update({'addNumbers.msocPool.cacId': self._context.number_cac_id})

        else:
            raise Exception(
                f"Invalid number type {number_type=}, it must be one of ['mainNumber', 'pool', 'pool_range']")

        # if there is a carrier id passed, it should be present in the kafka message
        if hasattr(self._context, "service_order_type") and hasattr(self._context, "carrier_id"):
            if not self._context.service_order_type == "add_tenant":
                validation_set.update({"addNumbers.carrierId": self._context.carrier_id})

        return validation_set

    def tmfmediator_create_deletenumbers(self, item: Dict, category=None):
        """
        Return validation set to tmfmediator_create_deletenumbers

        Returns:
            validation set dict representation
            :param item: initial order item
            :param category: UNITY/MSOC/TPM
            :return:
        """
        pool_category = {
            'MSOC': 'msocPool',
            'TPM': 'tpmPool'
        }.get(category, 'pool')

        validation_set = {
            "header.eventType": "DELETE_NUMBER_REQUESTED",
            "deleteNumbers.marketplace": "TMF",
            "deleteNumbers.marketplaceEventId": f"{self._context.service_order_id}/{item['id']}",
            "deleteNumbers.opCoDetails.name": self._context.payload["relatedParty"][0]["marketCode"],
            "deleteNumbers.opCoDetails.opCoCustomerId": self._context.op_co_customer_id
        }
        if numbers.is_pool(item):
            validation_set.update({
                f'deleteNumbers.{pool_category}.poolType': numbers.get_numbers_pooltype(item).upper(),
                f'deleteNumbers.{pool_category}.pool': numbers.get_pool(item)
            })
        elif numbers.is_range(item):
            pool_from_values = numbers.get_pool_range_from(item)
            pool_to_values = numbers.get_pool_range_to(item)
            pool_type = numbers.get_numbers_pooltype(item).upper()

            if not isinstance(pool_from_values, list):
                pool_from_values = [pool_from_values]
            if not isinstance(pool_to_values, list):
                pool_to_values = [pool_to_values]
            if len(pool_from_values) == len(pool_to_values):
                for i, (from_value, to_value) in enumerate(zip(pool_from_values, pool_to_values)):
                    validation_set.update({
                        f'deleteNumbers.{pool_category}.poolType': pool_type,
                        f'deleteNumbers.{pool_category}.poolRange.{i}.from': from_value,
                        f'deleteNumbers.{pool_category}.poolRange.{i}.to': to_value
                    })
            else:
                raise NotImplementedError
        else:
            raise Exception(f"Could not find validation for this number type: {numbers.type_of_pool(item)}")
        logging.info(f'{validation_set}')
        return validation_set

    def tmf_mediator_create_jira_ticket(self, expected_item: Dict = None):
        """
        Return validation set related to tmf mediator create jira ticket

        Args:
            expected_item: Some elements to update validation_Set

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.eventType": "JIRA_TICKET_REQUESTED",
            "jiraTicketRequested.clientReference.marketplace": "TMF",
            "jiraTicketRequested.clientReference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
            "jiraTicketRequested.customFields.customfield_20900": self._context.service_order_id,
        }

        if expected_item:
            validation_set[
                "jiraTicketRequested.clientReference.marketplace_event_id"] = f"{self._context.service_order_id}/{expected_item['id']}"
            validation_set["jiraTicketRequested.customFields.customfield_20901"] = expected_item['id']

        return validation_set

    @staticmethod
    def jira_ticket_mediator_respond_jira_ticket():
        """
        Return validation set related to jira ticket created

        Returns:
            validation set dict representation
        """

        return {
            "header.eventType": "JIRA_TICKET_CREATED",
            "jiraTicketCreated.clientReference.marketplace": "TMF",
            "jiraTicketCreated.success": True
        }

    def ring_central_respond_change_license(self, test_type: str = None, error_type: str = None):
        """
        Return validation set related to ring central respond change license

        Args:
            test_type: Test type
            error_type: Error type

        Returns:
            validation set dict representation
        """

        if error_type:
            if error_type == "JWT_error_message":
                return {
                    "license_changed.request_successful": False,
                    "license_changed.error.error_code": "UCAS_PROVIDER_ERROR",
                    "license_changed.error.error_message": "JwtToken is not present in token from RingCentral API"
                }
            else:
                raise NotImplementedError(f"Validation for {error_type} is not implemented")

        if test_type:
            if test_type == "purchase_addon_information":
                return {
                    "header.middleware_correlation_id": self._context.middleware_correlation_id,
                    "license_changed.marketplace_event_id": self._context.marketplaceEventID,
                    "license_changed.sku_id": self._context.skuID,
                    "license_changed.request_successful": True
                }

            elif test_type == "validate_information":
                return {
                    "header.middleware_correlation_id": self._context.middleware_correlation_id,
                    "license_changed.marketplace_event_id": self._context.marketplaceEventID,
                    "license_changed.quantity_added": int(self._context.new_license) - int(
                        self._context.initial_license),
                    "license_changed.sku_id": self._context.skuID
                }

            else:
                raise NotImplementedError(f"Validation for {test_type} is not implemented")

        else:
            raise NotImplementedError(f"Validation for {test_type} is not implemented")

    def ring_central_respond_account_status(self, error_type: str = None):
        """
        Return validation set related to ring central respond account status

        Args:
            error_type: Error type

        Returns:
            validation set dict representation
        """

        if error_type == "JWT_error_message":
            return {
                "license_changed.request_successful": None,
                "license_changed.error.error_code": "SERVICE_PROVIDER_ERROR",
            }

        elif error_type == "error_message":
            return {
                "header.event_type": "ACCOUNT_STATUS_CHANGED",
                "account_status_changed.marketplace": self._context.marketplace,
                "account_status_changed.marketplace_event_id": self._context.marketplaceEventID,
                "account_status_changed.request_successful": None,
                "account_status_changed.error.error_code": "SERVICE_PROVIDER_ERROR"

            }

        else:
            raise NotImplementedError(f"Validation for {error_type} is not implemented")

    def ordermanagement_event_account_created(self):
        """
        Return validation set related to order management create account

        Returns:
            validation set dict representation
        """

        return {
            "header.event_type": "ACCOUNT_CREATED",
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "header.event_realm": "com.vodafone.ucc.middleware",
            "account.ucas_account_id": self._context.RC_ID,
            "account.ucas_provider": "RINGCENTRAL",
            "account.marketplace": self._context.marketplace,
            "account.marketplace_event_id": self._context.marketplaceEventID,
            "account.op_co_details.name": self._context.opco_details_name,
            "account.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "account.name": payload.companyName
        }

    def tmfmediator_command_set_ssoconfig(self):
        """
        Returns validation set related to tmfmediator sso config

        Returns:
            validation set dict representation
        """
        return {
            "header.eventType": "SET_SSO_CONFIG_REQUESTED",
            "ssoConfigRequest.ssoConfig.idpEntityId": self._context.idp_entity_id,
            "ssoConfigRequest.ucasAccountId": self._context.RC_ID,
            "ssoConfigRequest.ucasProvider": "RINGCENTRAL",
            "ssoConfigRequest.ssoConfig.ssoEnabled": True,
            "ssoConfigRequest.ssoConfig.enforceSsoLogin": True,
            "ssoConfigRequest.clientReference.marketplace_event_id": self._context.marketplaceEventID,
            "ssoConfigRequest.clientReference.marketplace": "TMF"
        }

    def tmfmediator_command_set_accountserviceinfo(self):
        """
        Returns validation set related to tmfmediator account service info

        Returns:
            validation set dict representation
        """
        return {
            "header.eventType": "SET_ACCOUNT_SERVICE_INFO_REQUESTED",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "header.eventRealm": "com.vodafone.ucc.middleware",
            "setAccountServiceInfoRequest.limits.maxExtensionLimitLength": self._context.max_extension_length,
            "setAccountServiceInfoRequest.ucasAccountId": self._context.RC_ID,
            "setAccountServiceInfoRequest.ucasProvider": "RINGCENTRAL",
            "setAccountServiceInfoRequest.clientReference.marketplace_event_id": self._context.marketplaceEventID,
            "setAccountServiceInfoRequest.clientReference.marketplace": "TMF"
        }

    def tmfmediator_command_delete_unitylicense(self):
        """
        Returns validation set related to tmfmediator unity licenses operations

        Returns:
            validation set dict representation
        """

        validation_set = {
            "header.event_type": "DELETE_LICENSE_REQUESTED",
            "license_request.client_reference.marketplace": "TMF",
            "license_request.ucas_account_id": self._context.RC_ID,
            "license_request.ucas_provider": "RINGCENTRAL",
            "license_request.order.sku_id": self._context.unity_license.id,
            "license_request.order.quantity": self._context.unity_license.quantity
        }
        logging.info(f'{validation_set=}')
        return validation_set

    def _crfstub_process_resourceorder_tpm(self, action, pool) -> dict:
        validation_set = {}
        if pool is not None:
            validation_set.update({
                "serviceOrderItem.0.service.serviceCharacteristic.0.name": "dep.numbers.mobile",
                "serviceOrderItem.0.service.serviceCharacteristic.0.value":
                    lambda value, name: asserts.equals(numbers.dep_ranges_to_e164_numbers(value), pool, name)
            })
        validation_set.update({
            "serviceOrderItem.0.action": action,
            "serviceOrderItem.0.service.name": "Microsoft Teams Phone Mobile",
            "serviceOrderItem.0.service.serviceType": "dep.tpm",
            "serviceOrderItem.0.service.relatedParty.0.@type": "dep.microsoft.tenant",
            "serviceOrderItem.0.service.relatedParty.0.marketCustomerId": self._context.op_co_customer_id,
            "serviceOrderItem.0.service.relatedParty.0.marketCode": countries_data_manager.get_dep_market_code(self._context.market_code),
            "serviceOrderItem.0.service.relatedParty.0.id": self._context.tpm_account.tenant_id
        })
        # Adding this condition as the country code is being wrongly sent as GB instead of UK only for this case.
        # We already have the mapping for the other markets like VFDE.
        if self._context.market_code == "VFUK":
            validation_set.update({"serviceOrderItem.0.service.relatedParty.0.marketCode": "UK"
                                   })
        return validation_set

    def crfstub_process_resourceorder(self, action, pool, account_category):
        """
        Return validation set related to crfstub_process_resourceorder

        Returns:
            validation set dict representation
        """
        assert self._context
        # Add DEP restrictions as warning for now. This could help if tests are failing,
        # so we know we should update our test data.
        if not re.search(r"^[A-Za-z0-9]{1,25}$", self._context.op_co_customer_id):
            logging.warning(
                f"{self._context.op_co_customer_id} is not valid customer ID for DEP TMF652 Resource Ordering API")

        validation = {}
        if pool:
            pool = sorted(pool)

        carrier_id = self._context.carrier_id if hasattr(self._context, "carrier_id") and self._context.carrier_id \
            else read_xmldata.readxml("carrier_id_default", "tmf_testdata", "tmf_data")

        if self._context.op_co_customer_id == account.LONG_NAME_ACCOUNT["account_number"]:
            company_name = account.LONG_NAME_ACCOUNT["company_name"]
        else:
            company_name = getattr(self._context, "customer_name", payload.companyName)

        if account_category == "MSOC":
            service_value = "MsTeamsOperatorConnect"
            partner_name = "Microsoft"
        elif account_category == "TPM":
            # CRF Gateway calls TMF641 API in case of TPM, therefore message schema is entirely different
            return self._crfstub_process_resourceorder_tpm(action, pool)
        else:
            service_value = "UNITY"
            partner_name = "RingCentral"
        dep_markets = ["DE", "ES", "IT", "PT", "UK", "MNC", "CZ", "IE", "AL", "GR", "RO"]

        validation.update({
            "orderItem.0.resource.resourceCharacteristic.0.@type": "Service",
            "orderItem.0.resource.resourceCharacteristic.0.name": "Service",
            "orderItem.0.resource.resourceCharacteristic.0.valueType": "string",
            "orderItem.0.resource.resourceCharacteristic.0.value": service_value,
            "orderItem.0.resource.relatedParty.0.@type": "Customer",
            "orderItem.0.resource.relatedParty.0.@referredType": "Customer",
            "orderItem.0.resource.relatedParty.0.name": company_name[:50],
            "orderItem.0.resource.relatedParty.0.id": self._context.op_co_customer_id,

            "orderItem.0.resource.relatedParty.1.@type": "Market",
            "orderItem.0.resource.relatedParty.1.@referredType": "Market",
            "orderItem.0.resource.relatedParty.1.externalPstnProvider": str(carrier_id).replace('_', '-'),
            "orderItem.0.resource.relatedParty.1.name": self._context.market_code,
            "orderItem.0.resource.relatedParty.1.id": lambda value, name: asserts.in_list(value, dep_markets,
                                                                                          name)
        })

        index_rc_numbers = 1
        if action == "delete":
            validation.update({"orderItem.0.resource.relatedParty.1.externalPstnProvider": None})

        elif action in ("add", "modify"):
            validation.update({
                "orderItem.0.resource.relatedParty.2.@type": "Partner",
                "orderItem.0.resource.relatedParty.2.@referredType": "Partner",
                "orderItem.0.resource.relatedParty.2.name": partner_name,
                "orderItem.0.resource.relatedParty.2.id": partner_name,
            })
            if account_category == "MSOC" and "bgid" in self._context:
                validation["orderItem.0.resource.relatedParty.0.trunkId"] = self._context.bgid
            if hasattr(self._context, "state"):
                validation["orderItem.0.resource.place.stateOrProvince"] = self._context.state

            if hasattr(self._context, "number_cac_id"):
                cac_index = 1
                index_rc_numbers = 2
                validation.update({
                    f"orderItem.0.resource.resourceCharacteristic.{cac_index}.name": "dep.config.cac",
                    f"orderItem.0.resource.resourceCharacteristic.{cac_index}.value.id": self._context.number_cac_id.upper(),
                })
                if hasattr(self._context, "cac_uplift"):
                    margin_in = self._context.margin_in + self._context.previous_margin_in
                    margin_out = self._context.margin_out + self._context.previous_margin_out
                    margin_all = self._context.margin_all + self._context.previous_margin_all
                else:
                    margin_in = self._context.margin_in
                    margin_out = self._context.margin_out
                    margin_all = self._context.margin_all

                if hasattr(self._context, "msoc_cac_configuration"):
                    validation.update({
                        f"orderItem.0.resource.resourceCharacteristic.{cac_index}.value.marginOut": margin_out,
                        f"orderItem.0.resource.resourceCharacteristic.{cac_index}.value.marginAll": margin_all,
                        f"orderItem.0.resource.resourceCharacteristic.{cac_index}.value.marginIn": margin_in
                    })
                    if payload.has_modify_msoc_cac_configuration(self._context.payload):
                        validation.update({
                            f"orderItem.0.resource.resourceCharacteristic.{cac_index}.value.burstMarginIn": self._context.burst_margin_in,
                            f"orderItem.0.resource.resourceCharacteristic.{cac_index}.value.burstMarginOut": self._context.burst_margin_out,
                            f"orderItem.0.resource.resourceCharacteristic.{cac_index}.value.burstMarginAll": self._context.burst_margin_all,
                        })

        else:
            raise NotImplementedError(f"{action=}")

        validation.update({
            # Only 1 Order Item is allowed
            "orderItem": lambda value, name: asserts.equals(len(value), 1, f"Number of items in {name}"),

            "orderItem.0.id": asserts.is_valid_uuid,
            "orderItem.0.action": action,
            "orderItem.0.resource.id": asserts.is_valid_uuid,
            "orderItem.0.resource.href": asserts.is_valid_uuid,

            "orderItem.0.resource.place.role": "Resource Location Value",

            f"orderItem.0.resource.resourceCharacteristic.{index_rc_numbers}.@type": "dep.numbers.geo",
            f"orderItem.0.resource.resourceCharacteristic.{index_rc_numbers}.name": "dep.numbers.geo",
            f"orderItem.0.resource.resourceCharacteristic.{index_rc_numbers}.valueType": "array",
            f"orderItem.0.resource.resourceCharacteristic.{index_rc_numbers}.value": \
                lambda value, name: asserts.equals(numbers.dep_ranges_to_e164_numbers(value), pool, name),
        })
        if action == 'modify':
            validation.update({f"orderItem.0.resource.resourceCharacteristic.{index_rc_numbers}.value": \
                                   lambda value, name: asserts.in_list(numbers.dep_ranges_to_e164_numbers(value)[0],
                                                                       pool,
                                                                       name)})
        if hasattr(self._context, "operation") and self._context.operation == "CEASE":
            validation.update({f"orderItem.0.resource.resourceCharacteristic.{index_rc_numbers}.value": \
                                   lambda value, name: asserts.is_subset(numbers.dep_ranges_to_e164_numbers(value),
                                                                         pool,
                                                                         name)})

        return validation

    def idmapper_event_msoccustomer_created(self, error_type: str = None):
        """
        Return validation set related to order completed

        Args:
            error_type: Error type

        Returns:
                validation set dict representation
        """

        validation_set = {
            "header.eventType": "ADD_MSOC_CUSTOMER_CONFIRMATION",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "msocCustomerRequest.clientReference.marketplace": "TMF",
            "msocCustomerRequest.clientReference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
            "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.market_code
        }
        if 'msoc_account' in self._context:
            validation_set = {
                "msocCustomerRequest.msocAccount.bgid": self._context.msoc_account.bgid,
                "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.msoc_account.op_co_customer_id,
                "msocCustomerRequest.msocAccount.name": self._context.msoc_account.name,
                "msocCustomerRequest.msocAccount.msTeamsTenantId": self._context.msoc_account.tenant_id,
                "msocCustomerRequest.msocAccount.hqAddress.street": self._context.msoc_account.place.hq_street_full,
                "msocCustomerRequest.msocAccount.hqAddress.city": self._context.msoc_account.place.city,
                "msocCustomerRequest.msocAccount.hqAddress.zip": self._context.msoc_account.place.postcode,
                "msocCustomerRequest.msocAccount.hqAddress.country": self._context.msoc_account.place.country_code,
                "msocCustomerRequest.msocAccount.consentCountries": self._context.msoc_account.consent_countries
            }
            if self._context.msoc_account.itsm_provisioning is not None:
                validation_set.update({
                    "msocCustomerRequest.msocAccount.itsmProvisioning.contractStartDate": self._context.msoc_account.itsm_provisioning.contract_start_date,
                    "msocCustomerRequest.msocAccount.itsmProvisioning.contractEndDate": self._context.msoc_account.itsm_provisioning.contract_end_date})
                if self._context.msoc_account.itsm_provisioning.enable_provisioning is not False:
                    validation_set.update({
                        "msocCustomerRequest.msocAccount.itsmProvisioning.enableProvisioning": self._context.msoc_account.itsm_provisioning.enable_provisioning})

        elif not error_type:
            validation_set = {
                "msocCustomerRequest.msocAccount.bgid": self._context.bgid,
                "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
                "msocCustomerRequest.msocAccount.name": self._context.customer_name,
                "msocCustomerRequest.msocAccount.msTeamsTenantId": self._context.ms_teams_tenant_id,
                "msocCustomerRequest.msocAccount.hqAddress.street": self._context.hq_street_full,
                "msocCustomerRequest.msocAccount.hqAddress.city": self._context.city,
                "msocCustomerRequest.msocAccount.hqAddress.zip": self._context.postcode,
                "msocCustomerRequest.msocAccount.hqAddress.country": self._context.country_code,
                "msocCustomerRequest.msocAccount.consentCountries": self._context.consent_countries
            }
        elif error_type == "duplicate_opco_customer_id":
            validation_set["msocCustomerRequest.error.errorCode"] = "INVALID_REQUEST"
            validation_set[
                "msocCustomerRequest.error.errorMessage"] = f"MSOC Customer with market [{self._context.market_code}] and Vodafone ID [{self._context.op_co_customer_id}] already exists"

        elif error_type == "duplicate_ms_teamns_tenant_id":
            validation_set["msocCustomerRequest.error.errorCode"] = ErrorCodes.TENANT_ID_ALREADY_IN_USE
            validation_set[
                "msocCustomerRequest.error.errorMessage"] = f"MSOC Customer with MS Teams Tenant ID [{self._context.ms_teams_tenant_id}] already exists in market [{self._context.market_code}]"

        elif error_type == "blank_consent_countries":
            validation_set["msocCustomerRequest.error.errorCode"] = "INVALID_MESSAGE"
            validation_set[
                "msocCustomerRequest.error.errorMessage"] = f"Validation of event has failed: [[msoc_account.consent_countries] is null or empty]"

        return validation_set

    def idmapper_event_account_deleted(self, error_type: str = None):
        """
        Return validation set related to account deleted

        Returns:
                validation set dict representation
        """

        validation_set = {
            "header.event_type": "ACCOUNT_DELETED_CONFIRMATION",
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "delete_account.client_reference.marketplace": "TMF",
            "delete_account.client_reference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
            "delete_account.op_co_details.name": self._context.market_code,
            "delete_account.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "delete_account.ucas_provider": self._context.ucas_provider

        }

        if error_type == "invalid_opco_customer_id":
            validation_set["delete_account.error.error_code"] = "ACCOUNT_NOT_FOUND"
            validation_set["delete_account.error.error_message"] = f"MSOC account does not exist for [{self._context.market_code}] customer [{self._context.op_co_customer_id}]"

        return validation_set

    def tmfmediator_command_create_msoccustomer(self, error_type: str = None):
        """
        Return validation set related to order completed

        Args:
            error_type: Error type

        Returns:
                validation set dict representation
        """
        # TODO: move header value to the kafka topic properties because as you can see, we have repetitive set here
        if 'msoc_account' not in self._context:
            validation_set = {
                "header.eventType": "CREATE_MSOC_CUSTOMER",
                "header.middlewareCorrelationId": self._context.middleware_correlation_id,
                "msocCustomerRequest.clientReference.marketplace": "TMF",
                "msocCustomerRequest.clientReference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
                "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.market_code,
                "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
                "msocCustomerRequest.msocAccount.name": self._context.customer_name,
                "msocCustomerRequest.msocAccount.msTeamsTenantId": self._context.ms_teams_tenant_id,
                "msocCustomerRequest.msocAccount.hqAddress.street": f"{payload.streetNr} {payload.streetName_2}",
                "msocCustomerRequest.msocAccount.hqAddress.city": self._context.city,
                "msocCustomerRequest.msocAccount.hqAddress.zip": self._context.postcode,
                "msocCustomerRequest.msocAccount.hqAddress.country": self._context.country_code,
                "msocCustomerRequest.msocAccount.consentCountries": self._context.consent_countries,
                "msocCustomerRequest.msocAccount.customerDomains": self._context.customer_domains,
                "msocCustomerRequest.msocAccount.contact.firstName": self._context.first_name,
                "msocCustomerRequest.msocAccount.contact.lastName": self._context.last_name,
                "msocCustomerRequest.msocAccount.contact.email": self._context.msoc_email
            }
        else:
            # use context.msoc_account instead
            validation_set = {
                "header.eventType": "CREATE_MSOC_CUSTOMER",
                # "header.middlewareCorrelationId": self._context.middleware_correlation_id,
                "msocCustomerRequest.clientReference.marketplace": "TMF",
                "msocCustomerRequest.clientReference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
                "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.msoc_account.market_code,
                "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.msoc_account.op_co_customer_id,
                "msocCustomerRequest.msocAccount.name": self._context.msoc_account.name,
                "msocCustomerRequest.msocAccount.msTeamsTenantId": self._context.msoc_account.tenant_id,
                "msocCustomerRequest.msocAccount.hqAddress.street": f"{self._context.msoc_account.place.street_nr} {self._context.msoc_account.place.street_name}",
                "msocCustomerRequest.msocAccount.hqAddress.city": self._context.msoc_account.place.city,
                "msocCustomerRequest.msocAccount.hqAddress.zip": self._context.msoc_account.place.postcode,
                "msocCustomerRequest.msocAccount.hqAddress.country": self._context.msoc_account.place.country_code,
                "msocCustomerRequest.msocAccount.consentCountries": self._context.msoc_account.consent_countries,
                "msocCustomerRequest.msocAccount.customerDomains": self._context.msoc_account.customer_domains,
                "msocCustomerRequest.msocAccount.contact.firstName": self._context.msoc_account.contact.first_name,
                "msocCustomerRequest.msocAccount.contact.lastName": self._context.msoc_account.contact.last_name,
                "msocCustomerRequest.msocAccount.contact.email": self._context.msoc_account.contact.email
            }
            if self._context.msoc_account.itsm_provisioning is not None:
                prefix = 'msocCustomerRequest.msocAccount.itsmProvisioning'
                validation_set.update({
                    f"{prefix}.enableProvisioning": self._context.msoc_account.itsm_provisioning.enable_provisioning,
                    f"{prefix}.contractStartDate": self._context.msoc_account.itsm_provisioning.contract_start_date,
                    f"{prefix}.contractEndDate": self._context.msoc_account.itsm_provisioning.contract_end_date,
                    f"{prefix}.linkServiceToFullyOnboardedCustomer": self._context.msoc_account.itsm_provisioning.link_service_to_fully_onboarded_customer
                })

        return validation_set

    def tmfmediator_command_add_msoccountrybilling(self, error_type):
        validation_set = {
            "header.eventType": "ADD_MSOC_COUNTRY_BILLING_REQUEST",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "msocCustomerRequest.clientReference.marketplace": "TMF",
            "msocCustomerRequest.clientReference.marketplace_event_id": f"{self._context.marketplace_event_id}",
            "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
        }
        if 'msoc_account' not in self._context or error_type == "different_billing_info":
            validation_set.update({
                "msocCustomerRequest.msocAccount.billingInformation.country": self._context.country_code,
                "msocCustomerRequest.msocAccount.billingInformation.customerReferenceNumber": self._context.customer_reference_number,
                "msocCustomerRequest.msocAccount.billingInformation.serviceIdentifier": self._context.service_identifier,
                "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.market_code
            })
        else:
            validation_set.update({
                "msocCustomerRequest.msocAccount.billingInformation.country": self._context.msoc_account.place.country_code,
                "msocCustomerRequest.msocAccount.billingInformation.customerReferenceNumber": self._context.msoc_account.billing_info.customer_reference_number,
                "msocCustomerRequest.msocAccount.billingInformation.serviceIdentifier": self._context.msoc_account.billing_info.service_identifier,
                "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.msoc_account.market_code
            })
        return validation_set

    def tmfmediator_command_delete_all_numbers(self):
        validation_set = {
            "header.event_type": "DELETE_ALL_NUMBERS_REQUESTED",
            "delete_all_numbers.client_reference.marketplace": "TMF",
            "delete_all_numbers.op_co_details.name": self._context.market_code,
            "delete_all_numbers.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "delete_all_numbers.ucas_provider": self._context.category
        }

        logging.info(f'{validation_set}')
        return validation_set

    def crfgateway_event_all_crf_numbers_deleted(self, error_type=None):
        """
         Return validation set related to crf confirmation

         Returns:
             validation set dict representation
         """

        validation_set = {
            "header.event_type": "ALL_NUMBERS_DELETED_CONFIRMATION",
            "delete_all_numbers.client_reference.marketplace": "TMF",
            "delete_all_numbers.op_co_details.name": self._context.market_code,
            "delete_all_numbers.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "delete_all_numbers.ucas_provider": self._context.ucas_provider
        }

        if error_type == "non_existing_account":
            validation_set.update({"delete_all_numbers.error.error_code": "ACCOUNT_NOT_FOUND"})
            validation_set.update(
                {"delete_all_numbers.error.error_message": "Customer has not been onboarded"})
        elif error_type == "failed_dep_response":
            validation_set.update({"delete_all_numbers.error.error_code": "INVALID_REQUEST"})
            validation_set.update(
                {
                    "delete_all_numbers.error.error_message": f"Error occurred while processing the {'TPM' if self._context.ucas_provider == 'TPM' else 'CRF'} request"})
        elif error_type == 'tpm_bad_request' or error_type == 'tpm_server_error':
            error_code = 'SERVICE_PROVIDER_ERROR'
            validation_set.update({"delete_all_numbers.error.error_code": error_code})
            validation_set.update(
                {"delete_all_numbers.error.error_message": errors.GLOBAL_ERROR})
        elif error_type == 'failed_dep_notification':
            validation_set.update({"delete_all_numbers.error.error_code": ErrorCodes.SERVICE_PROVIDER_ERROR,
                                   "delete_all_numbers.error.error_message": "No error information provided in DEP Service Order"})
        elif error_type is not None:
            validation_set.update({"delete_all_numbers.error.error_code": ErrorCodes.SERVICE_PROVIDER_ERROR})
            error_message = "One or more numbers could not be deleted in CRF" if error_type == "partial" else f"Failed to delete all numbers from {'TPM' if self._context.ucas_provider == 'TPM' else 'CRF'}"
            validation_set.update({"delete_all_numbers.error.error_message": error_message})
        else:
            validation_set.update({"delete_all_numbers.success": True})

        return validation_set

    def idmapper_event_msoccountrybilling_added(self, error_type: str = None):
        if error_type is None:
            validation_set = {
                "header.eventType": "ADD_MSOC_COUNTRY_BILLING_CONFIRMATION",
                "header.middlewareCorrelationId": self._context.middleware_correlation_id,
                "msocCustomerRequest.clientReference.marketplace_event_id": f"{self._context.marketplace_event_id}",
                "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.op_co_customer_id
            }
            if 'msoc_account' in self._context:
                validation_set.update({
                    "msocCustomerRequest.msocAccount.billingInformation.country": self._context.msoc_account.place.country_code,
                    "msocCustomerRequest.msocAccount.billingInformation.customerReferenceNumber": self._context.msoc_account.billing_info.customer_reference_number,
                    "msocCustomerRequest.msocAccount.billingInformation.serviceIdentifier": self._context.msoc_account.billing_info.service_identifier,
                    "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.msoc_account.market_code
                })
            else:
                validation_set.update(
                    {"msocCustomerRequest.msocAccount.billingInformation.country": self._context.country_code,
                     "msocCustomerRequest.msocAccount.billingInformation.customerReferenceNumber": self._context.customer_reference_number,
                     "msocCustomerRequest.msocAccount.billingInformation.serviceIdentifier": self._context.service_identifier,
                     "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.market_code})
        elif error_type.startswith('blank_'):
            blank_field = error_type.removeprefix("blank_")
            validation_set = {
                "msocCustomerRequest.error.errorCode": "INVALID_MESSAGE",
                "msocCustomerRequest.error.errorMessage": f"Validation of event has failed: [[billing_information.{blank_field}] is null or empty]",
                f"msocCustomerRequest.msocAccount.billingInformation.{camel_converter.to_camel(blank_field)}": False
            }
        elif error_type == "no_account":
            validation_set = {
                "msocCustomerRequest.error.errorCode": ErrorCodes.ACCOUNT_NOT_FOUND,
                "msocCustomerRequest.error.errorMessage": f"MSOC account does not exist for [{self._context.market_code}] customer [{self._context.op_co_customer_id}]"}
        elif error_type == "different_billing_info":
            validation_set = {
                "msocCustomerRequest.error.errorCode": ErrorCodes.COUNTRY_BILLING_ALREADY_EXISTS,
                "msocCustomerRequest.error.errorMessage": f"MSOC Customer already has Country Billing Information for [{self._context.country_code}]: Service Identifier [{self._context.existing_service_identifier}] Customer Reference Number [{self._context.existing_customer_reference_number}]"}
        else:
            raise NotImplementedError(f"{error_type=}")

        return validation_set

    def idmapper_event_msoccustomercac_added(self, error_type: str = None):
        validation_set = {"header.eventType": "ADD_CAC_TO_MSOC_CUSTOMER_CONFIRMATION"}
        if not error_type:
            validation_set.update({"msocCustomerRequest.msocAccount.opCoDetails.name": self._context.market_code,
                                   "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
                                   "msocCustomerRequest.msocAccount.cacId": self._context.cac_id.upper(),
                                   "msocCustomerRequest.success": True
                                   })
        else:
            error_type = error_type.replace(".", "_")
            error_message = data_files.read_config("id_mapper_errors.yml", f"ID_Mapper_error_messages.{error_type}")
            if hasattr(self._context, "existing_cac_id"):
                error_message = error_message.replace(".", self._context.existing_cac_id.upper())
            if error_type.endswith("non_existing"):
                validation_set.update({"msocCustomerRequest.error.errorCode": "ACCOUNT_NOT_FOUND",
                                       "msocCustomerRequest.error.errorMessage": error_message})
            elif error_type.endswith("blank") or error_type.endswith("with_dot"):
                validation_set.update({"msocCustomerRequest.error.errorCode": "INVALID_MESSAGE",
                                       "msocCustomerRequest.error.errorMessage": error_message})
            else:
                validation_set.update({"msocCustomerRequest.error.errorCode": ErrorCodes.CUSTOMER_CAC_LIMIT_EXCEEDED,
                                       "msocCustomerRequest.error.errorMessage": error_message})
        return validation_set

    def numbermanagement_command_add_numbers(self):
        # note that middleware_correlation_id might be a fresh one
        validation_set = {"header.event_type": "ADD_NUMBER_REQUESTED",
                          "phone_numbers.ucas_account_id": self._context.RC_ID,
                          }
        if hasattr(self._context, "ucc_mw_correlation_id"):
            validation_set.update({"header.middleware_correlation_id": self._context.ucc_mw_correlation_id})
        return validation_set

    def ringcentral_event_numbers_added(self):
        return {
            "header.event_type": "NUMBER_ADDED",
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "phone_numbers.ucas_account_id": self._context.RC_ID,
        }

    def numbermanagement_command_delete_numbers(self):
        return {"header.event_type": "DELETE_NUMBER_REQUESTED",
                "phone_numbers.ucas_account_id": self._context.RC_ID,
                }

    def ringcentral_event_numbers_deleted(self):
        return {"header.event_type": "NUMBER_DELETED",
                "phone_numbers.ucas_account_id": self._context.RC_ID,
                }

    def numbermanagement_command_update_numbers(self):
        return {
            "phone_numbers.ucas_account_id": self._context.RC_ID,
            "phone_numbers.phone_number_details.0.id": self._context.main_number_id
        }

    def ordermanagement_command_update_accountstatus(self):
        return {
            "header.event_type": "ACCOUNT_STATUS_CHANGE_REQUESTED",
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "header.event_realm": "com.vodafone.ucc.middleware",
            "account.ucas_account_id": self._context.RC_ID,
            "account.ucas_provider": "RINGCENTRAL",
            "account.marketplace": self._context.marketplace,
            "account.marketplace_event_id": self._context.marketplaceEventID,
            "account.name": payload.companyName,
            "account.tenant_flow_settings.activate_immediately":
                self._context.consumer_payload['account']['tenant_flow_settings']['activate_immediately'],
            "account.tenant_flow_settings.send_welcome_email":
                self._context.consumer_payload['account']['tenant_flow_settings']['send_welcome_email'],
            "account.tenant_flow_settings.send_confirmation_email":
                self._context.consumer_payload['account']['tenant_flow_settings']['send_confirmation_email']
        }

    def ordermanagement_command_create_initialorder(self):
        validation_set = {
            "header.event_type": "INITIAL_ORDER_REQUESTED",
            "order.marketplace": self._context.marketplace,
            "order.company.name": payload.companyName,
            "order.company.location.head_quarters_address.city": self._context.city,
            "order.company.location.head_quarters_address.zip": self._context.postcode,
            "order.company.location.head_quarters_address.country": self._context.country_code,
            "order.primary_contact_details.email": self._context.email,
            "order.primary_contact_details.first_name": payload.firstName,
            "order.primary_contact_details.last_name": payload.lastName,
            "order.primary_contact_details.contact_phone": self._context.mobile,
            "order.order_details.quantity": self._context.initial_license,
            "order.order_details.sku_id": payload.sku_id,
            "order.order_details.package_id": payload.profile_package[self._context.product_type][
                self._context.currency],
            "order.op_co_details.name": self._context.opco_details_name,
            "order.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "order.op_co_details.op_co_order_reference": payload.OPCO_OR,
            "order.op_co_details.iso_country_code": self._context.country_code,
        }
        if self._context.marketplace == "APPDIRECT":
            del validation_set["order.op_co_details.iso_country_code"]
        # context.mobile is empty when we do not provide admin number (TMF case, AD always provide)
        if self._context.mobile == "":
            del validation_set["order.primary_contact_details.contact_phone"]
        if 'unity_account' in self._context:
            unity_account = self._context.unity_account
            validation_set.update({
                "order.op_co_details.op_co_billing_account_number": unity_account.billing_account_number,
                "order.op_co_details.op_co_billing_service_reference": unity_account.billing_service_reference,
                "order.op_co_details.op_co_opportunity_id": unity_account.opportunity_id,
                "order.pod_location": unity_account.pod_location
            })
        else:
            validation_set.update({
                "order.op_co_details.op_co_billing_account_number": payload.OPCO_BAN,
                "order.op_co_details.op_co_billing_service_reference": payload.OPCO_BSR,
                "order.op_co_details.op_co_opportunity_id": payload.OPCO_OI,
            })
        if hasattr(self._context, "state"):
            validation_set.update({
                "order.company.location.head_quarters_address.state": self._context.state})

        return validation_set

    def tmfmediator_command_add_msoccustomercac(self):
        return {
            "header.eventType": "ADD_CAC_TO_MSOC_CUSTOMER_REQUEST",
            "msocCustomerRequest.msocAccount.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
            "msocCustomerRequest.msocAccount.opCoDetails.name": self._context.market_code,
            "msocCustomerRequest.msocAccount.cacId": self._context.cac_id,
        }

    def tmfmediator_command_apply_cacconfiguration(self):
        validation_set = {
            "header.eventType": "APPLY_CAC_CONFIGURATION_REQUEST",
            "cacConfigurationRequest.clientReference.marketplace_event_id": self._context.marketplace_event_id,
            "cacConfigurationRequest.clientReference.marketplace": "TMF",
            "cacConfigurationRequest.ucasProvider": "MSOC",
            "cacConfigurationRequest.action": str(self._context.action).upper(),
            "cacConfigurationRequest.opCoDetails.name": self._context.market_code,
            "cacConfigurationRequest.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
            "cacConfigurationRequest.cacId": self._context.cac_id,
            "cacConfigurationRequest.cacConfiguration.marginIn": self._context.margin_in,
            "cacConfigurationRequest.cacConfiguration.marginOut": self._context.margin_out,
            "cacConfigurationRequest.cacConfiguration.marginAll": self._context.margin_all
        }
        if payload.has_modify_msoc_cac_configuration(self._context.payload):
            validation_set.update(
                {
                    "cacConfigurationRequest.cacConfiguration.burstMarginIn": self._context.burst_margin_in,
                    "cacConfigurationRequest.cacConfiguration.burstMarginOut": self._context.burst_margin_out,
                    "cacConfigurationRequest.cacConfiguration.burstMarginAll": self._context.burst_margin_all
                }
            )
        return validation_set

    def crfgateway_event_cacconfiguration_applied(self, outcome, error_type):
        validation_set = {
            "header.eventType": "APPLY_CAC_CONFIGURATION_CONFIRMATION",
        }
        if error_type:
            if "non_existing" in error_type:
                error_code = ErrorCodes.ACCOUNT_NOT_FOUND
            elif "failed_to_process_cac_configuration" in error_type:
                error_code = ErrorCodes.SYSTEM_ERROR
            else:
                error_code = ErrorCodes.INVALID_MESSAGE

            error_type = error_type.replace("missing", "blank")
            error_message = data_files.read_config("crf_gateway_errors.yml",
                                                   f"CRF_gateway_error_messages.{error_type}")
            validation_set.update({"cacConfigurationRequest.error.errorCode": error_code,
                                   "cacConfigurationRequest.error.errorMessage": error_message})
        else:
            validation_set.update({"cacConfigurationRequest.cacId": self._context.cac_id,
                                   "cacConfigurationRequest.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
                                   "cacConfigurationRequest.ucasProvider": "MSOC",
                                   "cacConfigurationRequest.cacConfiguration.marginIn": self._context.margin_in,
                                   "cacConfigurationRequest.cacConfiguration.marginOut": self._context.margin_out,
                                   "cacConfigurationRequest.cacConfiguration.marginAll": self._context.margin_all
                                   })
            if payload.has_modify_msoc_cac_configuration(self._context.payload):
                validation_set.update({
                    "cacConfigurationRequest.cacConfiguration.burstMarginIn": self._context.burst_margin_in,
                    "cacConfigurationRequest.cacConfiguration.burstMarginOut": self._context.burst_margin_out,
                    "cacConfigurationRequest.cacConfiguration.burstMarginAll": self._context.burst_margin_all
                })
        if outcome == "WAITING":
            validation_set.update({"cacConfigurationRequest.cacRequestStatus": "CAC_PROVISIONING_PENDING"
                                   })
        elif outcome == "COMPLETED":
            validation_set.update({
                "cacConfigurationRequest.cacRequestStatus": "CAC_PROVISIONING_COMPLETE",
            })
        elif outcome and outcome.startswith("FAILED"):
            validation_set.update({
                "cacConfigurationRequest.cacRequestStatus": "CAC_PROVISIONING_ERROR",
            })
            if outcome.endswith(":UCAS_PROVIDER_ERROR"):
                validation_set.update({
                    "cacConfigurationRequest.error.errorCode": "SERVICE_PROVIDER_ERROR",
                    "cacConfigurationRequest.error.errorMessage": "The Resource Order to apply the CAC Configuration has not completed successfully",
                })
        elif outcome is not None:
            raise NotImplementedError(f"validation for {outcome=}")
        return validation_set

    def snowgateway_event_snowcustomer_created(self, error: SNOWError = None, account_provisioned=True):
        validation_set = {
            "snow_onboarding.client_reference.marketplace": "TMF",
            "snow_onboarding.ucas_provider": self._context.category,
            "snow_onboarding.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "snow_onboarding.success": True,
            "snow_onboarding.account_provisioned": account_provisioned
        }
        if error:
            validation_set.update({"snow_onboarding.success": False,
                                   "snow_onboarding.error.error_code": error.code,
                                   "snow_onboarding.error.error_message": error.reason})

        return validation_set

    def tmfmediator_command_create_snowcustomer(self):
        return {
            "snow_onboarding.client_reference.marketplace": "TMF",
            "snow_onboarding.ucas_provider": self._context.category,
            "snow_onboarding.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
        }

    def tmfgateway_update_serviceorder(self, item_id, state):
        return {
            "header.event_type": "TMF_SERVICE_ORDER_UPDATED",
            "service_order_update.service_order_item_id": item_id,
            "service_order_update.service_order_item_state": state
        }

    def tmfmediator_command_delete_account(self):
        validation_set = {
            "header.event_type": "DELETE_ACCOUNT_REQUESTED",
            "delete_account.client_reference.marketplace": "TMF",
            "delete_account.op_co_details.name": self._context.market_code,
            "delete_account.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "delete_account.ucas_provider": self._context.ucas_provider}
        return validation_set

    def tmfmediator_command_create_tpmcustomer(self):
        tpm_customer_prefix = "tpmCustomerRequest.tpmCustomer"
        validation_set = {
            "header.eventType": "CREATE_TPM_CUSTOMER",
            f"{tpm_customer_prefix}.name": self._context.tpm_account.name,
            f"{tpm_customer_prefix}.msTeamsTenantId": self._context.tpm_account.tenant_id,
            f"{tpm_customer_prefix}.opCoDetails.name": self._context.tpm_account.market_code,
            f"{tpm_customer_prefix}.opCoDetails.opCoCustomerId": self._context.tpm_account.op_co_customer_id,
            f"{tpm_customer_prefix}.opCoDetails.countryCode": self._context.tpm_account.related_party.country_code
        }
        if tpm.is_snow_onboarding(self._context):
            validation_set.update({
                f"{tpm_customer_prefix}.itsmProvisioning.enableProvisioning": self._context.tpm_account.itsm_provisioning.enable_provisioning,
                f"{tpm_customer_prefix}.itsmProvisioning.contractStartDate": self._context.tpm_account.itsm_provisioning.contract_start_date,
                f"{tpm_customer_prefix}.itsmProvisioning.contractEndDate": self._context.tpm_account.itsm_provisioning.contract_end_date,
                f"{tpm_customer_prefix}.itsmProvisioning.linkServiceToFullyOnboardedCustomer": self._context.tpm_account.itsm_provisioning.link_service_to_fully_onboarded_customer
            })
            if self._context.market_code == "VFUK":
                validation_set.update({
                    f"{tpm_customer_prefix}.itsmProvisioning.localMarketServiceId": self._context.tpm_account.itsm_provisioning.local_market_service_id})
            logging.info("SNOW Validation applied")
        return validation_set

    def tmfmediator_command_send_tpmnotification(self):
        validation_set = {
            "header.eventType": "TPM_SERVICE_NOTIFICATION",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "tpmCustomerRequest.clientReference.marketplace": "TMF",
            "tpmCustomerRequest.tpmCustomer.opCoDetails.name": self._context.tpm_account.market_code,
            "tpmCustomerRequest.tpmCustomer.opCoDetails.opCoCustomerId": self._context.tpm_account.op_co_customer_id
        }
        return validation_set

    def tmfmediator_command_set_emergencyaddress(self):
        validation_set = {
            "header.eventType": "SET_EMERGENCY_ADDRESS_REQUESTED",
            "emergencyAddressRequest.clientReference.marketplace": "TMF",
            "emergencyAddressRequest.clientReference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",

            "emergencyAddressRequest.ucasProvider": self._context.ucas_provider,
            "emergencyAddressRequest.ucasAccountId": self._context.RC_ID,

            "emergencyAddressRequest.company.location.emergencyAddress.street": f"{payload.streetNr} {payload.streetName}",
            "emergencyAddressRequest.company.location.emergencyAddress.city": self._context.city,
            "emergencyAddressRequest.company.location.emergencyAddress.zip": self._context.postcode,
            "emergencyAddressRequest.company.location.emergencyAddress.country": self._context.country_code
        }
        return validation_set

    def idmapper_event_tpmcustomer_created(self, error_type: str = None):
        if not error_type:
            validation_set = {
                "header.eventType": "ADD_TPM_CUSTOMER_CONFIRMATION",
                "header.middlewareCorrelationId": self._context.middleware_correlation_id,
                "tpmCustomerRequest.clientReference.marketplace": "TMF",
                "tpmCustomerRequest.clientReference.marketplace_event_id": self._context.marketplace_event_id,
                "tpmCustomerRequest.tpmCustomer.bgid": self._context.tpm_account.bgid,
                "tpmCustomerRequest.tpmCustomer.name": self._context.tpm_account.name,
                "tpmCustomerRequest.tpmCustomer.msTeamsTenantId": self._context.tpm_account.tenant_id,
                "tpmCustomerRequest.tpmCustomer.opCoDetails.name": self._context.tpm_account.market_code,
                "tpmCustomerRequest.tpmCustomer.opCoDetails.opCoCustomerId": self._context.tpm_account.op_co_customer_id,
                "tpmCustomerRequest.tpmCustomer.opCoDetails.countryCode": self._context.tpm_account.related_party.country_code,
                "tpmCustomerRequest.success": True
            }
            if tpm.is_snow_onboarding(self._context):
                validation_set.update({
                    "tpmCustomerRequest.tpmCustomer.itsmProvisioning.enableProvisioning":
                        self._context.tpm_account.itsm_provisioning.enable_provisioning,
                    "tpmCustomerRequest.tpmCustomer.itsmProvisioning.contractStartDate":
                        self._context.tpm_account.itsm_provisioning.contract_start_date,
                    "tpmCustomerRequest.tpmCustomer.itsmProvisioning.contractEndDate":
                        self._context.tpm_account.itsm_provisioning.contract_end_date,
                    "tpmCustomerRequest.tpmCustomer.itsmProvisioning.linkServiceToFullyOnboardedCustomer":
                        self._context.tpm_account.itsm_provisioning.link_service_to_fully_onboarded_customer
                })
                if self._context.market_code == "VFUK":
                    validation_set.update({
                        "tpmCustomerRequest.tpmCustomer.itsmProvisioning.localMarketServiceId":
                            self._context.tpm_account.itsm_provisioning.local_market_service_id
                    })

        elif error_type.endswith(("_blank", "_invalid")) or error_type in ["local_market_service_id_existing"]:
            if not error_type.startswith("local_market_service_id"):
                error_type = error_type.removesuffix("_blank").removesuffix("_invalid")
            error_message = data_files.read_config("id_mapper_errors.yml", f"ID_Mapper_error_messages.{error_type}")
            error_code = ErrorCodes.LOCAL_MARKET_SERVICE_ID_ALREADY_EXISTS if error_type == 'local_market_service_id_existing' else ErrorCodes.INVALID_MESSAGE
            validation_set = ({
                "tpmCustomerRequest.error.errorCode": error_code,
                "tpmCustomerRequest.error.errorMessage": error_message
            })
        elif error_type == "op_co_customer_id_existing":
            validation_set = ({"tpmCustomerRequest.error.errorCode": "ACCOUNT_ALREADY_EXISTS"})
        elif error_type == 'tenant_id_duplicate':
            validation_set = ({
                "tpmCustomerRequest.error.errorCode": "INVALID_REQUEST",
                "tpmCustomerRequest.error.errorMessage": f"TPM Customer with MS Teams Tenant ID [{self._context.tpm_account.tenant_id}] already exists in market [{self._context.tpm_account.market_code}]"
            })
        else:
            raise NotImplementedError(f"{error_type=} is not defined")

        return validation_set

    def idmapper_event_tpmnotification_sent(self, error=None, email_status='not_sent'):
        if error:
            if error.startswith("blank"):
                validation_set = {"tpmCustomerRequest.error.errorCode": "INVALID_MESSAGE"}
            else:
                validation_set = {"tpmCustomerRequest.error.errorCode": "ACCOUNT_NOT_FOUND"}
            return validation_set

        validation_set = {
            "header.eventType": "TPM_SERVICE_NOTIFICATION_CONFIRMATION",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "tpmCustomerRequest.clientReference.marketplace": "TMF",
            "tpmCustomerRequest.tpmCustomer.opCoDetails.name": self._context.tpm_account.market_code,
            "tpmCustomerRequest.tpmCustomer.opCoDetails.opCoCustomerId": self._context.tpm_account.op_co_customer_id,
            "tpmCustomerRequest.success": True
        }
        if email_status == "sent" and common.config.is_dev_env:
            validation_set.update({"tpmCustomerRequest.notificationSent": True})
        elif email_status == "not_sent":
            validation_set.update({"tpmCustomerRequest.notificationSent": None})
        return validation_set

    def snowgateway_event_snowcustomer_deleted(self, deprovisioned=False):
        if deprovisioned == "system_error":
            validation_set = {"snowOffboarding.error.errorCode": "SERVICE_PROVIDER_ERROR",
                              "snowOffboarding.success": None,
                              "snowOffboarding.accountDeprovisioned": None
                              }
            return validation_set
        elif deprovisioned == "error":
            validation_set = {"snowOffboarding.error.errorCode": "INVALID_MESSAGE"}
            return validation_set

        validation_set = {
            "header.eventType": "SNOW_OFFBOARDING_CONFIRMATION",
            "header.middlewareCorrelationId": self._context.middleware_correlation_id,
            "snowOffboarding.clientReference.marketplace": "TMF",
            "snowOffboarding.opCoDetails.name": self._context.market_code,
            "snowOffboarding.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
            "snowOffboarding.ucasProvider": self._context.ucas_provider,
            "snowOffboarding.success": True
        }
        if deprovisioned:
            validation_set.update({"snowOffboarding.accountDeprovisioned": True})
        elif not deprovisioned:
            validation_set.update({"snowOffboarding.accountDeprovisioned": None})
        return validation_set

    def tmfmediator_command_delete_snowcustomer(self):
        validation_set = {
            "header.eventType": "SNOW_OFFBOARDING_REQUEST",
            "snowOffboarding.clientReference.marketplace": "TMF",
            "snowOffboarding.opCoDetails.name": self._context.market_code,
            "snowOffboarding.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
            "snowOffboarding.ucasProvider": self._context.ucas_provider
        }
        return validation_set

    def tmfmediator_command_set_extension(self):
        extension_path = "$.serviceOrderItem[*].service.serviceCharacteristic[?(@.name=='TenantAdminInfo')].value.extension"
        extension_number = common.get_field(self._context.payload, extension_path)
        validation_set = {
            "header.eventType": "SET_EXTENSION_REQUESTED",
            "extensionRequest.opCoDetails.name": self._context.market_code,
            "extensionRequest.opCoDetails.opCoCustomerId": self._context.op_co_customer_id,
            "extensionRequest.extensionNumber": extension_number
        }
        return validation_set

    def ringcentral_event_extension_set(self, error_type: str = None):
        extension_number = payload.get_extension_number_from_service_order(self._context.payload)
        validation_set = {
            "header.event_type": "SET_EXTENSION_CONFIRMATION",
            "extension_confirmation.op_co_details.name": self._context.market_code,
            "extension_confirmation.op_co_details.op_co_customer_id": self._context.op_co_customer_id,
            "extension_confirmation.extension_number": extension_number,
            "extension_confirmation.ucas_provider": self._context.ucas_provider,
            "extension_confirmation.success": True
        }
        if error_type:
            validation_set.update({"extension_confirmation.success": False})
            validation_set.update({
                "extension_confirmation.error.error_code": SetExtensionErrorCodes.error_code(error_type),
                "extension_confirmation.error.error_message": SetExtensionErrorCodes.error_message(error_type)
            })
        return validation_set

    def ringcentral_event_unitylicense_deleted(self, error_type: str = None):
        """
                Return validation set related to ring central delete unity license

                Args:
                    error_type: Error type

                Returns:
                    validation set dict representation
                """
        error_code_path = "license_confirmation.error.error_code"
        error_msg_path = "license_confirmation.error.error_message"
        validation_set = {
            "header.event_type": "LICENSE_DELETED",
            "license_confirmation.client_reference.marketplace": "TMF",
            "license_confirmation.ucas_account_id": self._context.RC_ID,
            "license_confirmation.ucas_provider": "RINGCENTRAL",
            "license_confirmation.order.sku_id": self._context.unity_license.id,
            "license_confirmation.order.quantity": self._context.unity_license.quantity
        }
        if hasattr(self._context, 'system_error'):
            error_message = RCErrorType.get_error_message(self._context.system_error)
            # For Bad_Request and Server_Error scenarios:
            validation_set.update({
                error_code_path: RCErrorType.RC_SYSTEM_ERROR_CODE,
                error_msg_path: error_message
            })
            logging.info(f'{validation_set=}')
            return validation_set
        else:
            error_dict = {
                "invalid_sku_id": {
                    error_code_path: ErrorCodes.INVALID_LICENSE_SKU_ID,
                    error_msg_path: f"The license SKU ID is not valid: {self._context.unity_license.id}"
                },
                "insufficient_licenses_to_delete": {
                    error_code_path: ErrorCodes.INSUFFICIENT_LICENSES,
                    error_msg_path: f"Insufficient {self._context.unity_license.id} licenses to delete {self._context.unity_license.quantity}"
                }
            }
        if error_type in error_dict:
            validation_set.update(error_dict[error_type])
        else:
            validation_set.update({
                "license_confirmation.success": True,
                "license_confirmation.licenses_added": -int(self._context.unity_license.quantity)
            })
        logging.info(f'{validation_set=}')
        return validation_set

    def tmfmediator_command_add_unitylicense(self):
        """
        Return validation set for add unity license

        Returns:
            validation set dict representation
        """
        validation_set = {
            "header.event_type": "ADD_LICENSE_REQUESTED",
            "license_request.client_reference.marketplace": "TMF",
            "license_request.ucas_account_id": self._context.RC_ID,
            "license_request.ucas_provider": "RINGCENTRAL",
            "license_request.order.sku_id": self._context.unity_license.id,
            "license_request.order.quantity": int(self._context.unity_license.quantity)
        }
        logging.info(f'{validation_set=}')
        return validation_set

    def tmfmediator_command_change_unitylicense(self):
        """
            Return validation set for modify unity license

            Returns:
                validation set dict representation
        """
        validation_set = {
            "header.event_type": "CHANGE_LICENSE_REQUESTED",
            "license_request.client_reference.marketplace": "TMF",
            "license_request.ucas_account_id": self._context.RC_ID,
            "license_request.ucas_provider": self._context.ucas_provider,
            "license_request.order.sku_id": self._context.unity_license.id
        }
        if self._context.unity_license.quantity != '0':
            validation_set.update({"license_request.order.quantity": self._context.unity_license.quantity})

        logging.info(f'{validation_set=}')
        return validation_set

    def ringcentral_event_unitylicense_added(self, error: str = None):
        """
                Return validation set related to ring central add unity license

                Args:
                    error: Error type

                Returns:
                    validation set dict representation
                """
        error_code_path = "license_confirmation.error.error_code"
        error_msg_path = "license_confirmation.error.error_message"
        validation_set = {
            "header.event_type": "LICENSE_ADDED",
            "license_confirmation.client_reference.marketplace": "TMF",
            "license_confirmation.ucas_account_id": self._context.RC_ID,
            "license_confirmation.ucas_provider": "RINGCENTRAL",
            "license_confirmation.order.sku_id": self._context.unity_license.id,
            "license_confirmation.order.quantity": int(self._context.unity_license.quantity)
        }
        match error:
            case "invalid_sku_id":
                validation_set.update({error_code_path: ErrorCodes.INVALID_LICENSE_SKU_ID,
                                       error_msg_path: RCErrorType.get_error_message(
                                           error).replace("*", self._context.unity_license.id)})
            case "add_license_bad_request" | "add_license_server_error":
                validation_set.update({error_code_path: RCErrorType.RC_SYSTEM_ERROR_CODE,
                                       error_msg_path: RCErrorType.get_error_message(
                                           error)})
            case "max_license_limit":
                validation_set.update({error_code_path: ErrorCodes.LICENSE_ORDER_EXCEEDS_LIMIT,
                                       error_msg_path: RCErrorType.get_error_message(
                                           error)})
            case None:
                validation_set.update({"license_confirmation.success": True,
                                       "license_confirmation.licenses_added": int(
                                           self._context.unity_license.quantity)})
            case "blank_sku_id":
                validation_set.update({error_code_path: RCErrorType.RC_INVALID_MESSAGE_CODE,
                                       error_msg_path: RCErrorType.get_error_message(
                                           error)})
                del validation_set["license_confirmation.order.sku_id"]
            case "zero_quantity":
                validation_set.update({error_code_path: RCErrorType.RC_INVALID_MESSAGE_CODE,
                                       error_msg_path: RCErrorType.get_error_message(
                                           error)})
                del validation_set["license_confirmation.order.quantity"]
            case _:
                raise NotImplementedError(f"{error} is not implemented")

        logging.info(f'{validation_set=}')
        return validation_set

    def ringcentral_event_unitylicense_changed(self, error: str = None):
        """
            Return validation set related to ring central modify unity license

            Args:
                error: Error type

            Returns:
                validation set dict representation
            """
        # the following variable describes the quantity of licenses that are preconfigured in the stub for the accounts
        stub_preconfigured_license_count: int = 5
        error_code_path = "license_confirmation.error.error_code"
        error_msg_path = "license_confirmation.error.error_message"

        validation_set = {
            "header.event_type": "LICENSE_CHANGED",
            "license_confirmation.client_reference.marketplace": "TMF",
            "license_confirmation.ucas_account_id": self._context.RC_ID,
            "license_confirmation.ucas_provider": "RINGCENTRAL",
            "license_confirmation.order.sku_id": self._context.unity_license.id,
        }
        if self._context.unity_license.quantity != '0':
            validation_set.update({"license_confirmation.order.quantity": self._context.unity_license.quantity})

        match error:
            case "invalid_sku_id":
                validation_set.update({error_code_path: ErrorCodes.INVALID_LICENSE_SKU_ID,
                                       error_msg_path: RCErrorType.get_error_message(
                                           error).replace("*", self._context.unity_license.id)})
            case "max_license_limit":
                validation_set.update({error_code_path: ErrorCodes.LICENSE_ORDER_EXCEEDS_LIMIT,
                                       error_msg_path: RCErrorType.get_error_message(error)})
            case "Bad_Request":
                validation_set.update({error_code_path: RCErrorType.RC_SYSTEM_ERROR_CODE,
                                       error_msg_path: RCErrorType.get_error_message(self._context.error_type)})
            case "Server_Error":
                validation_set.update({error_code_path: RCErrorType.RC_SYSTEM_ERROR_CODE,
                                       error_msg_path: RCErrorType.get_error_message(self._context.error_type)})
            case None:
                validation_set.update({"license_confirmation.success": True})
                if int(self._context.unity_license.quantity) != stub_preconfigured_license_count:
                    # checking if the SKU id used for licenses is one of the preconfigured ones in the stub
                    if self._context.unity_license.id != license.get_default_sku_id():
                        validation_set.update({
                            "license_confirmation.licenses_added": int(
                                self._context.unity_license.quantity)})
                    else:
                        validation_set.update({
                            "license_confirmation.licenses_added": int(
                                self._context.unity_license.quantity) - int(
                                stub_preconfigured_license_count)})
            case _:
                raise NotImplementedError(f"{error} is not implemented")

        logging.info(f'{validation_set=}')
        return validation_set

    def tmfmediator_command_set_policy_access(self):
        validation_set = {
            "header.event_type": "SET_POLICY_ACCESS_REQUESTED",
            "policy_access_request.client_reference.marketplace": "TMF",
            "policy_access_request.ucas_provider": "RINGCENTRAL",
            "policy_access_request.enabled": True,
            "policy_access_request.geo_locations": None,
            "policy_access_request.ips": None,
            "policy_access_request.default_policy_action": None
        }
        if self._context.unity_account.policies.geo_locations is not None:
            validation_set.update({
                "policy_access_request.geo_locations": self._context.unity_account.policies.geo_locations})
        if self._context.unity_account.policies.ips is not None:
            validation_set.update({
                "policy_access_request.ips": self._context.unity_account.policies.ips})
        if self._context.unity_account.policies.defaultPolicyAction is not None:
            validation_set.update({
                "policy_access_request.default_policy_action": self._context.unity_account.policies.defaultPolicyAction})
        logging.info(f'{validation_set=}')
        return validation_set

    def ringcentral_event_policy_access_set(self, error_type: str = None):
        validation_set = {
            "header.event_type": "SET_POLICY_ACCESS_CONFIRMATION",
            "policy_access_confirmation.client_reference.marketplace": "TMF",
            "header.middleware_correlation_id": self._context.middleware_correlation_id,
            "policy_access_confirmation.client_reference.operation_id": self._context.operation_id,
            "policy_access_confirmation.client_reference.marketplace_event_id": f"{self._context.service_order_id}/{payload.service_order_item_id}",
            "policy_access_confirmation.ucas_provider": "RINGCENTRAL",
            "policy_access_confirmation.op_co_details.name": self._context.market_code,
            "policy_access_confirmation.op_co_details.op_co_customer_id": self._context.unity_account.op_co_customer_id,
            "policy_access_confirmation.success": True,
            "policy_access_confirmation.enabled": True
        }

        if self._context.unity_account.policies.geo_locations is not None:
            validation_set.update({
                "policy_access_confirmation.geo_locations": self._context.unity_account.policies.geo_locations})

        if self._context.unity_account.policies.ips is not None:
            validation_set.update({
                "policy_access_confirmation.ips": self._context.unity_account.policies.ips})

        if error_type is not None:
            validation_set.update({
                "policy_access_confirmation.error.error_code": ErrorCodes.SERVICE_PROVIDER_ERROR,
                "policy_access_confirmation.success": False})

            error_message = RCErrorType.get_error_message(error_type=error_type)

            validation_set.update({
                "policy_access_confirmation.error.error_message": error_message})
        logging.info(f'{validation_set=}')

        return validation_set


class KafkaMessageValidationSetException(Exception):

    def __init__(self, message: str):
        super().__init__(message)


class InvalidErrorTypeException(KafkaMessageValidationSetException):

    def __init__(self, error_type: str):
        super().__init__(f"Invalid error_type {error_type}")
