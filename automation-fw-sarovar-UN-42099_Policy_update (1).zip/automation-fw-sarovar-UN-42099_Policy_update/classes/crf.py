import datetime
import json
import logging
import os
from http import HTTPStatus

from classes import asserts, common, database, numbers, polling, read_xmldata, utils
from classes.api.requests import number_management_api
from classes.kafka import consumer_data
from classes.kafka.topics import KafkaTopics
from common_python import api_requests

logger = logging.getLogger(__name__)

SLA = os.getenv('UCC_CRF_GATEWAY_REQUEST_STATUS_CALLBACK_SLAINSECONDS')
SLO = os.getenv('UCC_CRF_GATEWAY_REQUEST_STATUS_CALLBACK_SLOINSECONDS')
FREQUENCY = utils.cron_to_frequency(os.getenv('UCC_CRF_GATEWAY_REQUEST_STATUS_CALLBACK_CRONEXPRESSION'))

if common.config.is_dev_env:
    TMF652_NOTIFICATION_URL = "http://crf-gateway/crf-gateway/v1/notifications"
    TMF641_NOTIFICATION_URL = "http://crf-gateway/crf-gateway/v1/tmf641/notifications"
    CALLBACK_ERROR_TO_DXL = 'Resource order {} has breached SLA'
    TMF641_CALLBACK_ERROR_TO_DXL = 'Service order {} has breached SLA'


def get_pool_from_crf_confirmation(consumer_payload):
    if isinstance(consumer_payload, 'list'):
        consumer_payload = consumer_payload[-1]
    pool_list = consumer_payload['crf_confirmation']['pool']
    pool = []
    for num_dict in pool_list:
        for k in num_dict:
            pool.append(num_dict[k])
    logger.info(f'pool from message: {pool}')
    return pool


def generate_testdata_for_crf_notification(crf_stub_payload, state, notes=None):
    notification_payload = read_xmldata.read_jsonfile("create_crf_notification")
    notification_payload["event"]["resourceOrder"] = crf_stub_payload
    notification_payload["event"]["resourceOrder"]["state"] = state
    notification_payload["event"]["resourceOrder"]["completionDate"] = read_xmldata.get_current_datetime()
    notification_payload["event"]["resourceOrder"].update(
        {"orderItemIds": [str(len(notification_payload["event"]["resourceOrder"]))]})
    if "requestedStartDate" in notification_payload["event"]["resourceOrder"]:
        del notification_payload["event"]["resourceOrder"]["requestedStartDate"]
    if notes:
        notification_payload["event"]["resourceOrder"]["note"] = notes
    return notification_payload


def wait_for_crf_document(middleware_correlation_id: str, required_field="crfOrderInfo", timeout=60) -> dict:
    document = polling.wait_until(
        lambda: database.get_crf_document(middleware_correlation_id),
        'CRF order document',
        timeout=timeout,
        stop_when=lambda doc: doc and required_field in doc)
    return document


def get_all_crf_docs(middleware_correlation_id):
    documents = polling.wait_until(
        lambda: database.get_all_crf_documents(middleware_correlation_id),
        'CRF order document',
        stop_when=lambda docs: docs and all('crfOrderInfo' in d for d in docs))
    return documents


def generate_testdata_for_dep_notification(crf_stub_payload, state, note=None):
    notification_payload = read_xmldata.read_jsonfile("dep_tmf641_notification")
    notification_payload["event"]["serviceOrder"] = crf_stub_payload
    notification_payload["eventId"] = read_xmldata.gen_uuid()
    notification_payload["correlationId"] = read_xmldata.gen_uuid()
    notification_payload["eventTime"] = read_xmldata.get_current_datetime()
    notification_payload["event"]["serviceOrder"]["state"] = state
    if note:
        notification_payload["event"]["serviceOrder"]["serviceOrderItem"][0]["errorMessage"] = note
    return notification_payload


def send_notification(state, crf_stub_payload, expected_response=201, notification_type='tmf652', notes=None):
    if notification_type == 'tmf641':
        notification_payload = generate_testdata_for_dep_notification(crf_stub_payload, state, notes)
        notification_url = TMF641_NOTIFICATION_URL
    else:
        notification_payload = generate_testdata_for_crf_notification(crf_stub_payload, state, notes)
        notification_url = TMF652_NOTIFICATION_URL

    logger.info(f'Sending notification for CRF: ')
    logger.info(json.dumps(notification_payload, indent=3))

    response = api_requests.post(
        notification_url, json=notification_payload,
        token=api_requests.AuthType.VALID)
    asserts.equals(response.status_code, expected_response, "CRF notification response code")
    logger.info(f"Notification for resource order {crf_stub_payload['id']} is sent")


def get_resource_order_id(middleware_correlation_id):
    document = wait_for_crf_document(middleware_correlation_id)
    logger.info(f'crf_request document: {database.parse_json(document)}')
    assert 'crfOrderInfo' in document, "CRF order was not saved in DB"
    assert 'order' in document['crfOrderInfo'], f"CRF order was not assigned an id, {document['crfOrderInfo']=}"
    try:
        return document['crfOrderInfo']['order']['_id']
    except KeyError:
        logger.error(f"{document['crfOrderInfo']=}")
        raise Exception('CRF order has no ID') from None


def initiate_resource_order(context):
    pool = numbers.generate_pool(3, 'VFUK')
    payload = {'pool': pool}
    response = number_management_api.Client().add_numbers(context.market_code, context.op_co_customer_id, payload)
    asserts.equals(response.status_code, HTTPStatus.ACCEPTED, "Response from Number Management Add numbers")
    context.scenario_start_time = datetime.datetime.now()

    # getting middleware_correlation_id
    context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.numbermanagement_command_add_numbers.name)
    common.update_middleware_correlation_id(context)
    # making sure it passed the crf step
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.numbermanagement_command_add_crfnumber.name)

    # getting the crf resource id
    context.crf_request_id = get_resource_order_id(context.middleware_correlation_id)


def get_non_terminal_crf_requests():
    db_filter = {"crfOrderInfo.order.state": {"$nin": ["COMPLETED", "FAILED", "PARTIAL"]},
                 "crfOrderInfo.order": {"$exists": True},
                 "crfOrderInfo.slaBreachNotificationTimestamp": {"$exists": False}
                 }
    with database.open_database('crf-gateway', 'crf_requests') as db:
        count = db.collection.count_documents(db_filter)
        documents = db.collection.find(db_filter)
        logger.info(f'not terminated resource order {count=}')
        return count, documents


def get_crf_doc_with_action(middleware_correlation_id, action):
    get_all_documents = get_all_crf_docs(middleware_correlation_id)
    logger.info(f'{get_all_documents=}')
    for item in get_all_documents:
        if len(get_all_documents) > 1 and str(action).upper() in item['eventType']:
            return item['crfOrderInfo']['order']['_id']
    return get_all_documents[0]['crfOrderInfo']['order']['_id']


def get_cac_info_properties():
    return ['marginIn',
            'marginOut',
            'marginAll',
            'burstMarginIn',
            'burstMarginOut',
            'burstMarginAll',
            'enabled']


def validate_number_details(number_details_response, expected_number, has_cac_info):
    asserts.equals(number_details_response["number"], expected_number, "main number")
    if has_cac_info:
        logger.info("validating that the response has cac info")
        assert "cacInfo" in number_details_response
        cac_info_actual_properties = list(number_details_response["cacInfo"].keys())
        cac_info_expected_properties = get_cac_info_properties()
        for key in cac_info_expected_properties:
            asserts.in_list(key, cac_info_actual_properties, key)
    else:
        logger.info("validating that the response has cac info with fields as 0")
        cac_info = number_details_response["cacInfo"]
        for key, value in cac_info.items():
            asserts.equals(value, 0, f"{key} in cacInfo")


def validate_crf_request_failed_db(middleware_correlation_id: str, error_message: str = None, http_status: str = None):
    crf_document = wait_for_crf_document(middleware_correlation_id, "isCrfRequestSuccessful")
    logger.info(f"{crf_document=}")
    asserts.equals(crf_document["isCrfRequestSuccessful"], False, "isCrfRequestSuccessful")
    if error_message:
        asserts.equals(crf_document["errorMessage"], error_message, "errorMessage")
    if "crfOrderInfo" in crf_document and http_status:
        asserts.equals(crf_document["crfOrderInfo"]["httpStatus"], http_status, "crfOrderInfo.httpStatus")
