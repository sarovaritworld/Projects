import logging

from classes import asserts, database
from classes.api.requests import idmapper

logger = logging.getLogger(__name__)


def get_existing_tpm_account(market="VFDE"):
    return database.get_tpm_account_document({"market": market})


def get_tpm_customer(op_co_customer_id, market_code):
    response = idmapper.Client(vodafone_id=op_co_customer_id, market_code=market_code).get_tpm_customer({
        'market': market_code,
        'vodafone_customer_id': op_co_customer_id
    })
    if response.status_code == 200:
        logger.info(f"account with {op_co_customer_id=} exists")
        parsed = response.json()
        from classes.domain.account import TPMAccount
        return TPMAccount(market_code=parsed['market'],
                          bgid=parsed['bgid'],
                          op_co_customer_id=op_co_customer_id,
                          tenant_id=parsed['ms_teams_tenant_id'])
    return None


def validate_order_tpm_snow_operation(service_order_id):
    operation = {"SNOW_ONBOARDING": 2}
    document = database.get_service_order_operation(service_order_id, next(iter(operation)))
    asserts.equals(document["order"], operation.get('SNOW_ONBOARDING'), 'order of operation')


def item_is_tpm_add_number(item: dict) -> bool:
    return item['service']['serviceType'] == 'ucc.tpm.numbers' and item['action'] == 'add'


def is_snow_onboarding(context):
    return 'snow_onboarding' in context and context.snow_onboarding


def is_snow_offboarding(context):
    return 'snow_offboarding' in context and context.snow_offboarding


class TPMDeleteNumberNote:

    def __init__(self, state: str, pool: list[str]):
        match state:
            case 'success':
                self.message = f"Deleted numbers from pool {pool} in TPM"
            case 'failed':
                self.message = f"Failed to delete numbers from pool {pool} in TPM"
            case 'no_numbers':
                self.message = "Failed to delete requested numbers from pool in TPM"


class TPMDeleteNumberMilestone:

    def __init__(self, pool):
        self.description = 'DELETE_TPM_NUMBERS:COMPLETED'
        self.status = 'COMPLETED'
        self.message_numbers = pool
