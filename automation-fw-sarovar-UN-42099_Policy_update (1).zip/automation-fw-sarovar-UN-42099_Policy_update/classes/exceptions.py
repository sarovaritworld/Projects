class NotFoundError(Exception):
    """Exception raised when operation is not found"""

class NoSuchElementError(Exception):
    """Element was not found (e.g. in payload)."""
