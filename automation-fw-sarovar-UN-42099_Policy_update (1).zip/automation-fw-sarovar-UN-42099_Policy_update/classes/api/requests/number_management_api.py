"""
Client for NumberManagement API.

API documentation:
    https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/number-management-api/-/blob/master/openapi.yaml
"""
import logging

logger = logging.getLogger(__name__)

from dataclasses import dataclass
from common_python import api_requests

BASE_URL = "http://number-management-api/number-management"


@dataclass
class Client:
    """Client interacting with NumberManagement API."""

    token: api_requests.AuthType | str = api_requests.AuthType.VALID

    def add_numbers(self, market: str, customer_id: str, payload: dict, headers: dict = None) -> api_requests.Response:
        """Post request to add numbers"""
        url = self.url_number_pool(market, customer_id)
        logger.info(f'sending {payload=}')
        return api_requests.post(url, json=payload, token=self.token, headers=headers)

    def delete_numbers(self, market: str, customer_id: str, payload: dict) -> api_requests.Response:
        """Delete request to delete numbers"""
        url = self.url_number_pool(market, customer_id)
        return api_requests.delete(url, json=payload, token=self.token)

    def put_notification(self, market, customer_id, payload, headers=None):
        """ Register or update an OpCo's market notification endpoint to receive operation status updates """
        url = self.url_notification(market, customer_id)
        return api_requests.put(url, json=payload, token=self.token, headers=headers)

    def lookup_number(self, number):
        """ Retrieve the associated market_id and customer_id of a given E164 number """
        url = self.url_lookup_number(number)
        return api_requests.get(url, token=self.token)

    @staticmethod
    def url_number_pool(market, customer_id) -> str:
        return f"{BASE_URL}/v1/ucc/management/numbers/markets/{market}/customers/{customer_id}/pool"

    @staticmethod
    def url_lookup_number(number) -> str:
        return f"{BASE_URL}/v1/ucc/management/numbers/lookup/e164/{number}"

    @staticmethod
    def url_operation_status() -> str:
        return f"{BASE_URL}/v1/ucc/management/numbers/operation/status"

    @staticmethod
    def url_notification(market, customer_id) -> str:
        return f"{BASE_URL}/v1/ucc/management/numbers/markets/{market}/customers/{customer_id}/operation/notification/url"
