"""
Validation sets for API responses
"""
import logging
from dataclasses import dataclass
from typing import Any

from classes import data_files, tpm, payload
from classes.convertions import format_date_to_iso

ValSet = dict[str, Any]


class APIResponseValidationSet:

    def __init__(self, context: Any = None) -> None:
        self._context = context

    def get_msoc_account_customer_info(self) -> ValSet:
        """
        Return validation set related to msoc account customer

        Returns:
                validation set dict representation
        """
        validation_set = {
            "name": self._context.customer_name,
            "market": self._context.market_code,
            "vodafone_id": self._context.op_co_customer_id,
            "msoc_bgid": self._context.bgid
        }

        if self._context.include_all_data:
            val_set = {"contact.first_name": self._context.first_name,
                       "contact.last_name": self._context.last_name,
                       "contact.email": self._context.email,
                       "contact.phone_number": self._context.phone_number,
                       "ms_teams_tenant_id": self._context.ms_teams_tenant_id,
                       "hq_address.street": self._context.hq_street_full,
                       "hq_address.city": self._context.city,
                       "hq_address.zip": self._context.postcode,
                       "hq_address.country": self._context.country_code,
                       "consent_countries": self._context.consent_countries,
                       f"billing_identifiers.{self._context.country_code}.service_identifier": self._context.service_identifier,
                       f"billing_identifiers.{self._context.country_code}.customer_reference": self._context.customer_reference_number}

            validation_set.update(val_set)

            if 'msoc_account' in self._context:
                if self._context.msoc_account.itsm_provisioning is not None:
                    validation_set.update({
                        "itsm_provisioning.enable_provisioning": self._context.msoc_account.itsm_provisioning.enable_provisioning,
                        "itsm_provisioning.contract_start_date": format_date_to_iso(
                            self._context.msoc_account.itsm_provisioning.contract_start_date),
                        "itsm_provisioning.contract_end_date": format_date_to_iso(
                            self._context.msoc_account.itsm_provisioning.contract_end_date),
                        "itsm_provisioning.link_service_to_fully_onboarded_customer": self._context.msoc_account.itsm_provisioning.link_service_to_fully_onboarded_customer
                    })
        logging.info(validation_set)

        return validation_set

    def get_tpm_customer_validation_set(self):
        """
        Return validation set related to tpm account customer
        Returns: validation set dict representation
        """
        validation_set = {
            "name": self._context.tpm_account.name,
            "market": self._context.tpm_account.market_code,
            "vodafone_id": self._context.tpm_account.op_co_customer_id,
            "market_country_code": self._context.tpm_account.related_party.country_code,
            "bgid": self._context.tpm_account.bgid,
            "ms_teams_tenant_id": self._context.tpm_account.tenant_id
        }
        if tpm.is_snow_onboarding(self._context):
            validation_set.update({
                'itsm_provisioning.local_market_service_id': self._context.tpm_account.itsm_provisioning.local_market_service_id})
        if self._context.tpm_account.itsm_provisioning is not None:
            validation_set.update({
                "itsm_provisioning.enable_provisioning": self._context.tpm_account.itsm_provisioning.enable_provisioning,
                "itsm_provisioning.contract_start_date": format_date_to_iso(
                    self._context.tpm_account.itsm_provisioning.contract_start_date),
                "itsm_provisioning.contract_end_date": format_date_to_iso(
                    self._context.tpm_account.itsm_provisioning.contract_end_date)
            })
            # Only include link_service_to_fully_onboarded_customer in validation if it's explicitly set
            if self._context.tpm_account.itsm_provisioning.link_service_to_fully_onboarded_customer is not None:
                validation_set.update({
                    "itsm_provisioning.link_service_to_fully_onboarded_customer": self._context.tpm_account.itsm_provisioning.link_service_to_fully_onboarded_customer
                })
        return validation_set


class TMFServiceInventoryValidationSet:
    """Validation set for TMF Service Inventory API."""

    def __init__(self, context: Any = None) -> None:
        self._context = context

    def endpoint_service(self, expected_status: int, response_data: dict) -> ValSet:
        """Validation set of endpoint: service."""
        if expected_status != 200:
            return self._val_set_service_errors(expected_status)

        val_set = self._val_set_single_service(service_data=response_data)
        val_set["id"] = self._context.request_service_id
        return val_set

    def endpoint_services(self, expected_status: int, response_data: list | dict) -> ValSet:
        """Validation set of endpoint: services."""
        if expected_status != 200:
            return self._val_set_service_errors(expected_status)

        validation_set = {}
        assert isinstance(response_data, list), "repsonse data for 200 status should be a list (of services)"
        for index, service_data in enumerate(response_data):
            val_set = self._val_set_single_service(service_data=service_data)
            validation_set.update({f"{index}.{key}": value for key, value in val_set.items()})
        return validation_set

    def _val_set_single_service(self, service_data: dict) -> ValSet:
        """Validation set of one service.

        Common for the validation for both endpoints: service and services
        """
        acct = _Account.from_payload_tmfgw_service_order_create(self._context.payload)

        validation_set = {
            "relatedParty.0.marketCode": self._context.market_code,
            "relatedParty.0.vodafoneAccountId": self._context.op_co_customer_id,
        }
        if "request_params" in self._context:
            validation_set["serviceType"] = self._context.request_params["serviceType"]

        characteristic_names = [c["name"] for c in service_data["serviceCharacteristic"]]
        index = characteristic_names.index("TenantInfo")
        validation_set.update({
            f"serviceCharacteristic.{index}.value.isvId": self._context.RC_ID,
            f"serviceCharacteristic.{index}.value.localAccountId": self._context.op_co_customer_id,
            f"serviceCharacteristic.{index}.value.mainNumber": acct.main_number,
            f"serviceCharacteristic.{index}.value.name": acct.name,
            f"serviceCharacteristic.{index}.value.billingAccountNumber": acct.billing_account_number,
            f"serviceCharacteristic.{index}.value.billingServiceReference": acct.billing_service_reference,
            f"serviceCharacteristic.{index}.value.opportunityId": acct.opportunity_id,
            f"serviceCharacteristic.{index}.value.profile": acct.profile,
        })

        index = characteristic_names.index("TenantAdminInfo")
        validation_set.update({
            f"serviceCharacteristic.{index}.value.email": acct.admin_email,
            f"serviceCharacteristic.{index}.value.firstName": acct.admin_first_name,
            f"serviceCharacteristic.{index}.value.lastName": acct.admin_last_name,
            f"serviceCharacteristic.{index}.value.phoneNumber": acct.admin_phone_number,
        })
        if hasattr(self._context, 'state'):
            validation_set.update({
                "place.0.stateOrProvince": self._context.state
            })

        return validation_set

    def _val_set_service_errors(self, expected_status: int) -> ValSet:
        """Validation set of error messages.

        Common for the validation for both endpoints: service and services
        """
        validation_set = {}
        if expected_status == 400:
            validation_set.update({
                "code": "INVALID_REQUEST",
                "reason": "Invalid Request Data",
                "message": "field(s) provided are invalid",
            })

        elif expected_status == 404:
            validation_set.update({
                "code": "INVALID_REQUEST",
                "reason": "Service not found",
                "message": "Not Found",
            })

        elif expected_status == 502:
            validation_set.update({
                "code": "UNKNOWN_ERROR",
                "reason": "There was an error trying to perform the request",
                "message": "Bad Gateway",
            })

        elif expected_status == 504:
            validation_set.update({
                "code": "TIME_OUT",
                "message": "Gateway timed-out",
                "reason": "There was an error trying to perform the request"
            })

        else:
            raise NotImplementedError(f"validation for {expected_status=}")

        return validation_set


class TMFServiceOrderGWValidationSet:
    """Validation set for TMF Service Order GW API."""

    def __init__(self, context: Any = None) -> None:
        self._context = context

    def endpoint_service_order_create(self, expected_status: int) -> ValSet:
        validation_set = {}
        if expected_status == 201:
            acct = _Account.from_payload_tmfgw_service_order_create(self._context.payload)
            validation_set.update({
                "serviceOrderItem.0.service.serviceType": acct.service_type,
            })
            if acct.cac_configuration:
                validation_set.update({
                    "serviceOrderItem.0.service.serviceCharacteristic.0.name": "MsocCacConfiguration",
                    "serviceOrderItem.0.service.serviceCharacteristic.0.value": acct.cac_configuration,
                })
            if not payload.has_modify_msoc_cac_configuration(self._context.payload):
                # keys to remove, as we don't need them for ADD and DELETE CAC
                keys_to_remove = ["burstMarginIn", "burstMarginOut", "burstMarginAll"]
                for key in keys_to_remove:
                    if key in validation_set["serviceOrderItem.0.service.serviceCharacteristic.0.value"]:
                        del validation_set["serviceOrderItem.0.service.serviceCharacteristic.0.value"][key]


        elif expected_status == 400 and "cac_parameter_impaired" in self._context:
            if self._context.cac_parameter_impaired == "@type":
                validation_set.update({
                    "code": "INVALID_SERVICE_ORDER", "reason": "InvalidRequestData"
                })
            else:
                message = data_files.read_config("tmf.yml", "TMF_gateway_error_messages.invalid_msoc_cac_configuration")
                validation_set.update({
                    "code": "INVALID_SERVICE_ORDER", "reason": "InvalidRequestData",
                    "message": message,
                })

        elif expected_status == 400 and "invalid_tpm_data" in self._context:
            message = data_files.read_config("tmf.yml",
                                             f"TMF_gateway_error_messages.invalid_{self._context.invalid_tpm_data}")
            validation_set.update({
                "code": "INVALID_SERVICE_ORDER", "reason": "InvalidRequestData",
                "message": message,
            })
        elif expected_status == 400 and "invalid_pod_location" in self._context:
            validation_set.update({
                "code": "INVALID_SERVICE_ORDER", "reason": "InvalidRequestData",
                "message": data_files.read_config("tmf.yml", f"TMF_gateway_error_messages.invalid_unity_tenant_info"),
            })
        else:
            raise NotImplementedError(f"validation for {expected_status=}")

        return validation_set


@dataclass
class _Account:
    """Account information.

    Contains the information required for validation.
    """
    market: str
    service_type: str | None = None
    main_number: str | None = None
    name: str | None = None
    profile: str | None = None
    admin_email: str | None = None
    admin_first_name: str | None = None
    admin_last_name: str | None = None
    admin_phone_number: str | None = None
    billing_account_number: str | None = None
    billing_service_reference: str | None = None
    opportunity_id: str | None = None
    activate_immediately: bool | None = None
    cac_configuration: dict | None = None

    @classmethod
    def from_payload_tmfgw_service_order_create(cls, payload: dict) -> "_Account":
        """Parse payload for Service order to create an account

        payload schema should match models.tmf_gateway_api.ServiceOrder_Create
        """
        kwargs = {
            "market": payload["relatedParty"][0]["marketCode"],
        }

        for item in payload["serviceOrderItem"]:
            kwargs["service_type"] = item["service"]["serviceType"]
            for characteristic in item["service"]["serviceCharacteristic"]:
                name = characteristic["name"]
                value = characteristic["value"]
                if name == "TenantInfo":
                    kwargs["main_number"] = value["mainNumber"]
                    kwargs["name"] = value["name"]
                    kwargs["profile"] = value["profile"]
                    kwargs["billing_account_number"] = value.get("billingAccountNumber")
                    kwargs["billing_service_reference"] = value.get("billingServiceReference")
                    kwargs["opportunity_id"] = value.get("opportunityId")
                elif name == "TenantAdminInfo":
                    kwargs["admin_email"] = value["email"]
                    kwargs["admin_first_name"] = value["firstName"]
                    kwargs["admin_last_name"] = value["lastName"]
                    kwargs["admin_phone_number"] = value["phoneNumber"]
                elif name == "TenantFlowSettings":
                    kwargs["activate_immediately"] = value["activateImmediately"]
                elif name == "MsocCacConfiguration":
                    kwargs["cac_configuration"] = value

        return cls(**kwargs)
