"""
Formatters.

Note: User-Defined formatter must be importable from python search path,
so `PYTHONPATH` must include the parent directory of `classes`.
Alternatively, use `python -m behave` instead of `behave` to include
the current directory.
"""
import re
from typing import Optional

from behave.formatter.json import PrettyJSONFormatter
from behave.formatter.pretty import PrettyFormatter

CAUSE_PREFIX = "PROBABLE FAILURE: "


class PrettyCustomFormatter(PrettyFormatter):
    name = "pretty_custom"
    description = "Pretty formatter cleaning up error/tracebacks"

    def result(self, step):
        step.error_message = _cleanup_full_error_message(step.error_message)
        super().result(step)


class PrettyJSONCustomFormatter(PrettyJSONFormatter):
    name = "json.pretty_custom"
    description = "Like json.pretty but cleaning up error/tracebacks"

    def result(self, step):
        step.error_message = _cleanup_full_error_message(step.error_message)
        super().result(step)


class PrettyJSONSimpleCustomFormatter(PrettyJSONFormatter):
    name = "json.pretty_simple_custom"
    description = "Like json.pretty_custom but reporting only the cause of error"

    def result(self, step):
        step.error_message = _cleanup_full_error_message(step.error_message)
        if step.error_message and step.error_message.startswith(CAUSE_PREFIX):
            # Keep only the 1st line, containing the cause of error
            first_line = step.error_message.split("\n", maxsplit=1)[0]
            # for behave to convert it to a list, error_message must contain \n
            step.error_message = f"{first_line}\n"
        super().result(step)


def _cleanup_full_error_message(full_error_msg: Optional[str]) -> Optional[str]:
    """Cleanup the full error message.

    In the exception section: Keep only 1 traceback (where the issue occurred).
    In the captured sections (logging, stdout, stderr): no modifications.
    Add a 1 line probable cause for error.

    :param full_error_msg: Full error message (including captured logs)
    :return: Modified error message with cleaned up traceback
    """
    if not full_error_msg or full_error_msg.startswith(CAUSE_PREFIX):
        return full_error_msg  # nothing to do, or already processed

    # Split the exception section and the captured sections
    exception_section, *captured_sections = re.split(
        r"^(?=Captured )",
        full_error_msg, flags=re.MULTILINE)
    
    exception_section = _cleanup_exception_section(exception_section)
    cause = _get_failure_cause(exception_section, captured_sections)

    return "".join([cause, exception_section] + captured_sections)


def _cleanup_exception_section(exception_section: str) -> str:
    """Cleanup the exception section only (containing traceback)."""
    # Remove sub-step tracebacks
    error_msg, *substep_tracebacks = exception_section.split("Traceback (of failed substep):")

    # On AssertionError with text, the traceback is not included (in `Step.run()`)
    if substep_tracebacks and "Traceback" not in error_msg:
        # Add the 1st traceback only (substep where the issue occurred)
        error_msg += "Traceback of failed substep:" + substep_tracebacks[0]
    return error_msg


def _get_failure_cause(exception_section: str, captured_sections: list) -> str:
    """Get the failure cause."""

    # Check whether a log line already identifies the failure cause
    # Log line should be similar to logging.error("error occurred: actual reason")
    for section in captured_sections:
        if m := re.search(r"^ERROR:[^:]*:error occurred: (.*)", section, flags=re.M):
            err_msg = m.group(1)
            cause = f"{CAUSE_PREFIX}{err_msg}\n"
            return cause
    
    # Otherwise, check what caused the exception/assert
    current_substep = None
    for line in exception_section.splitlines():
        if line.startswith((" ", "Traceback", "Substep info: Traceback")):
            continue  # inside a Traceback
        elif m := re.search(r": FAILED SUB-STEP: (.*)", line):
            current_substep = m.group(1)
            continue

        # Cleanup the prefix (exception name and sub-step indicator)
        line = line.removeprefix("Substep info: ")
        if m := re.search(r"^(\S+): (.*)", line):
            long_exception_name, message = m.groups()
            short_exception_name = long_exception_name.split(".")[-1]
            line = f"{short_exception_name}: {message}"

        # 'line' contains the error
        cause = f"{CAUSE_PREFIX}{line}\n"

        if current_substep:
            # the failure occured in a sub-step (i.e. called from context.execute_steps())
            cause += f"Failure occured in sub-step: '{current_substep}'\n"
        # else: the failure occured in a step (called from Gherkin) already logged

        return cause
    return ""  # Could not determine the cause (has not happened so far)
