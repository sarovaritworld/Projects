import json
import logging
import os
from typing import Iterable

from classes import asserts, common, data, numbers, payload, polling, read_xmldata
from common_python import api_requests


def get_jira_setting(setting):
    return read_xmldata.readxml(setting, 'tmf_testdata', 'jira')


jira_url = get_jira_setting('jira_base_url')
jira_search_path = get_jira_setting('jira_search_path')
jira_issue_path = get_jira_setting('jira_issue_path')
project = get_jira_setting('project')
issue_type = get_jira_setting('issue_type')
time_span = get_jira_setting('time_span')

service_order_id_field = get_jira_setting('service_order_id_field')
service_order_item_id_field = get_jira_setting('service_order_item_id_field')

DEFAULT_SELECTED_FIELDS = [
    # download only the commonly used fields for JIRA tickets
    "summary", "labels", "issuetype",
    service_order_id_field, service_order_item_id_field,
]
jira_story_status_map = {
    "inProgress": "831",
    "Done": "861",
    "Closed": "871"
}
JIRA_TOKEN = os.environ.get("JIRA_TOKEN")

logger = logging.getLogger(__name__)


def get_header():
    if JIRA_TOKEN is None:
        token = data.read_jira_token_json_file()
    else:
        token = JIRA_TOKEN
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def get_ticket_by_key(
        ticket_key: str,
        selected_fields: Iterable[str] = DEFAULT_SELECTED_FIELDS) -> dict:
    """Get a JIRA ticket.

    :param ticket_key:
    :param selected_fields: fields to download/return
    :return: JIRA ticket as dict

    Note: "*all" is a special field name returning all fields.
    
    Documentaion:
        https://developer.atlassian.com/cloud/jira/platform/rest/v2/api-group-issues/#api-rest-api-2-issue-issueidorkey-get
    """
    if not selected_fields:
        # The API does not allow selecting no fields (it would return all
        # fields), so we select a dummy field
        selected_fields = ["summary"]

    def response_from_jira_server() -> api_requests.Response | None:
        try:
            response = api_requests.get(
                jira_url + jira_issue_path + ticket_key,
                params={"fields": ",".join(selected_fields)},
                headers=get_header(),
                timeout=15)  # typically response takes 0.3s (but sometimes server does not respond)
        except Exception as ex:
            logger.info(f'Exception connecting to JIRA server: {ex}')
            response = None
        return response

    response = polling.wait_until(
        response_from_jira_server, "Response from JIRA server",
        stop_when=lambda response: response is not None,
        timeout=60)
    ticket = response.json()
    logger.debug(f"JIRA TICKET: {ticket}")
    return ticket


def transition_jira_story_to_status_done(ticket_key):
    jira_status_chain_to_done = ("inProgress", "Done")
    for status in jira_status_chain_to_done:
        res = modify_jira_ticket_status(ticket_key, status)
        if res is None:
            logging.debug("no need for more transitions")
            return

    logging.debug("jira status change done")


def get_jira_ticket_transitions(ticket_key):
    logging.debug("*** inside transition function ***")

    def get_jira_ticket_transitions_response() -> api_requests.Response | None:
        try:
            response = api_requests.get(
                jira_url + jira_issue_path + ticket_key + "/transitions",
                headers=get_header(),
                timeout=15)
        except Exception as ex:
            logger.info(f'Exception connecting to JIRA server: {ex}')
            response = None
        # logging.info(f'the available transitions are: {response}')
        return response

    response = polling.wait_until(
        get_jira_ticket_transitions_response, "Response from JIRA server",
        stop_when=lambda response: response is not None,
        timeout=60)
    transitions_list = response.content
    logging.debug(f"*** available validations are {transitions_list}")
    return transitions_list


def modify_jira_ticket_status(ticket_key, final_status):
    logging.info(f"changing ticket state to {final_status}")
    transition_list = json.loads(get_jira_ticket_transitions(ticket_key)).get("transitions")
    for status_object in transition_list:
        if status_object.get("id") == jira_story_status_map.get("Closed"):
            logging.debug("ticket is already at Done state exiting...")
            return

    try:
        response = api_requests.post(
            jira_url + jira_issue_path + ticket_key + "/transitions",
            data=json.dumps({"transition": {"id": f"{jira_story_status_map[final_status]}"}}),
            headers=get_header(),
            timeout=15)
    except Exception as ex:
        logger.info(f'Exception connecting to JIRA server: {ex}')
        response = None
    logger.debug(f'the response to transition change is: {response.content}')
    return response


def get_jira_key_from_context(service_order, item_id):
    logger.debug(f'service_order: {service_order}')
    logger.debug(f'item_id: {item_id}')
    for item in service_order:
        if item['id'] == int(item_id) or item['id'] == item_id:
            return item['jira_key']
    logger.warning('jira_key not found in context.service_order')
    return None


def skip_jira(context, item):
    if payload.item_is_add_account(item):
        if common.config.is_crf_add_number_enabled:
            logging.debug("item is add account and crf is enabled >> skip")
            return True
        elif payload.is_duplicate_account(context.payload, item):
            # this has to be handled as negative scenario and skip only the second item
            logging.debug("item is duplicate add account item >> skip")
            return True
        elif hasattr(context, 'middleware_correlation_id_changed'):
            logging.debug("item is add account and middleware_correlation_id has been changed due to patch")
            return True
    elif payload.item_is_add_number(item):
        if numbers.get_numbers_pooltype(item) == 'Fixed':
            if common.config.is_crf_add_number_enabled:
                logging.debug("item is add number with pool type 'Fixed' and crf is enabled >> skip")
                return True
            else:
                return False
        elif hasattr(context, 'number_type') and context.number_type in numbers.negative_numbers:
            logging.debug("item is add number and scenario is negative >> skip")
            return True
        elif numbers.get_numbers_pooltype(item) == 'Presentation':
            return True

    elif payload.item_is_delete_number(item):
        if numbers.get_numbers_pooltype(item) == 'Fixed':
            if common.config.is_crf_delete_number_enabled:
                logging.debug("item is delete number with pool type 'Fixed' and crf is enabled >> skip")
                return True
            else:
                return False
    elif payload.item_is_add_cac_configuration(item):
        return True

    return False


def validate_issue(item, ticket, service_order_id):
    asserts.field_equals(ticket['fields']['summary'], f"{item['action'].upper()} {item['service']['serviceType']}",
                         "Jira issue summary")

    labels = ticket['fields']['labels']

    expected_label = 'development'
    if common.config.is_staging_env:
        expected_label = 'test'

    asserts.in_list(expected_label, labels, "Jira ticket label")

    asserts.field_equals(
        ticket['fields']['issuetype']['name'], 'Service Request',
        'issue type name (in jira issue)')
    asserts.field_equals(
        ticket['fields'][service_order_id_field], service_order_id,
        'service order id (in jira issue)')
    asserts.field_equals(
        ticket['fields'][service_order_item_id_field], item['id'],
        'service order item id (in jira issue)')
