# https://confluence.tools.aws.vodafone.com/display/UCP/Service+Processing
from classes import asserts, database

# >>> from classes import operations
# >>> operations.validate_operations_order(service_type, action, service_order_id)


service_operations_dict = {
    "ucc.unity.tenant": {
        "add": {
            "CREATE_ACCOUNT": 1,
            "ADD_MAIN_NUMBER": 2,
            "SET_SSO_CONFIG": 2,
            "SET_ACCOUNT_SERVICE_INFO": 2,
            "SET_EMERGENCY_ADDRESS": 2,
            "SET_POLICY_ACCESS": 2,
            "SET_EXTENSION": 3,
            "CONFIRM_ACCOUNT": 4,
            "CREATE_JIRA_TICKET": 5,
            "WAIT_FOR_JIRA_TICKET": 5
        },
        "delete": {},
        "modify": {
            "SET_SSO_CONFIG": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2
        }
    },
    "ucc.unity.license": {
        "add": {
            "ADD_UNITY_LICENSE": 1
        },
        "delete": {
            "DELETE_UNITY_LICENSE": 1
        },
        "modify": {
            "CHANGE_UNITY_LICENSE": 1
        }
    },
    "ucc.unity.numbers": {
        "add": {
            "ADD_NUMBERS": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2
        },
        "delete": {
            "DELETE_NUMBERS": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2
        },
        "modify": {}
    },
    "ucc.msoc.customer": {
        "add": {
            "CREATE_MSOC_CUSTOMER": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2
        },
        "delete": {
            "DELETE_ALL_NUMBERS": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2,
            "SNOW_OFFBOARDING": 3,
            "DELETE_MSOC_CUSTOMER": 4
        },
        "modify": {}
    },
    "ucc.msoc.country-billing": {
        "add": {
            "ADD_MSOC_COUNTRY_BILLING": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2
        },
        "delete": {},
        "modify": {}
    },
    "ucc.msoc.cac-configuration": {
        "add": {
            "ADD_CAC_TO_MSOC_CUSTOMER": 1,
            "APPLY_CAC_CONFIGURATION": 2
        },
        "delete": {},
        "modify": {
            "ADD_CAC_TO_MSOC_CUSTOMER": 1,
            "APPLY_CAC_CONFIGURATION": 2
        }
    },
    "ucc.msoc.numbers": {
        "add": {
            "ADD_MSOC_NUMBERS": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2,
            "SNOW_ONBOARDING": 3
        },
        "delete": {
            "DELETE_MSOC_NUMBERS": 1,
            "CREATE_JIRA_TICKET": 2,
            "WAIT_FOR_JIRA_TICKET": 2
        },
        "modify": {}
    },
    "ucc.tpm.customer": {
        "add": {
            "CREATE_TPM_CUSTOMER": 1
        },
        "delete": {
            "DELETE_ALL_NUMBERS": 1,
            "SNOW_OFFBOARDING": 2,
            "DELETE_TPM_CUSTOMER": 3
        },
        "modify": {}
    },
    "ucc.tpm.numbers": {
        "add": {
            "ADD_TPM_NUMBERS": 1,
            "SNOW_ONBOARDING": 2,
            "TPM_SERVICE_NOTIFICATION": 2
        },
        "delete": {
            "DELETE_TPM_NUMBERS": 1
        },
        "modify": {}
    }
}


def validate_operations_order(service_type, action, service_order_id, operations_name=None):
    operations = service_operations_dict[service_type][action]
    if operations_name:
        operations = {operations_name: operations[operations_name]}

    for k, v in operations.items():
        document = database.get_service_order_operation(service_order_id, k)
        asserts.equals(document["order"], v, 'order of operation')
