import logging
import re

from classes import asserts, common
from models.tmf_gateway_api import Milestone, Note
from models.utils.validator import validate_model, model_to_json

logger = logging.getLogger(__name__)


def validate_milestones(expected_milestones: list[dict], context) -> None:
    """Validate all milestones."""
    # Get all received milestones from context

    milestones = context.response_payload["milestone"]
    if "extra_response_payloads" in context:
        for payload in context.extra_response_payloads:
            for ms in payload["milestone"]:
                if ms not in milestones:
                    milestones.append(ms)
    # validate Milestones schema
    received_milestones = []
    for data in milestones:
        ms = validate_model(data, Milestone)
        logger.info(f"Received milestone: {model_to_json(ms)}")
        received_milestones.append(ms)
    received_milestones.sort(key=lambda m: m.milestoneDate)

    # validate Notes schema
    notes = []
    for data in context.response_payload["note"]:
        note = validate_model(data, Note)
        logger.info(f"Received note: {model_to_json(note)}")
        notes.append(note)

    # Validate milestones
    for expected in expected_milestones:
        logger.info(f"Validate the expected milestone: {expected}")
        index = _find_first_corresponding_milestone(expected, received_milestones)
        received = received_milestones.pop(index)
        validate_milestone(expected, received, notes)

    if common.config.is_dev_env:
        # Warn if we receive extra milestones
        for ms in received_milestones:
            logger.warning(f"Extra milestone received not validated: {model_to_json(ms)}")


def validate_milestone(expected: dict, received: Milestone, notes: list[Note]) -> None:
    """Validate a milestone."""
    exp_description = expected.get("description")
    asserts.field_equals(received.description, exp_description, "Milestone description")

    if "status" in expected:
        asserts.field_equals(received.status, expected["status"], "Milestone status")
    if "message" in expected:
        asserts.field_equals(received.message, expected["message"], "Milestone message")
    if "message_text" in expected:
        asserts.equals(_parse_text(received.message), expected["message_text"], "Milestone message (text)")
    if "message_numbers" in expected:
        asserts.equals(
            parse_pool_numbers(received.message),
            sorted(set(expected["message_numbers"])),
            "Milestone message (numbers)")

    if exp_description == "SERVICE_ORDER:RECEIVED":
        asserts.field_equals(notes[0].text, received.message, "Service Order Received note")


def _find_first_corresponding_milestone(expected: dict, received_milestones: list[Milestone]) -> int:
    """Find the first corresponding received milestone.
    
    Milestones can be received in any order, so this function finds the corresponding one.
    """
    for index, received in enumerate(received_milestones):
        if received.description != expected["description"]:
            continue
        if "message_numbers" in expected:
            if sorted(set(expected["message_numbers"])) != parse_pool_numbers(received.message):
                continue
        if "message" in expected:
            if received.message != expected["message"]:
                continue
        return index  # found a candidate

    # Keep exception message brief for GCP results, but log full error
    logger.error(f"Received no milestone matching {expected=}")
    raise Exception(f"Received no milestone matching {expected['description']}")


def parse_pool_numbers(message: str) -> list[str]:
    """Parse pool numbers in message."""
    numbers = []
    if m := re.search(r"\[(.*?)]", message):
        numbers_as_csv = m.group(1).strip()
        numbers = re.split(r"\s*,\s*", numbers_as_csv)
    numbers.sort()
    return numbers


def _parse_text(message: str) -> str:
    """Parse text in message (containing a list of numbers)."""
    return re.sub(r"\[.*?]", "[]", message)
