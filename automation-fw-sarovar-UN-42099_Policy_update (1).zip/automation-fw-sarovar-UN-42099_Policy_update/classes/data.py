import base64
import json
import logging

from requests import Response

logger = logging.getLogger(__name__)

from google.protobuf.json_format import MessageToJson, Parse

import event_pb2


def convert_to_protobuf(data: dict):
    """
    Converts a python dict to Event protobuf object
    :param data: dict
    :return: Event
    """
    message = Parse(json.dumps(data), event_pb2.Event())
    return message


def convert_to_json(data, convert_to_camel_case: bool):
    """
    Converts a protobuf message to JSON
    :param data: protobuf message
    :return: json
    """
    message = MessageToJson(data, preserving_proto_field_name=not convert_to_camel_case)
    return message


def convert_string_into_Base_64(data):
    """
This function converts the input string data into base64value
    :param data:
    :return:
    """
    encoded = base64.b64encode(data.encode())
    data_as_base64 = encoded.decode()
    return data_as_base64


def read_jwt_token_json_file():
    """
This function reads the data from the jwttoken json file and returns the token in string format  clientId:clientSecret
    :return:
    """
    filename = "jwttoken.json"
    documentdb = 'oauth2'
    # above value taken from chart/value.yaml file
    secrets = read_document_db_json_file(filename, documentdb)
    jwt_token_as_string = secrets[0] + ":" + secrets[1]
    return jwt_token_as_string


def read_jira_token_json_file():
    """
This function reads the data from the Jira token json file and returns the token in string format  clientId:clientSecret
    :return:
    """
    filename = "jira-ticket-mediator-auth.json"
    documentdb = 'oauth2'
    # above value taken from chart/value.yaml file
    secrets = read_document_db_json_file(filename, documentdb)
    jira_token_as_string = secrets[1]
    return jira_token_as_string


def read_document_db_json_file(documentdb_jsonfile, documentdb=None):
    """
This function reads the data from a documentDb json file and returns the clientId and clientSecret
    :param documentdb_jsonfile:
    :param documentdb:
    :return:
    """
    json_parsed = get_secret_file(documentdb_jsonfile)
    clientid = json_parsed['secrets'][documentdb]['clientId']
    clientsecret = json_parsed['secrets'][documentdb]['clientSecret']
    return [clientid, clientsecret]


def get_msk_credentials(msk_jsonfile):
    """
    Gets user and password stored in a secret json file
    :param msk_jsonfile: The JSON file (with extension) object representing the message data (e.g. msk.json)
    :return: [username, password]
    """
    json_parsed = get_secret_file(msk_jsonfile)
    username = json_parsed['username']
    password = json_parsed['password']
    return [username, password]


def get_decoded_response(response: Response):
    """
    gets raw response and decodes it
    :param response: raw response from requests
    :return: python object (dict)
    """
    try:
        _response = json.loads(response.content.decode('utf-8'))
    except json.decoder.JSONDecodeError:
        raise Exception(f"response body is not JSON for URL={response.request.url}")
    return _response


def get_secret_file(file_name, mount_path="/var/secrets"):
    """
Gets secret file by name
    :param file_name:
    :param mount_path:
    :return: python object (dict)
    """
    file = open(mount_path + "/" + file_name, "r")
    json_data = file.read()
    json_parsed = json.loads(json_data)
    return json_parsed


def get_jira_processor_credentials():
    json_parsed = get_secret_file('jira_processor.json')
    email = json_parsed['email']
    token = json_parsed['token']
    return [email, token]
