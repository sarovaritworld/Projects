import random

from classes import read_xmldata

countries_data = read_xmldata.read_jsonfile('countries_data', './testdata/')


def get_city(market_code: str) -> str:
    """
    Returns the city for the given market code.

    :param market_code: The market code to look up.
    :return: The city corresponding to the market code.
    """
    return countries_data[market_code]["city"]


def get_postcode(market_code: str) -> str:
    """
    Returns the postcode for the given market code.

    :param market_code: The market code to look up.
    :return: The postcode corresponding to the market code.
    """
    return countries_data[market_code]["postcode"]


def get_area_code(market_code: str, pool_type: str = 'fixed') -> str:
    """
    Returns the area code for the given market code and pool type.

    :param market_code: The market code to look up.
    :param pool_type: The type of pool (default is 'fixed').
    :return: The area code corresponding to the market code and pool type.
    """
    try:
        return countries_data[market_code]["area_code"][pool_type.lower()]
    except KeyError:
        return countries_data[market_code]["area_code"]['fixed']


def get_local_number_length(market_code: str) -> int:
    """
    Returns the local number length for the given market code.

    :param market_code: The market code to look up.
    :return: The local number length corresponding to the market code.
    """
    return countries_data[market_code]["local_number_length"]


def get_different_market_code(market_code_to_exclude: str) -> str:
    """
    Returns a random market code from the available market codes, excluding the specified market code.

    :param market_code_to_exclude: The market code to exclude from the selection.
    :return: A random market code from the available market codes, excluding the specified market code.
    """
    markets = set(countries_data.keys())
    markets.discard(market_code_to_exclude)
    return random.choice(list(markets))


def get_currency(market_code: str) -> str:
    """
    Returns the currency for the given market code.

    :param market_code: The market code to look up.
    :return: The currency corresponding to the market code.
    """
    return countries_data[market_code]["currency"]


def get_country_code(market_code: str) -> str:
    """
    Returns the country code for the given market code.

    :param market_code: The market code to look up.
    :return: The country code corresponding to the market code.
    """
    return countries_data[market_code]["country_code"]


def get_isd_code(market_code: str) -> list:
    """
    Returns the ISD codes for the given market code.

    :param market_code: The market code to look up.
    :return: The ISD codes corresponding to the market code.
    """
    return countries_data[market_code]["isd_code"]


def get_dep_market_code(market_code: str) -> str:
    """
    Return the DEP market code for the Middleware market code
    Below link for mapping documentation
    https://confluence.tools.aws.vodafone.com/display/UCP/CRF+Gateway+Microservice#CRFGatewayMicroservice-MappingMiddlewareMarkettoDEPMarket
    :param market_code:
    :return:
    """
    return countries_data[market_code]["dep_market_code"]
