import logging
from datetime import datetime

from classes import read_xmldata
from classes.data_factory import countries_data_manager

add_tenant_notifications_list = [
    "Milestone added: SERVICE_ORDER:RECEIVED",
    "Service Order Item state value changed to: inProgress",
    "Service Order state change from 'acknowledged' to 'inProgress'",
    "Note(s) added: Account created in RINGCENTRAL:991676973307778",
    "Milestone(s) added: CREATE_ACCOUNT:COMPLETED",
    "Service Characteristic(s) modified: TenantInfo",
    "Created Service Order 63f494f908e29e47edfe161b",
    "Milestone(s) added: ADD_MAIN_NUMBER:COMPLETED",
    "Note(s) added: Added numbers to pool [+441155503307] in RINGCENTRAL",
    "Note(s) added: Account confirmed in RINGCENTRAL",
    "Service Order Item state value changed to: completed",
    "Milestone(s) added: CONFIRM_ACCOUNT:COMPLETED",
    "Service Order state change from 'inProgress' to 'completed'",
    "Service Characteristic(s) modified: TenantInfo"
]


def get_notes_for_notification(context, scenario: str, account_status: str) -> list[dict]:
    current_date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    # For add number scenario we need to exclude the new numbers from notification note
    new_numbers_for_add_scenario = getattr(context, "new_numbers", [])
    numbers = [str(i).replace('+', '') for i in context.number_pool_list if i not in new_numbers_for_add_scenario]
    pool_list = [int(i) for i in numbers]
    note = {
        "date": current_date,
        "author": "Digital Enablement Platform",
        "id": read_xmldata.gen_uuid()
    }
    dep_market_code = countries_data_manager.get_dep_market_code(context.market_code)
    text = ""
    match scenario:
        case 'ALL_NUMBERS_PROVISIONED' | 'NUMBERS_PARTIALLY_PROVISIONED':
            if account_status == "same":
                text = {"text": f"ERROR | OrderItem | {context.crf_request_id} |  |  | The number(s) {pool_list} have already been provisioned within NGIN"}
            else:
                text = {"text": f"ERROR | OrderItem | {context.crf_request_id} |  |  | Failed with error FAILED_SEARCH"}
        case 'ALL_NUMBERS_NOT_FOUND' | 'PARTIALLY_NUMBERS_NOT_FOUND':
            if account_status == "new":
                text = {"text": f"ERROR | OrderItem | {context.crf_request_id} |  |  | {pool_list} number(s) not found for market: {dep_market_code} customer: {context.op_co_customer_id}"}
            else:
                text = {"text": f"ERROR | OrderItem | {context.crf_request_id} |  |  | Failed with error FAILED_SEARCH"}
        case _:
            raise NotImplementedError(f"{scenario=} not implemented")
    note.update(text)
    return [note]


def get_final_state_by_scenario(scenario: str) -> str:
    match scenario:
        case "ALL_NUMBERS_PROVISIONED" | "ALL_NUMBERS_NOT_FOUND":
            return "failed"
        case "NUMBERS_PARTIALLY_PROVISIONED" | "PARTIALLY_NUMBERS_NOT_FOUND":
            return "partial"
        case _:
            raise NotImplementedError(f"{scenario=} not implemented")
