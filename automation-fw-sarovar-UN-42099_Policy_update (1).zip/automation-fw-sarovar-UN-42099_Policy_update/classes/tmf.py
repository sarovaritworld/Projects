import json
import logging

from classes import asserts, common, jira_helper, milestone_validator, msoc_numbers, numbers, payload, read_xmldata, tpm
from classes.errors import ErrorCodes, RCErrorType
from classes.geo_restriction import GeoRestrictionMilestone
from classes.license import AddLicenseMilestone, DeleteLicenseMilestone, ModifyLicenseMilestone
from classes.snow import SNOWMilestone, SNOWOffboardingMilestone
from classes.modify_sso import ModifySSOMilestone
from classes.tpm import TPMDeleteNumberMilestone
from common_python import api_requests

TMF_URL = read_xmldata.readxml("tmf_url", "tmf_testdata", "tmf_data")
TMF_BASE_URL = "http://" + read_xmldata.readxml("tmf_base_url", "tmf_testdata", "tmf_data")
SERVICE_ORDER_URL = TMF_BASE_URL + "/tmf" + TMF_URL + "/serviceOrder/"


def validate_service_order_status(_payload, state):
    asserts.equals(_payload['state'], state, 'Service order state')


def validate_error_message(context, outcome):
    expected_error = get_error(context, outcome)
    response_payload = context.response_payload

    error_path_code = "errorMessage.0.code"
    error_path_message = "errorMessage.0.message"
    error_path_reason = "errorMessage.0.reason"

    index = 0
    logging.info(f'Expected Error: {expected_error}')
    logging.info(f"{response_payload=}")
    # TODO: do not validate the exact location of not, just that it is there
    if outcome == 'failed_create_account_for_duplicate_opco' or 'failed_add_number' in outcome or 'failed_create_account' in outcome:
        index, error_item = payload.get_item_by_type(response_payload, 'ucc.unity.tenant')
    elif outcome in ['duplicate_opco_customer_id', 'duplicate_ms_teamns_tenant_id']:
        index, error_item = payload.get_item_by_type(response_payload, 'ucc.msoc.customer')
    elif outcome == 'different_billing_info':
        index, error_item = payload.get_item_by_type(response_payload, 'ucc.msoc.country-billing')
    elif outcome == 'failed_to_add_cac_id':
        index, error_item = payload.get_item_by_type(response_payload, ' ucc.msoc.cac-configuration')
    elif outcome == 'partial_fail_provisioning_in_snow':
        index, error_item = payload.get_item_by_type(response_payload, 'ucc.msoc.numbers')
    elif outcome in ('failed_duplicate_customer', 'failed_duplicate_customer', 'failed_dep_notification'):
        index, error_item = payload.get_item_by_type(response_payload, 'ucc.tpm.customer')
    elif outcome in ('failed_non_existing_tpm_account', 'failed_tpm_numbers'):
        index, error_item = payload.get_item_by_type(response_payload, 'ucc.tpm.numbers')

    if 'partial' in outcome and len(response_payload['serviceOrderItem']) > 1:
        index = 1

    item_prefix = f'serviceOrderItem.{index}.'
    error_path_code = item_prefix + error_path_code
    error_path_message = item_prefix + error_path_message
    error_path_reason = item_prefix + error_path_reason
    # asserts.field_equals(common.get_field(_payload, error_path_message), expected_error['message'], error_path_message)
    asserts.in_list(expected_error['message'], common.get_field(response_payload, error_path_message),
                    error_path_message)
    asserts.field_equals(common.get_field(response_payload, error_path_code), expected_error['code'], error_path_code)
    # asserts.field_equals(common.get_field(_payload, error_path_reason), expected_error['reason'], error_path_reason)
    asserts.in_list(expected_error['reason'], common.get_field(response_payload, error_path_reason), error_path_reason)


def validate_error_note(_payload, error_message, index):
    note_text_path = f'serviceOrderItem.{index}.' + "service.note.0.text"
    actual_note_text = common.get_field(_payload, note_text_path)
    logging.info(f"Validation for note : {actual_note_text}")
    asserts.field_equals(actual_note_text, error_message, note_text_path)


def get_status(outcome):
    if outcome.startswith('failed') or outcome.startswith('duplicate_'):
        status = 'failed'
    elif outcome.startswith('partial'):
        status = 'partial'
    elif outcome.startswith('completed'):
        status = 'completed'
    elif outcome.startswith('inProgress'):
        status = 'inProgress'
    elif outcome.startswith('acknowledged'):
        status = 'acknowledged'
    else:
        raise NotImplementedError(f"{outcome} is unknown")
    return status


def remove_statuses(outcome):
    statuses = ['inProgress', 'blocked', 'partial', 'acknowledged']
    for status in statuses:
        outcome = outcome.replace(status, '')
        outcome = outcome.replace('__', '_')
    outcome = outcome.lstrip('_')
    outcome = outcome.rstrip('_')
    return outcome


def get_error(context, outcome):
    SERVICE_PROVIDER_ERROR = ErrorCodes.SERVICE_PROVIDER_ERROR
    INVALID_REQUEST = ErrorCodes.INVALID_REQUEST
    ACCOUNT_NOT_FOUND = ErrorCodes.ACCOUNT_NOT_FOUND
    SYSTEM_ERROR = ErrorCodes.SYSTEM_ERROR
    ACCOUNT_ALREADY_EXISTS = 'ACCOUNT_ALREADY_EXISTS'
    INVALID_RESPONSE = 'INVALID_RESPONSE'
    UNKNOWN_ERROR = 'UNKNOWN_ERROR'
    NOK_Add_Number_0 = "Error with Phone Numbers (see Phone Number Details for more information)"
    NOK_Add_Number_1 = read_xmldata.readxml("NOK_Add_Number_1", "RC_inputdata", "RC_errors")
    full_NOK_Add_Number_1 = f'errorCode:\"PRT-102\", message:\"{NOK_Add_Number_1}\",'
    main_error = "Main Number could not be confirmed due to :"
    NOK_Add_Number_2 = f"{main_error} Unexpected error occurred at Ringcentral. (errorCode: UNKNOWN_ERROR),"
    update_number_api_error = "Error occurred calling Update Number API,"
    op_co_customer_id = context.tpm_account.op_co_customer_id if hasattr(context,
                                                                         'tpm_account') else context.op_co_customer_id
    TPM_ERROR = f"Failed to delete all numbers in TPM for account {op_co_customer_id} in market {context.market_code}"
    logging.debug(f'input outcome: {outcome}')
    expected_error = remove_statuses(outcome)
    logging.debug(f'input outcome: {outcome}')

    if not hasattr(context, 'ucas_provider'):
        context.ucas_provider = 'RINGCENTRAL'
    if 'patch_error' in outcome:
        return {
            'message': f'Unknown error occurred while PATCH for {context.item_to_change.capitalize()} from Automation tool',
            'code': 'PATCH_ERROR',
            'reason': 'Failed to PATCH in automation tool'
        }
    elif 'CRF' in outcome:
        errors = {
            'CRF_Rejected_Add_MainNumber_failed': {
                'message': "",
                'code': INVALID_RESPONSE,
                'reason': "Error while calling CRF API"
            },
            'CRF_Add_MainNumber_failed': {
                'message': "Number provisioning failed",
                'code': INVALID_RESPONSE,
                'reason': "CRF Provisioning failed: One or more numbers could not be provisioned in CRF"
            },
            'failed_CRF': {
                'message': "",
                'code': INVALID_RESPONSE,
                'reason': ""
            },
            'failed_add_pool_number_CRF': {
                'message': "",
                'code': INVALID_RESPONSE,
                'reason': "RingCentral Gateway get account failed for accountId '995757138' with status 502 BAD_GATEWAY and reason: There was a problem in RingCentral API"
            },
            'failed_add_main_number_patch_CRF': {
                'message': "Number provisioning failed",
                'code': INVALID_REQUEST,
                'reason': f"RingCentral provisioning failed:\n{context.main_number}: Main Number could not be confirmed due to : Error occurred calling Update Number API,"
            }

        }
    elif 'invalid_contact_info' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Failed to create account in RINGCENTRAL",
            "reason": "Invalid value for parameter"
        }
    elif 'invalid_primary_contact' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Failed to create account in RINGCENTRAL",
            "reason": "The primary contact phone number cannot be a RingCentral phone number"
        }
    elif 'pool_number' in outcome:
        errors = {
            "failed_add_pool_number": {
                'message': "Number provisioning failed",
                'code': INVALID_REQUEST,
                'reason': "Failed to provision numbers"
            },
            "failed_delete_pool_number": {
                'message': "Number deprovisioning failed",
                'code': INVALID_REQUEST,
                'reason': "Failed to remove numbers"
            },
            "partial_add_pool_number": {
                'message': "Number provisioning failed",
                'code': INVALID_REQUEST,
                'reason': "Failed to provision numbers"
            }
        }
    elif 'duplicate_opco_customer_id' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Failed to create MSOC Customer in Middleware",
            "reason": "MSOC Customer with market [VFUK] and Vodafone ID [88569403040] already exists"
        }
    elif 'duplicate_ms_teamns_tenant_id' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Failed to create MSOC Customer in Middleware",
            "reason": "MSOC Customer with MS Teams Tenant ID [MS-5952] already exists"
        }
    elif 'failed_to_add_billing_info' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation ADD_MSOC_COUNTRY_BILLING",
            "reason": "Customer has not been onboarded"
        }
    elif 'different_billing_info' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": f"Failed to add country billing information for {context.country_code}",
            "reason": f"MSOC Customer already has Country Billing Information for [{context.country_code}]"
        }
    elif 'failed_billing_info_not_set' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Failed to process operation ADD_MSOC_NUMBERS",
            "reason": "Account does not have any billing identifier"
        }
    elif 'failed_to_delete_numbers' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation DELETE_MSOC_NUMBERS",
            "reason": "Customer has not been onboarded"
        }
    elif 'failed_to_delete_unity_numbers' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation DELETE_NUMBERS",
            "reason": "Customer has not been onboarded"
        }
    elif 'failed_to_add_cac_id' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "The provided cacId cannot be added to the MSOC Customer",
            "reason": f"MSOC Customer already has the limit of 1 CAC ID(s) [{context.existing_cac_id.upper()}]"
        }
    elif 'failed_invalid_cac' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Failed to process operation ADD_MSOC_NUMBERS",
            "reason": f"CAC ID [{context.cac_id}] is not valid for the customer"
        }
    elif 'failed_duplicate_customer' in outcome:
        return {
            "code": ACCOUNT_ALREADY_EXISTS,
            "message": "Failed to process operation CREATE_TPM_CUSTOMER",
            "reason": "Customer has already been onboarded"
        }
    elif 'failed_non_existing_tpm_account' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation ADD_TPM_NUMBERS",
            "reason": "Customer has not been onboarded"
        }
    elif 'failed_duplicate_tenant' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Failed to create TPM Customer in Middleware",
            "reason": f"TPM Customer with MS Teams Tenant ID [{context.tpm_account.tenant_id}] already exists in "
                      f"market [{context.tpm_account.market_code}]"
        }
    elif 'partial_fail_provisioning_in_snow' in outcome:
        return {
            "code": SERVICE_PROVIDER_ERROR,
            "message": "Failed to create account in RINGCENTRAL",
            "reason": "CMN-101 Parameter [state] value is invalid."
        }
    elif 'failed_to_delete_tpm_numbers' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation DELETE_TPM_NUMBERS",
            "reason": "Customer has not been onboarded"
        }
    elif 'failed_dep_response' in outcome:
        return {
            "code": "UCAS_PROVIDER_ERROR",
            "message": "Some note text",
            "reason": "Some error text"
        }
    elif 'failed_dep_notification' in outcome or 'tpm' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": TPM_ERROR,
            "reason": TPM_ERROR
        }
    elif 'failed_to_add_unity_license' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation ADD_UNITY_LICENSE",
            "reason": "Customer has not been onboarded"
        }
    elif 'insufficient_licenses_to_delete' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": f"Failed to delete licenses with SKU {context.unity_license.id} from the {context.ucas_provider} account",
            "reason": f"Insufficient {context.unity_license.id} licenses to delete {context.unity_license.quantity}"
        }

    elif outcome in ('invalid_sku_id', 'max_license_limit'):
        reason = RCErrorType.get_error_message(outcome)
        message = f"Failed to {context.action} licenses with SKU {context.unity_license.id} {'to' if context.action == 'add' else 'from'} the {context.ucas_provider} account"
        if 'invalid_sku_id' in outcome:
            reason = RCErrorType.get_error_message(outcome).replace("*", context.unity_license.id)
        if context.action == 'modify':
            message = f"Failed to modify the licenses with SKU {context.unity_license.id} for the {context.ucas_provider} account"
        return {
            "code": INVALID_REQUEST,
            "message": message,
            "reason": reason
        }
    elif 'failed_to_delete_unity_license' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation DELETE_UNITY_LICENSE",
            "reason": "Customer has not been onboarded"
        }
    elif 'failed_to_modify_unity_license' in outcome:
        return {
            "code": ACCOUNT_NOT_FOUND,
            "message": "Failed to process operation CHANGE_UNITY_LICENSE",
            "reason": "Customer has not been onboarded"
        }
    elif 'CUSTOMER_MAPPING_ALREADY_EXISTS' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Number provisioning failed",
            "reason": "Failed to provision numbers"
        }
    elif 'CUSTOMER_MAPPING_NOT_OWNED_BY_CUSTOMER' in outcome or 'CUSTOMER_MAPPING_NOT_FOUND' in outcome:
        return {
            "code": INVALID_REQUEST,
            "message": "Number deprovisioning failed",
            "reason": "Failed to remove numbers"
        }
    else:
        errors = {
            'failed_create_account': {
                'message': f'Failed to create account in {context.ucas_provider}',
                'code': SERVICE_PROVIDER_ERROR,
                'reason': 'Parameter [status] is invalid. Unable to create account with status [Disabled].'},

            'failed_add_number': {
                'message': f"Failed to add numbers to pool [{context.main_number}] in {context.ucas_provider}",
                'code': INVALID_RESPONSE,
                'reason': f"{NOK_Add_Number_0}\n{context.main_number}: {full_NOK_Add_Number_1}"},

            'failed_2accounts': {
                'message': 'Failed to process operation CREATE_ACCOUNT',
                'code': ACCOUNT_ALREADY_EXISTS,
                'reason': 'Customer has already been onboarded'},

            'failed_add_main_number': {
                'message': f"Failed to add numbers to pool [{context.main_number}] in {context.ucas_provider}",
                'code': INVALID_RESPONSE,
                'reason': f'{NOK_Add_Number_0}\n{context.main_number}: {NOK_Add_Number_1}'},
            'failed_SSO': {
                'message': "Failed to update VBUC account SSO configuration",
                'code': ErrorCodes.INVALID_IDP_ENTITY_ID,
                'reason': "The value of idpEntityId is not valid in RingCentral"},
            'failed_Extension': {
                'message': f'Failed to change the extension limit for {context.ucas_provider} account',
                'code': INVALID_REQUEST,
                'reason': ""}
        }

    if 'failed_create_account' in outcome:
        expected_error = 'failed_create_account'
    elif 'failed_2accounts' in outcome:
        expected_error = 'failed_2accounts'

    return errors[expected_error]


def skip_number_milestone(context, item):
    if hasattr(context, 'number_type') and context.number_type in numbers.negative_numbers:
        return True
    if hasattr(context, 'error_type') and context.error_type in numbers.negative_numbers:
        return True
    if hasattr(context, 'notification') and context.notification in ('partial', 'failed'):
        return True
    if hasattr(context, 'usage_type') and context.pool_type in ("Fixed", "Presentation") and context.usage_type in (
            "ForwardedNumber", "PhoneLine"):
        return True


def get_milestones(context, outcome):
    service_order_received_milestone = {'description': 'SERVICE_ORDER:RECEIVED',
                                        'message': f'Service Order {context.service_order_id} Received',
                                        'status': 'COMPLETED'}

    if not hasattr(context, "service_order"):
        context.service_order = context.payload['serviceOrderItem']

    milestones = [service_order_received_milestone]
    context.add_numbers_milestones = []
    context.delete_numbers_milestones = []

    for item in context.service_order:
        if payload.item_is_add_account(item) and 'state_not_added' not in outcome:
            if payload.is_duplicate_account(context.payload, item):
                # this item should not have a milestone
                continue
            try:
                create_account_milestone = {'description': 'CREATE_ACCOUNT:COMPLETED',
                                            'message': f'Account created in {context.ucas_provider}:{context.RC_ID}',
                                            'status': 'COMPLETED'}
                add_main_number_milestone = {'description': 'ADD_MAIN_NUMBER:COMPLETED',
                                             'message': f'Added numbers to pool [{context.main_number}] in {context.ucas_provider}',
                                             'status': 'COMPLETED'}
                account_confirmed_milestone = {'description': 'CONFIRM_ACCOUNT:COMPLETED',
                                               'message': f'Account confirmed in {context.ucas_provider}',
                                               'status': 'COMPLETED'}
                add_emergency_address_milestone = {'description': 'SET_EMERGENCY_ADDRESS:COMPLETED',
                                                   'message': 'Emergency address added to RINGCENTRAL account',
                                                   'status': 'COMPLETED'}
                set_sso_milestone = {'description': 'SET_SSO_CONFIG:COMPLETED',
                                     'message': f'SSO Configuration modified for {context.ucas_provider} account',
                                     'status': 'COMPLETED'}
                set_extension_milestone = {
                    "description": "SET_EXTENSION:COMPLETED",
                    "message": "Updated the RingCentral account extension",
                    "status": "COMPLETED"
                }
                if hasattr(context, "max_extension_length"):
                    set_account_service_milestone = {'description': 'SET_ACCOUNT_SERVICE_INFO:COMPLETED',
                                                     'message': f'Extension limit for {context.ucas_provider} account modified to {context.max_extension_length}',
                                                     'status': 'COMPLETED'}

            except AttributeError:
                raise "Might have some missed attributes in the context"

            if '_only' not in outcome and payload.has_initial_order(context.payload):
                if 'failed_add_number' in outcome or 'failed_add_main_number' in outcome or 'CRF' in outcome or 'inProgress_add_main_number' in outcome:
                    milestones.append(create_account_milestone)
                    context.create_account_milestones = [create_account_milestone]
                elif 'blocked_confirm_account' in outcome or outcome in (
                        'completed_unconfirmed_account', 'partial_failed_SSO', 'partial_failed_Extension'):
                    milestones.append(create_account_milestone)
                    milestones.append(add_main_number_milestone)
                    context.create_account_milestones = [create_account_milestone, add_main_number_milestone]
                    if payload.check_country_code_vfuk(context):
                        milestones.append(add_emergency_address_milestone)
                        context.create_account_milestones.insert(2, add_emergency_address_milestone)
                    if 'partial_failed_Extension' in outcome and hasattr(context, "idp_entity_id"):
                        milestones.append(set_sso_milestone)
                        context.create_account_milestones.insert(2, set_sso_milestone)
                    elif 'partial_failed_SSO' in outcome and hasattr(context, "max_extension_length"):
                        milestones.append(set_account_service_milestone)
                        context.create_account_milestones.insert(2, set_account_service_milestone)
                elif payload.has_extension_number(item):
                    if outcome == "completed":
                        context.create_account_milestones = [
                            create_account_milestone,
                            add_main_number_milestone,
                            set_extension_milestone,
                            account_confirmed_milestone
                        ]
                    else:
                        context.create_account_milestones = [
                            create_account_milestone,
                            add_main_number_milestone
                        ]
                    milestones.extend(context.create_account_milestones)
                else:
                    milestones.append(create_account_milestone)
                    milestones.append(add_main_number_milestone)
                    milestones.append(account_confirmed_milestone)
                    context.create_account_milestones = [create_account_milestone, add_main_number_milestone,
                                                         account_confirmed_milestone]
                    if outcome == "completed_sso_ops" or (hasattr(context, "idp_entity_id") and
                                                          "invalid" not in context.idp_entity_id):
                        milestones.append(set_sso_milestone)
                        context.create_account_milestones.insert(2, set_sso_milestone)
                    if hasattr(context,
                               "max_extension_length") and not context.op_co_customer_id.startswith("MAX_EXT_FAIL"):
                        milestones.append(set_account_service_milestone)
                        context.create_account_milestones.insert(2, set_account_service_milestone)
                    if payload.check_country_code_vfuk(context):
                        milestones.append(add_emergency_address_milestone)
                        context.create_account_milestones.insert(2, add_emergency_address_milestone)

        # check if number milestone is required
        elif payload.item_is_number(item):
            if numbers.get_numbers_pooltype(item) not in numbers.nonautomated_pooltype_list:
                # failing scenarios should not have a milestone
                if skip_number_milestone(context, item):
                    continue

                if payload.item_is_add_number(item) and 'blocked_confirm_account' not in outcome:
                    context.number_pool_list = sorted(numbers.get_all_numbers(item))
                    milestone = {
                        'description': 'ADD_NUMBERS:COMPLETED',
                        'message_text': "Added numbers to pool [] in RINGCENTRAL",
                        'message_numbers': sorted(numbers.get_all_numbers(item)),
                        'status': 'COMPLETED'}
                    milestones.append(milestone)
                    context.add_numbers_milestones.append(milestone)

                elif payload.item_is_delete_number(item):
                    milestone = {
                        'description': 'DELETE_NUMBERS:COMPLETED',
                        'message_text': "Deleted numbers [] from pool in RINGCENTRAL",
                        'message_numbers': sorted(numbers.get_all_numbers(item)),
                        'status': 'COMPLETED'}
                    milestones.append(milestone)
        elif payload.item_is_add_msoc_account(item) and (
                outcome == 'completed' or getattr(context, 'error_type', False) == 'partial_fail_provisioning_in_snow'):
            milestone = {
                'description': 'CREATE_MSOC_CUSTOMER:COMPLETED',
                'message': f'MSOC Customer created in Middleware: {context.bgid}',
                'status': 'COMPLETED'}
            milestones.append(milestone)
            context.create_msoc_customer_milestones = [milestone]
        elif payload.item_is_delete_msoc_account(item) and (
                not tpm.is_snow_offboarding(context) or outcome == 'completed'):
            if outcome == 'inProgress':
                context.delete_msoc_customer_milestones = [
                    {
                        "description": "DELETE_ALL_NUMBERS:COMPLETED",
                        "message": f"Deleted all numbers in CRF for account {context.op_co_customer_id}"
                                   f" in market {context.market_code}",
                        "status": "COMPLETED"
                    }
                ]
                milestones.extend(context.delete_msoc_customer_milestones)
            elif outcome == 'completed':
                context.delete_msoc_customer_milestones = [
                    {
                        "description": "DELETE_ALL_NUMBERS:COMPLETED",
                        "message": f"Deleted all numbers in CRF for account {context.op_co_customer_id}"
                                   f" in market {context.market_code}",
                        "status": "COMPLETED"
                    },
                    {
                        "description": "DELETE_MSOC_CUSTOMER:COMPLETED",
                        "message": "MSOC customer deleted from Middleware",
                        "status": "COMPLETED"
                    }
                ]
                milestones.extend(context.delete_msoc_customer_milestones)
        elif payload.item_is_delete_tpm_account(item) and (
                not tpm.is_snow_offboarding(context) or outcome == 'completed'):
            if outcome == 'inProgress':
                context.delete_tpm_customer_milestones = [
                    {
                        "description": "DELETE_ALL_NUMBERS:COMPLETED",
                        "message": f"Deleted all numbers in TPM for account {context.op_co_customer_id}"
                                   f" in market {context.market_code}",
                        "status": "COMPLETED"
                    }
                ]
            else:
                context.delete_tpm_customer_milestones = [
                    {
                        "description": "DELETE_ALL_NUMBERS:COMPLETED",
                        "message": f"Deleted all numbers in TPM for account {context.op_co_customer_id}"
                                   f" in market {context.market_code}",
                        "status": "COMPLETED"
                    },
                    {
                        "description": "DELETE_TPM_CUSTOMER:COMPLETED",
                        "message": "TPM customer deleted from Middleware",
                        "status": "COMPLETED"
                    }
                ]
            milestones.extend(context.delete_tpm_customer_milestones)
        elif payload.item_is_add_msoc_country_biiling(item) and (
                outcome == 'completed' or getattr(context, 'error_type', False) == 'partial_fail_provisioning_in_snow'):
            country = context.msoc_account.place.country_code if 'msoc_account' in context else context.country
            context.add_msoc_country_billing_milestone = {
                'description': 'ADD_MSOC_COUNTRY_BILLING:COMPLETED',
                'message': f'Country billing information for {country} has been added',
                'status': 'COMPLETED'}
            milestones.append(context.add_msoc_country_billing_milestone)
        elif msoc_numbers.item_is_add_msoc_number(item) and (
                outcome == 'completed' or getattr(context, 'error_type', False) == 'partial_fail_provisioning_in_snow'):
            context.add_msoc_numbers_milestone = {
                "description": "ADD_MSOC_NUMBERS:COMPLETED",
                'message_text': "Added numbers to pool [] in CRF",
                'message_numbers': sorted(numbers.get_all_numbers(item)),
                "status": "COMPLETED"
            }
            milestones.append(context.add_msoc_numbers_milestone)
            context.add_numbers_milestones.append(context.add_msoc_numbers_milestone)
        elif msoc_numbers.item_is_delete_msoc_number(item) and outcome == 'completed':
            context.delete_msoc_numbers_milestone = {
                "description": "DELETE_MSOC_NUMBERS:COMPLETED",
                'message_text': "Deleted numbers [] from pool in CRF",
                'message_numbers': sorted(numbers.get_all_numbers(item)),
                "status": "COMPLETED"
            }
            milestones.append(context.delete_msoc_numbers_milestone)
            context.delete_numbers_milestones.append(context.delete_msoc_numbers_milestone)
        elif payload.item_is_add_cac_configuration(item) and outcome == 'completed':
            cac_milestone = {"description": "APPLY_CAC_CONFIGURATION:COMPLETED",
                             "message": f"CAC Configuration with ID {context.cac_id} will be applied to CRF when the next numbers with CAC are provisioned",
                             "status": "COMPLETED"
                             }
            milestones.append(cac_milestone)

        elif payload.item_is_create_tpm_customer(item) and outcome == 'completed':
            context.tpm_customer_milestone = {"description": "CREATE_TPM_CUSTOMER:COMPLETED",
                                              "message": f"TPM Customer created in Middleware: {context.tpm_account.bgid}",
                                              "status": "COMPLETED"
                                              }
            milestones.append(context.tpm_customer_milestone)
        elif payload.item_is_add_tpm_numbers(item) and outcome == 'completed':
            context.tpm_number_milestone = [
                {"description": "ADD_TPM_NUMBERS:COMPLETED",
                 'message_text': "Added numbers to pool [] in TPM",
                 'message_numbers': sorted(numbers.get_all_numbers(item)),
                 "status": "COMPLETED"},
                {"description": "TPM_SERVICE_NOTIFICATION:COMPLETED",
                 "message": "Notification of new TPM service sent",
                 "status": "COMPLETED"
                 }
            ]
        elif payload.item_is_delete_tpm_numbers(item) and outcome == 'completed':
            milestones.append(vars(TPMDeleteNumberMilestone(sorted(context.tpm_numbers.pool))))
        elif payload.item_is_add_unity_license(item) and outcome == 'completed':
            milestones.append(vars(AddLicenseMilestone(context.unity_license.quantity, context.unity_license.id)))
        elif payload.item_is_delete_unity_license(item) and outcome == 'completed':
            milestones.append(vars(DeleteLicenseMilestone(context.unity_license.quantity, context.unity_license.id)))
        elif payload.item_is_modify_unity_license(item) and outcome == 'completed':
            milestones.append(vars(ModifyLicenseMilestone(context.unity_license.id, int(context.licenses_modified))))

    if tpm.is_snow_onboarding(context) and (
            tpm.item_is_tpm_add_number(item) or msoc_numbers.item_is_add_msoc_number(item)):
        milestones.append(vars(SNOWMilestone()))
    elif tpm.is_snow_offboarding(context) and (
            payload.item_is_delete_tpm_account(item) or payload.item_is_delete_msoc_account(item)):
        if hasattr(context, 'account_deprovisioned') and context.account_deprovisioned:
            milestones.append(vars(SNOWOffboardingMilestone(ucas_provider=context.ucas_provider,
                                                            op_co_customer_id=context.op_co_customer_id,
                                                            market_code=context.market_code)))
    elif payload.has_unity_add_policy(context, context.payload) and outcome == 'completed':
        milestones.append(vars(GeoRestrictionMilestone()))

    elif payload.has_modify_sso_config(context.payload) and outcome == 'completed':
        milestones.append(vars(ModifySSOMilestone()))

    if hasattr(context, 'msoc_create_customer_failed'):
        milestones.append(vars(RollbackMilestone('WAIT_FOR_JIRA_TICKET', '[1]')))

    # Expected milestones for jira ticket created
    if ("created_jira_ticket_keys" in context
            and outcome not in ["failed_billing_info_not_set", 'failed_different_billing_info']):
        for ticket_key in context.created_jira_ticket_keys:
            milestone = {
                'description': 'CREATE_JIRA_TICKET:COMPLETED',
                'message': f"Jira ticket created with key {ticket_key}",
                'status': 'COMPLETED'}
            milestones.append(milestone)

    logging.info(f"Expected milestones for {outcome}: \n {milestones}")
    return milestones


def get_patch_milestone(item):
    item = payload.get_item_to_change(item)
    message = payload.assign_path('message', item.title())
    patch_milestone = {'description': 'SERVICE_ORDER:PATCHED',
                       'message': message,
                       'status': 'COMPLETED'}
    return patch_milestone


def validate_note(payload, note, item_id):
    actual_note = common.get_field(payload, f"$.serviceOrderItem[?(@.id=='{item_id}')].service.note")
    asserts.equals(actual_note[0]['text'], note.text, 'note text')


def validate_jira_note(context, item):
    logging.debug(f'validating {item}')
    item_notes = item['service']['note']

    jira_key = jira_helper.get_jira_key_from_context(context.service_order, item['id'])
    logging.debug(f'jira_key: {jira_key}')

    ticket = jira_helper.get_ticket_by_key(jira_key, selected_fields=())

    for note in item_notes:
        if note['text'] == f"Jira ticket created with key {ticket['key']}":
            assert True
            return
        continue
    assert False, f"Jira ticket is not found for {item['service']['serviceType']}"


def validate_patch_note(patch, item):
    logging.debug(f'validating {item}')
    item_notes = item['service']['note']
    for note in item_notes:
        if note['text'] == patch['message']:
            return True


def validate_unity_create_account_notes(context, _payload, outcome):
    i, item = payload.get_item_by_type(_payload, 'ucc.unity.tenant')
    item_notes = item['service']['note']
    actual_notes_text = [note["text"] for note
                         in item_notes
                         if 'Jira' not in note['text'] and 'Automation' not in note['author']]

    expected_notes_text = [milestone["message"] for milestone in context.create_account_milestones]

    extension = common.get_field(item, "$.service.serviceCharacteristic[?(@.name=='TenantAdminInfo')].value.extension")
    if extension and outcome == "partial":
        expected_notes_text.append("Failed to update the RingCentral account extension")

    if 'failed' in outcome and 'CRF' not in outcome:
        # adding that only not for crf
        expected_notes_text.append(get_error(context, outcome)["message"])
    elif 'Add_MainNumber_failed' in outcome:
        expected_notes_text.append(f'Added numbers to pool [{context.main_number}] in {context.ucas_provider}')

    # Sort before validating
    actual_notes_text = sorted(actual_notes_text)
    expected_notes_text = sorted(expected_notes_text)
    logging.info(f'Received Notes Text: {actual_notes_text}')
    logging.info(f'Expected Notes Text: {expected_notes_text}')

    asserts.equals(actual_notes_text, expected_notes_text, "Unity Account Notes")


def validate_add_numbers_notes(context, response_payload, outcome):
    item_notes = []
    service_type = 'ucc.unity.numbers'
    if msoc_numbers.has_add_msoc_numbers(response_payload):
        service_type = 'ucc.msoc.numbers'
    for item in payload.get_items_by_type(response_payload, service_type):
        logging.debug(f'item {item}')

        item_notes.extend(item['service']['note'])
    logging.debug(f'item_notes {item_notes}')
    milestones = context.add_numbers_milestones
    if hasattr(context, "duplicated_numbers"):
        milestones.append({
            "text": f"Duplicated numbers removed from request {context.duplicated_numbers}"
        })
    logging.debug(f'expected milestones: {milestones}')
    add_numbers_notes = []
    for note in item_notes:
        if 'Jira' in note['text'] or 'Automation Tool' in note['text']:
            continue
        add_numbers_notes.append(note)
        # note_num_list = re.findall(r"\+\d+", note['text'])
        # mil_num_list = re.findall(r"\+\d+", milestones[i]['message'])
        # asserts.equals(sorted(note_num_list), sorted(mil_num_list), "numbers in note")
    logging.debug(f'outcome {outcome}')
    if 'failed_add_pool_number' in outcome or outcome in ("failed_billing_info_not_set", "failed_invalid_cac"):
        milestones = ['we expect only one error note for negative add number scenarios']

    if 'failed_msoc_add_numbers' in outcome:
        i, item = payload.get_item_by_type(response_payload, 'ucc.msoc.numbers')
        milestones = ['we expect only one error note for negative add number scenarios']
        item_notes = item['service']['note']
        logging.info(f'item notes: {item_notes}')
        for i, note in enumerate(item_notes):
            if 'Failed to add numbers' in note['text']:
                asserts.equals(note['text'], response_payload['serviceOrderItem'][i]['errorMessage'][0]['message'],
                               "notes")
    asserts.equals(len(milestones), len(add_numbers_notes), "number of milestones")
    return None


def get_service_order(service_order_id):
    response = api_requests.get(SERVICE_ORDER_URL + service_order_id,
                                headers={"Authorization": api_requests.AuthType.VALID})
    return json.loads(response.text)


def validate_msoc_create_account_notes(context, _payload, outcome):
    if 'completed' in outcome:
        _, item = payload.get_item_by_type(_payload, 'ucc.msoc.customer')
        item_notes = item['service']['note']
        logging.debug(f'Expected milestones: {context.create_msoc_customer_milestones}')
        logging.info(f'Received item notes: {item_notes}')
        for note in item_notes:
            if 'Jira' in note['text']:
                logging.info(f"Skipping note validation fot 'Jira', '{note['text']=}")
                continue

            logging.info(f"Validating note containing text '{note['text']}'")
            for milestone in context.create_msoc_customer_milestones:
                if milestone["message"] == note["text"]:
                    logging.info(f"Found a milestone with message matching note text '{note['text']}'")
                    break
            else:
                raise Exception(f"Could not find milestone with message matching note text")

    elif outcome in ['duplicate_opco_customer_id', 'duplicate_ms_teamns_tenant_id']:
        i, item = payload.get_item_by_type(_payload, 'ucc.msoc.customer')
        item_notes = item['service']['note']
        logging.info(f'item notes: {item_notes}')
        for i, note in enumerate(item_notes):
            if 'Failed to create MSOC Customer' in note['text']:
                continue
            asserts.equals(note['text'], _payload[i]['serviceOrderItem']['errorMessage']['message'])

    elif outcome == 'failed_to_add_billing_info':
        i, item = payload.get_item_by_type(_payload, 'ucc.msoc.country-billing')
        item_notes = item['service']['note']
        logging.info(f'item notes: {item_notes}')
        for i, note in enumerate(item_notes):
            if 'Customer has not been onboarded' in note['text']:
                continue
            asserts.equals(note['text'], _payload[i]['serviceOrderItem']['errorMessage']['message'])


def validate_msoc_country_billing_notes(context, _payload, outcome):
    i, item = payload.get_item_by_type(_payload, 'ucc.msoc.country-billing')
    item_notes = item['service']['note']

    if outcome == 'failed_different_billing_info':
        i, item = payload.get_item_by_type(_payload, 'ucc.msoc.country-billing')
        item_notes = item['service']['note']
        logging.info(f'item notes: {item_notes}')
        for i, note in enumerate(item_notes):
            if 'MSOC Customer already has billing information for DE' in note['text']:
                continue
            asserts.equals(note['text'], _payload['serviceOrderItem'][0]['errorMessage'][0]['message'],
                           'note for different billing info')


def validate_msoc_numbers_notes(context, _payload, outcome):
    if outcome == 'failed':
        i, item = payload.get_item_by_type(_payload, 'ucc.msoc.numbers')
        item_notes = item['service']['note']
        logging.info(f'item notes: {item_notes}')


def validate_delete_numbers_notes(context, response_payload, outcome):
    item_notes = []
    service_type = 'ucc.unity.numbers'
    if msoc_numbers.has_delete_msoc_numbers(response_payload):
        service_type = 'ucc.msoc.numbers'
    for item in payload.get_items_by_type(response_payload, service_type):
        logging.debug(f'item {item}')

        item_notes.extend(item['service']['note'])
    logging.debug(f'item_notes {item_notes}')
    milestones = context.delete_numbers_milestones
    logging.debug(f'expected milestones: {milestones}')
    delete_numbers_notes = []
    for note in item_notes:
        if 'Jira' in note['text'] or 'Automation Tool' in note['text']:
            continue
        delete_numbers_notes.append(note)
    logging.debug(f'outcome {outcome}')
    if 'failed_delete_pool_number' in outcome:
        milestones = ['we expect only one error note for negative delete number scenarios']

    if 'failed_msoc_delete_numbers' in outcome:
        i, item = payload.get_item_by_type(response_payload, 'ucc.msoc.numbers')
        milestones = ['we expect only one error note for negative delete number scenarios']
        item_notes = item['service']['note']
        logging.info(f'item notes: {item_notes}')
        for i, note in enumerate(item_notes):
            if 'Failed to delete numbers' in note['text']:
                asserts.equals(note['text'], response_payload['serviceOrderItem'][i]['errorMessage'][0]['message'],
                               "notes")
    asserts.equals(len(milestones), len(delete_numbers_notes), "number of milestones")
    return None


def validate_bgid_in_service_order(response_payload, bgid):
    item = payload.get_item_by_type(response_payload, 'ucc.tpm.customer')[1]
    asserts.equals(item['service']['serviceCharacteristic'][0]['value']['bgid'], bgid, "BGID generated in SO")


def validate_tpm_create_customer_notes(service_order, status, bgid=None):
    item = payload.get_item_by_type(service_order, 'ucc.tpm.customer')[1]
    item_notes = item['service']['note']
    if status == 'completed':
        expected_note = f"TPM Customer created in Middleware: {bgid}"
    elif status == 'failed_duplicate_customer':
        expected_note = "Customer has already been onboarded"
    elif status == 'failed_duplicate_tenant':
        expected_note = "Failed to create TPM Customer in Middleware"
    else:
        raise NotImplementedError

    asserts.equals(item_notes[0]['text'], expected_note, "Note for tpm customer")


def validate_tpm_add_number_notes(service_order, status, pool, snow_onboarding):
    item = payload.get_item_by_type(service_order, 'ucc.tpm.numbers')[1]
    item_notes = item['service']['note']
    expected_notes = []
    if status == 'completed':
        expected_notes.append("Notification of new TPM service sent")
        expected_notes.append(pool)
        if snow_onboarding:
            expected_notes.append("Customer service created in SNOW")
    elif status == 'failed_non_existing_tpm_account':
        expected_notes.append('Customer has not been onboarded')
    for note in item_notes:
        if "Added numbers to pool" in note['text']:
            note['text'] = milestone_validator.parse_pool_numbers(note['text'])
        asserts.in_list(note['text'], expected_notes, "Note for tpm add numbers")


class RollbackMilestone:
    def __init__(self, failed_service_order_operation, service_order_item_id):
        self.message = f"Rollback initiated for service order item {service_order_item_id}"
        self.description = f"{failed_service_order_operation}:FAILED"


class DependentOrderItemCancelledNote:
    def __init__(self, service_order_item, service_order_item_id):
        self.text = f"Cancelled because dependent Service Order Item {service_order_item}/{service_order_item_id} did not complete successfully"
