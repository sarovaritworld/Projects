import logging
from typing import Any

from classes import read_xmldata, payload, common, utils
from classes.api.requests import idmapper

logger = logging.getLogger(__name__)

ACCOUNT_NOT_FOUND_DB_ERROR = ("ID Mapper lookup failed for market '{market_code}' "
                              "and customerId '{op_co_customer_id}' "
                              "with status 404 NOT_FOUND and reason: Customer has not been onboarded")

CONFIRMATION_ACCOUNT_FAIL = 'CONFIRMATION_ACCOUNT_FAIL'

# An account already created, with a long name (expected to be truncated)
LONG_NAME_ACCOUNT = {
    "account_number": "88540459734",
    "company_name": "Test_Automation_To_Test_Name_Character_Length_More_Than_Fifty",
}

EXISTING_UNITY_ACCOUNT = {
    "account_number": "88207144555"
}

# DEP has provided this tenant ID for testing in staging environment
# If Tenant ID changes, a new account number has to be created in Middleware
# and staging_opco_account and staging_bgid has to be updated
EXISTING_TPM_CUSTOMER = {
    "account_number": "88820116994",
    "staging_opco_account": "TPM88830724",
    "staging_tenant": "ef58a18d-c98b-473d-b0df-47083042a9fa",
    "staging_bgid": "1228100122",
    "staging_itsm_tenant": "a4a19c1b-a945-4490-a98a-576c2b827f32",
    "ceased_account_number": "88114164424"
}

EXISTING_MSOC_CUSTOMER = {
    "ceased_account_number": "88114304400"
}
# Account already created with Local Market Service ID
# Invalid LMSID - not matching the regex ^[0-9A-Za-z-]{1,20}$
EXISTING_LOCAL_MARKET_SERVICE_ID = {
    "account_number": "88108196185",
    "existing_lmsid": "kHoDWw",
    "invalid_lmsid": "abc!XYZ"
}


def generate_account_fail_confirmation():
    return CONFIRMATION_ACCOUNT_FAIL + read_xmldata.gen_contact(10)


def create_account_if_doesnt_exist(
        context: Any,
        vodafone_id: str | None,
        product_type: str = 'FULL_STACK_STANDARD',
        market_code: str = 'VFUK',
        confirmation_status: str = 'confirmed') -> None:
    """
    Checks if account with given vodafone_id already exists using id mapper
    If YES: RC_ID is saved to context
    If NO: creates a new account op_co_customer_id and RC_ID is saved to context
        and reusable_accounts.json is updated with new account to be used in subsequent tests
    @param context:
    @param product_type:
    @param vodafone_id: op_co_customer_id
    @param market_code:
    @param confirmation_status: default 'confirmed'
    """
    logger.debug(f"create_account_if_doesnt_exist: "
                 f"{product_type=}, {vodafone_id=}, {market_code=}, {confirmation_status=}")
    if vodafone_id is not None:
        context.op_co_customer_id = vodafone_id
        account = idmapper.Client(vodafone_id=context.op_co_customer_id, market_code=market_code).get_account()
        account_creation_needed = not account.exists
        if account.exists:
            context.RC_ID = account.ringcentral_id()
            logger.info(f"account with {context.op_co_customer_id=} exists, saving rc_id to context {context.RC_ID=}")
    else:
        account_creation_needed = True

    if account_creation_needed:
        create_new_account(context, product_type, market_code, confirmation_status)
        search_filter = {
            'environment': common.config.ENVIRONMENT,
            'market_code': market_code,
            'confirmation_status': confirmation_status
        }
        update_reusables_accounts(search_filter, context.op_co_customer_id)


def create_new_account(context: Any, product_type: str, market_code: str, confirmation_status: str) -> None:
    """
    Creates a new account
    @param context:
    @param product_type:
    @param market_code:
    @param confirmation_status:
    """
    payload.prepare_account_payload(context, 'add', product_type, market_code)
    if confirmation_status == 'unconfirmed':
        payload.update_payload_activate_immediately(context, False)
    context.execute_steps("""
        When customer sends an order to Middleware
    """)
    logger.info(f"New account created {context.op_co_customer_id=}, {context.RC_ID=}")


def read_all_reusable_accounts() -> list[dict] | None:
    """
    Reads the reusable_accounts.json into a list of dict
    :return: list of account items as in reusable_accounts.json
    """
    account_filename = "reusable_accounts.json"
    accounts_data = read_xmldata.read_jsonfile(account_filename, "./testdata/")
    if accounts_data and "accounts" in accounts_data:
        return accounts_data["accounts"]
    else:
        logger.error(f"Could not read account data from {account_filename=}")


def get_reusable_account(filter_dict: dict) -> dict:
    """
    Finds and returns first matching account item as per filter dict
    :param filter_dict:
    :return: First matching account
    """
    logger.debug(f"get_reusable_account: {filter_dict=}")
    reusable_accounts = read_all_reusable_accounts()
    return common.find_item(reusable_accounts, filter_dict)


def get_matching_reusable_accounts(filter_dict: dict) -> list[dict]:
    """
    Finds and returns all matching account items as per filter_dict
    :param filter_dict:
    :return: A list of all matching accounts
    """
    logger.debug(f"get_matching_reusable_accounts: {filter_dict=}")
    reusable_accounts = read_all_reusable_accounts()
    return common.find_matching_items(reusable_accounts, filter_dict)


def get_reusable_account_number(filter_dict: dict) -> str | None:
    """
    Gets the reusable account number (vodafone id OR op_co_customer_id) for given filter
    @param filter_dict:
    @return: account number of the first matching record or None
    """
    matching_account = get_reusable_account(filter_dict)
    if matching_account:
        logger.info(f"Found a reusable account {utils.to_json(matching_account)}")
        return matching_account['account_number']
    else:
        logger.info(f"No account found for {filter_dict=}")


def get_numbers_added_to_reusable_account(op_co_customer_id: str) -> list[str] | None:
    """
    Get the list added numbers to a reusable account if available
    :param op_co_customer_id:
    :return:
    """
    matching_account = get_reusable_account({"account_number": op_co_customer_id})
    if matching_account:
        logger.info(f"Found a reusable account {utils.to_json(matching_account)}")
        if "added_numbers" in matching_account:
            logger.info(f"added_numbers: {matching_account['added_numbers']}")
            return matching_account["added_numbers"]
        else:
            logger.warning(f"added_numbers not available for account {op_co_customer_id}")


def get_numbers_added_to_account_except(filter_dict: dict, except_customer_id: str) -> list[str] | None:
    """
    Finds matching accounts and returns the list of numbers added to different account (except op_co_customer_id)
    :param filter_dict:
    :param except_customer_id:
    :return:
    """
    # Find numbers added to some different account than this from reusable account json
    accounts = get_matching_reusable_accounts(filter_dict)
    logger.debug(f"get_numbers_added_to_account_except: {accounts=}, {except_customer_id=}")
    added_numbers_to_different_account = None
    for acc in accounts:
        if acc["account_number"] != except_customer_id and "added_numbers" in acc:
            logger.debug(f"{acc['account_number']}, {acc['added_numbers']=}")
            added_numbers_to_different_account = acc["added_numbers"]
    if added_numbers_to_different_account:
        return added_numbers_to_different_account
    else:
        logger.warning(f"number added to account except {except_customer_id} were not in the reusable accounts")


def update_reusables_accounts(filter: dict, account_number: str) -> None:
    """
    Updates the reusables accounts json with new account number to be used
    in subsequent test scenarios.
    If matching account details is found account number is updated to the existing record.
    If no matching record is found new account is added.
    @param filter:
    @param account_number: new account number
    """
    logger.debug(f"update_reusables_accounts: {filter=}, {account_number=}")
    account_filename = "reusable_accounts.json"
    filepath = "./testdata/"
    json_data = read_xmldata.read_jsonfile(account_filename, filepath)
    account_update_successful = common.find_item_and_update(json_data['accounts'], filter,
                                                            {'account_number': account_number})

    if not account_update_successful:
        logger.info("Matching account was not found in the account json file, adding a new entry.")
        filter['account_number'] = account_number
        json_data['accounts'].append(filter)

    # Overwrite the reusable_accounts.json file with updated accounts
    read_xmldata.write_jsonfile(account_filename, json_data, filepath)
