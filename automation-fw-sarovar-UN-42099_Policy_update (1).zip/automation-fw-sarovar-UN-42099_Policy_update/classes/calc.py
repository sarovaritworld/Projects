def add(number1, number2):
    return int(number1 + number2)

def subtract(number1, number2):
    return int(number1 - number2)
