import logging
from email import policy
from email.parser import BytesParser

import boto3
from botocore.exceptions import ClientError

from classes import common

bucket_prefix = "unity-development" if common.Config.is_dev_env else "ucc-test"
BUCKET_NAME = f"vgsl-{bucket_prefix}-euwest1-workload-s3.email-out"
LATEST_MAIL_QUANTITY = 20


def get_email(search_property, number_of_emails: None | int = None, search_in='Subject'):
    try:
        session = boto3.Session()
        s3_client = session.client('s3')
        s3 = boto3.resource('s3')
        my_bucket = s3.Bucket(BUCKET_NAME)
        files = my_bucket.objects.filter()
        last_added = [obj.key for obj in sorted(files, key=lambda x: x.last_modified,
                                                reverse=True)]
    except ClientError:
        raise "Client Error Occurred: S3 resource not available"
    msg_list = []
    start_time = int(common.Config.feature_start_time)
    logging.info(f"Total number of mails in Bucket {len(last_added)}")
    for index, key in enumerate(last_added[0:LATEST_MAIL_QUANTITY]):
        logging.info(f"Key: {key}")
        object_data = s3_client.get_object(Bucket=BUCKET_NAME, Key=key)
        email_raw_string = object_data['Body'].read()

        msg = BytesParser(policy=policy.default).parsebytes(email_raw_string)
        logging.info(f"Subject: {msg['Subject']}")
        logging.info(f"Checking for {object_data['LastModified'].strftime('%s')} < {start_time}")
        if int(object_data['LastModified'].strftime('%s')) < start_time:
            break
        search_data = msg['Subject']
        if search_in != 'Subject':
            search_data = msg.get_body().get_content()
        if search_property in search_data:
            msg_list.append(msg)
        if number_of_emails and len(msg_list) == number_of_emails:
            return msg_list
        elif index == (LATEST_MAIL_QUANTITY - 1):
            logging.warning("Mail not found in latest mails. You might need to increase LATEST_MAIL_QUANITY")
    return msg_list
