from dataclasses import dataclass
from enum import Enum, StrEnum
from typing import List


class ResourceType(StrEnum):
    def is_pool(self):
        return True if self.name == 'pool' else False

    def is_range(self):
        return True if self.name == 'pool_range' else False


class UsageType(Enum):
    CallingUserAssignment = 1
    FirstPartyAppAssignment = 2


class UnityResourceType(ResourceType):
    pool = 'UccTenantPool'
    pool_range = 'UccTenantPoolRange'


class MsocResourceType(ResourceType):
    pool = 'UccMsocNumberPool'
    pool_range = 'UccMsocNumberPoolRange'


class TpmResourceType(ResourceType):
    pool = 'UccTpmNumberPool'
    pool_range = 'UccTpmNumberPoolRange'


class PoolType(StrEnum):
    Fixed = 'FIXED'
    Presentation = 'PRESENTATION'
    FMC = 'FMC'
    Mobile = 'MOBILE'


class NMPoolType(StrEnum):
    fw_pool = PoolType.Presentation
    pool = PoolType.Fixed


@dataclass
class NumbersOrderItem:
    """ Holds information about service order item which orders numbers """
    quantity: int = 5
    pool_type: PoolType | NMPoolType = PoolType.Fixed
    resource_type: ResourceType | TpmResourceType | UnityResourceType | MsocResourceType = None
    pool: List = None
    from_range_number: str = None
    to_range_number: str = None
    carrier_id: str = None


@dataclass
class UnityNumbers(NumbersOrderItem):
    """
    Holds Unity specific fields
    https://confluence.tools.aws.vodafone.com/display/UCP/ucc.unity.numbers
    """
    name: str = 'TenantPool'
    site_id: str = None
    activation_status: str = None


@dataclass
class MSOCNumbers(NumbersOrderItem):
    """
    Holds MSOC specific fields
    https://confluence.tools.aws.vodafone.com/display/UCP/MSOC+Use+Cases#MSOCUseCases-Service:ucc.msoc.numbers
    """
    usage_type: UsageType = UsageType.CallingUserAssignment.name
    capability = "InboundCalling"
    emergency_address_location_id = "ID1"


@dataclass
class TPMNumbers(NumbersOrderItem):
    """
    Holds TPM specific fields
    https://confluence.tools.aws.vodafone.com/display/UCP/TPM+Services#TPMServices-Service:ucc.tpm.numbers
    """
    pool_type: PoolType = PoolType.Mobile
