from classes import read_xmldata
from classes.payload import assign_path


def update_patch_message(payload, param, item_to_change):
    payload[1]["value"]["text"] = payload[2]["value"]["message"] = assign_path(param, item_to_change.title())
    return payload


def create_payload_for_patch(order_type, item_to_change):
    payload = read_xmldata.read_jsonfile(order_type)
    payload[1]["value"]["date"] = read_xmldata.get_current_datetime()
    if order_type == "update_service_order_with_error":
        payload[2]["value"]["timestamp"] = read_xmldata.get_current_datetime()
        update_patch_message(payload, 'errormessage', item_to_change)
    else:
        payload[2]["value"]["milestoneDate"] = read_xmldata.get_current_datetime()
        update_patch_message(payload, 'message', item_to_change)
    return payload
