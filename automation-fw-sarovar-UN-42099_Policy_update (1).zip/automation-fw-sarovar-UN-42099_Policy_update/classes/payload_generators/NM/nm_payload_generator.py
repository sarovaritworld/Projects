from dataclasses import dataclass

from classes import numbers
from classes.domain.numbers import ResourceType, NMPoolType, NumbersOrderItem


class NMResourceType(ResourceType):
    pool = 'pool'
    pool_range = 'pool_range'


@dataclass
class NumberManagementPayload:
    main_number: bool | str = None
    admin_number: bool | str = None
    market_code: str = 'VFUK'
    pools: bool | list[NumbersOrderItem] = None

    def __post_init__(self):

        if not isinstance(self.main_number, str) and self.main_number is not False:
            self.main_number = numbers.generate_phone_number(self.market_code)
        if not isinstance(self.admin_number, str) and self.admin_number is not False:
            self.admin_number = numbers.generate_phone_number(self.market_code)
        if not isinstance(self.pools, list) and self.pools is not False:
            self.pools = [NumbersOrderItem(quantity=5,
                                           resource_type=NMResourceType.pool,
                                           pool_type=NMPoolType.pool),
                          NumbersOrderItem(quantity=5,
                                           resource_type=NMResourceType.pool_range,
                                           pool_type=NMPoolType.fw_pool)
                          ]

    def to_dict(self):
        payload = {}

        if bool(self.main_number) is not False:
            payload['main_number'] = self.main_number
        if bool(self.admin_number) is not False:
            payload['admin_number'] = self.admin_number
        if bool(self.pools) is not False:
            for pool in self.pools:
                if pool.pool is None:
                    pool.generate_numbers(self.market_code)
                l = payload.get(pool.pool_type.name, [])
                if pool.resource_type.is_range():
                    n = {'start': pool.from_range_number,
                         'end': pool.to_range_number}
                    l.append(n)
                elif pool.resource_type.is_pool():
                    assert len(self.pools) <= 1, "Only 1 pool of numbers is supported"
                    l = pool.pool
                payload[pool.pool_type.name] = l
        return payload
