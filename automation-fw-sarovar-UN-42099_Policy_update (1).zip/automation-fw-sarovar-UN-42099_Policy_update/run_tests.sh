#!/bin/bash

export PYTHONPATH=.:$PYTHONPATH
log_dir="execution_logs"
user_tag=$1
if [ -n "$user_tag" ]
then
    if [ ! -d $log_dir ]
    then
      mkdir -p $log_dir
      echo "INFO: Directory $log_dir created."
    fi
    now=$(date "+%Y%m%d%H%M%S")
    log_file=$log_dir/$user_tag-$now.log
    python appdirectRunner.py --tags=$user_tag 2>&1 | tee -a $log_file
else
  echo "Usage: $0 <tags>"
  exit 1
fi