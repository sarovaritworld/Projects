import json
import argparse

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--tags', required=True, help="TC ID")
    args = parser.parse_args()
    tags = args.tags

class style():
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'


jsonFile = open("./report_"+tags+".json", "r")
data_list = json.load(jsonFile)
jsonFile.close()


def get_failures():
    for curr_dict in data_list:
        feature_name = curr_dict["name"]
        elements_list = curr_dict["elements"]
        for element_dict in elements_list:
            tag_name = element_dict['tags']
            test_name = element_dict['name']
            for step_dict in element_dict["steps"]:
                step_name = step_dict["name"]
                try:
                    result_dict = step_dict["result"]
                    if result_dict['status'] == "failed":
                        display_error = result_dict['error_message']
                        print(style.GREEN, f"Feature Name: {feature_name}\n",
                              style.YELLOW, f"Tags: {tag_name}\n",
                              style.BLUE, f"Test Name: {test_name}\n",
                              style.CYAN, f"Step Name: {step_name}")
                        print(style.RED, display_error)
                except:
                    error_list = result_dict.get("error_message")


def count_test_results():
    feature_passed_count = 0
    feature_failed_count = 0
    test_passed_count = 0
    test_failed_count = 0
    for current_list in data_list:
        elements_list = current_list["elements"]
        if current_list['status'] == 'passed':
            feature_passed_count += 1
        elif current_list['status'] == 'failed':
            feature_failed_count += 1
        else:
            raise Exception(
                "Unexpected status for feature. Expected 'passed' or 'failed' but found '{}'".format(current_list['status']))
        for element_dict in elements_list:
            if element_dict['status'] == 'passed':
                test_passed_count += 1
            elif element_dict['status'] == 'failed':
                test_failed_count += 1
            else:
                raise Exception(
                    "Unexpected status for feature. Expected 'passed' or 'failed' but found '{}'".format(element_dict['status']))
    print(f"\n\n")
    print(style.BLUE, f"Total Features: {feature_failed_count+feature_passed_count}\n",
          style.GREEN, f"Features Passed: {feature_passed_count}\n",
          style.RED, f"Features Failed: {feature_failed_count}\n",
          style.RESET)
    print(style.BLUE, f"Total Tests: {test_failed_count+test_passed_count}\n",
          style.GREEN, f"Passed Tests: {test_passed_count}\n",
          style.RED, f"Failed Tests:{test_failed_count}\n",
          style.RESET)


get_failures()
count_test_results()
