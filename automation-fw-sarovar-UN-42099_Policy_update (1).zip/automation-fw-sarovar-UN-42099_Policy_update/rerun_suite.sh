#!/bin/bash

export PYTHONPATH=.:$PYTHONPATH

python appdirect_stub.py --tags=$1 &
behave features/ --tags=$1 -k --no-capture -f json.pretty_custom -o report_$1.json -f pretty_custom --junit
python PrintFailures.py --tags=$1
python report_generator.py --input_json_file report_$1.json --output_html_file report_$1.html
if test -f "rerun_failing.features"; then
  python appdirect_stub.py --tags=$1 &
  behave @rerun_failing.features -k --no-capture -f json.pretty_custom -o report_rerun_failing_$1.json -f pretty_custom --junit
  python PrintFailures.py --tags=rerun_failing_$1
  python report_generator.py --input_json_file report_rerun_failing_$1.json --output_html_file report_rerun_failing_$1.html
fi
if test -f "rerun_failing.features"; then
  echo "Test failing after rerun"
  exit 1
fi
