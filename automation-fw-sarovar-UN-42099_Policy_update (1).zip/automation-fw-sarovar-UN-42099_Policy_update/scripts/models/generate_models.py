#!/usr/bin/env python
"""
Generate pydantic models from an API definition

Usage:
    $ pip install datamodel-code-generator[http] pydantic python-gitlab PyYAML requests
    $ GITLAB_TOKEN='123456789' scripts/models/generate_models.py

The GITLAB access token must have scope 'read_api' or 'api' (or 'all'):
    https://gitlab-ucc.tools.aws.vodafone.com/-/profile/personal_access_tokens

Links:
  - Gitlab API: https://docs.gitlab.com/ee/api/api_resources.html
"""
from __future__ import annotations

import logging
import os
import shlex
import subprocess
import tempfile
from datetime import datetime
from typing import TYPE_CHECKING, cast

import gitlab
import requests
import yaml
from pydantic import BaseModel

if TYPE_CHECKING:
    from gitlab.v4.objects.projects import Project


CONFIG = [
    # project_name must be exactly as displayed on the home page of the project
    {"project_name": "TMF Gateway API Schemas", "file_path": "api/TMF641-ServiceOrdering-v4.1.0.swagger.json"},
    {"project_name": "CRF Gateway", "file_path": "openapi.yaml"},
    {"project_name": "Email Management API", "file_path": "openapi.yaml"},
    {"project_name": "Email Sender API", "file_path": "openapi.yaml"},
    {"project_name": "ID Mapper API", "file_path": "openapi.yaml"},
    {"project_name": "Number Management API", "file_path": "openapi.yaml"},
    {"project_name": "RingCentral Gateway", "file_path": "openapi.yml"},
    {"project_name": "TMF Service Inventory Gateway API", "file_path": "openapi.yaml"},
    {"project_name": "TMF Service Order Gateway API", "file_path": "openapi.yaml"},
]
BRANCH = "master"
GITLAB_HOST = "https://gitlab-ucc.tools.aws.vodafone.com"
GITLAB_TOKEN = os.getenv("GITLAB_TOKEN", "")
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_TOP_DIR = os.path.join(THIS_DIR, "..", "..")
MODELS_DIR = os.path.join(REPO_TOP_DIR, "models")

logger = logging.getLogger()


def main():
    assert GITLAB_TOKEN, "Missing environment variable GITLAB_TOKEN"
    gl = gitlab.Gitlab(GITLAB_HOST, private_token=GITLAB_TOKEN)

    errors = []
    for config in CONFIG:
        try:
            process_project(config, gl)
        except Exception as ex:
            msg = f"{config['project_name']}: {ex}"
            errors.append(msg)
            logger.error(msg)

    for msg in errors:
        logger.error(msg)


def process_project(config: dict, gl: gitlab.Gitlab) -> None:
    logger.info(f"=== project: {config["project_name"]}")
    logger.info(f"Download Project information")
    project = cast(list["Project"], gl.projects.list(search=config["project_name"]))[0]

    logger.info(f"Get latest commit where this file was modified")
    response = requests.get(
        url=f"{GITLAB_HOST}/api/v4/projects/{project.id}/repository/commits",
        params=dict(ref_name=BRANCH, path=config["file_path"], page=1, per_page=1),
        headers={"PRIVATE-TOKEN": GITLAB_TOKEN})
    response.raise_for_status()
    commit = Commit(**response.json()[0])

    logger.info(f"Download API definition file: {config["file_path"]}")
    api_def_content = project.files.get(file_path=config["file_path"], ref=commit.short_id)\
        .decode().decode("utf-8")
    # Fix minor formatting issues in input API definition files
    api_def_content = api_def_content.replace("\t", " ").replace("\xe9", "e").replace(r"\_", "_")
    api_def_file = os.path.join(tempfile.gettempdir(), project.path + "_" + os.path.basename(config["file_path"]))
    with open(api_def_file, "w") as f:
        f.write(api_def_content)

    file_header = generate_file_header(project, commit, config)
    output_file = project.path.replace("-", "_") + ".py"
    generate_models(api_def_file, file_header, output_file)


def generate_file_header(project: Project, commit: Commit, config: dict) -> str:
    return f'''"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : {config["project_name"]}
  API definition : {project.web_url}/-/blob/master/{config["file_path"]}
  Commit         : {commit.short_id}  (on {commit.committed_date.strftime('%Y-%m-%d')})
  Commit title   : {commit.title}

Generated with script: {os.path.relpath(__file__, REPO_TOP_DIR).replace("\\", "/")}
"""'''


def generate_models(api_def_file: str, file_header: str, output_file: str) -> None:
    output_path = os.path.join(MODELS_DIR, output_file)
    logger.info(f"Generate Pydantic models: {output_path}")

    with open(api_def_file, "r") as f:
        data = yaml.safe_load(f)

    if data.get("swagger", "").startswith("2"):
        logger.info("Input format is Swagger2")
        cmd = [
            "python", os.path.join(THIS_DIR, "generate_models_from_swagger2.py"),
            "--input", api_def_file,
            "--output", output_path,
            "--additional-imports", ".utils.base_configuration",
            "--custom-file-header", file_header,
        ]
    elif data.get("openapi", "").startswith("3"):
        # datamodel-codegen only supports openapi 3 (or newer)
        logger.info("Input format is openapi3")
        cmd = [
            "datamodel-codegen",
            "--input", api_def_file,
            "--output", output_path,
            "--output-model-type", "pydantic_v2.BaseModel",

            # our configuration of BaseModel
            "--additional-imports", ".utils.base_configuration",

            # add docstrings (from description)
            "--use-field-description", "--use-schema-description",

            # keep enum types
            "--use-subclass-enum",

            # do not duplicate model definition
            "--reuse-model",

            # formatting
            "--target-python-version=3.12",
            "--use-union-operator",
            "--use-double-quotes",
            "--capitalize-enum-members",
            "--use-default-kwarg",
            "--encoding", "utf-8",
            "--custom-file-header", file_header,
        ]
    else:
        raise Exception(f"Unknown API definition format")

    logger.debug("Executing command:\n  $ " + " ".join([shlex.quote(c) for c in cmd]))
    proc: subprocess.CompletedProcess = subprocess.run(cmd, capture_output=True)
    logger.info(f"    output:\n{proc.stdout+proc.stderr}")
    assert proc.returncode == 0, \
        f"Could not generate model {output_file} from {api_def_file}: {proc.stdout+proc.stderr}"


class Commit(BaseModel, extra="ignore"):
    short_id: str
    committed_date: datetime
    title: str


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    main()


