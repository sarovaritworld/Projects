import argparse
import os
import sys

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_TOP_DIR = os.path.join(THIS_DIR, "..")
sys.path.append(REPO_TOP_DIR)

from classes import pod

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--pod', required=True, help="Name of pod")
    parser.add_argument('--search_value', required=False, help="log should contain this value")

    args = parser.parse_args()
    pod_name = args.pod
    search_value = args.search_value

    print(pod_name)
    print(search_value)

    pod_logs = pod.read_logs(pod_name).split('\n')
    with open(pod_name + ".txt", "w") as f:
        if search_value:
            for log in pod_logs:
                if search_value in log:
                    print(log)
                    f.write(log + '\n')
        else:
            for log in pod_logs:
                print(log)
                f.write(log + '\n')
