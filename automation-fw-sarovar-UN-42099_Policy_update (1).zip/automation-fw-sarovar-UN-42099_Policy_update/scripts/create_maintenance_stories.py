import argparse
import os
import sys

import yaml
from jira import JIRA

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_TOP_DIR = os.path.join(THIS_DIR, "..")
sys.path.append(REPO_TOP_DIR)

from classes import data

def get_cli_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Create maintainer stories into PI TechDebt Feature")
    parser.add_argument("-o",
                        "--pi-number",
                        required=True,
                        help="PI number")
    parser.add_argument("-p",
                        "--parent-issue",
                        required=True,
                        help="technical debt to solve issue key (like UN-123)")
    parser.add_argument("-n",
                        "--number-of-sprints",
                        default=5,
                        help="number of sprints (to create)")
    parser.add_argument("-r",
                        "--dry-run",
                        action='store_true',
                        help="use if you need to dry-run")
    return parser.parse_args()


def create_maintenance_issues(pi_number, parent_issue, number_of_sprints, dry_run):
    # connect to JIRA token read from secret
    token = data.get_jira_processor_credentials()[1]

    def load_config(filepath):
        with open(filepath, "r") as f:
            return yaml.safe_load(f)

    try:
        # will try to use testing_tools setting file, local if fails
        config = load_config(f'{REPO_TOP_DIR}/testing_tools/scripts/jira/jira_processor.yml')
    except FileNotFoundError:
        config = load_config(f'{REPO_TOP_DIR}/config/jira_processor.yml')
    jira_processor = JIRA(config['jira_base_url'], token_auth=token)

    stories_data = {
        "Nightly run support": "As a automation tester, I would like to fix/update all the regression test scripts that are affected because of new changes in design/tech debt or new features.",
        "Pipeline check support": "As a automation tester, I would like to monitor pipelines and support dev and other members of team with feedback"
    }
    for name, description in stories_data.items():
        # compose issue fields
        for i in range(1, int(number_of_sprints) + 2):
            fields = {
                "description": description,
                "issuetype": {
                    "id": "10101"
                },
                "project": {'id': config['project_id']}
                ,
                "summary": f"PI-{pi_number}.{i} {name}",
                'customfield_10006': parent_issue,
                "customfield_11018": {"value": "Middleware"},
                "customfield_10002": 2.0

            }
            if i == int(number_of_sprints) + 1:
                if name == "Nightly run support":
                    # skip first 6th story
                    continue

                fields['summary'] = f"PI-{pi_number}.IP {name} and Nightly run support"
                fields['description'] = ', '.join(map(str, stories_data.values()))
            if dry_run:
                print(f'Dry mode for issue with {fields=}')
            else:
                result = jira_processor.create_issue(fields=fields)
                print(result)


if __name__ == "__main__":
    args = get_cli_arguments()
    create_maintenance_issues(args.pi_number, args.parent_issue, args.number_of_sprints, args.dry_run)
