import re
import sys

def update_tags_in_feature_file(file_path):
    print(f"Processing file: {file_path}")

    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Find the first tag
    first_tag = None
    first_tag_index = None
    for index, line in enumerate(lines):
        match = re.match(r'^\s*@(\w+)', line)
        if match:
            first_tag = match.group(1)
            first_tag_index = index
            print(f"First tag found: {first_tag} at line {first_tag_index}")
            break

    if not first_tag:
        print("No tags found in the feature file.")
        return

    scenario_count = 0
    updated_lines = []


    for index, line in enumerate(lines):
        if index == first_tag_index:
            updated_lines.append(line)  # Keep the first tag at the same place
            continue
        if re.match(r'^\s*Scenario', line):
            scenario_count += 1
            example_count = 0

            new_tag = f"@{first_tag}_{scenario_count:02d}"
            print(f"Adding tag to scenario: {new_tag}")
            updated_lines.append(f"{new_tag}\n")
            updated_lines.append(line)
        elif re.match(r'^\s*Examples', line):
            example_count += 1
            new_example_tag = f"@{first_tag}_{scenario_count:02d}_{example_count:02d}"
            print(f"Adding tag to example: {new_example_tag}")
            updated_lines.append(f"{new_example_tag}\n")
            updated_lines.append(line)
        elif re.match(r'^\s*@', line):
            continue  # Skip existing tags to avoid duplication
        else:
            updated_lines.append(line)

    with open(file_path, 'w') as file:
        file.writelines(updated_lines)

    print(f"Updated tags in {file_path}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <path_to_feature_file>")
    else:
        print(f"Arguments received: {sys.argv}")
        update_tags_in_feature_file(sys.argv[1])
