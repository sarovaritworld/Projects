import re
import sys


def replace_keywords(file_path):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()

        new_lines = []
        previous_keyword = None
        for line in lines:
            match = re.match(r'^\s*(Given|When|Then)', line, re.IGNORECASE)
            if match:
                current_keyword = match.group(1)
                if previous_keyword and previous_keyword.lower() == current_keyword.lower():
                    line = re.sub(r'^\s*(Given|When|Then)', 'And', line, flags=re.IGNORECASE)
                previous_keyword = current_keyword
            else:
                previous_keyword = None
            new_lines.append(line)

        with open(file_path, 'w') as file:
            file.writelines(new_lines)
        print(f"Keywords replaced successfully in {file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python replace_keywords.py <file_path>")
    else:
        replace_keywords(sys.argv[1])
