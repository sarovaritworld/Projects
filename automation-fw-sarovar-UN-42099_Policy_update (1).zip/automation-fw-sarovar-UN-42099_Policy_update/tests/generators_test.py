from classes import common
from classes.domain.account import Policies
from classes.domain.numbers import MSOCNumbers, MsocResourceType, NumbersOrderItem, PoolType, TpmResourceType
from classes.license import LicenseOrderItem
from classes.payload_generators.TMF import Action
from classes.payload_generators.TMF.account_generator import MSOCAccountPayloadGenerator, TPMAccountPayloadGenerator, \
    UnityAccountPayloadGenerator
from classes.payload_generators.TMF.country_billing_generator import CountryBillingGenerator
from classes.payload_generators.TMF.license_generator import LicensePayloadGenerator
from classes.payload_generators.TMF.number_generator import NumbersPayloadGenerator
from classes.payload_generators.TMF.service_characteristic_generator import \
    ItsmProvisioningServiceCharacteristicGenerator
from classes.utils import to_json
from classes.domain.account import UnityAccount
from classes.domain.account import Contact

MARKET_CODE = 'VFUK'
extension_path = "$.serviceOrderItem[*].service.serviceCharacteristic[?(@.name=='TenantAdminInfo')].value.extension"


def test_unity_account_payload():
    from classes.domain.account import UnityAccount
    unity_account = UnityAccount(market_code=MARKET_CODE)
    generator = UnityAccountPayloadGenerator(unity_account=unity_account, action=Action.add)
    payload = generator.to_dict()
    print(payload)


def test_msoc_account_payload():
    from classes.domain.account import MSOCAccount
    msoc_account = MSOCAccount(market_code=MARKET_CODE)
    generator = MSOCAccountPayloadGenerator(msoc_account=msoc_account, action=Action.add)
    payload = generator.to_dict()
    print(payload)


def test_msoc_billing_info():
    from classes.domain.account import BillingInfo
    billing_info = BillingInfo(service_identifier='NEW', customer_reference_number='123')
    from classes.domain.account import MSOCAccount
    msoc_account = MSOCAccount(market_code=MARKET_CODE, billing_info=billing_info)
    generator = CountryBillingGenerator(account=msoc_account, action=Action.add)
    payload = generator.to_dict()
    print(payload)


def test_msoc_account_and_billing_info():
    from classes.domain.account import BillingInfo
    billing_info = BillingInfo(service_identifier='NEW', customer_reference_number='123')
    from classes.domain.account import MSOCAccount
    msoc_account = MSOCAccount(market_code=MARKET_CODE, billing_info=billing_info)
    generator = MSOCAccountPayloadGenerator(msoc_account=msoc_account, action=Action.add)
    payload = generator.to_dict()
    generator_2 = CountryBillingGenerator(account=msoc_account, action=Action.add, payload=payload)
    payload = generator_2.to_dict()
    print(payload)


def test_msoc_account_with_billing_info_and_ddi():
    from classes.domain.account import BillingInfo
    billing_info = BillingInfo(service_identifier='NEW', customer_reference_number='123')
    from classes.domain.account import MSOCAccount
    msoc_account = MSOCAccount(market_code=MARKET_CODE, billing_info=billing_info)
    generator = MSOCAccountPayloadGenerator(msoc_account=msoc_account, action=Action.add)
    msoc_account_payload = generator.to_dict()

    msoc_billing_info_payload = CountryBillingGenerator(account=msoc_account, action=Action.add,
                                                        payload=msoc_account_payload)
    payload = msoc_billing_info_payload.to_dict()

    requested_numbers = MSOCNumbers(quantity=5,
                                    resource_type=MsocResourceType.pool_range,
                                    pool_type=PoolType.Presentation)
    generator_2 = NumbersPayloadGenerator(account=msoc_account,
                                          requested_numbers=requested_numbers,
                                          action=Action.add,
                                          payload=payload)
    payload = generator_2.to_dict()
    print(payload)


def test_append_characteristic():
    from classes.domain.account import MSOCAccount
    from classes.domain.account import ItsmProvisioning
    msoc_account = MSOCAccount(market_code=MARKET_CODE, itsm_provisioning=ItsmProvisioning())
    generator = MSOCAccountPayloadGenerator(msoc_account=msoc_account, action=Action.add)
    generator.account_item.update_service_characteristic(
        ItsmProvisioningServiceCharacteristicGenerator(msoc_account).to_dict())
    payload = generator.to_dict()
    print(to_json(payload))


def test_tpm_account_payload():
    from classes.domain.account import TPMAccount
    tpm_account = TPMAccount(market_code=MARKET_CODE)
    generator = TPMAccountPayloadGenerator(tpm_account=tpm_account, action=Action.add)
    payload = generator.to_dict()
    print(to_json(payload))


def test_tpm_order_created_for_numbers(quantity=5, pool_type='pool_range'):
    payload = None
    from classes.domain.account import TPMAccount
    tpm_account = TPMAccount(market_code='VFDE')
    requested_numbers = NumbersOrderItem(quantity,
                                         resource_type=TpmResourceType[pool_type],
                                         pool_type=PoolType.Mobile)
    generator = NumbersPayloadGenerator(account=tpm_account,
                                        requested_numbers=requested_numbers,
                                        action=Action.add,
                                        payload=payload)
    payload = generator.to_dict()
    print(to_json(payload))


def test_itsm_prov_with_local_market_id():
    from classes.domain.account import TPMAccount
    from classes.domain.account import ItsmProvisioning
    tpm_account = TPMAccount(market_code=MARKET_CODE,
                             itsm_provisioning=ItsmProvisioning(local_market_service_id='test'))
    generator = TPMAccountPayloadGenerator(tpm_account=tpm_account, action=Action.add)
    payload = generator.to_dict()
    print(to_json(payload))


def test_without_itsm_prov():
    from classes.domain.account import TPMAccount
    tpm_account = TPMAccount(market_code=MARKET_CODE)
    generator = TPMAccountPayloadGenerator(tpm_account=tpm_account, action=Action.add)
    payload = generator.to_dict()
    print(to_json(payload))


def test_geo_locations():
    from classes.domain.account import UnityAccount

    from classes.data_factory import countries_data_manager
    unity_account = UnityAccount(market_code=MARKET_CODE, policies=Policies(enabled=True,
                                                                            geo_locations=[
                                                                                countries_data_manager.get_country_code(
                                                                                    MARKET_CODE)],
                                                                            ips=['1.0.0.80']
                                                                            ))
    generator = UnityAccountPayloadGenerator(unity_account=unity_account, action=Action.add)
    payload = generator.to_dict()
    print(to_json(payload))


def test_unity_account_plus_license_payload(action="add", quantity=1):
    from classes.domain.account import UnityAccount
    unity_account = UnityAccount(market_code=MARKET_CODE)
    requested_licenses = LicenseOrderItem()
    payload = LicensePayloadGenerator(account=unity_account, action=Action.add,
                                      requested_licenses=requested_licenses).to_dict()
    print(to_json(payload))


def test_extension_field_not_generated():
    unity_account = UnityAccount(market_code=MARKET_CODE, contact=Contact())
    generator = UnityAccountPayloadGenerator(unity_account=unity_account, action=Action.add)
    payload = generator.to_dict()
    print(to_json(payload))
    actual_extension = common.get_field(payload, extension_path)
    print(f"{actual_extension=}")
    assert actual_extension is None


def test_extension_field_generated():
    contact = Contact()
    contact.set_extension_number()
    unity_account = UnityAccount(market_code=MARKET_CODE, contact=contact)
    generator = UnityAccountPayloadGenerator(unity_account=unity_account, action=Action.add)
    payload = generator.to_dict()
    print(to_json(payload))
    actual_extension = common.get_field(payload, extension_path)
    print(f"{actual_extension=}")
    assert actual_extension is not None


def test_extension_field_saved():
    contact = Contact()
    contact.set_extension_number(1234)
    unity_account = UnityAccount(market_code=MARKET_CODE, contact=contact)
    generator = UnityAccountPayloadGenerator(unity_account=unity_account, action=Action.add)
    payload = generator.to_dict()
    print(to_json(payload))
    actual_extension = common.get_field(payload, extension_path)
    print(f"{actual_extension=}")
    assert actual_extension == 1234
