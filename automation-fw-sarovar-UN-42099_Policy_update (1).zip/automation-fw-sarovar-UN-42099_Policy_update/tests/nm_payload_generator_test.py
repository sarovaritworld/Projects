import pytest

from classes.domain.numbers import NMPoolType, NumbersOrderItem
from classes.payload_generators.NM.nm_payload_generator import NumberManagementPayload, NMResourceType


def test_generate_numbers():
    market_code = 'VFDE'
    payload = NumberManagementPayload(market_code=market_code,
                            main_number=True,
                            admin_number='123',
                            pools=[NumbersOrderItem(quantity=5,
                                                    resource_type=NMResourceType.pool,
                                                    pool_type=NMPoolType.pool),
                                   NumbersOrderItem(quantity=15,
                                                    resource_type=NMResourceType.pool_range,
                                                    pool_type=NMPoolType.fw_pool),
                                   NumbersOrderItem(quantity=15,
                                                    resource_type=NMResourceType.pool_range,
                                                    pool_type=NMPoolType.fw_pool)
                                   ]).to_dict()
    assert payload['admin_number'] == '123'


def test_request_2_pools():
    with pytest.raises(AssertionError):
        payload = NumberManagementPayload(pools=[
            NumbersOrderItem(quantity=5,
                             resource_type=NMResourceType.pool,
                             pool_type=NMPoolType.pool),
            NumbersOrderItem(quantity=5,
                             resource_type=NMResourceType.pool,
                             pool_type=NMPoolType.pool)
        ]).to_dict()

def test_generate_payload_with_defaults():
    payload = NumberManagementPayload().to_dict()
    assert 'main_number' in payload.keys()
    assert 'admin_number' in payload.keys()
    assert 'pool' in payload.keys()
    assert 'fw_pool' in payload.keys()
