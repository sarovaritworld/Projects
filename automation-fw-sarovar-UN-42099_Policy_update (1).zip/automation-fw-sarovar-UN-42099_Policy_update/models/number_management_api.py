"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : Number Management API
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/number-management-api/-/blob/master/openapi.yaml
  Commit         : 2117a099  (on 2024-02-29)
  Commit title   : docs(https://jira.tools.aws.vodafone.com/browse/UN-27306): Update OpenAPI spec to remove Swap operations and add details of the Test environment

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List

from pydantic import AwareDatetime, BaseModel, Field, RootModel, constr

from .utils import base_configuration


class State(str, Enum):
    """
    Operation state - one of `PENDING`, `PROCESSING`, `SUCCESS` or `ERROR`
    """

    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"


class Status(BaseModel):
    state: State
    """
    Operation state - one of `PENDING`, `PROCESSING`, `SUCCESS` or `ERROR`
    """
    code: str | None = None
    """
    MW provided status code
    """
    message: str | None = None
    """
    Operation status description
    """


class Status1(Status):
    pass


class RingCentralEmailResponseData(BaseModel):
    """
    List of rows containing the status messages from RingCentral for each of the requested number actions.
    """

    ringCentralUUID: str | None = None
    """
    RingCentral Customer Unique ID
    """
    action: str | None = None
    """
    Action that was performed by RingCentral
    """
    e164: constr(pattern=r"^\+?[1-9]\d{0,14}$") | None = None
    """
    The E164 number from which the action was performed
    """
    extension: str | None = None
    """
    Addition to E164 numbers.
    This is required for some actions - specified as a numerical property for ADDs, or a target E164 number for SWAPs
    """
    type: str | None = None
    """
    The type of number processes (A for Admin and M for Main number)
    """
    date: AwareDatetime | None = None
    """
    The original request date
    """
    status: str | None = None
    """
    The status of the individual request (OK, NOK)
    """
    message: str | None = None
    """
    The associated message for the individual request
    """


class NumberPoolData(RootModel[str]):
    root: str = Field(..., title="")
    """
    A list of pool numbers
    """


class NumberBatchPayload(BaseModel):
    """
    The object containing the numbers to be added or removed to/from the customer pool.
    """

    pool: List[NumberPoolData] | None = None
    """
    The customer pool of PSTN numbers
    """
    fw_pool: List[NumberPoolData] | None = None
    """
    The customer pool of presentation numbers
    """


class NumberPoolRangeData(BaseModel):
    """
    A range definition of pool numbers
    """

    start: constr(pattern=r"^\+?[1-9]\d{0,14}$") | None = None
    """
    The start of the number range
    """
    end: constr(pattern=r"^\+?[1-9]\d{0,14}$") | None = None
    """
    The end of the number range
    """


class Params(BaseModel):
    """
    Query parameters
    """

    header: Dict[str, Any] | None = None
    query: Dict[str, Any] | None = None


class Method(str, Enum):
    POST = "POST"
    PUT = "PUT"


class OperationStatusNotificationUrlInfo(BaseModel):
    """
    Operation status notification endpoint details
    """

    scheme: str | None = None
    host: str | None = None
    path: str | None = None
    params: Params | None = None
    """
    Query parameters
    """
    port: int | None = None
    method: Method | None = None


class Ringcentral(BaseModel):
    id: str
    main_number: str | None = None
    admin_number: str | None = None


class MarketCode(str, Enum):
    MNC = "MNC"
    VFUK = "VFUK"
    VFDE = "VFDE"
    VFPT = "VFPT"
    VFES = "VFES"
    VFIT = "VFIT"


class CustomerId(RootModel[constr(max_length=25)]):
    root: constr(max_length=25)


class Response(BaseModel):
    """
    HTTP response
    """

    code: int | None = None
    """
    HTTP response code
    """
    data: List[RingCentralEmailResponseData] | None = None


class OperationStatus(BaseModel):
    """
    API operation status descriptor
    """

    uuid: str | None = None
    """
    Operation unique identifier reference
    """
    status: Status | None = None
    response: Response | None = None
    """
    HTTP response
    """


class OperationStatusResponse(BaseModel):
    """
    API operation status descriptor
    """

    uuid: str | None = None
    """
    Operation unique identifier reference
    """
    status: Status1 | None = None
    response: Response | None = None
    """
    HTTP response
    """
    total_number_of_requests: int | None = None
    """
    Number of total requests
    """
    number_of_pending_requests: int | None = None
    """
    Number of pending requests
    """


class NumberAdditionBatchPayload(NumberBatchPayload):
    """
    This call will add numbers to the customer pool and also configure the initial set of numbers to present on the customer *main_number* and *admin_number*.

    This payload specifies the OpCo's main and administrative numbers - `main_number` and `admin_number` respectively, which are required for customer pool provisioning.
    Additionally it will include the list of numbers that will be included on the customer pool and the list of numbers that will be used for the presentation IDs.
    """

    main_number: constr(pattern=r"^\+?[1-9]\d{0,14}$") | None = None
    """
    A customer defined number which is subsequently excluded from the pool of available numbers.
    """
    admin_number: constr(pattern=r"^\+?[1-9]\d{0,14}$") | None = None
    """
    A customer defined administrative number, which is subsequently excluded from the pool of available numbers.
    """


class NumberRangePayload(BaseModel):
    """
    The object containing the numbers to be added or removed to/from the customer pool.
    """

    pool: List[NumberPoolRangeData] | None = None
    """
    The customer pool of PSTN numbers in range format
    """
    fw_pool: List[NumberPoolRangeData] | None = None
    """
    The customer pool of presentation numbers in range format
    """


class NumberInfo(BaseModel):
    """
    Information about a given number
    """

    market: MarketCode
    customer_id: CustomerId
    e164: str
    ringcentral: Ringcentral | None = None


class NumberAdditionRangePayload(NumberRangePayload):
    """
    This call will add numbers to the customer pool and also configure the initial set of numbers to present on the customer *main_number* and *admin_number*.

    This payload specifies the OpCo's main and administrative numbers - `main_number` and `admin_number` respectively, which are required for customer pool provisioning.
    Additionally it will include the list of numbers that will be included on the customer pool and the list of numbers that will be used for the presentation IDs.
    """

    main_number: constr(pattern=r"^\+?[1-9]\d{0,14}$") | None = None
    """
    A customer defined number which is subsequently excluded from the pool of available numbers.
    """
    admin_number: constr(pattern=r"^\+?[1-9]\d{0,14}$") | None = None
    """
    A customer defined administrative number, which is subsequently excluded from the pool of available numbers.
    """
