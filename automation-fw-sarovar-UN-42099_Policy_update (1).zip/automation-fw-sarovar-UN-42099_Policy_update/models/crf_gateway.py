"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : CRF Gateway
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/crf-gateway/-/blob/master/openapi.yaml
  Commit         : 4cf2f285  (on 2024-05-06)
  Commit title   : docs(https://jira.tools.aws.vodafone.com/browse/UN-26223): update Swagger to include information about Get Numbers endpoint

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import AnyUrl, AwareDatetime, BaseModel, Field, RootModel

from .utils import base_configuration


class ResourceCharacteristic(BaseModel):
    """
    Describes a given characteristic of an object or entity through a name/value pair.
    """

    name: str
    """
    Name of the characteristic
    """
    value: bool
    field_type: str = Field(..., alias="@type")
    """
    Type of the characteristic
    """


class CharacteristicRelationship(BaseModel):
    """
    Another Characteristic that is related to the current Characteristic
    """

    marginIn: int | None = None
    marginOut: int | None = None
    marginAll: int | None = None
    burstMarginIn: int | None = None
    burstMarginOut: int | None = None
    burstMarginAll: int | None = None


class RelatedParty(BaseModel):
    """
    Related Entity reference. A related party defines party or party role linked to a specific entity.
    """

    id: str
    """
    Unique identifier of a related entity.
    """
    name: str
    """
    Name of the related entity.
    """
    externalPstnProvider: str | None = None
    """
    Identifier of any external PSTN provider associated with the given Market. Only used for Market related party objects.
    """
    field_referredType: str = Field(..., alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """
    field_type: str = Field(..., alias="@type")
    """
    Type of the related party
    """


class MarketRelatedParty(RelatedParty):
    externalPstnProvider: str


class RelatedPlaceRefOrValue(BaseModel):
    """
    Related Entity reference. A related place defines a place described by reference or by value linked to a specific entity. The polymorphic attributes @type, @schemaLocation & @referredType are related to the place entity and not the RelatedPlaceRefOrValue class itself
    """

    role: str = Field(..., examples=["Resource Location Value"])
    countryCode: str | None = Field(default=None, examples=["GB"])
    stateOrProvince: str | None = Field(default=None, examples=["Berkshire"])
    city: str | None = Field(default=None, examples=["Newbury"])
    postCode: str | None = Field(default=None, examples=["RG14 2FN"])
    streetName: str | None = Field(
        default=None, examples=["Vodafone House, The Connection"]
    )
    streetNr: str | None = Field(default=None, examples=["1"])


class Action(str, Enum):
    """
    Can be "add" | "modify" | "no_change" | "delete"
    """

    ADD = "add"
    MODIFY = "modify"
    NO_CHANGE = "no_change"
    DELETE = "delete"


class ResourceRelationshipItem(BaseModel):
    id: str | None = Field(default=None, examples=["447534889125"])
    """
    id of the related resource.
    """


class ResourceRelationship(RootModel[List[ResourceRelationshipItem]]):
    root: List[ResourceRelationshipItem]


class EventSubscription(BaseModel):
    """
    Sets the communication endpoint address the service instance must use to deliver notification information
    """

    id: str
    """
    Id of the listener
    """
    callback: str
    """
    The callback being registered.
    """
    query: str | None = None
    """
    additional data to be passed
    """


class EventSubscriptionInput(BaseModel):
    """
    Sets the communication endpoint address the service instance must use to deliver notification information
    """

    callback: str
    """
    The callback being registered.
    """
    query: str | None = None
    """
    additional data to be passed
    """


class ResourceCacInfo(BaseModel):
    """
    Item which contains all CAC information
    """

    marginIn: int | None = Field(default=None, examples=[1])
    marginOut: int | None = Field(default=None, examples=[2])
    marginAll: int | None = Field(default=None, examples=[1])
    burstMarginIn: int | None = Field(default=None, examples=[2])
    burstMarginOut: int | None = Field(default=None, examples=[3])
    burstMarginAll: int | None = Field(default=None, examples=[2])
    enabled: bool | None = Field(default=None, examples=[True])


class Error(BaseModel):
    """
    Used when an API throws an Error, typically with a HTTP error response-code (3xx, 4xx, 5xx)
    """

    code: str
    """
    Application relevant detail, defined in the API or a common list.
    """
    reason: str
    """
    Explanation of the reason for the error which can be shown to a client user.
    """
    message: str | None = None
    """
    More details and corrective actions related to the error which can be shown to a client user.
    """
    status: str | None = None
    """
    HTTP Error code extension
    """
    referenceError: AnyUrl | None = None
    """
    URI of documentation describing the error.
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class.
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class entity name.
    """


class ConfigResourceCharacteristic(ResourceCharacteristic):
    characteristicRelationship: List[CharacteristicRelationship] | None = None


class ResourceRefOrValue(BaseModel):
    """
    Resource is an abstract entity that describes the common set of attributes shared by all concrete resources. The polymorphic attributes @type, @schemaLocation & @referredType are related to the Resource entity and not the related ResourceRefOrValue class itself
    """

    id: str = Field(..., examples=["447534889125"])
    """
    Identifier of an instance of the resource. Required to be unique within the resource type.  Used in URIs as the identifier for specific instances of a type.
    """
    href: str = Field(..., examples=["tel:+447534889125"])
    """
    The URI for the object itself.
    """
    place: RelatedPlaceRefOrValue | None = None
    resourceCharacteristic: (
        List[ResourceCharacteristic | ConfigResourceCharacteristic] | None
    ) = Field(
        default=None,
        examples=[
            [
                {"name": "Service", "value": "UNITY", "@type": "Service"},
                {"name": "Range", "value": 1, "@type": "Range"},
                {"name": "HEC Groups ID", "value": "HQ", "@type": "HEC Groups ID"},
                {
                    "name": "Market Configuration",
                    "value": True,
                    "@type": "Configuration",
                    "characteristicRelationship": [
                        {
                            "marginIn": 10,
                            "marginOut": 0,
                            "marginAll": 0,
                            "burstMarginIn": 30,
                            "burstMarginOut": 0,
                            "burstMarginAll": 0,
                        }
                    ],
                },
            ]
        ],
    )
    resourceRelationship: ResourceRelationship | None = None
    relatedParty: List[RelatedParty | MarketRelatedParty] | None = Field(
        default=None,
        examples=[
            [
                {
                    "id": "VFUK",
                    "name": "Market",
                    "externalPstnProvider": "VCS-TATA",
                    "@type": "Market",
                    "@referredType": "Market",
                },
                {
                    "id": "RingCentral",
                    "name": "Partner",
                    "@type": "Partner",
                    "@referredType": "Partner",
                },
                {
                    "id": "1SF222321",
                    "name": "Mercedes-Benz AG",
                    "@type": "Customer",
                    "@referredType": "Customer",
                },
            ]
        ],
    )


class ResourceCacInfoResponse(BaseModel):
    """
    Response returned by our get number information endpoint
    """

    id: str | None = Field(default=None, examples=["4183213758"])
    number: str | None = Field(default=None, examples=["+4183213758"])
    service: str | None = Field(default=None, examples=["UNITY"])
    market: str | None = Field(default=None, examples=["UK"])
    customer: str | None = Field(default=None, examples=["31546478"])
    cacInfo: ResourceCacInfo | None = None


class ResourceOrderItem(BaseModel):
    """
    An identified part of the order. A resource order is decomposed into one or more order items.
    """

    id: str | None = Field(default=None, examples=["01"])
    """
    Identifier of the line item (generally it is a sequence number 01, 02, 03, ...)
    """
    action: Action | None = None
    """
    Can be "add" | "modify" | "no_change" | "delete"
    """
    resource: ResourceRefOrValue | None = None


class ResourceOrder(BaseModel):
    """
    A Resource Order is a request to provision a set of Resources (logical and physical) triggered by the request to provision a Service through a Service Order
    """

    id: str | None = Field(
        default=None, examples=["123e4567-e89b-12d3-a456-426614174000"]
    )
    """
    Identifier of an instance of the Resource Order. Required to be unique within the resource type.  Used in URIs as the identifier for specific instances of a type.
    """
    orderDate: AwareDatetime | None = None
    """
    Date when the order was created
    """
    completionDate: AwareDatetime | None = None
    """
    Date when the order was created
    """
    priority: int | None = Field(default=None, examples=[0])
    """
    A way that can be used by consumers to prioritize orders in OM system (from 0 to 4 : 0 is the highest priority, and 4 the lowest)
    """
    state: str | None = Field(default=None, examples=["acknowledged"])
    """
    The life cycle state of the resource.
    """
    orderItem: List[ResourceOrderItem] | None = None


class ResourceOrderStateChangeEventPayload(BaseModel):
    """
    The event data structure
    """

    resourceOrder: ResourceOrder | None = None
    """
    The involved resource data for the event
    """


class ResourceOrderInformationRequiredEventPayload(
    ResourceOrderStateChangeEventPayload
):
    """
    The event data structure
    """


class ResourceOrderStateChangeEvent(BaseModel):
    """
    The notification data structure
    """

    id: str | None = None
    """
    Identifier of the Process flow
    """
    href: str | None = None
    """
    Reference of the ProcessFlow
    """
    eventId: str | None = None
    """
    The identifier of the notification.
    """
    eventTime: AwareDatetime | None = None
    """
    Time of the event occurrence.
    """
    eventType: str | None = None
    """
    The type of the notification.
    """
    correlationId: str | None = None
    """
    The correlation id for this event.
    """
    domain: str | None = None
    """
    The domain of the event.
    """
    title: str | None = None
    """
    The title of the event.
    """
    description: str | None = None
    """
    An explnatory of the event.
    """
    priority: str | None = None
    """
    A priority.
    """
    timeOcurred: AwareDatetime | None = None
    """
    The time the event occured.
    """
    event: ResourceOrderStateChangeEventPayload | None = None
    """
    The event payload linked to the involved resource object
    """


class ResourceOrderInformationRequiredEvent(BaseModel):
    """
    The notification data structure
    """

    eventId: str | None = None
    """
    The identifier of the notification.
    """
    eventTime: AwareDatetime | None = None
    """
    Time of the event occurrence.
    """
    eventType: str | None = None
    """
    The type of the notification.
    """
    correlationId: str | None = None
    """
    The correlation id for this event.
    """
    domain: str | None = None
    """
    The domain of the event.
    """
    title: str | None = None
    """
    The title of the event.
    """
    description: str | None = None
    """
    An explnatory of the event.
    """
    priority: str | None = None
    """
    A priority.
    """
    timeOcurred: AwareDatetime | None = None
    """
    The time the event occured.
    """
    fieldPath: str | None = None
    """
    The path identifying the object field concerned by this notification.
    """
    event: ResourceOrderInformationRequiredEventPayload | None = None
    """
    The event payload linked to the involved resource object
    """
