"""
THIS FILE IS AUTO-GENERATED. DO NOT EDIT!

Generated from:
  Repository     : TMF Service Order Gateway API
  API definition : https://gitlab-ucc.tools.aws.vodafone.com/ucc-platform/middleware/tmf-svc-order-gw-api/-/blob/master/openapi.yaml
  Commit         : cb47b069  (on 2023-11-14)
  Commit title   : feat(https://jira.tools.aws.vodafone.com/browse/UN-19728): Receive and validate new GET Service Order API query parameters

Generated with script: scripts/models/generate_models.py
"""

from __future__ import annotations

from enum import Enum
from typing import Any, List

from pydantic import AnyUrl, AwareDatetime, BaseModel, ConfigDict, Field, RootModel

from .utils import base_configuration


class Op(str, Enum):
    """
    The operation to perform
    """

    ADD = "add"
    REPLACE = "replace"


class CancellationReason(BaseModel):
    cancellationReason: str | None = None
    """
    Reason why the order is cancelled. This is used when order is cancelled.
    """


class Category(BaseModel):
    category: str | None = Field(default=None, examples=["UNITY"])
    """
    Used to categorize the order
    """


class Description(BaseModel):
    description: str | None = None
    """
    A free-text description of the service order
    """


class ExternalId(BaseModel):
    externalId: str | None = Field(
        default=None, examples=["54169701-7a40-43ad-b75f-132afe7ab123"]
    )
    """
    ID given by the consumer to facilitate searches
    """


class NotificationContact(BaseModel):
    notificationContact: str | None = None
    """
    Contact attached to the order to send back information regarding this order
    """


class Priority(BaseModel):
    priority: str | None = None
    """
    Can be used by consumers to prioritize orders
    """


class ExternalReference(BaseModel):
    """
    External reference of the individual or reference in other system
    """

    id: str | None = None
    """
    unique identifier
    """
    href: AnyUrl | None = None
    """
    Hyperlink reference
    """
    externalReferenceType: str | None = None
    """
    Type of the external reference
    """
    name: str
    """
    External reference name
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """


class ServiceOrderItemRef(BaseModel):
    itemId: str | None = None
    """
    Identifier of the line item
    """
    serviceOrderHref: AnyUrl | None = None
    """
    Link to the order to which this item belongs to
    """
    serviceOrderId: str | None = None
    """
    Identifier of the order that this item belongs to
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """


class ServiceOrderRelationship(BaseModel):
    """
    Linked service order to the one containing this attribute
    """

    id: str
    """
    The id of the related order
    """
    href: str | None = None
    """
    A hyperlink to the related order
    """
    relationshipType: str
    """
    The type of related order, such as: [dependency] if the order needs to be [not started] until another order item is complete (a service order in this case) or [cross-ref] to keep track of the source order (a productOrder)
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The entity type of the related order
    """


class RelatedParty(BaseModel):
    """
    Related Party reference. A related party defines party or party role linked to a specific entity.
    """

    id: str
    """
    unique identifier
    """
    href: AnyUrl | None = None
    """
    Hyperlink reference
    """
    name: str | None = None
    """
    Name of the related entity.
    """
    role: str | None = None
    """
    Role played by the related party
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str = Field(..., alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str = Field(..., alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """


class OrderItemActionType(str, Enum):
    """
    action to be performed on the product
    """

    ADD = "add"
    MODIFY = "modify"
    DELETE = "delete"
    NO_CHANGE = "noChange"


class AppointmentRef(BaseModel):
    """
    Refers an appointment, such as a Customer presentation or internal meeting or site visit
    """

    id: str
    """
    The identifier of the referred appointment
    """
    href: str | None = None
    """
    The reference of the appointment
    """
    description: str | None = None
    """
    An explanatory text regarding the appointment made with a party
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation
    """


class RelatedPlaceRefOrValue(BaseModel):
    """
    Related Entity reference. A related place defines a place described by reference or by value linked to a specific entity. The polymorphic attributes @type, @schemaLocation & @referredType are related to the place entity and not the RelatedPlaceRefOrValue class itself
    """

    id: str | None = None
    """
    Unique identifier of the place
    """
    href: str | None = None
    """
    Unique reference of the place
    """
    name: str | None = None
    """
    A user-friendly name for the place, such as [Paris Store], [London Store], [Main Home]
    """
    role: str
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """


class RelatedEntityRefOrValue(BaseModel):
    """
    A reference to an entity, where the type of the entity is not known in advance. A related entity defines a entity described by reference or by value linked to a specific entity. The polymorphic attributes @type, @schemaLocation & @referredType are related to the Entity and not the RelatedEntityRefOrValue class itself
    """

    id: str | None = None
    """
    Unique identifier of a related entity.
    """
    href: str | None = None
    """
    Reference of the related entity.
    """
    name: str | None = None
    """
    Name of the related entity.
    """
    role: str
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """


class ServiceSpecificationRef(BaseModel):
    """
    Service specification reference: ServiceSpecification(s) required to realize a ProductSpecification.
    """

    id: str
    """
    unique identifier
    """
    href: AnyUrl | None = None
    """
    Hyperlink reference
    """
    name: str | None = None
    """
    Name of the related entity.
    """
    version: str | None = None
    """
    Service specification version
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """


class ResourceRef(BaseModel):
    id: str
    """
    unique identifier
    """
    href: AnyUrl | None = None
    """
    Hyperlink reference
    """
    name: str | None = None
    """
    Name of the related entity.
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """


class ConstraintRef(BaseModel):
    """
    Constraint reference. The Constraint resource represents a policy/rule applied to an entity or entity spec.
    """

    id: str
    """
    unique identifier
    """
    href: AnyUrl | None = None
    """
    Hyperlink reference
    """
    name: str | None = None
    """
    Name of the related entity.
    """
    version: str | None = None
    """
    constraint version
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation.
    """


class CharacteristicRelationship(BaseModel):
    """
    Another Characteristic that is related to the current Characteristic;
    """

    id: str | None = None
    """
    Unique identifier of the characteristic
    """
    href: AnyUrl | None = None
    """
    Hyperlink reference
    """
    relationshipType: str | None = None
    """
    The type of relationship
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """


class TimePeriod(BaseModel):
    """
    A period of time, either as a deadline (endDateTime only) a startDateTime only, or both
    """

    endDateTime: AwareDatetime | None = Field(
        default=None, examples=["1985-04-12T23:20:50.52Z"]
    )
    """
    End of the time period, using IETC-RFC-3339 format
    """
    startDateTime: AwareDatetime | None = Field(
        default=None, examples=["1985-04-12T23:20:50.52Z"]
    )
    """
    Start of the time period, using IETC-RFC-3339 format
    """


class State(str, Enum):
    """
    The state of the Service Order or Service Order Item.
    """

    ACKNOWLEDGED = "acknowledged"
    REJECTED = "rejected"
    IN_PROGRESS = "inProgress"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"
    acknowledged_1 = "acknowledged"


class DateTime(RootModel[AwareDatetime]):
    root: AwareDatetime = Field(..., examples=["2023-06-01T10:00:00Z"])


class AnyModel(RootModel[Any]):
    root: Any


class SchemaRefs(BaseModel):
    """
    Properties used to identify sub-class and super-class relationships within the schema
    """

    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """


class ReferredType(BaseModel):
    field_referredType: str | None = Field(default=None, alias="@referredType")
    """
    The actual type of the target instance when needed for disambiguation
    """


class ErrorResponse(BaseModel):
    code: str | None = None
    reason: str | None = None
    message: str | None = None


class CancellationDate(BaseModel):
    cancellationDate: DateTime | None = None
    """
    Date when the order is cancelled. This is used when order is cancelled.
    """


class RequestedCompletionDate(BaseModel):
    requestedCompletionDate: DateTime | None = None
    """
    Requested delivery date from the requester's perspective
    """


class RequestedStartDate(BaseModel):
    requestedStartDate: DateTime | None = None
    """
    Order start date wished by the requester
    """


class ExternalReferenceList(BaseModel):
    externalReference: List[ExternalReference] | None = Field(
        default=None, title="External References"
    )
    """
    A list of external references related to this order
    """


class ServiceOrderJeopardyAlert(BaseModel):
    """
    A ServiceOrderJeopardyAlert represents a predicted exception during a service order processing that would brings risk to complete successfully the ordetr.
    """

    id: str | None = None
    """
    identifier of the JeopardyAlert
    """
    alertDate: AwareDatetime | None = None
    """
    A date time( DateTime). The date that the alert issued
    """
    exception: str | None = None
    """
     The exception associated with this jeopardy alert
    """
    jeopardyType: str | None = None
    """
    A string represents the type of jeopardy/risk like Normal, Hazard, Critical, ...
    """
    message: str | None = None
    """
    A string represents the message of the alert
    """
    name: str | None = None
    """
    A string used to give a name to the jeopardy alert
    """
    serviceOrderItem: List[ServiceOrderItemRef] | None = None
    """
    A list of order item references corresponded to this alert
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """


class ServiceOrderMilestone(BaseModel):
    """
    ServiceOrderMilestone represents an action or event marking a significant change or stage in processing of a service order.
    """

    id: str | None = None
    """
    identifier of the Milestone
    """
    description: str | None = None
    """
    free-text description of the Milestone
    """
    message: str | None = None
    """
    A string represents the message of the milestone
    """
    milestoneDate: AwareDatetime | None = None
    """
    A date time( DateTime). The date that the milestone happens
    """
    name: str | None = None
    """
    A string used to give a name to the milestone
    """
    status: str | None = None
    """
    The milestone status
    """
    serviceOrderItem: List[ServiceOrderItemRef] | None = None
    """
    A list of order item references corresponded to this milestone
    """
    field_baseType: str | None = Field(default=None, alias="@baseType")
    """
    When sub-classing, this defines the super-class
    """
    field_schemaLocation: AnyUrl | None = Field(default=None, alias="@schemaLocation")
    """
    A URI to a JSON-Schema file that defines additional attributes and relationships
    """
    field_type: str | None = Field(default=None, alias="@type")
    """
    When sub-classing, this defines the sub-class Extensible name
    """


class OrderRelationshipList(BaseModel):
    orderRelationship: List[ServiceOrderRelationship] | None = Field(
        default=None, title="Order Relationships"
    )
    """
    A list of service orders related to this order (e.g. prerequisite, dependent on).
    """


class RelatedPartyList(BaseModel):
    relatedParty: List[RelatedParty] | None = Field(
        default=None, title="Related Parties"
    )
    """
    A list of parties which are involved in this order and the role they are playing
    """


class ErrorMessageBase(BaseModel):
    """
    An error that causes a status change in a Service Order or Service Order Item. Used for PATCH operations.
    """

    code: str | None = None
    """
    Error code
    """
    message: str
    """
    More details and corrective actions related to the error
    """
    reason: str | None = None
    """
    Explanation of the reason for the error
    """
    referenceError: str | None = None
    """
    URI of documentation describing the error
    """
    status: State | None = None
    """
    The resulting status after the error occurred
    """
    timestamp: str | None = None
    """
    Date when the error happened
    """
    serviceOrderItem: List[ServiceOrderItemRef] | None = None
    """
    A list of order item references corresponded to this error
    """


class ErrorMessage(ErrorMessageBase, SchemaRefs):
    """
    An error that causes a status change in a Service Order or Service Order Item. Used in the Service Order and Service Order Item schemas. The field 'serviceOrderItem' should only be populated for Error Messages added at Service Order level.
    """


class Note(BaseModel):
    """
    Extra information about a given entity
    """

    id: str | None = None
    """
    Identifier of the note within its containing entity
    """
    author: str | None = None
    """
    Author of the note
    """
    date: DateTime | None = None
    """
    Date of the note
    """
    text: str
    """
    Text of the note
    """


class NoteWithRefs(Note, SchemaRefs):
    """
    Extra information about a given entity
    """


class Characteristic(SchemaRefs):
    """
    Describes a given characteristic of an object or entity through a name/value pair.
    """

    id: str | None = None
    """
    Unique identifier of the characteristic
    """
    name: str
    """
    Name of the characteristic
    """
    valueType: str | None = None
    """
    Data type of the value of the characteristic
    """
    characteristicRelationship: List[CharacteristicRelationship] | None = Field(
        default=None, title="Characteristic Relationships"
    )
    """
    A list of Characteristic Relationships
    """
    value: AnyModel


class FeatureRelationship(BaseModel):
    """
    Configuration feature relationship
    """

    id: str | None = None
    """
    Unique identifier of the target feature
    """
    name: str
    """
    The name of the target feature
    """
    relationshipType: str
    """
    The type of the feature relationship
    """
    validFor: TimePeriod | None = Field(default=None, title="TimePeriod")


class ServiceOrderItemRelationship(SchemaRefs):
    """
    Linked service order items to the one containing this attribute.
    """

    relationshipType: str | None = None
    """
    The type of related order item, can be: dependency if the order item needs to be not started until another order item is complete
    """
    orderItem: ServiceOrderItemRef | None = Field(default=None, title="Order Item")
    """
    A service order item in relationship with this order item
    """


class SchemaRefsWithReferredType(SchemaRefs, ReferredType):
    """
    Properties used to identify sub-class and super-class relationships within the schema. "@referredType" required for disambiguation.
    """


class ServiceOrderPatchItem(BaseModel):
    """
    JSON PATCH object. Valid for 'add' and 'replace' operations.
    """

    model_config = ConfigDict(
        extra="forbid",
    )
    path: str
    """
    A JSON pointer; the path of the object to patch
    """
    value: State | Note | ErrorMessageBase
    """
    The value to patch with
    """
    op: Op
    """
    The operation to perform
    """


class ServiceOrderPatch(RootModel[List[ServiceOrderPatchItem]]):
    """
    A JSON Patch array (https://jsonpatch.com/). The supported operations for this API are 'add' and 'replace'.
    """

    root: List[ServiceOrderPatchItem] = Field(..., title="Service Order (Update)")
    """
    A JSON Patch array (https://jsonpatch.com/). The supported operations for this API are 'add' and 'replace'.
    """


class ErrorMessageList(BaseModel):
    errorMessage: List[ErrorMessage] | None = Field(
        default=None, title="Error Messages"
    )
    """
    Any error(s) that cause an Order status change
    """


class JeopardyAlertList(BaseModel):
    jeopardyAlert: List[ServiceOrderJeopardyAlert] | None = Field(
        default=None, title="Jeopardy Alerts"
    )
    """
    A list of jeopardy alerts related to this order
    """


class MilestoneList(BaseModel):
    milestone: List[ServiceOrderMilestone] | None = Field(
        default=None, title="Milestones"
    )
    """
    A list of milestones related to this order
    """


class NoteList(BaseModel):
    note: List[NoteWithRefs] | None = None
    """
    Extra-information about the order; e.g. useful to add extra delivery information that could be useful for a human process.
    """


class Feature(BaseModel):
    """
    Configuration feature
    """

    id: str | None = None
    """
    Unique identifier of the feature
    """
    isBundle: bool | None = Field(default=None, examples=[False])
    """
    True if this is a feature group. Default is false.
    """
    isEnabled: bool | None = Field(default=None, examples=[True])
    """
    True if this feature is enabled. Default is true.
    """
    name: str
    """
    The name for the feature
    """
    constraint: List[ConstraintRef] | None = Field(default=None, title="Constraints")
    """
    A list of feature constraints
    """
    featureCharacteristic: List[Characteristic] = Field(
        ..., title="Feature Characteristics"
    )
    """
    A list of Characteristics for a particular feature
    """
    featureRelationship: List[FeatureRelationship] | None = Field(
        default=None, title="Feature Relationships"
    )
    """
    A list of Feature Relationships
    """


class RelatedServiceOrderItem(SchemaRefsWithReferredType):
    """
    A related ServiceOrder item. The service order item which triggered service creation/change/termination.
    """

    id: str | None = None
    """
    Unique identifier
    """
    href: str | None = None
    """
    Hyperlink reference
    """
    itemId: str | None = None
    """
    Identifier of the order item where the service was managed
    """
    role: str | None = None
    """
    Role of the service order item for this service
    """
    serviceOrderHref: str | None = None
    """
    Reference of the related entity
    """
    serviceOrderId: str | None = None
    """
    Unique identifier of a related entity
    """
    itemAction: OrderItemActionType | None = None
    """
    Action to be performed on the product
    """


class ServiceOrdersList(RootModel[List[ServiceOrder]]):
    """
    A list of Service Orders
    """

    root: List[ServiceOrder] = Field(..., title="Service Orders List")
    """
    A list of Service Orders
    """


class ServiceOrderItemList(BaseModel):
    serviceOrderItem: List[ServiceOrderItem] | None = Field(
        default=None, title="Service Order Items"
    )
    """
    A list of service order items to be processed by this order
    """


class ServiceOrderItem(SchemaRefs):
    """
    An action on a type of resource.
    """

    id: str
    """
    Identifier of the individual service order item
    """
    quantity: int | None = Field(default=None, examples=[2])
    """
    Quantity ordered
    """
    action: OrderItemActionType = Field(..., title="Action")
    appointment: AppointmentRef | None = Field(default=None, title="Appointment")
    errorMessage: List[ErrorMessage] | None = Field(
        default=None, title="Error Messages"
    )
    """
    The error(s) cause an order item status change
    """
    service: ServiceRefOrValue = Field(..., title="Service")
    serviceOrderItem: List[ServiceOrderItem] | None = Field(
        default=None, title="Service Order Items"
    )
    """
    A list of order items embedded to this order item
    """
    serviceOrderItemRelationship: List[ServiceOrderItemRelationship] | None = Field(
        default=None, title="Service Order Item Relationships"
    )
    """
    A list of order items related to this order item
    """
    state: State | None = Field(default=None, title="Service Order Item State")


class ServiceRefOrValue(SchemaRefsWithReferredType):
    """
    A Service to be created defined by value or existing defined by reference. The polymorphic attributes @type, @schemaLocation & @referredType are related to the Service entity and not the RelatedServiceRefOrValue class itself.
    """

    id: str | None = None
    """
    Unique identifier of the service
    """
    href: str | None = None
    """
    Reference of the service
    """
    category: str | None = None
    """
    Is it a customer facing or resource facing service
    """
    description: str | None = None
    """
    Free-text description of the service
    """
    endDate: DateTime | None = None
    """
    Date when the service ends
    """
    hasStarted: bool | None = None
    """
    If true, this Service has already been started
    """
    isBundle: bool | None = Field(default=None, examples=[False])
    """
    If true, the service is a ServiceBundle, which regroups a service hierarchy. If false, the service is an 'atomic' service (hierarchy leaf)
    """
    isServiceEnabled: bool | None = Field(default=None, examples=[True])
    """
    If false and 'hasStarted' is false, this particular Service has NOT been enabled for use. If false and hasStarted is true, then the service has failed
    """
    isStateful: bool | None = Field(default=None, examples=[True])
    """
    If true, this Service can be changed without affecting any other services
    """
    name: str | None = None
    """
    Name of the service
    """
    serviceDate: DateTime | None = None
    """
    Date when the service was created (whatever the status)
    """
    serviceType: str | None = None
    """
    Business type of the service
    """
    startDate: DateTime | None = None
    """
    Date when the service starts
    """
    startMode: str | None = Field(default=None, examples=[0])
    """
    This attribute is an enumerated integer that indicates how the Service is started, such as: 0: Unknown; 1: Automatically by the managed environment; 2: Automatically by the owning device; 3: Manually by the Provider of the Service; 4: Manually by a Customer of the Provider; 5: Any of the above.
    """
    feature: List[Feature] | None = Field(default=None, title="Features")
    """
    A list of feature associated with this service
    """
    note: List[NoteWithRefs] | None = Field(default=None, title="Notes")
    """
    A list of notes made on this service
    """
    place: List[RelatedPlaceRefOrValue] | None = Field(default=None, title="Places")
    """
    A list of places. Used to define places useful for the service (for example a geographical place where the service is installed)
    """
    relatedEntity: List[RelatedEntityRefOrValue] | None = Field(
        default=None, title="Related Entities"
    )
    """
    A list of related entity in relationship with this service
    """
    relatedParty: List[RelatedParty] | None = Field(
        default=None, title="Related Parties"
    )
    """
    A list of related party references. A related party defines party or party role linked to a specific entity
    """
    serviceCharacteristic: List[Characteristic] | None = Field(
        default=None, title="Service Characteristics"
    )
    """
    A list of characteristics that characterize this service
    """
    serviceOrderItem: List[RelatedServiceOrderItem] | None = Field(
        default=None, title="Related Service Order Items"
    )
    """
    A list of service order items related to this service
    """
    serviceRelationship: List[ServiceRelationship] | None = Field(
        default=None, title="Service Relationships"
    )
    """
    A list of service relationships. Describes links with other service(s) in the inventory
    """
    serviceSpecification: ServiceSpecificationRef | None = Field(
        default=None, title="Service Specification"
    )
    state: State | None = None
    supportingResource: List[ResourceRef] | None = Field(
        default=None, title="Supporting Resources"
    )
    """
    A list of supporting resources. Note: only Services of type RFS can be associated with Resources.
    """
    supportingService: List[ServiceRefOrValue] | None = Field(
        default=None, title="Supporting Services"
    )
    """
    A list of supporting services. A collection of services that support this service (bundling, link CFS to RFS).
    """


class ServiceRelationship(SchemaRefs):
    """
    A list of service relationships. Describes links with other service(s) in the inventory
    """

    id: str | None = None
    """
    Unique identifier
    """
    href: str | None = None
    """
    Hyperlink reference
    """
    relationshipType: str
    """
    The type of relationship
    """
    service: ServiceRefOrValue | None = None
    serviceRelationshipCharacteristic: List[Characteristic] | None = Field(
        default=None, title="Service Relationship Characteristics"
    )
    """
    A list of Service Relationship Characteristics
    """


class ServiceOrderCreate(
    CancellationDate,
    CancellationReason,
    Category,
    Description,
    ExternalId,
    NotificationContact,
    Priority,
    RequestedCompletionDate,
    RequestedStartDate,
    ExternalReferenceList,
    NoteList,
    OrderRelationshipList,
    RelatedPartyList,
    ServiceOrderItemList,
    SchemaRefs,
):
    """
    Skipped properties: id, href, orderDate, completionDate, expectedCompletionDate, startDate, state, jeopardyAlert, errorMessage, milestone.
    """

    serviceOrderItem: List[ServiceOrderItem] = Field(..., title="Service Order Items")
    """
    A list of service order items to be processed by this order
    """


class ServiceOrder(
    CancellationDate,
    CancellationReason,
    Category,
    Description,
    ExternalId,
    NotificationContact,
    Priority,
    RequestedCompletionDate,
    RequestedStartDate,
    ErrorMessageList,
    ExternalReferenceList,
    JeopardyAlertList,
    MilestoneList,
    NoteList,
    OrderRelationshipList,
    RelatedPartyList,
    ServiceOrderItemList,
    SchemaRefs,
):
    id: Any | None = Field(default=None, examples=["6483414be0c0409ccb968d70"])
    """
    The Middleware Service Order identifier
    """
    href: str | None = Field(
        default=None,
        examples=["/tmf-api/serviceOrdering/v4/serviceOrder/6483414be0c0409ccb968d70"],
    )
    """
    Hyperlink to access the order
    """
    completionDate: DateTime | None = None
    """
    Effective delivery date amended by Middleware
    """
    expectedCompletionDate: DateTime | None = None
    """
    Expected delivery date amended by Middleware
    """
    orderDate: DateTime | None = None
    """
    Set by Middleware when the order is received
    """
    startDate: DateTime | None = None
    """
    Set by Middleware when the order is acknowledged
    """
    state: State | None = None


ServiceOrdersList.model_rebuild()
ServiceOrderItemList.model_rebuild()
ServiceOrderItem.model_rebuild()
ServiceRefOrValue.model_rebuild()
ServiceOrderCreate.model_rebuild()
ServiceOrder.model_rebuild()
