"""
Update configuration for all pydantic models.

This file should be imported before using BaseModel (for this configuration to take effect)

Note: configuration is updated at import time, to make it more convenient with
      autogeneration tools like `datamodel-code-generator`
"""
from pydantic import BaseModel

# Update configuration for all pydantic models

# BaseModel.model_config["extra"] = "forbid"
# classes with @schemaLocation have "extra" attributes (that are defined elsewhere) so we allow "extra"
