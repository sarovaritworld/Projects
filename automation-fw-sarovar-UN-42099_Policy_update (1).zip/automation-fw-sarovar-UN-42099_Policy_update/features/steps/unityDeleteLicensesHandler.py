from behave import *

from classes import common, operations, read_xmldata
from classes.domain.account import UnityAccount
from classes.kafka import consumer_data, producer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.license import LicenseOrderItem, get_default_sku_id
from classes.payload_generators.TMF.license_generator import LicensePayloadGenerator
from classes.payload_generators.TMF.payload_generator import Action
from features.steps import TMFHandler, kafkaHandler, sharedHandler, unityAddLicensesHandler, validationHandler
from features.steps.TMFHandler import retrieve_and_validate, validate_final_state
from features.steps.flowHandler import initial_order_processsed_in_mw
from features.steps.unityAddLicensesHandler import create_complex_service_order_with_license, \
    licenses_addition_resolved, make_service_order_create_confirmed_unity_account_validate_success


@given("an unity account is already provisioned with '{licenses_count}' licenses")
def create_account_with_licenses(context, licenses_count):
    if not common.config.is_dev_env:
        create_complex_service_order_with_license(context, Action.add, licenses_count, get_default_sku_id())
        retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
        initial_order_processsed_in_mw(context)
        licenses_addition_resolved(context)
        del context.initial_license
        return
    make_service_order_create_confirmed_unity_account_validate_success(context, 'confirmed')


@given("an existing Unity account with licenses that cannot be deleted due to '{error_type}'")
def create_error_account_with_licenses(context, error_type):
    context.error_type = error_type
    if not common.config.is_dev_env:
        create_account_with_licenses(context, '5')
        return
    if error_type == 'insufficient_licenses_to_delete':
        context.op_co_customer_id = 'NOK_Bad_Request'
        context.RC_ID = '990095274'


@when("a service order is sent to '{action}' '{licenses_count}' licenses")
def request_order_for_delete_license_count(context, action, licenses_count=1):
    if not hasattr(context, 'unity_license'):
        context.unity_license = LicenseOrderItem(id=get_default_sku_id())
    unityAddLicensesHandler.request_order_for_license_count(context, action, licenses_count, context.unity_license.id)


@when("a service order is sent to delete '{licenses_count}' licenses against a different SKU ID")
def compose_delete_license_payload_different_sku_id(context, licenses_count):
    if common.config.is_dev_env:
        make_service_order_create_confirmed_unity_account_validate_success(context, 'confirmed')
    context.action = "delete"
    if not hasattr(context, 'unity_account'):
        if not hasattr(context, 'op_co_customer_id'):
            context.unity_account = UnityAccount(market_code='VFUK')
        else:
            context.unity_account = UnityAccount(op_co_customer_id=context.op_co_customer_id, market_code='VFUK')
    context.unity_license = LicenseOrderItem(quantity=licenses_count, id="VA_LR_398")
    context.payload = LicensePayloadGenerator(context.unity_account, Action.delete,
                                              context.unity_license).to_dict()
    TMFHandler.request_is_sent_to_create_service_order(context)


@when("kafka message for topic tmfmediator_command_delete_unitylicense is sent with {error_type} account")
def tmfmediator_command_delete_unitylicense(context, error_type):
    topic_name = "tmfmediator_command_delete_unitylicense"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.event_type = context.payload["header"]["event_type"]
    context.marketplace_event_id = context.payload["license_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.operation_id = context.payload["license_request"]["client_reference"][
        "operation_id"] = read_xmldata.gen_uuid()

    match error_type:
        case "Bad_Request":
            context.op_co_customer_id = context.system_error = "System_Error_Bad_Request"
            context.RC_ID = '995757138'
        case "Server_Error":
            context.op_co_customer_id = "Server_Not_found"
            context.system_error = "Server_Not_Found"
            context.RC_ID = "991923415"
    context.payload["license_request"]["ucas_account_id"] = context.RC_ID
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)

    if not hasattr(context, 'unity_license'):
        order = context.payload["license_request"]["order"]
        context.unity_license = LicenseOrderItem(quantity=order["quantity"], id=order["sku_id"])


@then("data is validated in ringcentral_event_unitylicense_deleted for {error_type}")
def ringcentral_event_unitylicense_deleted(context, error_type=None):
    topic = 'ringcentral_event_unitylicense_deleted'
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).ringcentral_event_unitylicense_deleted(error_type)


@then("tmfmediator_command_delete_unitylicense_topic is validated")
def tmfmediator_command_delete_unitylicense_topic_validation(context):
    topic = 'tmfmediator_command_delete_unitylicense'
    kafkaHandler.get_messages(context, topic)
    KafkaTopicValidator(context).tmfmediator_command_delete_unitylicense()


@then("delete license request fails for the account")
@then("the new licenses are successfully deleted for the account")
def licenses_operation_processed(context, error_type=None):
    if hasattr(context, 'error_type'):
        error_type = context.error_type
    sharedHandler.validate_status_response(context, 201)
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')
    operations.validate_operations_order("ucc.unity.license", "delete", context.service_order_id)
    tmfmediator_command_delete_unitylicense_topic_validation(context)
    ringcentral_event_unitylicense_deleted(context, error_type)
    if error_type:
        # for invalid_request which means the operation state will be 'failed'
        unsuccessful_license_operation_check(context, error_type)
    else:
        # for positive scenarios
        validate_final_state(context, 'completed')


@then("licenses are not deleted with error '{error}'")
def unsuccessful_license_operation_check(context, error):
    validationHandler.validate_order_status(context, 'failed')
    validationHandler.validate_error_message(context, error)
