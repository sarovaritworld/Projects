import json
import logging
import os
import time
from datetime import datetime

import uuid
from behave import *

from classes import read_xmldata
from classes import s3_bucket, polling, asserts, common, emailer
from classes.delay import Delay
from classes.sendemail import gen_csv_row, get_filename
from classes.status_code_validator import StatusCodeValidator
from common_python import api_requests

UK_TELEPHONE_CODE = read_xmldata.readxml("UK_ISD_CODE", "test_inputdata", "num_prov")
NUMBER_OF_DIGIT = read_xmldata.readxml("NUMBER_OF_DIGIT", "test_inputdata", "num_prov")


# Given I create a request to send an email
@given('I create a request to send an email')
def create_send_email_request(context):
    context.mailpayload = read_xmldata.read_jsonfile("postReq_sendEmailTemplate")
    url = read_xmldata.readxml("mailserver_url", "test_inputdata", "email_mgnt")
    server_ip = common.config.EMAIL_SENDER_SERVER
    context.url = "http://" + server_ip + url
    print("context.url:{}".format(context.url))


@given("I create a request to send an email in '{filename}'")
def create_send_email_request_filename(context, filename):
    filename = filename.replace('"', '')
    context.mailpayload = read_xmldata.read_jsonfile(filename)

    context.mailpayload['subject'] = "AutomationTest_" + str(int(time.time())) + filename + "_Email Comms MW -> RC"
    url = read_xmldata.readxml("mailserver_url", "test_inputdata", "email_mgnt")
    server_ip = common.config.EMAIL_SENDER_SERVER
    context.url = "http://" + server_ip + url
    print("context.url:{}".format(context.url))
    print(" ")


@when("I attempt to send the email to '{server_Type}' without an authentication header")
def send_email_without_auth_header(context, server_Type):
    print("context.url:{}".format(context.url))
    print(" ")
    print("Email payload: {}".format(json.dumps(context.mailpayload, indent=3)))
    print(" ")
    context.postresponse = api_requests.post(context.url, data=context.mailpayload)


@given("it has authentication header with an '{value_Type}'")
def email_auth_header_vale_type_exists(context, value_Type):
    if "incorrect_format" in value_Type.lower():
        context.access_token = api_requests.AuthType.VALID
        uuid_no = uuid.uuid1()
        uuid_no = str(uuid_no)
        context.header = {
            'Authorization': context.access_token,
            'X-Request-ID': uuid_no,
            'Content-Type': "abcd"
        }
    if "empty_value" in value_Type.lower():
        context.header = {
            'Authorization': "",
        }


# And it contains an authentication header without passing token
@given('it contains an authentication header without passing token')
def email_auth_header_exists_no_passing_token(context):
    context.header = {
        'Authorization': "",
        'Content-Type': 'application/x-www-form-urlencoded',
    }


@given("it contains an authentication header with a token that has '{value_Type}'")
def email_auth_header_exists_with_value_token(context, value_Type):
    uuid_no = uuid.uuid1()
    uuid_no = str(uuid_no)
    if "expired" in value_Type.lower():
        context.header = {
            'Authorization': api_requests.AuthType.EXPIRED,
            'X-Request-ID': uuid_no,
            'Content-Type': "application/json",
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Media-Type': 'application/json'
        }
    if "blank_value" in value_Type.lower():
        print("inside blank")
        print("inside blank")
        print("inside blank")
        access_token = ""
        context.header = {
            'Authorization': "Bearer " + access_token,
            'Content-Type': 'application/x-www-form-urlencoded',
        }


@given('it contains an authentication header with a token')
def email_auth_header_exists_with_token(context):
    context.access_token = api_requests.AuthType.VALID
    uuid_no = str(uuid.uuid1())
    context.header = {
        'Authorization': context.access_token,
        'X-Request-ID': uuid_no,
        'Content-Type': "application/json"
    }


@when("I attempt to send the email to '{server_Type}'")
def send_email_to_server_type(context, server_Type):
    # print("context.header:{}".format(context.header))
    context.mailpayload = json.dumps(context.mailpayload)
    print("context.url:{}".format(context.url))
    print(" ")
    print("Email payload: {}".format(context.mailpayload))
    print(" ")
    context.postresponse = api_requests.post(context.url, data=context.mailpayload, headers=context.header)
    if context.postresponse.ok:
        jsonresponse = context.postresponse.json()
        context.requestId = jsonresponse['requestId']
        print("requestId send:{}".format(context.requestId))


@when("I attempt to send the email with above created request to '{server_Type}'")
def send_email_with_request_to_server_type(context, server_Type):
    # print("context.header final server:{}".format(context.header))
    print("context.payload:{}".format(context.mailpayload))
    print("context.url:{}".format(context.url))
    context.mailpayload = json.dumps(context.mailpayload)
    context.postresponse = api_requests.post(context.url, data=context.mailpayload, headers=context.header)
    # print("jsonresponse:{}".format(context.postresponse))


@then("I receive '{expected_status_code}' response")
def receive_status_code_response(context, expected_status_code):
    StatusCodeValidator.validate_status_code_response(context.postresponse.status_code, expected_status_code)


@given("it has To field with '{type_Of_Data}' data '{To_Field_Value}'")
def expected_to_field_value_date_type(context, type_Of_Data, To_Field_Value):
    if type_Of_Data == "valid":
        To_Field_Value = To_Field_Value + emailer.get_domain()
    context.To_Field_Value = To_Field_Value
    context.mailpayload['to'][0]['email'] = To_Field_Value
    context.mailpayload['to'][0]['name'] = To_Field_Value


@given("it has From field with '{type_Of_Data}' data '{From_Field_Value}'")
def expected_from_field_value_date_type(context, type_Of_Data, From_Field_Value):
    if type_Of_Data == "valid":
        From_Field_Value = From_Field_Value + emailer.get_domain()
    context.From_Field_Value = From_Field_Value
    # context.payload = read_xmldata.readjsonfile("postReq_sendEmailTemplate")
    context.mailpayload['from']['email'] = From_Field_Value
    context.mailpayload['from']['name'] = From_Field_Value
    # print("updated payload", context.payload)


@given("it has CC field with '{type_Of_Data}' data '{CC_Field_Value}'")
def expected_cc_field_data_value(context, type_Of_Data, CC_Field_Value):
    context.CC_Field_Value = CC_Field_Value
    context.mailpayload['cc'][0]['email'] = CC_Field_Value
    context.mailpayload['cc'][0]['name'] = CC_Field_Value
    # print("updated payload", context.payload)


@given("it has BCC field with '{type_Of_Data}' data '{BCC_Field_Value}'")
def expected_bcc_field_data_value(context, type_Of_Data, BCC_Field_Value):
    context.BCC_Field_Value = BCC_Field_Value
    context.mailpayload['bcc'][0]['email'] = BCC_Field_Value
    context.mailpayload['bcc'][0]['name'] = BCC_Field_Value
    # print("updated payload", context.payload)


@given("it has Attachment field with '{Attachment_Field_format}' data '{Attachment_Field_Value}'")
def expected_attachment_format_field_value(context, Attachment_Field_format, Attachment_Field_Value):
    context.Attachment_Field_format = Attachment_Field_format
    context.attachment_field_value = Attachment_Field_Value
    context.attachdata = read_xmldata.convertintoBase64(Attachment_Field_Value)
    logging.info("context.attachdata: {}".format(context.attachdata))
    context.mailpayload['attachment'][0]['data'] = context.attachdata
    context.mailpayload['attachment'][0]['name'] = Attachment_Field_Value
    context.mailpayload['attachment'][0]['format'] = Attachment_Field_format


@given("it has Attachment field with '{Attachment_Field_format}' with blank '{fieldtype}'")
def expected_attachment_format_blank_field(context, Attachment_Field_format, fieldtype):
    if "data" in fieldtype.lower():
        context.Attachment_Field_format = Attachment_Field_format
        # print("context.attachdata: {}".format(context.attachdata))
        context.mailpayload['attachment'][0]['data'] = ""
        context.mailpayload['attachment'][0]['name'] = "blank"
        context.mailpayload['attachment'][0]['format'] = Attachment_Field_format
    if "value" in fieldtype.lower():
        context.mailpayload['attachment'][0]['data'] = "abcd"
        context.mailpayload['attachment'][0]['name'] = ""
        context.mailpayload['attachment'][0]['format'] = Attachment_Field_format


@given("it has Subject field with '{type_Of_Data}' data '{Subject_Field_Value}'")
def expected_subject_field_data_value(context, type_Of_Data, Subject_Field_Value):
    context.Subject_Field_Value = Subject_Field_Value
    context.mailpayload['subject'] = Subject_Field_Value
    # print("updated payload", context.payload)


@given("it has Content field with '{Content_Field_Type}' data '{Content_Field_Value}'")
def expected_content_field_type_value(context, Content_Field_Type, Content_Field_Value):
    if "text/html" in Content_Field_Type.lower():
        context.Content_Field_Value = read_xmldata.read_file(Content_Field_Value)
    else:
        context.Content_Field_Value = Content_Field_Value
    print("Content_Field_Type: {}".format(Content_Field_Type))
    context.mailpayload['content'][0]['value'] = context.Content_Field_Value
    context.mailpayload['content'][0]['type'] = Content_Field_Type
    # print("updated payload", context.payload)


# And it does not have any content in Body"
@given('it does not have any content in Body')
def expected_no_body(context):
    context.mailpayload = ""


@then("I create a request to mailhog server to read data")
def requested_mailhog_server_read(context):
    time.sleep(Delay.email_handler_read_data)
    mailhogurl = read_xmldata.readxml("mailhog_url", "test_inputdata", "email_mgnt")
    mail_ip = os.environ.get("MAILHOG_SERVER")
    # mail_ip = "10.1.7.98:8025"
    print("mail_ip{}".format(mail_ip))
    url = "http://" + mail_ip + mailhogurl
    context.getresponse = api_requests.get(url)
    decodedresponse = context.getresponse.content.decode('utf-8')
    context.jsonresponse = json.loads(decodedresponse)
    responserequestId = context.jsonresponse["items"][0]["Content"]["Headers"]["X-Vodafone-SendMail-Request-ID"]
    responserequestId = ' '.join(responserequestId)
    print("responserequestId {}".format(responserequestId))
    assert responserequestId in context.requestId, "Response request ID: {} and expected request ID: {}".format(
        responserequestId, context.requestId)


# Given user creates an email request by providing type as 'all' for 'Add' action
# Given user creates an email request by providing type as 'primary customer number' for 'Add' action
@when("user creates an email request by providing type as '{type_value}' for '{action_value}' action")
def create_email_request_with_type_action_when(context, type_value, action_value):
    type_action_value = type_value + ":" + action_value
    if type_value == "all":
        if action_value == "Add to Forwarded list":
            context.action_value = "AF"
        elif action_value == "Delete":
            context.action_value = "D"
            context.message_list = ['Number not found', 'Number format error', 'Number belongs to another customer']
        elif action_value == "Add":
            context.action_value = "A"
            context.action_value1 = "AF"
            context.message_list = ['Number already exists', 'Number format error',
                                    'Number belongs to another customer']
    elif type_value == "mandatory_numbers":
        if action_value == "Add":
            context.action_value = "A"
        elif action_value == "Delete":
            context.action_value = "D"
    elif type_value == "forward_pool":
        if action_value in ("Add", "Add_Range"):
            context.action_value = "A"
            context.action_value1 = "AF"
            context.message_list = ['Number already exists', 'Number format error',
                                    'Number belongs to another customer']
        elif action_value in ("Delete", "Delete_Range"):
            context.action_value = "D"
            context.message_list = ['Number not found', 'Number format error', 'Number belongs to another customer']
    elif type_action_value in ("presentation:Delete", "pool_number:Delete"):
        context.action_value = "D"
    elif type_action_value in (
            "main_null:Add", "admin_null:Add", "null_pool_list:Add", "null_fw_pool:Add", "null_E164:Add",
            "null_pool_nos:Add",
            "null_admin_main_nos:Add", "only_main_and_pool:Add"):
        context.action_value = "A"
        context.action_value1 = "AF"
        context.message_list = ['Number already exists', 'Number format error', 'Number belongs to another customer']
    elif type_action_value in (
            "main_null:Delete", "admin_null:Delete", "null_pool_list:Delete", "null_fw_pool:Delete",
            "only_main_and_pool:Delete"):
        context.action_value = "D"
        context.message_list = ['Number not found', 'Number format error', 'Number belongs to another customer']
    if not hasattr(context, 'action_value'):
        assert False, f"No match found for type_value {type_value}, action_value {action_value}"

    try:
        if context.flag == 1:
            context.E164_main = context.save_main_number
            context.E164_admin = context.save_admin_number
        else:
            context.E164_main = context.main_number_add
            context.E164_admin = context.admin_number_add
    except AttributeError:
        logging.error("Attributes already set !!! Skipping...")

    iso_date = datetime.now()
    current_iso_date = iso_date.strftime('%Y-%m-%dT%H:%M:%S.%f%z')
    rows_list = list()
    if type_value == "all":
        if action_value == "Add":
            rows_list.append(
                gen_csv_row(context.RC_ID, context.action_value, context.main_number_add, '4400', 'M', current_iso_date,
                            'OK', ''))
            rows_list.append(
                gen_csv_row(context.RC_ID, context.action_value, context.admin_number_add, '4400', 'A',
                            current_iso_date,
                            'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400', '',
                                current_iso_date,
                                'NOK', context.message_list[i]))
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value1, context.number_fwpool_list[i], '4400', '',
                                current_iso_date,
                                'OK', ''))
        elif action_value == "Delete":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.main_number_delete, '4400', 'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.admin_number_delete, '4400', 'A',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400', '',
                                current_iso_date,
                                'NOK', context.message_list[i]))
        elif action_value == "Add to Forwarded list":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.main_number_add, '4400', 'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.admin_number_add, '4400', 'A',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value, context.number_fwpool_list[i], '4400', '',
                                current_iso_date,
                                'OK', ''))
    elif type_value == "main_null":
        if action_value == "Add":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value1, context.number_fwpool_list[i], '4400',
                                '',
                                current_iso_date,
                                'OK', ''))
        elif action_value == "Delete":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
    elif type_value == "admin_null":
        if action_value == "Add":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value1, context.number_fwpool_list[i], '4400',
                                '',
                                current_iso_date,
                                'OK', ''))
        elif action_value == "Delete":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
    elif type_value == "null_pool_list":
        if action_value == "Add":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value1, context.number_fwpool_list[i], '4400',
                                '',
                                current_iso_date,
                                'OK', ''))
        elif action_value == "Delete":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))
    elif type_value == "null_fw_pool":
        if action_value == "Add":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
        elif action_value == "Delete":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
    elif type_value == "only_main_and_pool":
        if action_value == "Add":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
        elif action_value == "Delete":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            for i in range(len(context.number_pool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))
    elif type_value == "mandatory_numbers":
        if action_value == "Add":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))

        elif action_value == "Delete":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                         'M',
                                         current_iso_date,
                                         'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                         'A',
                                         current_iso_date,
                                         'OK', ''))
    elif type_value == "forward_pool":
        if action_value == "Add":
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value1, context.number_fwpool_list[i], '',
                                             '',
                                             current_iso_date,
                                             'OK', ''))
        elif action_value == "Add_Range":
            for i in range(len(context.E164_FwPoolList)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value1, context.E164_FwPoolList[i], '',
                                             '',
                                             current_iso_date,
                                             'OK', ''))
        elif action_value == "Delete":
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))

        elif action_value == "Delete_Range":
            for i in range(len(context.E164_FwPoolList)):
                rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_FwPoolList[i], '4400',
                                             '',
                                             current_iso_date,
                                             'NOK', context.message_list[i]))

    elif type_action_value == "null_pool_nos:add":
        rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_main, '4400',
                                     'M',
                                     current_iso_date,
                                     'OK', ''))
        rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.E164_admin, '4400',
                                     'A',
                                     current_iso_date,
                                     'OK', ''))

    elif type_action_value == "null_admin_main_nos:Add":
        for i in range(len(context.number_pool_list)):
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400',
                                         '',
                                         current_iso_date,
                                         'NOK', context.message_list[i]))
        for i in range(len(context.number_fwpool_list)):
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value1, context.number_fwpool_list[i], '4400',
                                         '',
                                         current_iso_date,
                                         'OK', ''))
    elif type_action_value == "presentation:Delete":
        for i in range(len(context.number_fwpool_list)):
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.number_fwpool_list[i], '',
                                         '',
                                         current_iso_date,
                                         'OK', ''))
    elif type_action_value == "null_E164:Add":
        rows_list.append({})

    if len(rows_list) == 0:
        assert False, f"No condition matched for type_value {type_value}, action_value {action_value} so no file has been created"

    original_filename = get_filename(context.NumPool_UUID, rows_list)

    context.filename = "email_inbound1"
    context.Attachment_Field_Value = original_filename
    context.To_Field_Value = "middleware"
    context.From_Field_Value = "uccunitymw"
    context.Attachment_Field_format = "text/csv"
    context.Content_Field_Type = "text/plain"
    context.Content_Field_Value = "content_TEXT"
    context.Content_subject_Value = "RE: " + context.NumPool_UUID
    context.execute_steps(u"""
                       Given I create a request to send an email in '{file}'
                       And it contains an authentication header with a token
	                   And it has To field with 'valid' data '{To_Field_Value}'
	                   And it has From field with 'valid' data '{From_Field_Value}'
	                   And it has Attachment field with '{Attachment_Field_format}' data '{Attachment_Field_Value}'
                       And it has Content field with '{Content_Field_Type}' data '{Content_Field_Value}'
                       And it has Subject field with 'valid' data '{Subject_Field_Value}'
                                                       """.format(file=context.filename,
                                                                  To_Field_Value=context.To_Field_Value,
                                                                  From_Field_Value=context.From_Field_Value,
                                                                  Attachment_Field_format=context.Attachment_Field_format,
                                                                  Attachment_Field_Value=context.Attachment_Field_Value,
                                                                  Content_Field_Type=context.Content_Field_Type,
                                                                  Content_Field_Value=context.Content_Field_Value,
                                                                  Subject_Field_Value=context.Content_subject_Value))


# When user sends the email from RingCentral to Middleware
@when("user sends the email from RingCentral to Middleware")
def rc_send_email_mw(context):
    context.execute_steps(u"""
                       When I attempt to send the email to 'mail_server'
                       Then I receive '202' response
                       Then user delete the file""")


# Then user delete the file
@then("user delete the file")
def delete_file(context):
    # read_xmldata.delete_file(context.Attachment_Field_Value)
    pass


# Given user creates the email request by providing type as 'all' for 'Add' action
@given("user creates the email request by providing type as '{type_value}' for '{action_value}' action")
def create_email_request_with_type_action_given(context, type_value, action_value):
    if type_value == "all" and action_value == "Add":
        context.action_value = "A"
        context.action_value1 = "AF"
        context.message_list = ['Number already exists', 'Number format error', 'Number belongs to another customer']
    elif type_value == "all" and action_value == "Add to Forwarded list":
        context.action_value = "AF"
    else:
        assert False, f"File is not present : type_value {type_value}, action_value {context.action_value}"

    iso_date = datetime.now()
    current_iso_date = iso_date.strftime('%Y-%m-%dT%H:%M:%S.%f%z')
    rows_list = list()
    if type_value == "all":
        if action_value == "Add":
            context.main_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
            context.admin_number_add = UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
            pool_1, pool_2, pool_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
                NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
                NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
            context.number_pool_list = [pool_1, pool_2, pool_3]
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.main_number_add, '4400', 'M',
                                         current_iso_date, 'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.admin_number_add, '4400', 'A',
                                         current_iso_date, 'OK', ''))

            for i in range(len(context.number_pool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value, context.number_pool_list[i], '4400', '',
                                current_iso_date, 'NOK', context.message_list[i]))

            fw_1, fw_2, fw_3 = UK_TELEPHONE_CODE + read_xmldata.gen_contact(
                NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(
                NUMBER_OF_DIGIT), UK_TELEPHONE_CODE + read_xmldata.gen_contact(NUMBER_OF_DIGIT)
            context.number_fwpool_list = [fw_1, fw_2, fw_3]
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value1, context.number_fwpool_list[i], '4400', '',
                                current_iso_date, 'OK', ''))

        elif action_value == "Add to Forwarded list":
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.main_number_add, '4400', 'M',
                                         current_iso_date, 'OK', ''))
            rows_list.append(gen_csv_row(context.RC_ID, context.action_value, context.admin_number_add, '4400', 'A',
                                         current_iso_date, 'OK', ''))
            for i in range(len(context.number_fwpool_list)):
                rows_list.append(
                    gen_csv_row(context.RC_ID, context.action_value, context.number_fwpool_list[i], '4400', '',
                                current_iso_date, 'OK', ''))
    if len(rows_list) == 0:
        assert False, f"No condition matched for type_value {type_value}, action_value {action_value} so no file has been created"

    original_filename = get_filename(context.NumPool_UUID, rows_list)

    context.filename = "email_inbound1"
    context.Attachment_Field_Value = original_filename
    context.To_Field_Value = "middleware"
    context.From_Field_Value = "uccunitymw"
    context.Attachment_Field_format = "text/csv"
    context.Content_Field_Type = "text/plain"
    context.Content_Field_Value = "content_TEXT"
    context.Content_subject_Value = "RE: " + context.NumPool_UUID
    context.execute_steps(u"""
                       Given I create a request to send an email in '{file}'
                       And it contains an authentication header with a token
	                   And it has To field with 'valid' data '{To_Field_Value}'
	                   And it has From field with 'valid' data '{From_Field_Value}'
	                   And it has Attachment field with '{Attachment_Field_format}' data '{Attachment_Field_Value}'
                       And it has Content field with '{Content_Field_Type}' data '{Content_Field_Value}'
                       And it has Subject field with 'valid' data '{Subject_Field_Value}'
                                                       """.format(file=context.filename,
                                                                  To_Field_Value=context.To_Field_Value,
                                                                  From_Field_Value=context.From_Field_Value,
                                                                  Attachment_Field_format=context.Attachment_Field_format,
                                                                  Attachment_Field_Value=context.Attachment_Field_Value,
                                                                  Content_Field_Type=context.Content_Field_Type,
                                                                  Content_Field_Value=context.Content_Field_Value,
                                                                  Subject_Field_Value=context.Content_subject_Value))


@then("user will validate the received email from Middleware to '{action}' '{number_type}'")
def validate_email_action_type_mw(context, action, number_type):
    expected_list = emailer.get_expected_attachment_data(context, number_type, action)
    number_of_emails = 1
    if number_type == 'pool and pool_range':
        number_of_emails = 2
    search_property = emailer.get_email_search_property(context)
    email_data = polling.wait_until(lambda: s3_bucket.get_email(search_property, number_of_emails),
                                    f"Email for {search_property}", period=5, timeout=120,
                                    stop_when=lambda x: len(x) > 0)

    actual_data, file_name = emailer.get_attachment_data(email_data)

    logging.info(f"Actual: {actual_data}")
    logging.info(f"Expected: {expected_list}")
    asserts.equals(len(expected_list), len(actual_data),
                   f"Length of ROWS in attached CSV")
    for list1 in expected_list:
        assert list1 in actual_data

    if hasattr(context, "status_get_response_num_pool_uuid"):
        today = datetime.now().strftime("%Y%m%d")
        expected_filename = today + "_" + context.status_get_response_num_pool_uuid + ".csv"
        asserts.equals(file_name, expected_filename, f"Attachment file name")


@then("Received email is retrieved and validated from mailbox")
def validate_received_email(context):
    search_property = json.loads(context.mailpayload)['subject']
    received_email = emailer.get_email(search_property)
    emailer.validate_email(context, received_email)
