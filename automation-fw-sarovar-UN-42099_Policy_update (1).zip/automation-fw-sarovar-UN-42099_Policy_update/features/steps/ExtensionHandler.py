import logging

from behave import given, then

from classes import asserts, common, database, tmf
from classes.kafka import KafkaTopics, consumer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from features.steps import CRFHandler, flowHandler, validationHandler
from features.steps.TMFHandler import create_payload_add_unity_account
from common_python.stub_accounts.stub_accounts import StubAccounts

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)
stub_accounts = StubAccounts()


def get_extension_number(ext_number_or_scenario: str) -> int | str:
    """
    Returns the extension number for different scenario if found else same number as passed
    :param ext_number_or_scenario:
    :return:
    """
    extension_map = {
        "UNKNOWN_ERROR": int(stub_accounts.rc.invalid_extension_number),
        "SYSTEM_ERROR": int(stub_accounts.rc.system_error_extension_number),
        "EXTENSION_ALREADY_IN_USE": int(stub_accounts.rc.same_extension_number_in_account_twice),
        "EXTENSION_OUT_OF_RANGE": int(stub_accounts.rc.extension_number_out_of_range),
        "EXTENSION_RESERVED": int(stub_accounts.rc.extension_number_reserved),
        "__NULL__": " "
    }
    return extension_map.get(ext_number_or_scenario, ext_number_or_scenario)


def get_expected_service_order_state(error_type: str) -> str:
    """
    Returns final service order state based on error_type
    :param error_type:
    :return:
    """
    match error_type:
        case None:
            return "completed"
        case "UNKNOWN_ERROR" | "SYSTEM_ERROR":
            # These are server side errors, either Ring Central or Middleware
            # operation SET_EXTENSION will be in SUSPEND state and service order will be inProgress
            return "inProgress"
        case "EXTENSION_ALREADY_IN_USE" | "EXTENSION_OUT_OF_RANGE" | "EXTENSION_RESERVED":
            # These are client side errors,
            # operation SET_EXTENSION will fail and service order will be partial
            return "partial"
        case _:
            raise NotImplementedError(f"Unknown error scenario {error_type}")


@given("service order is created for unity account with extension number '{extension_number}'")
@given("service order is created for unity account with extension number")
def service_order_created_with_extension_number(context, extension_number=None):
    # create unity account payload with extension_number
    generate_extension = True
    if extension_number is not None:
        generate_extension = False
        extension_number = get_extension_number(extension_number)

    create_payload_add_unity_account(context, None, 'FULL_STACK_STANDARD', 'VFDE', generate_extension, extension_number)


@then("extension number updated successfully")
@then("extension number failed to update with '{error_type}'")
def extension_number_updated_successfully(context, error_type: str = None):
    flowHandler.account_is_created(context)

    # Validate operation SET_EXTENSION is created and its order is correct
    operation_doc = database.get_service_order_operation(context.service_order_id, 'SET_EXTENSION')
    asserts.equals(operation_doc["order"], 3, "operation order for SET_EXTENSION")

    # Validate ADD_MAIN_NUMBER and complete the flow by sending notification
    flowHandler.main_number_is_added(context)
    CRFHandler.processed_crf_number(context)

    # Validate the message in Kafka topic 'tmfmediator_command_set_extension'
    context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.tmfmediator_command_set_extension.name)
    KafkaTopicValidator(context).validate_topic(KafkaTopics.tmfmediator_command_set_extension.name)

    # Validate the message in kafka topic 'ringcentral_event_extension_set'
    context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.ringcentral_event_extension_set.name)
    KafkaTopicValidator(context).ringcentral_event_extension_set(error_type)

    # Validate the final state of the Service Order, Milestones and Notes according to the expected outcome
    # expected_service_order_state = "completed" if error_type is None else "partial"
    expected_service_order_state = get_expected_service_order_state(error_type)
    validationHandler.validate_order_status(context, expected_service_order_state)
    validationHandler.validate_milestones_achieved(context, expected_service_order_state)
    tmf.validate_unity_create_account_notes(context, context.response_payload, expected_service_order_state)
