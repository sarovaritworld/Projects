import logging

from behave import *

from classes import common
from classes.utils import to_json
from classes.api.requests import ringcentral_gateway
from classes.kafka.msg_validation_set import KafkaMsgValidationSet
from classes.status_code_validator import StatusCodeValidator
from common_python import api_requests
from models.utils import validator
from models.ringcentral_gateway import AccountEntity

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@when("the ringcentral gateway API is accessible with '{rc_type}' Ringcentral_ID and include_all_data '{include_all_data}'")
@when("the ringcentral gateway API is accessible with '{rc_type}' Ringcentral_ID")
def validate_rcgw_api_accessible_with_rcid_include_all_data(context, rc_type: str, include_all_data: str = "__MISSING__"):
    if context.access_token == api_requests.AuthType.VALID:
        # Invalid endpoints do not have a corresponding valid scope
        if rc_type in ["wrong_url", "blank"]:
            scope = "rc_account/read"  # valid scope from another endpoint
            context.access_token = "Bearer " + api_requests.auth_handler.get_valid_access_token(scope)

    client = ringcentral_gateway.Client(token=context.access_token)
    if rc_type == 'wrong_url':
        context.response = client.request_to_invalid_path()
    else:
        context.RC_ID = ringcentral_gateway.td_ringcentral_id[rc_type]
        context.include_all_data = include_all_data
        match include_all_data:
            case "__MISSING__":
                params = {}
            case "false" | "true":
                params = {"include_all_data": include_all_data}
            case _:
                raise NotImplementedError(f"{include_all_data=}")
        context.response = client.get_account_info(ucas_account_id=context.RC_ID, params=params)


# validate the "Unauthorized" response from ringcentral gateway
# Then validate the "success" response from ringcentral gateway
@then("validate the '{status:d}' response from ringcentral gateway")
def validate_rcgw_response(context, status: int):

    StatusCodeValidator.validate_status_code_response(context.response.status_code, status)
    if not context.response.ok:
        return  # on error, checking status code is enough (no payload check)

    response_data = context.response.json()
    logger.info(f"Validate the response: {to_json(response_data)}")
    logger.info(f"include_all_data={context.include_all_data}")

    # Schema validation
    validator.validate_model(response_data, AccountEntity)

    # Validate data that should be present
    validation_set = KafkaMsgValidationSet(context).ringcentral_gateway_account()
    common.validate_message(response_data, validation_set)

    # Validate data that should be excluded from the response
    if context.include_all_data != "true":
        logger.info(f"Validate that response excludes all optional fields")
        optional_fields = [name for name, info in AccountEntity.model_fields.items() if not info.is_required()]
        logger.debug(f"{optional_fields=}")
        for field in optional_fields:
            assert field not in response_data, f"{field=} should be excluded from the response"
