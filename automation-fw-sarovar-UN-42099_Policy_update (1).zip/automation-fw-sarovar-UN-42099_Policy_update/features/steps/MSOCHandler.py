import json
import logging

from behave import given, then, when

from classes import common, database, msoc_numbers, payload, read_xmldata, utils
from classes.data_factory import countries_data_manager
from classes.domain.account import BillingInfo, MSOCAccount
from classes.domain.numbers import MSOCNumbers, MsocResourceType, PoolType
from classes.kafka import consumer_data
from classes.kafka.messages_filter import KafkaMessagesFilter
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF import Action, MSOCAccountPayloadGenerator
from classes.payload_generators.TMF.country_billing_generator import CountryBillingGenerator
from classes.payload_generators.TMF.number_generator import NumbersPayloadGenerator
from features.steps import TMFHandler, commonHandler, databaseHandler, flowHandler, idmapperHandler, jiraHandler, \
    kafkaHandler, patchHandler, sharedHandler, validationHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


def update_context_from_msoc_customer_document(context, customer_doc):
    """
    Updates the context object with the values MsocCustomer Database document
    :param context: Behave context object
    :param customer_doc: MSOC customer document from DB
    :return:
    """
    context.market_code = customer_doc["market"]
    logger.info(f"Saved {context.market_code=}")
    context.country_code = countries_data_manager.get_country_code(context.market_code)
    logger.info(f"Saved {context.country_code=}")
    context.op_co_customer_id = customer_doc['vodafoneId']
    logger.info(f"Saved {context.op_co_customer_id=}")
    context.bgid = customer_doc["bgid"]
    logger.info(f"Saved {context.bgid=}")
    context.ms_teams_tenant_id = customer_doc["msTeamsTenantId"]
    logger.info(f"Saved {context.ms_teams_tenant_id=}")
    context.customer_name = customer_doc["name"]
    logger.info(f"Saved {context.customer_name=}")

    if "countryBillingInformation" in customer_doc:
        context.existing_service_identifier = customer_doc['countryBillingInformation'][context.country_code][
            'serviceIdentifier']
        logger.info(f"Saved {context.existing_service_identifier=}")
        context.existing_customer_reference_number = customer_doc['countryBillingInformation'][context.country_code][
            'customerReferenceNumber']
        logger.info(f"Saved {context.existing_customer_reference_number=}")

    if "cacId" in customer_doc and len(customer_doc["cacId"]) > 0:
        context.existing_cac_id = context.cac_id = customer_doc["cacId"][0]
        logger.info(f"Saved {context.cac_id=}")
        logger.info(f"Saved {context.existing_cac_id=}")


@given("Process MSOC create account request for '{market}'")
@given("Process MSOC create account request for '{market}' with {billing_info}")
def process_msoc_create_account_for_market(context, market, billing_info=None):
    context.market_code = market
    context.country_code = countries_data_manager.get_country_code(market)
    saved_customer = database.get_msoc_customer_documents(context.market_code, billing_info)
    logging.info(f'{saved_customer=}')
    if saved_customer and common.Config.is_dev_env:
        # create an object for MSOCAccount with existing info and save to the context to be used with new approach
        update_context_from_msoc_customer_document(context, saved_customer)
        context.msoc_account = MSOCAccount.from_msoc_customer_document(saved_customer)

    else:
        context.execute_steps(f"""
                Given customer creates a service order to 'add' MSOC account for '{market}'
                When customer sends an order to Middleware
                Then user retrieves and validates data in 'tmfmediator_command_create_msoccustomer' topic
                And BGID is stored in database
                And user retrieves and validates data in 'idmapper_event_msoccustomer_created' topic
                And JIRA tickets has been created successfully
                When BO tool sends PATCH request on 'update_service_order' level for 'ucc.msoc.customer' is 'completed'
                 """)
        if billing_info:
            context.execute_steps("""
                    Given service order is created for 'add' MSOC Billing Identifiers
                    When Service Order processed successfully in TMF Gateway
                    Then data in tmfmediator_command_add_msoccountrybilling topic is validated
                    And data in idmapper_event_msoccountrybilling_added topic is validated
                    And JIRA tickets has been created successfully
                    When BO tool sends PATCH request on 'update_service_order' level for 'ucc.msoc.country-billing' is 'completed'
                    """)
            context.existing_service_identifier = context.service_identifier
            context.existing_customer_reference_number = context.customer_reference_number


@when("create msoc customer request is processed in Middleware")
def new_msoc_customer_onboarded(context):
    context.service_order = [context.payload['serviceOrderItem'][0]]
    context.execute_steps("""
        When Service Order processed successfully in TMF Gateway""")
    TMFHandler.retrieve_and_validate(context, 'tmfmediator_command_create_msoccustomer')
    databaseHandler.bgid_is_stored_in_database(context)
    TMFHandler.retrieve_and_validate(context, 'idmapper_event_msoccustomer_created')

    context.service_order = [context.payload['serviceOrderItem'][0]]
    context.execute_steps(""" 
        Then JIRA tickets has been created successfully
        When BO tool sends PATCH request on 'update_service_order' level for 'ucc.msoc.customer' is 'completed'
        """)
    context.msoc_add_customer_jira_validated = True
    context.service_order = context.payload['serviceOrderItem']


# adding here then because this step in fact a validation!
@then("'{action}' msoc number request is processed in Middleware")
@when("'{action}' msoc number request is processed in Middleware")
@when("'{action}' msoc number request is processed in Middleware for '{so_type}' SO")
def validate_msoc_numbers_request(context, action, so_type=None):
    if so_type is not None:
        context.complex_so_flag = True
    context.service_order = [context.payload['serviceOrderItem'][0]]
    if action == 'add':
        context.action = 'add'
        tmf_topic = 'tmfmediator_create_addnumbers'
        nm_topic = 'numbermanagement_command_add_crfnumber'
        crf_topic = 'crfgateway_event_crfnumber_added'
        nm_confirmation_topic = 'numbermanagement_respond_numbersadded'
        context.execute_steps(f"""
        Then user retrieves and validates data in {tmf_topic} topic for MSOC Number""")
    else:
        context.action = 'delete'
        tmf_topic = 'tmfmediator_create_deletenumbers'
        nm_topic = 'numbermanagement_command_delete_crfnumber'
        crf_topic = 'crfgateway_event_crfnumber_deleted'
        nm_confirmation_topic = 'numbermanagement_event_numbers_deleted'
        context.execute_steps(f"""
        Then user retrieves and validates data in '{tmf_topic}' topic""")

    context.execute_steps(f"""
    Then user retrieves and validates data in '{nm_topic}' topic
    And CRF id saved in DB for 'complex_SO'
    And state of CRF request is 'acknowledged' in DB
    And user can retrieve payload from 'crfstub_process_resourceorder'

    When CRF notification is sent with status 'inProgress'
    And CRF notification is sent with status 'completed'
    Then state of CRF request is 'completed' in DB
    And user retrieves and validates data in '{crf_topic}' topic""")

    if action == 'add':
        context.execute_steps(f"""
        Then user retrieves and validates data in '{nm_confirmation_topic}' topic for 'COMPLETED_PROVISIONING'""")
        context.msoc_add_numbers_jira_validated = True
    else:
        context.execute_steps(f"""
        Then user can retrieve and validate payload for kafka topic '{nm_confirmation_topic}' for 'Fixed' number""")
        context.msoc_delete_numbers_jira_validated = True

    context.service_order = [context.payload['serviceOrderItem'][0]]
    context.execute_steps("""
    Then JIRA tickets has been created successfully
    When BO tool sends PATCH request on 'update_service_order' level for 'ucc.msoc.numbers' is 'completed'
        """)
    context.ddis_provisioned_in_sippio = True
    context.service_order = context.payload['serviceOrderItem']


@given("service order is created for '{action}' MSOC Billing Identifiers")
def create_payload_for_msoc_billing_identifiers(context, action):
    if hasattr(context, 'payload') and hasattr(context, 'bgid'):
        del context.payload
    context.action = action
    context.payload = payload.create_msoc_billing_identifiers(context, action)
    logging.info("MSOC Billing Identifiers SO Item payload:")
    logging.info(json.dumps(context.payload, indent=3))


@given("customer creates a service order to 'add' an MSOC Billing Identifiers with '{error_type}'")
def create_payload_add_msoc_billing_identifiers_for_condition(context, error_type):
    create_payload_for_msoc_billing_identifiers(context, "add")
    if error_type == "different_billing_info":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0][
            "value"] = context.country_code = "DE"

        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1][
            "value"]["serviceIdentifier"] = context.service_identifier = "SI-" + read_xmldata.gen_contact(5)

        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1][
            "value"]["customerReferenceNumber"] = context.customer_reference_number = "CRN-" + read_xmldata.gen_contact(
            5)
        logging.debug(f'payload for {error_type}: {utils.to_json(context.payload)}')

    else:
        raise NotImplementedError(f"The error type {error_type} is not supported")


@given("customer creates a service order with '{field_type}' to '{action}' MSOC Billing Identifiers")
def create_payload_msoc_billing_identifiers_with_field(context, field_type, action):
    context.execute_steps(f"Given service order is created for '{action}' MSOC Billing Identifiers")

    if field_type == "blank_msoc_customer_billing_country":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["valueType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"] = ""

    elif field_type == "blank_msoc_customer_billing_info":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["valueType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["@type"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1][
            "value"]["serviceIdentifier"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1][
            "value"]["customerReferenceNumber"] = ""

    elif field_type == "blank_service_identifier":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1][
            "value"]["serviceIdentifier"] = ""

    elif field_type == "blank_customer_reference_number":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1][
            "value"]["customerReferenceNumber"] = ""

    else:
        raise NotImplementedError(f"The error type {field_type} is not supported")

    logging.info("Altered initial payload:")
    logging.info(json.dumps(context.payload, indent=3))


# @given("customer creates a service order to '{action}' MSOC account for '{market_code}'")
# def create_payload_add_msoc_customer(context, action, market_code='VFUK'):
#     context.action = action
#     context.msoc_account = MSOCAccount(market_code=market_code)
#     context.payload = MSOCAccountPayloadGenerator(msoc_account=context.msoc_account, action=action,
#                                                   payload=context.payload).to_dict()


@given("customer creates a service order to '{action}' MSOC account")
@given("customer creates a service order to '{action}' MSOC account for '{market_code}'")
def create_payload_msoc_account(context, action, market_code=None):
    commonHandler.set_market(context, market_code)

    if hasattr(context, "payload") and len(context.payload["serviceOrderItem"]) > 0:
        del context.payload
    context.action = action
    context.payload = payload.create_msoc_account(context, context.action)

    logging.info("MSOC SO Item payload:")
    logging.info(json.dumps(context.payload, indent=3))


@given("customer creates a service order to 'add' an MSOC account with '{error_type}'")
def create_payload_add_msoc_account_with_condition(context, error_type):
    context.execute_steps("""Given customer creates a service order to 'add' MSOC account""")

    if error_type == "duplicate_opco_customer_id":
        context.payload["externalReference"][0]["id"] = context.op_co_customer_id = "88569403040"

    elif error_type == "duplicate_ms_teamns_tenant_id":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "tenantId"] = context.ms_teams_tenant_id = "MS-5952"


@then('data in tmfmediator_command_add_msoccountrybilling topic is validated')
@then("data in tmfmediator_command_add_msoccountrybilling topic is validated with '{error_type}'")
def validate_tmfmediator_add_msoccountrybilling_data(context, error_type=None):
    topic_name = 'tmfmediator_command_add_msoccountrybilling'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    context.consumer_payload = KafkaMessagesFilter(context).tmfmediator_command_add_msoccountrybilling(
        context.service_order_id)[0]
    common.update_middleware_correlation_id(context)
    context.marketplace_event_id = context.consumer_payload['msocCustomerRequest']['clientReference'][
        'marketplace_event_id']
    KafkaTopicValidator(context).tmfmediator_command_add_msoccountrybilling(error_type)


@then('data in idmapper_event_msoccountrybilling_added topic is validated')
def validate_idmapper_msoccountrybilling_added_data(context):
    topic_name = 'idmapper_event_msoccountrybilling_added'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    context.marketplace_event_id = context.consumer_payload['msocCustomerRequest']['clientReference'][
        'marketplace_event_id']
    KafkaTopicValidator(context).idmapper_event_msoccountrybilling_added()


@then("user retrieves and validates data in tmfmediator_create_addnumbers topic for MSOC Number")
def validate_tmfmediator_create_addnumbers_for_msoc_number(context):
    topic_name = 'tmfmediator_create_addnumbers'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    item = payload.get_item_by_type_and_action(context.payload, 'ucc.msoc.numbers', action='add')

    assert item is not None, 'No item found'
    if isinstance(context.consumer_payload, list):
        consumer_message = context.consumer_payload[-1]
    context.middleware_correlation_id = consumer_message["header"]["middlewareCorrelationId"]
    context.opCoCustomerId = consumer_message['addNumbers']['opCoDetails']['opCoCustomerId']
    logger.info(f'{context.middleware_correlation_id=}')
    logger.info(f'{consumer_message=}')
    KafkaTopicValidator(context).tmfmediator_create_addnumbers(
        number_type="pool",
        item=item,
        consumer_message=consumer_message,
        category="MSOC")


@given("MSOC Order is created for '{action}' '{quantity}' numbers in pool type '{pool_type}'")
@given("MSOC Order is created for '{action}' '{quantity}' numbers in pool type '{pool_type}' as '{order_type}' order")
@given(
    "MSOC Order is created for '{action}' '{quantity}' numbers in pool type '{pool_type}' as '{order_type}' order for '{carrier_id}'")
def msoc_order_created_for_numbers(context, action, quantity, pool_type, order_type=None, carrier_id=None,
                                   number_pool=None):
    if 'msoc_account' in context:
        if order_type == 'separate':
            context.payload = None
        context.requested_numbers = MSOCNumbers(
            quantity=quantity,
            resource_type=MsocResourceType[pool_type],
            pool_type=PoolType.Fixed,
            pool=number_pool,
            carrier_id=carrier_id
        )
        generator = NumbersPayloadGenerator(
            account=context.msoc_account,
            requested_numbers=context.requested_numbers,
            action=Action(action),
            payload=context.payload
        )

        context.msoc_numbers = context.requested_numbers
        context.number_pool_list = context.requested_numbers.pool
        context.carrier_id = carrier_id
        context.payload = generator.to_dict()
        # this line for tmfgateway_process_serviceorder validation and needs to be removed once
        context.pool_type = pool_type
        context.action = action
        logging.info(json.dumps(context.payload, indent=3))
        return

    if not hasattr(context, 'payload'):
        context.payload = payload.compose_service_order(context=context)
    context.payload = msoc_numbers.add_remove_msoc_numbers(context, action, quantity, pool_type, order_type, carrier_id)
    logging.info(str(action) + " MSOC Numbers SO Item payload:")
    logging.info(json.dumps(context.payload, indent=3))


@given("customer updates '{field}' with '{value}' in MSOC service order")
def update_msoc_service_order_field_with_value(context, field, value):
    if value == 'null':
        value = ''
    elif value == 'non_existing_msoc_account':
        value = '12345678901'

    if field in ('id', 'category'):
        context.payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0][field] = value
    elif field == 'market_account_id':
        context.payload['externalReference'][0]['id'] = value
    elif field in ('name', 'valueType'):
        context.payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0][
            "resourceCharacteristic"][0][field] = value
    elif field in ('@type', 'poolType', 'usageType', 'carrierId', 'emergencyAddressLocationId', 'capability'):
        context.payload["serviceOrderItem"][context.index]["service"]["supportingResource"][0][
            "resourceCharacteristic"][0]["value"][field] = value
        if field == 'usageType':
            context.usage_type = value
        elif field == 'capability':
            context.capability = value
    else:
        raise NotImplementedError(f"{field} is not supported")


@when("create msoc billing request is processed in Middleware")
def msoc_billing_request_processed(context):
    context.service_order = [context.payload['serviceOrderItem'][0]]
    context.execute_steps("""
    Then data in tmfmediator_command_add_msoccountrybilling topic is validated
    Then data in idmapper_event_msoccountrybilling_added topic is validated""")

    context.service_order = [context.payload['serviceOrderItem'][0]]
    context.execute_steps(""" 
        Then JIRA tickets has been created successfully
        When BO tool sends PATCH request on 'update_service_order' level for 'ucc.msoc.country-billing' is 'completed'
        """)
    context.msoc_add_billing_jira_validated = True
    context.service_order = context.payload['serviceOrderItem']


# And customer sends a service order with msoc account and create account
@given("customer sends a service order with msoc account and create account")
def send_payload_with_msoc_account(context):
    payload.prepare_account_payload(context, 'add', 'FULL_STACK_STANDARD', 'VFUK')
    context.execute_steps("Given customer creates a service order to 'add' MSOC account")

    context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["name"] = payload.companyName
    context.payload["serviceOrderItem"][1]["service"]["serviceCharacteristic"][0]["value"][
        "name"] = context.customer_name = payload.customerName
    context.payload["serviceOrderItem"][1]["service"]["serviceCharacteristic"][0]["value"][
        "tenantId"] = context.ms_teams_tenant_id = payload.generate_msoc_tenantid()

    logging.info("Complex create account and msoc SO Item payload:")
    logging.info(json.dumps(context.payload, indent=3))

    # Given customer creates a service order with '<field_type>' to 'add' MSOC account


@given("customer creates a service order with '{field_type}' to '{action}' MSOC account")
def create_payload_with_field_to_msoc_account(context, field_type, action):
    context.execute_steps(f"Given customer creates a service order to '{action}' MSOC account")

    if field_type == "invalid_country_code":
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["country"] = "$^%&^*&^"

    elif field_type == "blank_country_code":
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["country"] = ""

    elif field_type == "blank_name_field":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "name"] = ""

    elif field_type == "service_order_item_ID_not_present":
        del context.payload["serviceOrderItem"][0]["id"]

    elif field_type == "blank_tenantId_field":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "tenantId"] = ""

    elif field_type == "blank_service_order_item_service_type":
        context.payload["serviceOrderItem"][0]["service"]["serviceType"] = ""

    elif field_type == "blank_service_order_item_action":
        context.payload["serviceOrderItem"][0]["action"] = ""

    elif field_type == "invalid_payload":
        context.payload["serviceOrderItem"][0] = ""

    elif field_type == "blank_place":
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["@baseType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["@type"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["@schemaLocation"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["role"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["streetNr"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["streetName"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["city"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["postcode"] = ""
        context.payload["serviceOrderItem"][0]["service"]["place"][0]["country"] = ""

    elif field_type == "blank_MsocCustomer_Info":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["valueType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["@type"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "@schemaLocation"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"]["tenantId"] = ""

    elif field_type == "blank_consentCountries":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "consentCountries"] = ""

    elif field_type == "blank_customerDomains":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "customerDomains"] = ""

    elif field_type == "blank_MsocCustomerContact":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["name"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["valueType"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["@type"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["firstName"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["lastName"] = ""
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["email"] = ""

    elif field_type == "blank_firstName":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["firstName"] = ""

    elif field_type == "blank_lastName":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["lastName"] = ""

    elif field_type == "blank_email":
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"]["email"] = ""

    elif field_type == 'invalid_consentCountries':
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "consentCountries"] = "WAKANDA"

    elif field_type == 'empty_several_consentCountries':
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "consentCountries"] = ["VFDE", ""]

    elif field_type == 'invalid_several_consentCountries':
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "consentCountries"] = ["VFDE", "WAKANDA"]

    elif field_type == 'empty_customerDomains':
        context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][0]["value"][
            "customerDomains"] = ["", "abc.com"]

    else:
        raise NotImplementedError(f'{field_type=} is not implemented')

    logging.info("Altered initial payload:")
    logging.info(json.dumps(context.payload, indent=3))


@when("DDIs are processed in Middleware")
def ddis_are_processed_in_middleware(context):
    """ verify that both onboard customer and ddi process are complete"""
    # if msoc customer has not been onboarded, we need to perform the patching
    if not getattr(context, 'msoc_customer_onboarded', False):
        logger.info('processing msoc customer onboard')
        new_msoc_customer_onboarded(context)  # has submit request action!
        msoc_billing_request_processed(context)
    if not getattr(context, 'ddis_provisioned_in_sippio', False):
        validate_msoc_numbers_request(context, 'add')


@given("DDIs are ordered")
def default_ddi_order(context):
    """ default add ddi request """
    msoc_order_created_for_numbers(context, 'add', 5, pool_type=MsocResourceType.pool.name)
    flowHandler.customer_sends_an_order_to_middleware(context)


def request_payload_for_msoc_customer_with_billing_info_add_numbers_generated(context, quantity, market):
    context.msoc_account = MSOCAccount(market_code=market, billing_info=BillingInfo())
    msoc_account_payload = MSOCAccountPayloadGenerator(msoc_account=context.msoc_account, action=Action.add).to_dict()
    msoc_billing_info_payload = CountryBillingGenerator(account=context.msoc_account, action=Action.add,
                                                        payload=msoc_account_payload).to_dict()
    context.requested_numbers = MSOCNumbers(quantity=quantity,
                                            resource_type=MsocResourceType.pool,
                                            pool_type=PoolType.Fixed)

    context.payload = NumbersPayloadGenerator(account=context.msoc_account,
                                              requested_numbers=context.requested_numbers,
                                              action=Action.add,
                                              payload=msoc_billing_info_payload).to_dict()

    msoc_numbers.update_msoc_customer_context(context)
    msoc_numbers.update_msoc_numbers_context(context)


def request_payload_for_msoc_customer_with_billing_info_generated(context, market):
    context.billing_info = BillingInfo()
    context.msoc_account = MSOCAccount(market_code=market, billing_info=context.billing_info)

    msoc_account_payload = MSOCAccountPayloadGenerator(msoc_account=context.msoc_account, action=Action.add).to_dict()
    context.payload = CountryBillingGenerator(account=context.msoc_account, action=Action.add,
                                              payload=msoc_account_payload).to_dict()
    msoc_numbers.update_msoc_customer_context(context)


@then("a new MSOC Account is successfully created in the Middleware")
def msoc_account_created_in_middleware(context):
    TMFHandler.retrieve_and_validate(context, 'tmfmediator_command_create_msoccustomer')
    databaseHandler.bgid_is_stored_in_database(context)
    TMFHandler.retrieve_and_validate(context, 'idmapper_event_msoccustomer_created')
    jiraHandler.validate_jira_ticket_creation_success(context)
    patchHandler.send_patch_request_from_bo_tool(context, "update_service_order", "ucc.msoc.customer", "completed")
    TMFHandler.send_patch_request_tmf_service_order_gw(context, "get_service_order_by_id")
    validationHandler.validates_msoc_customer_or_number_status(context, "completed")
    idmapperHandler.lookup_msoc_account_by_properties(context, "BGID")
    sharedHandler.validate_status_response(context, "200")
    idmapperHandler.validate_msoc_account_information_correct(context)


@given("payload is created for topic '{topic_name}' for MSOC")
def create_payload_for_topic_msoc(context, topic_name):
    kafkaHandler.payload_created_for_topic(context, topic_name, category="MSOC")
