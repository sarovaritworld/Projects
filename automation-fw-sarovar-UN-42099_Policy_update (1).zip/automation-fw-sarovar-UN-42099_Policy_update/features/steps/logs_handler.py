import json
import logging

from behave import *
from jsonschema import validate

from classes import pod, read_xmldata


@when("The logs for pod '{pod_name}' are retrieved")
@when("The logs for pod '{pod_name}' are retrieved with '{search_value}'")
def retrieve_pod_logs(context, pod_name, search_value=None):
    context.pod_name = pod_name
    pod_logs = pod.read_logs(pod_name).split('\n')
    context.pod_logs = []
    if search_value is None:
        search_value = context.middleware_correlation_id
    for log in pod_logs:
        if search_value in log:
            context.pod_logs.append(log)


@then("Logs structure is validated")
def log_structure(context):
    schema = read_xmldata.read_jsonfile("schemas/log_schema")
    assert len(context.pod_logs) > 0, "No logs present in the list"
    for logs in context.pod_logs:
        logging.info(f"Validating {logs}")
        log_data = json.loads(logs)
        validate(log_data, schema=schema)
        if log_data["message"].startswith("Message received"):
            assert "dd.trace_id" in log_data["mdc"], "Log MDC should contain a field 'dd.trace_id' "
