import json
import logging
import os
import time
from http import HTTPStatus

from behave import *

from classes import read_xmldata, data_files, numbers, common
from classes.api.requests import number_management_api as nm
from classes.delay import Delay
from classes.status_code_validator import StatusCodeValidator
from common_python import api_requests
from features.steps import numProvisionHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)

MIDDLEWARE_API_SERVER = os.environ.get("MIDDLEWARE_API_SERVER")
NUMBER_OF_DIGIT = read_xmldata.readxml("NUMBER_OF_DIGIT", "test_inputdata", "num_prov")
UK_TELEPHONE_CODE = read_xmldata.readxml("UK_ISD_CODE", "test_inputdata", "num_prov")
NUMBER_MANAGEMENT_URL = read_xmldata.readxml("number_management", "test_inputdata", "MS_urls")


@when("User wants to retrieve operation status from RingCentral")
def retrieve_operation_status_rc(context):
    context.finalurl = f"http://{NUMBER_MANAGEMENT_URL}/number-management/v1/ucc/management/numbers/operation" \
                       "/status"


@when("user have a '{uuid_type}' UUID")
def validate_user_uuid(context, uuid_type):
    if "valid" in uuid_type:
        # context.UUID = read_xmldata.gen_uuid()
        # print("UUID generated: ", context.UUID)
        context.RC_UUID = context.RC_ID
        context.RingCentralUUID = context.RC_ID
    if "blank" in uuid_type:
        context.UUID = ""
    if "invalid" in uuid_type:
        context.UUID = "a#$567%hy*"


@when("user creates a request to get the operation status")
def create_operation_status_request(context):
    # context.NumPool_UUID = "cc5cede6-c91f-4e7f-9cd1-01d6735cec35"
    paramvalue = {'uuid': context.UUID}
    time.sleep(Delay.get_operation_status)
    context.postresponse2 = api_requests.get(
        context.finalurl, params=paramvalue, token=context.access_token)
    # context.resp = context.postresponse2.json()
    print("GET Response:", context.postresponse2)
    print("------")


@when("user sends request to get provisioning status")
def request_provisioning_status(context):
    # context.NumPool_UUID = "cc5cede6-c91f-4e7f-9cd1-01d6735cec35"
    paramvalue = {'uuid': context.status_get_response_num_pool_uuid, 'include_data': True}
    time.sleep(Delay.get_provisioning_status)
    context.get_action = []
    context.get_E164 = []
    context.get_status = []
    context.get_type = []
    context.get_Extension = []
    time_slice = data_files.read_config("common.yml", "timeouts.email_kafka_timer")
    read_xmldata.wait_to_connect(time_slice)
    logging.info(context.finalurl)
    context.postresponse2 = api_requests.get(
        context.finalurl, params=paramvalue, token=context.access_token)
    logging.info(f"response: {context.postresponse2}")
    context.get_response = context.postresponse2.json()
    logging.info(f"Response Payload of Get status: {context.get_response}")
    logging.info(" ")
    logging.info(" ")
    if context.postresponse2.status_code == HTTPStatus.OK:
        context.get_response = context.postresponse2.json()
        logging.info(f"GET Response:{json.dumps(context.get_response, indent=3)}")
        logging.info(" ")


@then("user receives response from RingCentral as '{expected_code}'")
def response_code_from_rc(context, expected_code):
    StatusCodeValidator.receive_response_from_ring_central(context, expected_code)


# When users sends an End Notification Request for 'Add' operation to Number management>>>>>Put request
# When users sends an End Notification Request for 'Add' operation to Number management>>>>>Post request
@when("users sends an End Notification Request for '{requestType}' operation to Number management")
def send_end_notification_request_nm(context, requestType):
    time.sleep(Delay.end_notification_number_management)
    context.market_code = read_xmldata.readxml("market", "test_inputdata", "appdirectinput")
    # context.op_co_customer_id = "7797239476"
    # context.op_co_customer_id = context.consumer_payload["account"]["op_co_details"]["op_co_customer_id"]

    url = read_xmldata.readxml("middleware_api_url", "test_inputdata", "ringCentralAPI")
    context.puturl = nm.Client.url_notification(context.market_code, context.op_co_customer_id)
    # context.puturl = MIDDLEWARE_API_SERVER + url + context.market_code + "/customers/" + context.op_co_customer_id + "/operation/notification/url"
    context.operationstatuspayload = read_xmldata.read_jsonfile("putRequest_OperationStatus")
    context.operationstatuspayload["host"] = common.config.appdirect_stub["host"]
    context.operationstatuspayload["params"]["header"]["Authorization"] = "Bearer yygsfs"
    context.operationstatuspayload["params"]["query"]["market"] = context.market_code
    context.operationstatuspayload["params"]["query"]["customer_id"] = context.op_co_customer_id
    context.operationstatuspayload["port"] = common.config.appdirect_stub["port"]
    if "add" in requestType.lower():
        context.operationstatuspayload["method"] = "PUT"
    if "delete" in requestType.lower():
        context.operationstatuspayload["method"] = "DELETE"
    context.execute_steps(u"""
                        Then it contains a '{token_type}' JWT Token
                        """.format(token_type="valid"))
    context.putresponse_Operationstatus = nm.Client(token=context.access_token).put_notification(context.market_code,
                                                                                                 context.op_co_customer_id,
                                                                                                 context.operationstatuspayload,
                                                                                                 context.header)
    print(context.putresponse_Operationstatus)


# And Validate the response received from Number management Notification
@then("Validate the response received from Number management Notification")
def validate_number_management_notification_response(context):
    time.sleep(Delay.number_management_notification)
    # context.resp = read_xmldata.readjsonfile("OperationStatusEndNotification")
    # print("from step def",OperationStatusEndNotification)
    # context.resp = context.postresponse2.json()
    # print("GET Response:", context.resp)
    for i in range(len(context.resp['response']['data'])):
        context.RC_UUID = context.resp['response']['data'][0]['ringCentralUUID']
        context.get_action.append(context.resp['response']['data'][i]['action'])
        context.get_E164.append(context.resp['response']['data'][i]['e164'])
        context.get_status.append(context.resp['response']['data'][i]['status'])
        context.get_type.append(context.resp['response']['data'][i]['type'])
        context.get_Extension.append(context.resp['response']['data'][i]['extension'])
        # print(context.resp['response']['data'][i]['Action'])
    print("ID:", context.RC_UUID)
    print("Action:", context.get_action)
    print("E164:", context.get_E164)
    print("Status List:", context.get_status)
    print("Extension List:", context.get_Extension)
    print("Get Request Response:", context.postresponse2.content)
    print(" ")
    print(" ")
    print("------")
    context.execute_steps(u"""
                            Then user validates CSV file received from RingCentral
                            """)


@then("user validates CSV file received from RingCentral")
def validate_rc_csv_file(context):
    context.filename = context.Attachment_Field_Value
    context.RingCentralUUID = context.RC_ID
    # context.Action = context.action_value
    # context.RingCentralUUID = context.RC_UUID
    context.Action = context.get_action
    context.E164 = context.get_E164
    context.Extension = context.get_Extension
    context.type = context.get_type
    context.status = context.get_status
    context.tempfile = read_xmldata.read_file(context.filename)
    print(context.tempfile)
    assert context.RingCentralUUID in context.tempfile, "RC_ID is not present in CSV File"
    # assert context.Action in context.tempfile, "Requested Action is not present in CSV File"
    # assert context.Extension in context.tempfile, "Extension not present in CSV File"
    # assert context.type in context.tempfile, "Type Not present in CSV File"
    for i in range(len(context.E164)):
        assert context.E164[i] in context.tempfile, "E164 number not found: {}".format(context.E164[i])
        assert context.Action[i] in context.tempfile, "Action not found: {}".format(context.Action[i])
        assert context.type[i] in context.tempfile, "Type not found: {}".format(context.type[i])
        assert context.Extension[i] in context.tempfile, "Extension Not Found"
    context.csv_content = read_xmldata.readcsvfile(context.filename)
    # context.csv_content = read_xmldata.readcsvfile(context.filename)
    print("CSV Records are as follows: {}".format(context.csv_content))
    for line in context.csv_content:
        for item in range(len(context.E164)):
            if ((context.E164[item] == line['E164']) and (context.status[item] == line['Status']) and (
                    context.Action[item] == line['Action'])):
                print(
                    "Row matched -- E164: {} Line: {} Status: {} Action: {}".format(context.E164[item], line['E164'],
                                                                                      line['Status'],
                                                                                      context.Action[item]))
                # print("")
            # else:
            # print("Row Not Matched -- E164: {} Line: {} Status: {} Action: {}".format(context.E164[item],
            #                                                                         line['E164'], line['Status'],
            #                                                                        context.Action[item]))
            #    print("")
        for record in range(len(context.Action)):
            if ((context.Action[record] == "S") or (context.Action[record] == "SU") or (
                    context.Action[record] == "SC")):
                if ((context.Extension[record] == line['Extension']) and (
                        context.status[record] == line['Status']) and (context.Action[record] == line['Action'])):
                    print("Extension Matched -- Extension : {} CSV Extension : {} Status : {} Action : {}".format(
                        context.Extension[record], line['Extension'], \
                        line['Status'], context.Action[record]))
                # else:
                # print("Extension not Matched -- Extension : {} CSV Extension : {} Status : {} Action : {}".format(
                #   context.Extension[record], line['Extension'], \
                #  line['Status'], context.Action[record]))
                #    print("_______________")
    print("Test Case marked as Completed...")
    print("")
    # print("==========================================================================================")
    # for record in range(len(context.Action)):
    # if ((context.E164[record] == line['E164']) and (context.Action[record] == line['Action'])):
    # print("Row matched for Action -- E164: {} Line: {} Action: {}".format(context.E164[record], line['E164'], line['Action']))
    # else:
    # print("Row not matched Action -- E164: {} Line: {} Action: {}".format(context.E164[record], line['E164'], line['Action']))


# And user makes a lookup for 'Add' operation by providing 'all' numbers
@then("user makes a lookup for '{action_type}' operation by providing '{action}' numbers")
def lookup_action_operation_by_numbers(context, action_type, action):
    logging.info(f"Action Type = {action_type} and action is: {action}")
    for i in range(len(context.E164_LookupValue)):
        context.lookup_num = context.E164_LookupValue[i]
        numProvisionHandler.perform_lookup(context, context.lookup_num, HTTPStatus.OK)
        json_response = context.response
        logging.info(f"Look-up get response Payload: {json.dumps(json_response, indent=3)}")
        assert context.admin_number_add == json_response["admin_number"], \
            f"Response admin_number: {json_response['admin_number']}, Expected admin_number: {context.admin_number_add}"
        assert context.market_code == json_response["market"], \
            f"Response market: {json_response['market']}, Expected market: {context.market_code}"
        assert context.op_co_customer_id == json_response["customer_id"], \
            f"Response customer_id: {json_response['customer_id']}, Expected customer_id: {context.op_co_customer_id}"


# And user creates 'no_main_number' for optional parameters
@given("user creates '{payload}' for optional parameters")
@when("user creates '{payload}' for optional parameters")
def create_payload_for_optional_parameters(context, payload):
    if "no_main_number" in payload:
        numProvisionHandler.contains_requestbody(context)

        if context.flag == 1:
            print("Inside flag if statement")
            print(
                "####################################################################################################################################")

            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']
        context.E164_List.remove(context.main_number_add)
        context.E164_LookupValue.remove(context.main_number_add)

    if "no_pool_list" in payload:
        numProvisionHandler.contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['pool']
        context.E164_List.remove(context.pool_1)
        context.E164_List.remove(context.pool_2)
        context.E164_List.remove(context.pool_3)
        context.E164_List.remove(context.fw_1)
        context.E164_List.remove(context.fw_2)
        context.E164_List.remove(context.fw_3)
        context.E164_LookupValue = context.E164_List

    if "no_fw_pool_list" in payload:
        numProvisionHandler.contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['fw_pool']
        context.E164_List.remove(context.fw_1)
        context.E164_List.remove(context.fw_2)
        context.E164_List.remove(context.fw_3)
        context.E164_LookupValue = context.E164_List

    if "pool_number" in payload:
        # print("old Context.Poolpayload in parameter of pool number=", context.poolpayload)
        print("")
        print("")
        context.poolpayload_json = read_xmldata.read_jsonfile("pool_number")
        logging.info(f"Pool List {context.number_pool_list}")
        if "duplicate" in payload:
            context.number_pool_list[0] = context.number_pool_list[1]
        context.poolpayload_json["pool"] = context.number_pool_list

        context.poolpayload = context.poolpayload_json
        print("New Context.Poolpayload in in parameter of pool number=", context.poolpayload)
        print("")
        print("")
        # if context.flag == 1:
        #     context.poolpayload['main_number'] = context.save_main_number
        #     context.poolpayload['admin_number'] = context.save_admin_number
        # del context.poolpayload['fw_pool']
        # context.E164_List.remove(context.fw_1)
        # context.E164_List.remove(context.fw_2)
        # context.E164_List.remove(context.fw_3)
        # del context.poolpayload['main_number']
        # del context.poolpayload['admin_number']
        # context.E164_List.remove(context.main_number_add)
        # context.E164_List.remove(context.admin_number_add)
        context.E164_List = context.number_pool_list[1]
        context.E164_LookupValue = context.poolpayload["pool"]

    if "admin_number" == payload:
        context.poolpayload_json = read_xmldata.read_jsonfile("admin_number")
        if not hasattr(context, 'admin_number_add'):
            context.admin_number_add = numbers.generate_phone_number('VFUK')
        context.poolpayload_json["admin_number"] = context.admin_number_add
        context.poolpayload = context.poolpayload_json
        print("New Context.Poolpayload in in parameter of pool number=", context.poolpayload)
        # context.E164_List = context.number_pool_list[1]
        context.E164_List = context.admin_number_add
        context.E164_LookupValue = context.E164_List

    if "no_admin_number" == payload:
        numProvisionHandler.contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['admin_number']
        context.E164_List.remove(context.admin_number_add)
        context.E164_LookupValue.remove(context.admin_number_add)

    if "mandatory_numbers" in payload:
        context.flag = 1
        numProvisionHandler.contains_requestbody(context)

        context.save_main_number = context.poolpayload['main_number']
        context.save_admin_number = context.poolpayload['admin_number']
        del context.poolpayload['pool']
        del context.poolpayload['fw_pool']
        del context.poolpayload['admin_number']
        context.E164_List.remove(context.admin_number_add)
        context.E164_List.remove(context.pool_1)
        context.E164_List.remove(context.pool_2)
        context.E164_List.remove(context.pool_3)
        context.E164_List.remove(context.fw_1)
        context.E164_List.remove(context.fw_2)
        context.E164_List.remove(context.fw_3)
        del context.E164_FwPoolList
        # context.E164_LookupValue = [context.save_main_number, context.save_admin_number]
        context.E164_LookupValue = [context.save_main_number]

    if "no_main_admin_numbers" in payload:
        numProvisionHandler.contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['main_number']
        del context.poolpayload['admin_number']
        context.E164_List.remove(context.main_number_add)
        context.E164_List.remove(context.admin_number_add)
        context.E164_LookupValue = context.E164_List

    if "no_fwpool_admin_numbers" in payload:
        numProvisionHandler.contains_requestbody(context)

        if context.flag == 1:
            context.poolpayload['main_number'] = context.save_main_number
            context.poolpayload['admin_number'] = context.save_admin_number
        del context.poolpayload['admin_number']
        del context.poolpayload['fw_pool']
        context.E164_List.remove(context.admin_number_add)
        context.E164_List.remove(context.fw_1)
        context.E164_List.remove(context.fw_2)
        context.E164_List.remove(context.fw_3)
        context.E164_LookupValue = context.E164_List

    if "OKMain_NOKPool" in payload:
        numProvisionHandler.contains_requestbody(context, 'jsonrequest_body_OKMain_NOKPool')

        del context.poolpayload['admin_number']
        del context.poolpayload['fw_pool']
        context.E164_List.remove(context.admin_number_add)
        context.E164_LookupValue = context.E164_List

    if "NOKMain_OKPool" in payload:
        numProvisionHandler.contains_requestbody(context, 'jsonrequest_body_NOKMain_OKPool')

        del context.poolpayload['admin_number']
        # del context.poolpayload['fw_pool']
        context.E164_List.remove(context.admin_number_add)
        context.E164_LookupValue = context.E164_List

    if "Main_Pool_SameAccount" in payload:
        numProvisionHandler.contains_requestbody(context, 'jsonrequest_Main_Pool_SameAccount')


        del context.poolpayload['admin_number']
        del context.poolpayload['main_number']
        del context.poolpayload['fw_pool']

    if "Main_FwPool_SameAccount" in payload:
        numProvisionHandler.contains_requestbody(context, 'jsonrequest_Main_FwPool_SameAccount')

        del context.poolpayload['admin_number']
        del context.poolpayload['main_number']
        del context.poolpayload['pool']


@then("user validates Error message in response of operation status for '{action_type}'")
def validate_operation_status_error_message(context, action_type):
    time.sleep(Delay.validate_error_operation_status)
    assert context.get_response["status"][
               "state"] == "ERROR", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
        context.get_response["status"]["state"], "ERROR")
    if action_type == "NOKMain_OKPool":
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue)):
            print("test list >>>>>", context.E164_LookupValue)
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> pool list", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['status'] == "NOK":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "NOK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "NOK")
                assert context.get_response['response']['data'][x][
                           'type'] == None, "Type of Number is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], None)

            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match in pool list. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

        for y in range(0, len(context.number_fwpool_list)):
            print("test", len(context.E164_LookupValue), y)
            print("test list>>>>>", context.number_fwpool_list)
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'])
            print("e164 ----> fw number ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'])
            print("status ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'])
            print("message ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'])
            print(" ")

            if context.get_response['response']['data'][y]['status'] == "NOK":
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['ringCentralUUID'],
                    context.RingCentralUUID)
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'e164'] in context.number_fwpool_list, "E164 does not match in fw pool list. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'],
                    context.number_fwpool_list)
                assert context.op_action1 == \
                       context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'],
                    context.op_action1)
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'message'] == "Phone number could not be provisioned in RingCentral", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'], "Phone number could not be provisioned in RingCentral")
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'status'] == "NOK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'], "NOK")
            else:
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['ringCentralUUID'],
                    context.RingCentralUUID)
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'e164'] in context.number_fwpool_list, "E164 does not match in fw pool list. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'],
                    context.number_fwpool_list)
                assert context.op_action1 == context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'],
                    context.op_action1)
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'], "")
                assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'], "OK")

            print("Operation Status Validated Successfully...")
            print(" ")

    elif action_type == "OKMain_NOKPool":
        context.op_action = "A"
        context.RingCentralUUID = context.RC_UUID
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print(" ")

            if context.get_response['response']['data'][x]['action'] == "A" and \
                    context.get_response['response']['data'][x]['type'] != "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                print("context.RingCentralUUID ----> ", context.RingCentralUUID)
                print("ops action ----> ", context.get_response['response']['data'][x]['action'])
                print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
                print("status ----> ", context.get_response['response']['data'][x]['status'])
                print("message ----> ", context.get_response['response']['data'][x]['message'])
                print(" ")

                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "NOK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "NOK")
                # assert context.get_response['response']['data'][x][
                # 'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                # context.get_response['response']['data'][x]['message'], "")

            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                print("context.RingCentralUUID ----> ", context.RingCentralUUID)
                print("ops action ----> ", context.get_response['response']['data'][x]['action'])
                print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
                print("status ----> ", context.get_response['response']['data'][x]['status'])
                print("message ----> ", context.get_response['response']['data'][x]['message'])
                print(" ")

                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif "Delete_Pool_Number_with_NOK" == action_type:
        context.op_action = "D"
        for x in range(0, len(context.number_pool_list)):
            print("test", len(context.number_pool_list), x)
            print(" ")
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.number_pool_list, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.number_pool_list)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.op_action)

            assert context.get_response['response']['data'][x][
                       'status'] == "NOK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "NOK")
        print("Operation Status Validated Successfully...")
        print(" ")


@then("user validates response of '{operation_type}' operation status for '{action_type}'")
@then("user validates response of operation status for '{action_type}'")
def validate_operation_status_response_for_action(context, action_type, operation_type = None):
    time.sleep(Delay.validate_response_operation_status)
    print("")
    assert context.get_response["status"][
               "state"] == "SUCCESS", f"Status mismatch. current value: {context.get_response['status']['state']}, expected Value: SUCCESS"
    # if "Add" in action_type:
    if action_type == "addall":
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print("context.E164_LookupValue>>>>>>", context.E164_LookupValue)
            print(" ")
            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x]['e164'] == context.main_number_add
            if context.get_response['response']['data'][x]['type'] == "A":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x]['e164'] == context.admin_number_add
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.op_action)
            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")
            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

        for y in range(0, len(context.number_fwpool_list)):
            logging.info(f"test {len(context.E164_LookupValue)}, {y}")
            logging.info(f"context.number_fwpool_list>>>> {context.number_fwpool_list}")
            logging.info(f"context.RingCentralUUID: {context.RingCentralUUID}")
            logging.info(
                f"ops action : {context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action']}")
            logging.info(
                f"e164 : {context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164']}")
            logging.info(
                f"status : {context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status']}")
            logging.info(
                f"message : {context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message']}")
            logging.info(f" ")

            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['ringCentralUUID'],
                context.RingCentralUUID)
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'e164'] in context.number_fwpool_list, "E164 does not match from number_fwpool_list. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'],
                context.number_fwpool_list)
            assert context.op_action1 == context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'],
                context.op_action1)
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'], "")
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'], "OK")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif action_type == "forward_pool":
        context.op_action1 = "AF"
        if operation_type == "Delete":
            context.op_action1 = "D"
        for y in range(0, len(context.number_fwpool_list)):
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][y]['action'])
            print("e164 ----> ", context.get_response['response']['data'][y]['e164'])
            print("status ----> ", context.get_response['response']['data'][y]['status'])
            # print("message ----> ", context.get_response['response']['data'][y]['message'])
            print(" ")

            assert context.get_response['response']['data'][y][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][y][
                       'e164'] in context.number_fwpool_list, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y]['e164'], context.number_fwpool_list)
            assert context.op_action1 == context.get_response['response']['data'][y][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y]['action'], context.op_action1)
            # assert context.get_response['response']['data'][y][
            # 'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
            # context.get_response['response']['data'][y]['message'], "")
            assert context.get_response['response']['data'][y][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y]['status'], "OK")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif action_type == "pool_list":
        context.op_action = "A"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print(" ")
            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.main_number_add)
            if context.get_response['response']['data'][x]['type'] == "A":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'e164'] == context.admin_number_add, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.admin_number_add)
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.op_action)
            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")
            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

    elif action_type == "onlypool":
        context.op_action = "A"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print(" ")
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.op_action)
            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")
            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

    elif action_type == "no_main_number":
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['type'] == "A":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.admin_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.admin_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")

            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

        for y in range(0, len(context.number_fwpool_list)):
            print("test", len(context.E164_LookupValue), y)
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'])
            print("e164 ----> ",
                        context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'])
            print("status ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'])
            print("message ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'])
            print(" ")

            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['ringCentralUUID'],
                context.RingCentralUUID)
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'e164'] in context.number_fwpool_list, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'],
                context.number_fwpool_list)
            assert context.op_action1 == context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'],
                context.op_action1)
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'], "")
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'], "OK")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif action_type == "no_admin_number":
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")

            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

        for y in range(0, len(context.number_fwpool_list)):
            print("test", len(context.E164_LookupValue), y)
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'])
            print("e164 ----> ",
                        context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'])
            print("status ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'])
            print("message ----> ",
                  context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'])
            print(" ")
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['ringCentralUUID'],
                context.RingCentralUUID)
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'e164'] in context.number_fwpool_list, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['e164'],
                context.number_fwpool_list)
            assert context.op_action1 == context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['action'],
                context.op_action1)
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['message'], "")
            assert context.get_response['response']['data'][y + len(context.E164_LookupValue)][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + len(context.E164_LookupValue)]['status'], "OK")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif action_type == "no_pool_list":
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID

            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                print("context.RingCentralUUID ----> ", context.RingCentralUUID)
                print("ops action ----> ", context.get_response['response']['data'][x]['action'])
                print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
                print("status ----> ", context.get_response['response']['data'][x]['status'])
                print("message ----> ", context.get_response['response']['data'][x]['message'])
                print(" ")

                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

            if context.get_response['response']['data'][x]['type'] == "A":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                print("context.RingCentralUUID ----> ", context.RingCentralUUID)
                print("ops action ----> ", context.get_response['response']['data'][x]['action'])
                print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
                print("status ----> ", context.get_response['response']['data'][x]['status'])
                print("message ----> ", context.get_response['response']['data'][x]['message'])
                print(" ")

                assert context.get_response['response']['data'][x][
                           'e164'] == context.admin_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.admin_number_add)
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

        for y in range(0, len(context.number_fwpool_list)):
            print("test", len(context.E164_LookupValue), y)
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][y + 2]['action'])
            print("e164 ----> ", context.get_response['response']['data'][y + 2]['e164'])
            print("status ----> ", context.get_response['response']['data'][y + 2]['status'])
            print("message ----> ", context.get_response['response']['data'][y + 2]['message'])
            print(" ")

            assert context.get_response['response']['data'][y + 2][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + 2]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][y + 2][
                       'e164'] in context.number_fwpool_list, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + 2]['e164'], context.number_fwpool_list)
            assert context.op_action1 == context.get_response['response']['data'][y + 2][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + 2]['action'], context.op_action1)
            assert context.get_response['response']['data'][y + 2][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + 2]['message'], "")
            assert context.get_response['response']['data'][y + 2][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][y + 2]['status'], "OK")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif action_type == "no_fw_pool_list":
        context.op_action = "A"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print(" ")
            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.main_number_add)
            if context.get_response['response']['data'][x]['type'] == "A":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'e164'] == context.admin_number_add, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.admin_number_add)
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.op_action)
            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")
            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif action_type == "mandatory_numbers":
        context.op_action = "A"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print(" ")
            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.main_number_add)
            context.RingCentralUUID = context.RC_UUID,

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.op_action)
            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")
            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif action_type == "admin_number_only":
        context.op_action = "A"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print(" ")
            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'e164'] == context.admin_number_add, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.admin_number_add)
            context.RingCentralUUID = context.RC_UUID,

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.op_action)
            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")
            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

        print("Operation Status Validated Successfully...")
        print(" ")

    elif "Delete" == action_type:
        context.op_action = "D"
        for y in range(len(context.E164_LookupValue)):
            if context.get_response['response']['data'][y]['type'] == "M":
                assert context.get_response['response']['data'][y][
                           'e164'] == context.main_number_delete, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y]['e164'], context.main_number_delete)
            if context.get_response['response']['data'][y]['type'] == "A":
                assert context.get_response['response']['data'][y][
                           'e164'] == context.admin_number_delete, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][y]['e164'], context.admin_number_delete)

    elif "Delete_Pool_Number" == action_type:
        context.op_action = "D"
        for x in range(0, len(context.number_pool_list)):
            print("test", len(context.number_pool_list), x)
            print(" ")
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.number_pool_list, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.number_pool_list)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['action'], context.number_pool_list)

            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")

            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matched. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

        print("Operation Status Validated Successfully...")
        print(" ")

    else:
        assert 1 == 0, "Validation is not available for this event={}".format(action_type)


# And user validates 'pending' response of operation status for 'Add' operation for 'no_main_number' numbers
@then(
    "user validates '{response_type}' response of operation status for '{action_type}' operation for '{number_type}' numbers")
def validate_operation_status_response_for_numbers(context, response_type, action_type, number_type):
    context.get_response = context.postresponse2.json()
    print("context.E164_LookupValue for pending ------>>>>", context.E164_LookupValue)
    print(" ")
    # if "Add" in action_type:
    if response_type == "pending" and action_type == "Add" and number_type == "no_main_number":
        assert context.get_response["status"][
                   "state"] == "PENDING", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "PENDING")
        # assert context.get_response["status"]["message"] == "Processing", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(context.get_response["status"]["message"], "Processing")
        # Defect has been raised for this validation UPUA-3935
        context.op_action = "A"
        context.op_action1 = "AF"

        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['type'] == "A":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.admin_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.admin_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")

            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

    elif response_type == "pending" and action_type == "Add" and number_type == "no_admin_number":
        assert context.get_response["status"][
                   "state"] == "PENDING", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "PENDING")
        # assert context.get_response["status"]["message"] == "Processing", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(context.get_response["status"]["message"], "Processing")
        # Defect has been raised for this validation UCCA_3935
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")

            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

    elif response_type == "pending" and action_type == "Add" and number_type == "no_pool_list":
        context.E164_LookupValue1 = [context.main_number_add, context.admin_number_add]
        print("context.E164_LookupValue1 for pending ------***>>>>", context.E164_LookupValue1)
        print(" ")
        assert context.get_response["status"][
                   "state"] == "PENDING", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "PENDING")
        # assert context.get_response["status"]["message"] == "Processing", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(context.get_response["status"]["message"], "Processing")
        # Defect has been raised for this validation UPUA-3935
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue1)):
            print("test", len(context.E164_LookupValue1), x)
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")

            if context.get_response['response']['data'][x]['type'] == "A":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'e164'] == context.admin_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.admin_number_add)
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

    elif response_type == "pending" and action_type == "Add" and number_type == "all":

        print("context.E164_LookupValue for pending ------***>>>>", context.E164_LookupValue)
        print(" ")
        assert context.get_response["status"][
                   "state"] == "PENDING", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "PENDING")
        # assert context.get_response["status"]["message"] == "Processing", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(context.get_response["status"]["message"], "Processing")
        # Defect has been raised for this validation UPUA-3935
        context.op_action = "A"
        context.op_action1 = "AF"

        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            print(" ")
            try:
                if context.get_response['response']['data'][x]['type'] == "M":
                    print("validate number >>", context.get_response['response']['data'][x]['type'])
                    assert context.get_response['response']['data'][x][
                               'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                        context.get_response['response']['data'][x]['e164'], context.main_number_add)
                if context.get_response['response']['data'][x]['type'] == "A":
                    print("validate number >>", context.get_response['response']['data'][x]['type'])
                    assert context.get_response['response']['data'][x][
                               'e164'] == context.admin_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                        context.get_response['response']['data'][x]['e164'], context.admin_number_add)
                context.RingCentralUUID = context.RC_UUID
            except (KeyError, IndexError):
                print("KeyError/IndexError for get ops status, Please check the JSON payload")
                assert 1 == 0, "KeyError/IndexError for get ops status, Please check the JSON payload"

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            assert context.get_response['response']['data'][x][
                       'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
            assert context.get_response['response']['data'][x][
                       'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
            assert context.op_action == context.get_response['response']['data'][x][
                'action'], "Incorrect Action defined"
            assert context.get_response['response']['data'][x][
                       'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['status'], "OK")
            assert context.get_response['response']['data'][x][
                       'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                context.get_response['response']['data'][x]['message'], "")

    elif response_type == "pending" and action_type == "Add" and number_type == "mandatory_numbers":
        assert context.get_response["status"][
                   "state"] == "PENDING", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "PENDING")
        # assert context.get_response["status"]["message"] == "Processing", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(context.get_response["status"]["message"], "Processing")
        # Defect has been raised for this validation UPUA-3935
        context.op_action = "A"
        context.op_action1 = "AF"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")

            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match"
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

    elif response_type == "pending" and action_type == "Add" and number_type == "NOKMain_OKPool":
        assert context.get_response["status"][
                   "state"] == "ERROR", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "ERROR")
        assert context.get_response["status"][
                   "message"] == "Order was partially fulfilled", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["message"], "Order was partially fulfilled")
        # Defect has been raised for this validation UPUA-3935
        context.op_action = "A"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID
            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['status'] == "NOK":
                print("validate number type of Main number>>",
                            context.get_response['response']['data'][x]['type'])
                print(" ")
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "NOK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "NOK")
                assert "errorCode:" in context.get_response['response']['data'][x][
                    'message'], "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")
                assert context.get_response['response']['data'][x][
                           'type'] == None, "Type of Number is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['type'], None)
            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
                assert context.get_response['response']['data'][x][
                           'message'] == "", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

    elif response_type == "pending" and action_type == "Add" and number_type == "OKMain_NOKPool":
        assert context.get_response["status"][
                   "state"] == "PENDING", "Status is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["state"], "PENDING")
        assert context.get_response["status"][
                   "message"] == "Order was partially fulfilled", "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
            context.get_response["status"]["message"], "Order was partially fulfilled")

        context.op_action = "A"
        for x in range(0, len(context.E164_LookupValue)):
            print("test", len(context.E164_LookupValue), x)
            context.RingCentralUUID = context.RC_UUID

            print("context.RingCentralUUID ----> ", context.RingCentralUUID)
            print("ops action ----> ", context.get_response['response']['data'][x]['action'])
            print("e164 ----> ", context.get_response['response']['data'][x]['e164'])
            print("status ----> ", context.get_response['response']['data'][x]['status'])
            print("message ----> ", context.get_response['response']['data'][x]['message'])
            print(" ")

            if context.get_response['response']['data'][x]['type'] == "M":
                print("validate number >>", context.get_response['response']['data'][x]['type'])
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'e164'] == context.main_number_add, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.main_number_add)
                assert context.get_response['response']['data'][x][
                           'status'] == "OK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "OK")
            else:
                assert context.get_response['response']['data'][x][
                           'ringCentralUUID'] in context.RingCentralUUID, "RC_ID does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['ringCentralUUID'], context.RingCentralUUID)
                assert context.get_response['response']['data'][x][
                           'e164'] in context.E164_LookupValue, "E164 does not match. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['e164'], context.E164_LookupValue)
                assert context.op_action == context.get_response['response']['data'][x][
                    'action'], "Incorrect Action defined. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['action'], context.op_action)
                assert context.get_response['response']['data'][x][
                           'status'] == "NOK", "Status of E164 is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['status'], "NOK")
                assert "errorCode:" in context.get_response['response']['data'][x][
                    'message'], "Message is not matching. Actual value = {} and Expected Value = {}  ".format(
                    context.get_response['response']['data'][x]['message'], "")

    else:
        assert 1 == 0, "Validation is not available for this event = {}".format(number_type)


# And user validates get operation status response for 'same_account_inventory'
@then("user validates get operation status response for '{error_type}'")
def validate_get_operation_status_response_for_error(context, error_type):
    context.get_response = context.postresponse2.json()
    validation_set = {}
    context.get_response['response']['data'].sort(key=lambda x: (x['e164']))

    if error_type in ("same_account_inventory", "same_account_presentation", "MainCompanyNumber_inventory"):
        action = {"same_account_inventory": "A",  "same_account_presentation": "AF", "MainCompanyNumber_inventory": "A"}
        context.new_pool.insert(0, context.main_number_add)
        context.E164_List = numbers.sorted_numbers(context.new_pool)
        validation_set["status.state"] = "SUCCESS"
        validation_set["status.code"] = "200"
        validation_set["status.message"] = "Operation successful"
        for i, number in enumerate(context.E164_List):
            if i == 0:
                validation_set[f"response.data.{0}.type"] = "M"
                validation_set[f"response.data.{0}.action"] = "A"
            else:
                validation_set[f"response.data.{i}.action"] = action[error_type]
            validation_set[f"response.data.{i}.ringCentralUUID"] = context.RC_UUID
            validation_set[f"response.data.{i}.e164"] = number
            validation_set[f"response.data.{i}.status"] = 'OK'

    elif error_type in ("different_account_inventory", "different_account_presentation", "DirectNumber_presentation"):
        context.E164_List = numbers.sorted_numbers(context.new_pool)
        validation_set["status.state"] = "ERROR"
        validation_set["status.code"] = "206"
        validation_set["status.message"] = "Order was partially fulfilled"
        for i, number in enumerate(context.E164_List):
            validation_set[f"response.data.{i}.ringCentralUUID"] = context.RC_UUID
            validation_set[f"response.data.{i}.e164"] = number
            validation_set[f"response.data.{i}.status"] = 'NOK'
            validation_set[f"response.data.{i}.message"] = 'Phone number is already in use but does not exist in the customer inventory'
            if error_type == "DirectNumber_presentation":
                validation_set[f"response.data.{i}.message"] = f'Phone number is already in use with an incompatible usage type: {error_type.split("_")[0]}'

    elif error_type in "same_account_partial_inventory":
        context.new_pool.insert(0, context.main_number_add)
        context.E164_List = numbers.sorted_numbers(context.new_pool)
        validation_set["status.state"] = "ERROR"
        validation_set["status.code"] = "206"
        validation_set["status.message"] = "Order was partially fulfilled"
        for i in range(len(context.E164_List)):
            if i == 0 or i == 1:
                validation_set[f"response.data.{i}.status"] = 'NOK'
                validation_set[f"response.data.{i}.message"] = 'Phone number is already in use but does not exist in the customer inventory'
            else:
                validation_set[f"response.data.{i}.status"] = 'OK'
            validation_set[f"response.data.{i}.ringCentralUUID"] = context.RC_UUID
            validation_set[f"response.data.{i}.e164"] = context.E164_List[i]

    elif error_type == "ForwardedNumber_presentation":
        context.E164_List = numbers.sorted_numbers(context.new_pool)
        validation_set["status.state"] = "SUCCESS"
        validation_set["status.code"] = "200"
        validation_set["status.message"] = "Operation successful"
        for i, number in enumerate(context.E164_List):
            validation_set[f"response.data.{i}.action"] = "AF"
            validation_set[f"response.data.{i}.ringCentralUUID"] = context.RC_UUID
            validation_set[f"response.data.{i}.e164"] = number
            validation_set[f"response.data.{i}.status"] = 'OK'

    elif error_type == "ForwardedCompanyNumber_inventory":
        context.new_pool.insert(0, context.main_number_add)
        context.E164_List = numbers.sorted_numbers(context.new_pool)
        validation_set["status.state"] = "ERROR"
        validation_set["status.code"] = "206"
        validation_set["status.message"] = "Order was partially fulfilled"
        for i, number in enumerate(context.E164_List):
            validation_set[f"response.data.{i}.action"] = "A"
            validation_set[f"response.data.{i}.ringCentralUUID"] = context.RC_UUID
            validation_set[f"response.data.{i}.e164"] = number
            validation_set[f"response.data.{i}.status"] = 'NOK'
            validation_set[f"response.data.{i}.message"] = f'Phone number is already in use with an incompatible usage type: {error_type.split("_")[0]}'

    common.validate_message(context.get_response, validation_set)
