from behave import given


@given("it contains a '{value_type}' for market")
def set_market(context, value_type):
    """
Sets market_code to the context
if None is passed (used for tests where you don't need to update the market_code > returns
icorrect_value > Vodafone_Market
no_value > empty string
if market_code is passed, like VFDE, VFES etc. > it sets it up
if context.market_code has not been previously set up, it sets it to Default value VFUK

    :param context:
    :param value_type: 'icorrect_value', 'no_value', 'valid_value', None, any market_code (ex VFDE, VFES etc)
    """
    match value_type:
        case None:
            return
        case "incorrect_value":
            context.market_code = "Vodafone_Market"
        case "no_value":
            context.market_code = ""
        case _:
            if not hasattr(context, 'market_code'):
                context.market_code = 'VFUK'
            if value_type.startswith("VF"):
                context.market_code = value_type

@given("it contains a '{value_type}' for customerid")
def set_op_co_customer_id(context, value_type):
    if "valid_value" in value_type:
        if not hasattr(context, 'op_co_customer_id'):
            context.op_co_customer_id = '88519941972'
    if "invalid_value" in value_type:
        context.op_co_customer_id = "112233"
    if "no_value" in value_type:
        context.op_co_customer_id = ''
