from behave import *

from classes import operations
from classes import read_xmldata
from classes.kafka import KafkaTopics, consumer_data, producer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.license import LicenseOrderItem, RCStubPreconfiguredLicenseCount, get_default_sku_id, \
    get_modified_license_number, get_test_failure_values
from classes.payload_generators.TMF import Action
from features.steps import TMFHandler, kafkaHandler
from features.steps.unityAddLicensesHandler import add_license_fails_with_error_message, \
    create_complex_service_order_with_license, request_order_for_license_count


@given("the change license operation is set to fail at '{api}' with '{error}'")
def trigger_license_change_error(context, api, error):
    # Set the fail at GET or POST level with different errors
    if api == 'Post_Licenses':
        if error == 'Bad_Request':
            context.error_type = "add_license_bad_request"
        else:
            context.error_type = "Server_Not_Found"
    else:
        context.error_type = f"{api}_{error}"
    context.RC_ID, context.op_co_customer_id = get_test_failure_values(api, error)


@when(
    "a complex service order is sent to add a unity account and '{license_operation}' the number of licenses to '{licenses_count}'")
def create_complex_license_so(context, license_operation, licenses_count):
    create_complex_service_order_with_license(context, license_operation, licenses_count)


@when(
    "against a different SKU_id a service order is sent to '{license_operation}' the number of licenses to '{licenses_count}'")
def create_licenses_service_order_different_sku_id(context, license_operation, licenses_count):
    request_order_for_license_count(context, license_operation, licenses_count, 'LC_LR_398')


@when("a service order is sent to '{license_operation}' the number of licenses to '{licenses_count}'")
@when("a modified request is sent to increase the number of licenses")
def create_license_service_order(context, license_operation: str = 'modify', licenses_count: int = 10):
    if not hasattr(context, 'unity_license'):
        context.unity_license = LicenseOrderItem(id=get_default_sku_id())
    request_order_for_license_count(context, license_operation, licenses_count, context.unity_license.id)


@when("kafka message for topic tmfmediator_command_change_unitylicense is sent with error account")
def tmfmediator_command_change_unitylicense(context):
    topic_name = "tmfmediator_command_change_unitylicense"
    context.payload = read_xmldata.read_jsonfile(f"topics/{topic_name}")
    context.middleware_correlation_id = context.payload["header"]["middleware_correlation_id"] = read_xmldata.gen_uuid()
    context.event_type = context.payload["header"]["event_type"]
    context.marketplace_event_id = context.payload["license_request"]["client_reference"][
        "marketplace_event_id"] = read_xmldata.gen_uuid() + "/1"
    context.operation_id = context.payload["license_request"]["client_reference"][
        "operation_id"] = read_xmldata.gen_uuid()

    context.payload["license_request"]["ucas_account_id"] = context.RC_ID
    context.kafka_send_message_response = producer_data.send_data(context.payload, topic_name)

    if not hasattr(context, 'unity_license'):
        order = context.payload["license_request"]["order"]
        context.unity_license = LicenseOrderItem(quantity=order["quantity"], id=order["sku_id"])


@then("the number of licenses is successfully modified for the account")
def validate_licenses_modification(context, error: str = None):
    # Default number of licenses the account will have in Dev and Test env, in the latter because we created a customer with 5 licenses added
    context.initial_license_count = RCStubPreconfiguredLicenseCount.quantity

    # Validate the message in Kafka topic 'tmfgateway_process_serviceorder'
    TMFHandler.retrieve_and_validate(context, 'tmfgateway_process_serviceorder')

    # Validate CHANGE_UNITY_LICENSE operation is created and its order is correct
    operations.validate_operations_order("ucc.unity.license", Action.modify, context.service_order_id)

    # Validate the message in Kafka topic 'tmfmediator_command_change_unitylicense'
    if not hasattr(context, 'ucas_provider'):
        context.ucas_provider = 'RINGCENTRAL'
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_change_unitylicense.name)
    KafkaTopicValidator(context).tmfmediator_command_change_unitylicense()

    # Validate the message in Kafka topic 'ringcentral_event_unitylicense_changed'
    kafkaHandler.get_messages(context, KafkaTopics.ringcentral_event_unitylicense_changed.name)
    KafkaTopicValidator(context).ringcentral_event_unitylicense_changed(error)

    # Depending on the ENV and the type of sku ID, obtain a number of licenses modified (deleted or added) that will be used for the following validation
    context.licenses_modified = get_modified_license_number(context.unity_license.id,
                                                            context.initial_license_count,
                                                            context.unity_license.quantity)

    # Validate the final status of the SO, Milestones and Notes, and Error Messages (depending on the scenario)
    if not error:
        TMFHandler.validate_final_state(context, 'completed')
    else:
        add_license_fails_with_error_message(context, error)


@then("modify license request fails with an error '{error_type}'")
def licenses_addition_fails_with_error(context, error_type):
    validate_licenses_modification(context, error_type)


@then("data is validated in ringcentral_event_unitylicense_changed for '{error}'")
def data_is_validated_in_ringcentral_event_unitylicense_added(context, error):
    topic = "ringcentral_event_unitylicense_changed"
    context.consumer_payload = consumer_data.get_messages(context, topic)
    KafkaTopicValidator(context).ringcentral_event_unitylicense_changed(error)


@then("licenses are not modified with error '{error}'")
def modify_license_fails_with_error_message(context, error):
    add_license_fails_with_error_message(context, error)
