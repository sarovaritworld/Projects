import logging

from behave import then, when

from classes import asserts, cac, common, data_files, database, payload
from classes.kafka import consumer_data, topic_validator
from classes.kafka.messages_filter import KafkaMessagesFilter
from classes.kafka.topic_validator import KafkaTopicValidator
from features.steps import CRFHandler, TMFHandler


@then("CAC ID is stored in UC MW MSOC Customer inventory")
def add_cac_to_msoc_customer_success(context):
    """ Validating that CAC configuration is stored in Middleware (up to CRF)
    https://confluence.tools.aws.vodafone.com/display/UCP/ADD_CAC_TO_MSOC_CUSTOMER+Operation
    """
    add_cac_to_msoc_customer(context)

    # database.get_cac_configuration_request(context.cac_id)  # we may search by other parameters
    # assert it is 'CREATED' if possible


@then("CAC ID is failed to be stored in id-mapper")
def add_cac_to_msoc_customer_fail(context):
    """ Validating that CAC configuration is failed to store in Middleware on id mapper stage
    https://confluence.tools.aws.vodafone.com/display/UCP/ADD_CAC_TO_MSOC_CUSTOMER+Operation
    """
    add_cac_to_msoc_customer(context, "cac_id_already_exist")


@then("CAC ID is stored in Middleware with '{error_type}'")
def add_cac_to_msoc_customer(context, error_type: str = None):
    """ Validating that CAC configuration is stored in Middleware (up to CRF)
    https://confluence.tools.aws.vodafone.com/display/UCP/ADD_CAC_TO_MSOC_CUSTOMER+Operation
    """
    # filter to get the cac message
    context.consumer_payload = consumer_data.get_messages(context, 'tmfgateway_process_serviceorder')
    topic_validator.KafkaTopicValidator(context).validate_topic(
        'tmfgateway_process_serviceorder')  # may pass expected soi
    common.update_middleware_correlation_id(context)
    common.save_marketplace_event_id(context)
    cac.validate_order_of_operations(context.service_order_id)
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_add_msoccustomercac')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_add_msoccustomercac()
    cac_id = context.cac_id
    if "existing_cac_id" in context:
        cac_id = context.existing_cac_id
    cac.validate_cac_id_in_idmapper_db(context.op_co_customer_id, cac_id.upper())

    context.consumer_payload = consumer_data.get_messages(context, 'idmapper_event_msoccustomercac_added')
    topic_validator.KafkaTopicValidator(context).idmapper_event_msoccustomercac_added(error_type)
    expected_state = "COMPLETED" if not error_type else "FAILED"
    cac.validate_state_of_operations(context.service_order_id, "ADD_CAC_TO_MSOC_CUSTOMER", expected_state)


@then("CAC ID is updated in CRF")
def apply_cac_configuration_success(context):
    """ Validate that CAC configuration is applied in the CRF
    https://confluence.tools.aws.vodafone.com/display/UCP/APPLY_CAC_CONFIGURATION+Operation
    """
    apply_cac_configuration(context, 'COMPLETED')


@then("CAC ID is failed to be updated in CRF")
def apply_cac_configuration_fail(context):
    """ Validate that CAC configuration is failed in the CRF
    https://confluence.tools.aws.vodafone.com/display/UCP/APPLY_CAC_CONFIGURATION+Operation
    """
    apply_cac_configuration(context, 'FAILED')


@then("CAC ID is pending to be updated in CRF")
def apply_cac_configuration_pending(context):
    """ Validate that CAC configuration is pending in the CRF
    https://confluence.tools.aws.vodafone.com/display/UCP/APPLY_CAC_CONFIGURATION+Operation
    """
    apply_cac_configuration(context, 'WAITING')


@then("CAC ID state in '{state}' in CRF")
def apply_cac_configuration(context, state):
    """ Validate that CAC configuration processed in the CRF
        https://confluence.tools.aws.vodafone.com/display/UCP/APPLY_CAC_CONFIGURATION+Operation
        """
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_apply_cacconfiguration')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_apply_cacconfiguration()
    common.update_middleware_correlation_id(context)
    common.save_marketplace_event_id(context)

    # here we need to catch modify resource in CRF stub and save to kafka/db and then validate

    if state in ("COMPLETED", "FAILED") and "fail_on_crf_req" not in context:
        context.action = 'modify'
        CRFHandler.crf_id_saved_in_db(context, search_strategy="last_request")
        TMFHandler.retrieve_and_validate(context, 'crfstub_process_resourceorder')
        CRFHandler.crf_notification_sent_with_status(context, state.lower())
        CRFHandler.validate_crf_request_state_db(context, state.lower())
    margin_in = None if not hasattr(context, "marging_in") else context.margin_in
    # changing it to upper case because of this defect: https://jira.tools.aws.vodafone.com/browse/UN-32435
    context.cac_id = context.cac_id.upper()
    database.get_cac_configuration_request(context.cac_id, state, context.op_co_customer_id, margin_in)
    # assert that state is 'state'
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_cacconfiguration_applied')
    topic_validator.KafkaTopicValidator(context).crfgateway_event_cacconfiguration_applied(outcome=state)
    context.cac_provisioning_status = common.get_field(context.consumer_payload,
                                                       "$.cacConfigurationRequest.cacRequestStatus")
    context.cac_provisioning_error_message = common.get_field(context.consumer_payload, "$.error.error_message")

    logging.info("Assert that tmf-mediator updated the state of APPLY_CAC_CONFIGURATION")
    expected_state = "SUSPEND" if context.cac_provisioning_status == "CAC_PROVISIONING_ERROR" else "COMPLETED"
    cac.validate_state_of_operations(context.service_order_id, "APPLY_CAC_CONFIGURATION", expected_state)

    if expected_state != "SUSPEND":
        msg = data_files.read_config('cac_errors.yml', f"CAC_errors.{context.cac_provisioning_status}")
        context.service_order_item_id = payload.get_item_by_type(context.payload, "ucc.msoc.cac-configuration")[0] + 1
        logging.info("Assert that tmf-mediator sent tmfmediator_update_serviceorder")
        msg = msg.replace('.', context.cac_id)
        context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_update_serviceorder')
        context.consumer_payload = KafkaMessagesFilter(context).tmfmediator_update_serviceorder(msg)[0]
        topic_validator.KafkaTopicValidator(context).tmfmediator_update_serviceorder()


@then("default NGIN values are applied")
def step_impl(context):
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_apply_cacconfiguration')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_apply_cacconfiguration()
    common.update_middleware_correlation_id(context)
    context.cac_id = context.cac_id.upper()
    context.margin_in = context.margin_out = context.margin_all = context.burst_margin_in = context.burst_margin_out = context.burst_margin_all = 0
    state = "IN_PROGRESS" if hasattr(context, "action") and context.action == "modify" else "WAITING"
    doc = database.get_cac_configuration_request(context.cac_id.upper(), state, context.op_co_customer_id,
                                                 str(context.margin_in))
    validate_cac_configuration_in_db(context, state, doc)


@then("CAC ID is passed successfully to CRF for add numbers")
def pass_cac_id_to_crf(context):
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_create_addnumbers')
    topic_validator.KafkaTopicValidator(context).validate_topic('tmfmediator_create_addnumbers')

    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_command_add_crfnumber')
    topic_validator.KafkaTopicValidator(context).validate_topic('numbermanagement_command_add_crfnumber')


@then("data in topic 'idmapper_event_msoccustomercac_added' is retrieved and validated with {parameter} and {value}")
def validate_topic_idmapper_event_msoccustomercac_added(context, parameter, value):
    topic_name = "idmapper_event_msoccustomercac_added"
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    error_type = f"{parameter}_{value}"
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name, error_type=error_type)


@then("data in topic 'crfgateway_event_cacconfiguration_applied' is retrieved and validated with outcome '{outcome}'")
@then(
    "data in topic 'crfgateway_event_cacconfiguration_applied' is retrieved and validated with {parameter} and {value}")
def validate_topic_crfgateway_event_cacconfiguration_applied_with_error(context, parameter=None, value=None,
                                                                        outcome=None):
    topic_name = "crfgateway_event_cacconfiguration_applied"
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    error_type = f"{parameter}_{value}" if parameter else None
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name, error_type=error_type, outcome=outcome)


@then("CAC ID is persisted in CRF")
def validate_apply_cac_in_crf_db(context):
    # changing it to upper case because of this defect: https://jira.tools.aws.vodafone.com/browse/UN-32435
    context.cac_id = context.cac_id.upper()
    document = database.get_cac_configuration_request(context.cac_id, "CANCELLED", context.op_co_customer_id)
    logging.info(f'{document=}')
    document = database.get_cac_configuration_request(context.cac_id, "WAITING", context.op_co_customer_id)
    validate_cac_configuration_in_db(context, "WAITING", document)


@then("validate cac configuration in DB for '{state}'")
def validate_cac_configuration_in_db(context, state, document=None):
    if not document:
        document = context.cac_document
    asserts.equals(document["cacId"], context.cac_id, 'cac_id')
    asserts.equals(document["cacConfiguration"]["marginIn"], context.margin_in, 'margin_in')
    asserts.equals(document["cacConfiguration"]["marginOut"], context.margin_out, 'margin_out')
    asserts.equals(document["cacConfiguration"]["marginAll"], context.margin_all, 'margin_all')
    if payload.has_modify_msoc_cac_configuration(context.response_payload):
        asserts.equals(document["cacConfiguration"]["burstMarginIn"], context.burst_margin_in, 'burst_margin_in')
        asserts.equals(document["cacConfiguration"]["burstMarginOut"], context.burst_margin_out, 'burst_margin_out')
        asserts.equals(document["cacConfiguration"]["burstMarginAll"], context.burst_margin_all, 'burst_margin_all')
    if state == "COMPLETED":
        asserts.equals(document["resourceOrder"]["state"], state, 'resource order state')


@then("Add cac configuration is processed in Middleware")
def cac_configuration_processed(context, error_type=None):
    common.update_middleware_correlation_id(context)

    cac.validate_order_of_operations(context.service_order_id)
    index, _ = payload.get_item_by_type(context.payload, 'ucc.msoc.cac-configuration')
    context.marketplace_event_id = context.service_order_id + "/" + str(index + 1)
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_add_msoccustomercac')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_add_msoccustomercac()
    cac_id = context.cac_id
    if "existing_cac_id" in context:
        cac_id = context.existing_cac_id
    cac.validate_cac_id_in_idmapper_db(context.op_co_customer_id, cac_id.upper())

    context.consumer_payload = consumer_data.get_messages(context, 'idmapper_event_msoccustomercac_added')
    topic_validator.KafkaTopicValidator(context).idmapper_event_msoccustomercac_added()
    common.update_middleware_correlation_id(context)
    expected_state = "COMPLETED" if not error_type else "FAILED"
    cac.validate_state_of_operations(context.service_order_id, "ADD_CAC_TO_MSOC_CUSTOMER", expected_state)


@then("Apply cac configuration is processed in Middleware")
def apply_cac_processed(context):
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_apply_cacconfiguration')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_apply_cacconfiguration()

    # assert that state is 'state'
    # changing it to upper case because of this defect: https://jira.tools.aws.vodafone.com/browse/UN-32435
    context.cac_id = context.cac_id.upper()
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_cacconfiguration_applied')
    topic_validator.KafkaTopicValidator(context).crfgateway_event_cacconfiguration_applied(outcome='WAITING')


@then("CAC document has state '{state}' in DB")
def step_impl(context, state):
    margin_in = None if not hasattr(context, "margin_in") else context.margin_in
    database.get_cac_configuration_request(context.cac_id, state, context.op_co_customer_id, margin_in)


@then("data is validated in 'tmfmediator_command_apply_cacconfiguration'")
def data_validated_in_tmfmediator_command_apply_cacconfiguration(context):
    topic_name = 'tmfmediator_command_apply_cacconfiguration'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name)
    common.update_middleware_correlation_id(context)


@then("data is validated in 'crfgateway_event_cacconfiguration_applied'")
def data_validated_in_crfgateway_event_cacconfiguration_applied(context):
    topic_name = 'crfgateway_event_cacconfiguration_applied'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    topic_validator.KafkaTopicValidator(context).validate_topic(topic_name)


@when("crf updates the resource order with inProgress state for CAC")
def crf_updates_state(context):
    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_command_add_crfnumber')
    KafkaTopicValidator(context).validate_topic('numbermanagement_command_add_crfnumber')
    CRFHandler.crf_id_saved_in_db(context)
    CRFHandler.validate_crf_request_state_db(context, 'acknowledged')
    TMFHandler.retrieve_and_validate(context, 'crfstub_process_resourceorder')
    CRFHandler.crf_notification_sent_with_status(context, 'inProgress', 201)
    CRFHandler.validate_crf_request_state_db(context, 'inProgress')
    context.cac_id = context.cac_id.upper()
    document = database.get_cac_configuration_request(context.cac_id, "IN_PROGRESS", context.op_co_customer_id)
    asserts.equals(document['state'], "IN_PROGRESS", "cac_configuration_request Document")


@then("resource order is failed to process CAC Configuration")
def resource_order_failed(context):
    context.consumer_payload = consumer_data.get_messages(context, 'numbermanagement_command_add_crfnumber')
    KafkaTopicValidator(context).validate_topic('numbermanagement_command_add_crfnumber')
    TMFHandler.retrieve_and_validate(context, 'crfstub_process_resourceorder')
    CRFHandler.crf_notification_sent_with_status(context, 'completed', 201)
    CRFHandler.validate_crf_request_state_db(context, 'completed')
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_crfnumber_added')
    KafkaTopicValidator(context).validate_topic('crfgateway_event_crfnumber_added')
    cac_configuration_processed(context)
    context.consumer_payload = consumer_data.get_messages(context, 'tmfmediator_command_apply_cacconfiguration')
    topic_validator.KafkaTopicValidator(context).tmfmediator_command_apply_cacconfiguration()
    context.consumer_payload = consumer_data.get_messages(context, 'crfgateway_event_cacconfiguration_applied')
    topic_validator.KafkaTopicValidator(context).crfgateway_event_cacconfiguration_applied(
        error_type="failed_to_process_cac_configuration", outcome='FAILED')
