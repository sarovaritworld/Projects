import logging
from behave import given, when, then

from classes import common, operations, database, asserts
from classes.domain.account import UnityAccount
from classes.payload_generators.TMF import UnityAccountPayloadGenerator, Action
from classes.kafka import KafkaTopics, consumer_data, topic_validator
from features.steps import TMFHandler, jiraHandler, patchHandler, validationHandler, kafkaHandler
from features.steps.TMFHandler import validate_final_state

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("modify ucc.unity.tenant service order requested with idpEntityId")
@given("modify ucc.unity.tenant service order requested with idpEntityId as {idp_entity_id}")
def create_modify_account_service_order(context, idp_entity_id=None):
    op_co_customer_id = getattr(context, "op_co_customer_id", None)
    market_code = getattr(context, "market_code", None)
    if idp_entity_id:
        match idp_entity_id:
            case 'blank':
                idp_entity_id = ""
            case 'SSO_FAIL':
                idp_entity_id = "http://failed123.com"
            case'SSO_NOK':
                idp_entity_id = "http://invalid.com"
    else:
        idp_entity_id = "https://pt-test-auth.dep.vodafone.com/ons-idp/saml2/idp/metadata.php"
    logger.info(f"{idp_entity_id=}")
    context.idp_entity_id = idp_entity_id
    context.unity_account = UnityAccount(op_co_customer_id=op_co_customer_id, market_code=market_code,
                                         idp_entity_id=idp_entity_id)
    context.payload = UnityAccountPayloadGenerator(context.unity_account, Action.modify).to_dict()
    if idp_entity_id == "NO_SSO":
        common.delete_key(context.payload, 'serviceOrderItem.[0].service.serviceCharacteristic[?(@.name '
                                           '=="TenantConfig")].value.idpEntityId')
        context.unity_account.idp_entity_id = None
    logger.info(f"{context.payload=}")


@then("sso config is updated in RingCentral")
def sso_config_is_updated_in_ringcentral(context):
    # Validate operation
    operations.validate_operations_order('ucc.unity.tenant', 'modify', context.service_order_id)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfmediator_command_set_ssoconfig.name)
    context.consumer_payload = consumer_data.get_messages(context, 'ringcentral_event_ssoconfig_updated')
    topic_validator.KafkaTopicValidator(context).validate_topic("ringcentral_event_ssoconfig_updated")
    jiraHandler.validate_jira_ticket_creation_success(context)
    patchHandler.send_patch_request_from_bo_tool(context, "update_service_order", "ucc.unity.tenant", "completed")
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    TMFHandler.validate_service_order_final_state(context, 'completed')


@then("sso config is failed to updated in RingCentral with '{error}'")
def sso_config_is_failed_to_updated_in_ringcentral(context, error):
    operations.validate_operations_order('ucc.unity.tenant', 'modify', context.service_order_id)
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfmediator_command_set_ssoconfig.name)
    context.consumer_payload = consumer_data.get_messages(context, 'ringcentral_event_ssoconfig_updated')
    topic_validator.KafkaTopicValidator(context).validate_topic('ringcentral_event_ssoconfig_updated', error)
    if error == "modify_sso_system_error":
        validationHandler.validate_order_status(context, 'inProgress')
    else:
        validationHandler.validate_order_status(context, 'failed')
        validationHandler.validate_error_message(context, 'failed_SSO')


@then("SET_SSO_CONFIG operation is not created in middleware")
def set_sso_config_operation_is_not_created(context):
    kafkaHandler.validate_payload_not_present_in_topic(context, 'tmfmediator_command_set_ssoconfig')
