import logging

from behave import given, then, when

from classes import common, database, tmf, utils
from classes.kafka import KafkaTopics, consumer_data
from classes.tmf import DependentOrderItemCancelledNote
from features.steps import MSOCHandler, patchHandler, validationHandler, kafkaHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@when("msoc create account order is failed")
def msoc_create_account_order_is_failed(context):
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.jiraticketmediator_respond_jiraticket.name)

    patchHandler.send_patch_request_from_bo_tool(context, "update_service_order", "ucc.msoc.customer", "failed")
    context.msoc_create_customer_failed = True

@then("delete msoc customer operation is created and completed")
def delete_msoc_customer_operation_is_created_and_completed(context):
    """
    Validate that delete msoc customer operation are created along with kafka topics checks
    Also validate that service order state is failed as msoc customer operation is failed
    """

    database.get_service_order_operation(context.service_order_id, 'DELETE_MSOC_CUSTOMER', timeout=120)
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder)
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_delete_account)

    common.update_middleware_correlation_id(context)
    kafkaHandler.get_messages(context, KafkaTopics.idmapper_event_account_deleted)
    kafkaHandler.validate_topic(context, KafkaTopics.idmapper_event_account_deleted.name)

    expected_status = 'failed'
    validationHandler.validate_order_status(context, expected_status)
    validationHandler.validate_milestones_achieved(context, expected_status)

    del context.msoc_create_customer_failed


@given(
    "customer creates a service order to '{action}' MSOC account, billing and '{number}' numbers of type '{pool_type}'")
def customer_creates_an_so_wth_msoc_customer_billing_and_numbers(context, action: str,
                                                                 number: int,
                                                                 pool_type: int):
    MSOCHandler.create_payload_msoc_account(context, action=action)
    MSOCHandler.create_payload_for_msoc_billing_identifiers(context, action=action)
    MSOCHandler.msoc_order_created_for_numbers(context, action=action, quantity=number, pool_type=pool_type)


@then("validate billing and add number order is cancelled")
def validate_billing_and_add_number_order_is_cancelled(context):
    validationHandler.validate_service_order_status(context, 'numbers', 'cancelled', 'msoc')
    validationHandler.validate_service_order_status(context, 'country-billing', 'cancelled', 'msoc')

    cancelled_note = DependentOrderItemCancelledNote(context.service_order_id, '1')
    tmf.validate_note(context.response_payload, cancelled_note, '2')
    tmf.validate_note(context.response_payload, cancelled_note, '3')


@when("customer re-creates a service order")
def service_order_recreated(context):
    # Add a check if payload is already there, if yes then re-use it
    logger.info('Sending the same payload')
    logger.debug(utils.to_json(context.payload))
