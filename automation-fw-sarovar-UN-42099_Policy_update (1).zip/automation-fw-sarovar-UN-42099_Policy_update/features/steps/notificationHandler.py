import logging
import time
from behave import *

from classes import common, read_xmldata, asserts, database, notifications
from classes.delay import Delay


@then("client receives a notification '{authorization}'")
def receive_notification_authorisation(context, authorization):
    with database.open_database('automation-fw', 'tmf-notifications') as db:
        expected_count = len(notifications.add_tenant_notifications_list)

        # check if all notifications has been received by stub
        for attempt in range(10):
            count = db.collection.count_documents({'event.serviceOrder.id': context.service_order_id})
            if count == expected_count:
                break
            time.sleep(Delay.short)
        else:
            raise Exception(f"received count of notifications: {count}, expected count {expected_count}")

        # get all notifications
        documents = db.get_documents('event.serviceOrder.id', context.service_order_id,
                                     {'is_authorized': 1, 'source': 1})

        logging.info(f'authorization: -{authorization}-')

        if 'without authentication header' in authorization:
            authorization_state = ''
            source = 'automation-fw'
        elif 'with authentication header' in authorization:
            authorization_state = True
            source = 'ringcentral-stub'
        else:
            raise NotImplementedError(f'unknown authorization: {authorization}')
        for document in documents:
            asserts.field_equals(document['is_authorized'], authorization_state, 'is_authorized')
            asserts.field_equals(document['source'], source, 'source endpoint which received notification checks')


@when("user unregister all active subscriptions")
def unregister_active_subscriptions(context):
    if len(context.subscriptions) == 0:
        logging.info("No active subscriptions found (or maybe DB returned nothing)")
        assert True
    count = 0
    for sub in context.subscriptions:
        context.subscription_id = str(sub["_id"])
        context.execute_steps("""
            Given it contains a 'valid' JWT Token
            When user sends a request to 'unregister_events_subscription'
        """)
        del context.subscription_id
        count = + 1
    logging.info(f"deactivated subscriptions count: {count}")


@then("user validates there no active subscriptions left")
def validate_no_active_subscriptions(context):
    context.execute_steps("""
                Given user gets all 'active' 'subscriptions' from database
            """)
    asserts.equals(len(context.subscriptions), 0, 'subscription count')


@given("user registers a subscription")
@given("user registers a subscription with '{auth_method}'")
def register_subscription(context, auth_method="no_authorization"):
    context.execute_steps(f"""
    Given payload for subscription is ready
    And authorization methods is '{auth_method}'
    When user sends a request to 'register_events_subscription'
    Then user validates the response data for 'register_events_subscription' from TMF Service Order API Gateway
    """)


@given("payload for subscription is ready")
def validate_subscription_payload_ready(context):
    context.subscription_payload = read_xmldata.read_jsonfile("hub_register")


@given("authorization methods is '{auth_method}'")
def validate_authorization_method(context, auth_method):
    if auth_method == 'no_authorization':
        context.subscription_payload["callback"] = common.config.appdirect_stub["url"] + "/listener/serviceOrderCreateEvent"
    elif auth_method == 'OAuth':
        context.subscription_payload["callback"] = 'http://ringcentral-stub/tmf641/notifications'
    else:
        raise NotImplementedError(f'auth_method {auth_method} is not supported')

    # make callback URL unique to this test (to avoid receiving notifications registered by other tests)
    context.subscription_test_id = str(time.time())
    context.subscription_payload["callback"] += "?subscription_test_id=" + context.subscription_test_id
