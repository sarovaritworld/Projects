import logging
from http import HTTPStatus

from behave import given, then

from classes import common, database, msoc_numbers, read_xmldata, utils
from classes.domain.account import BillingInfo, ItsmProvisioning, MSOCAccount
from classes.domain.numbers import MsocResourceType
from classes.common import create_or_update_key, delete_key
from classes.kafka import KafkaTopics
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF import Action
from classes.payload_generators.TMF.account_generator import MSOCAccountPayloadGenerator
from classes.payload_generators.TMF.country_billing_generator import CountryBillingGenerator
from classes.snow import SNOWAPIError, SNOWMilestone, check_snow_onboarding_state
from features.steps import MSOCHandler, TMFHandler, idmapperHandler, kafkaHandler, logs_handler, sharedHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


def onboard_msoc_account(context, enable_provisioning=True, link_service_to_fully_onboarded_customer=None):
    """ MSOC customer has been created and onboarded without DDIs"""
    add_account_with_snow(context, enable_provisioning, market_code=context.market_code,
                          link_service_to_fully_onboarded_customer=link_service_to_fully_onboarded_customer)
    MSOCHandler.new_msoc_customer_onboarded(context)
    MSOCHandler.msoc_billing_request_processed(context)
    context.msoc_customer_onboarded = True

    # after flow cleanup
    context.payload = None


# region Given
@given("customer creates a service order to add SNOW onboarding details")
def add_account_with_snow(context, enable_provisioning=True, market_code='VFDE',
                          link_service_to_fully_onboarded_customer: bool | None = None):
    # TODO: think how to set marketplace in general way
    context.marketplace = 'TMF'
    context.snow_onboarding = True  ## maybe could be controlled with tags?
    context.enable_provisioning = enable_provisioning
    if not hasattr(context, 'market_code'):
        context.market_code = market_code

    msoc_account = MSOCAccount(market_code=context.market_code,
                               op_co_customer_id=getattr(context, 'op_co_customer_id', None),
                               tenant_id=getattr(context, 'ms_teams_tenant_id', None),
                               itsm_provisioning=ItsmProvisioning(enable_provisioning=enable_provisioning,
                                                                  link_service_to_fully_onboarded_customer=
                                                                  link_service_to_fully_onboarded_customer),
                               billing_info=BillingInfo())
    generator = MSOCAccountPayloadGenerator(msoc_account=msoc_account, action=Action.add)
    context.msoc_account = msoc_account
    context.market_code = msoc_account.market_code
    context.op_co_customer_id = context.msoc_account.op_co_customer_id

    context.customer_name = context.msoc_account.name
    generator_2 = CountryBillingGenerator(account=msoc_account, action=Action.add, payload=generator.to_dict())
    context.payload = generator_2.to_dict()
    context.phone_number = context.payload["serviceOrderItem"][0]["service"]["serviceCharacteristic"][1]["value"][
        "phoneNumber"]


@given(
    "MSOC customer SNOW onboarding details are processed for market '{market}' with full onboarding as '{fully_onboarded_customer}'")
@given("customer with SNOW onboarding details is processed for market '{market}'")
def customer_with_snow_processed(context, market: str = None, fully_onboarded_customer: str = None):
    context.market_code = market if not None else "VFDE"
    if fully_onboarded_customer:
        fully_onboarded_customer = bool(utils.strtobool(fully_onboarded_customer))
    onboard_msoc_account(context, True, link_service_to_fully_onboarded_customer=fully_onboarded_customer)
    del context.created_jira_ticket_keys
    context.service_order_item_id = '3'


@given("customer does not want to use automated service onboarding into SNOW")
def customer_with_snow_false(context):
    onboard_msoc_account(context, False)
    del context.created_jira_ticket_keys


@given("customer with SNOW onboarding details and add DDIs are requested in same order")
def customer_with_snow_and_add_ddis(context, enable_provisioning=True, market_code='VFDE'):
    # generate payload
    add_account_with_snow(context, enable_provisioning, market_code, None)
    # generate payload and complete numbers item
    MSOCHandler.msoc_order_created_for_numbers(context, 'add', 5, pool_type=MsocResourceType.pool.name)

    # validations and patches
    MSOCHandler.new_msoc_customer_onboarded(context)  # has submit request action!
    MSOCHandler.msoc_billing_request_processed(context)
    context.msoc_customer_onboarded = True
    context.service_order_item_id = '1'


@given("tenant id is set to fail with '{outcome}'")
def set_tenant_id(context, outcome):
    context.error_type = outcome
    context.ms_teams_tenant_id = 'SNOW_fail_' + read_xmldata.generate_msoc_tenantid()
    context.snow_onboarding = False


@given("MSOC account is already onboarded to SNOW")
def msoc_account_is_onboarded_to_snow(context):
    customer_with_snow_and_add_ddis(context)
    context.snow_onboarding_validated = True
    logger.info('account is onboarded')
    MSOCHandler.validate_msoc_numbers_request(context, 'add')

    snow_onboarding_is_processed_in_middleware(context)
    # TMFHandler.validate_service_order_final_state(context, 'completed')

    context.payload = None
    del context.snow_onboarding
    del context.created_jira_ticket_keys


@given("customer updates '{field}' with '{value}' in snow onboarding service order")
def update_snow_onboarding_payload(context, field, value):
    path = 'serviceOrderItem.[0].service.serviceCharacteristic[?(@.name =="ItsmProvisioning")]'
    if value == '__NULL__':
        value = ' '
    if field in ('@type', 'enableProvisioning', 'localMarketServiceId', 'linkServiceToFullyOnboardedCustomer'):
        if value == '__MISSING__':
            delete_key(context.payload, f'{path}.value.[{field}]')
        else:
            # This code needs to uncommented/deleted based on discussion about boolean value handling in TMF GW
            # defect UN-40313
            # value = int(value) if value.isdigit() else value
            create_or_update_key(context.payload, f'{path}.value.[{field}]', value)
    # this condition needs to be moved somewhere
    elif field == 'marketCode':
        create_or_update_key(context.payload, f'relatedParty.[0].{field}', value)
    elif field in ['contractStartDate', 'contractEndDate']:
        start_path = path + '.value.contractStartDate'
        end_path = path + '.value.contractEndDate'
        today = read_xmldata.get_current_date()
        day_before = read_xmldata.get_days_before_now()
        day_after = read_xmldata.get_days_after_now()
        if value == 'today':
            create_or_update_key(context.payload, f'{path}.value.{field}',
                                 read_xmldata.get_current_date('%d-%m-%Y'))
        elif value == '1_day_before_start_date':
            create_or_update_key(context.payload, start_path, today)
            create_or_update_key(context.payload, end_path, day_before)
        elif value == '1_day_after_end_date':
            create_or_update_key(context.payload, start_path, day_after)
            create_or_update_key(context.payload, end_path, today)
        elif value == 'same_day_as_end_date':
            create_or_update_key(context.payload, start_path, today)
            create_or_update_key(context.payload, end_path, today)


# endregion

# region Then
@then("SNOW onboarding is processed in Middleware")
def snow_onboarding_is_processed_in_middleware(context, fully_onboarded_customer: bool | None = None):
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()
    if common.config.is_dev_env:
        database.validate_service_inventory_request(context.msoc_account.tenant_id,
                                                    context.msoc_account.place.country_code, fully_onboarded_customer,
                                                    context.msoc_account.op_co_customer_id)

    check_snow_onboarding_state('ACTIVE', context.msoc_account.op_co_customer_id)
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created()

    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    # this should be handled in the topic validator - it should validate only the last message
    # (or have an option to validate multiple)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(milestone=SNOWMilestone(), use_last_message=True)

    del context.extra_response_payloads

    TMFHandler.validate_service_order_final_state(context, 'completed')


@then("SNOW onboarding is not processed twice")
def snow_onboarding_not_processed_twice(context):
    MSOCHandler.validate_msoc_numbers_request(context, 'add')

    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()

    # for this topic we need to validate different outcome
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created(account_provisioned=False)

    context.service_order_item_id = '1'

    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)

    del context.extra_response_payloads

    TMFHandler.validate_service_order_final_state(context, 'completed')


@then("SNOW onboarding is not processed for this account")
def snow_onboarding_not_processed(context):
    del context.snow_onboarding

    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()

    # for this topic we need to validate different outcome
    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created(account_provisioned=False)

    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)

    del context.extra_response_payloads

    TMFHandler.validate_service_order_final_state(context, 'completed')


@then("SNOW onboarding is failed in Middleware")
def snow_onboarding_is_failed_in_middleware(context):
    logger.info(f'validating {getattr(context, "error_type")=}')
    context.snow_onboarding = False
    # should have context.snow_failure which is saved when the test is started, in prerequisite step
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_command_create_snowcustomer.name)
    KafkaTopicValidator(context).tmfmediator_command_create_snowcustomer()

    kafkaHandler.get_messages(context, KafkaTopics.snowgateway_event_snowcustomer_created.name)
    KafkaTopicValidator(context).snowgateway_event_snowcustomer_created(error_type=SNOWAPIError(),
                                                                        account_provisioned=False)

    # in order to pass tmfmediator_update_serviceorder validation it needs to have
    # service_order_item_id in the context
    context.service_order_item_id = '3'

    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)

    kafkaHandler.get_messages(context, KafkaTopics.tmfgateway_update_serviceorder.name)
    KafkaTopicValidator(context).tmfgateway_update_serviceorder(item_id='3', state='COMPLETED')

    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    KafkaTopicValidator(context).tmfmediator_update_serviceorder(use_last_message=True)

    # fetch logs from TMF Mediator
    logs_handler.retrieve_pod_logs(context, pod_name='tmf-mediator', search_value=context.service_order_id)

    assert 'TMF operation has been suspended:' in str(context.pod_logs)

    context.service_order_item_id = '3'
    TMFHandler.support_topic_sent(context, 'OPERATION_FAILED', 'SNOW')

    TMFHandler.validate_service_order_final_state(context, context.error_type)


@then("information is validated in ID mapper")
def information_validated_in_id_mapper(context):
    msoc_numbers.update_msoc_customer_context(context)
    idmapperHandler.lookup_msoc_account_by_properties(context, "bgid", "include_all_data", 'true')
    sharedHandler.validate_status_response(context, HTTPStatus.OK)
    idmapperHandler.validate_extended_msoc_account_information(context)


@given("customer sets enableProvisioning as false and provide link service field")
def customer_with_enable_provisioning_false(context):
    onboard_msoc_account(context, False, link_service_to_fully_onboarded_customer=True)
    del context.created_jira_ticket_keys
# endregion
