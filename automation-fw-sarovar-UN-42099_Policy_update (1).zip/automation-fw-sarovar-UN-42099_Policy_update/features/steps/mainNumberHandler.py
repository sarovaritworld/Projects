import logging

from behave import then

from classes import asserts, common, payload
from classes.kafka import consumer_data
from classes.kafka.messages_filter import KafkaMessagesFilter
from classes.kafka.topic_validator import KafkaTopicValidator

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@then("user retrieves and validates data in numbermanagement_command_add_numbers topic for Main Number")
def validate_numbermanagement_command_add_numbers_for_main_number(context):
    topic_name = 'numbermanagement_command_add_numbers'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    KafkaTopicValidator(context).numbermanagement_command_add_numbers("Inventory", [context.main_number],
                                                                   context.consumer_payload[0])


@then("user retrieves and validates data in tmfmediator_create_addnumbers topic for Main Number")
def validate_tmfmediator_create_addnumbers_for_main_number(context):
    topic_name = 'tmfmediator_create_addnumbers'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)

    items = payload.get_items_by_type(context.payload, 'ucc.unity.tenant')
    asserts.equals(len(items), 1, "Number of service order items for mainNumber")
    item = items[0]
    logger.debug(f'Service order item: {item}')

    consumer_messages = KafkaMessagesFilter(context).tmfmediator_create_addnumbers('mainNumber')
    asserts.equals(len(consumer_messages), 1, "Number of messages in received consumer payload for mainNumber")
    consumer_message = consumer_messages[0]
    logger.debug(f'Received consumer message: {consumer_message}')

    KafkaTopicValidator(context).tmfmediator_create_addnumbers('mainNumber', item, consumer_message)


@then("user retrieves and validates data in ringcentral_event_numbers_added topic for Main Number")
@then("user retrieves and validates data in ringcentral_event_numbers_added topic for Main Number with {error}")
def validate_rc_respond_addnumber_for_main_number(context, error=None):
    topic_name = 'ringcentral_event_numbers_added'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    if not error:
        context.main_number_id = context.consumer_payload[0]['phone_numbers']['phone_number_details'][0]['id']
    KafkaTopicValidator(context).ringcentral_event_numbers_added('Inventory', [context.main_number],
                                                                 context.consumer_payload[0], error_type=error)


@then("user retrieves and validates data in update main number topics for Main Number")
def validate_numbermanagement_command_update_numbers_for_main_number(context):
    topic_name = 'numbermanagement_command_update_numbers'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)[0]
    KafkaTopicValidator(context).numbermanagement_command_update_numbers()
    topic_name = 'ringcentral_event_numbers_updated'
    context.consumer_payload = consumer_data.get_messages(context, topic_name)
    KafkaTopicValidator(context).ringcentral_event_numbers_updated()
