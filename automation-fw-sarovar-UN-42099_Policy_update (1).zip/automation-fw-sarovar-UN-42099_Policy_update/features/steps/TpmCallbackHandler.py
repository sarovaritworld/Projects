import datetime
import logging

from behave import given

from classes import common, tpm, crf
from classes.api.requests import tmf_gateway
from classes.crf import get_resource_order_id
from classes.domain.account import TPMAccount
from classes.kafka import consumer_data, KafkaTopics
from features.steps import TpmHandler, callbackHandler, TMFHandler

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("TPM account is prepared to return '{callback_state}' from CRF")
def tpm_account_is_prepared_for_callback(context, callback_state):
    context.callback_state = callback_state
    context.notification_type = 'tmf641'
    context.market_code = 'VFDE'
    if common.config.is_staging_env:
        context.market_code = 'VFUK'
    callbackHandler.save_customer_id_for_callback(context, callback_state)
    if tpm_account := tpm.get_tpm_customer(context.op_co_customer_id, market_code=context.market_code):
        context.tpm_account = tpm_account
    else:
        context.tpm_account = TPMAccount(op_co_customer_id=context.op_co_customer_id,
                                         market_code=context.market_code)
        TpmHandler.create_tpm_customer_service_order(context, market_code=context.market_code)
        TMFHandler.request_is_sent_to_create_service_order(context)
        TpmHandler.tpm_customer_created_in_middleware(context)


@given("Service Order state is '{callback_state}'")
def initiate_service_order(context, callback_state):
    context.scenario_start_time = datetime.datetime.now()
    # it is not possible to create number request for TPM via NM
    # hence creating it from the TMF

    TpmHandler.tpm_order_created_for_numbers(context,
                                             'add',
                                             5,
                                             'pool',
                                             'separate')
    context.response_payload = tmf_gateway.Client().create_service_order(context.payload)
    context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.tmfmediator_create_addnumbers.name)

    # getting middleware_correlation_id
    common.update_middleware_correlation_id(context)
    # making sure it passed the crf step
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.numbermanagement_command_add_crfnumber.name)

    # getting the crf resource id
    context.crf_request_id = get_resource_order_id(context.middleware_correlation_id)
    logger.info(f'{context.crf_request_id=}')

    if common.config.is_dev_env:
        context.consumer_payload = consumer_data.get_messages(context, KafkaTopics.crfstub_process_resourceorder.name)
        context.crf_stub_payload = context.consumer_payload

        if context.consumer_payload['state'] != context.callback_state.upper():
            crf.send_notification(callback_state, context.crf_stub_payload, notification_type=context.notification_type)
