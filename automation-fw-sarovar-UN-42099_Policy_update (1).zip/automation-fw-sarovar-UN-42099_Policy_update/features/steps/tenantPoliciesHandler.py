import logging
import json

from behave import given, then

from classes import common, database, operations, read_xmldata
from classes.api.requests.ringcentral_gateway import stub_accounts
from classes.common import create_or_update_key
from classes.domain.account import Policies
from classes.kafka import KafkaTopics
from classes.kafka import consumer_data
from classes.kafka.topic_validator import KafkaTopicValidator
from classes.payload_generators.TMF import Action, UnityAccountPayloadGenerator
from classes.utils import strtobool
from features.steps import TMFHandler
from features.steps import flowHandler, kafkaHandler
from features.steps.CRFHandler import processed_crf_number
from features.steps.kafkaHandler import get_messages

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("add ucc.unity.tenant service order requested")
def add_ucc_unity_tenant_service_order_requested(context):
    TMFHandler.create_payload_add_unity_account(context, market_code='VFIT', product_type='FULL_STACK_STANDARD',
                                                order_type=None)
    context.service_type = 'ucc.unity.tenant'
    context.action = Action.add.name


@then("Tenant policy service characteristic are sent to the RingCentral")
def tenant_policy_service_characteristic_sent_to_ringcentral(context, error_type=None):
    """
    Validates that tenant policy service characteristic is sent to RingCentral and validates all database records.
    This step combines:
    1. Kafka message validation
    2. Account creation validation
    3. CRF number processing
    4. Operations validation
    5. Database validation for policy creation, rules, and status
    """
    logger.info("Starting tenant policy service characteristic validation")
    
    # Process Kafka messages and validate account creation
    logger.info("Getting messages from tmfgateway_process_serviceorder topic")
    get_messages(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    
    logger.info("Validating account creation")
    flowHandler.account_is_created(context)
    
    logger.info("Processing CRF number")
    processed_crf_number(context)
    
    # Validate operations
    logger.info(f"Validating operations order for service type: {context.service_type}, action: {context.action}")
    operations.validate_operations_order(context.service_type,
                                      context.action,
                                      context.service_order_id,
                                      'SET_POLICY_ACCESS')
    context.operation_id = database.get_operation_id_by_service_order_operation('SET_POLICY_ACCESS',
                                                                              context.service_order_id)
    logger.info(f"Operation ID retrieved: {context.operation_id}")

    # Validate TMF gateway process
    logger.info("Validating TMF gateway process")
    TMFHandler.retrieve_and_validate(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    common.update_middleware_correlation_id(context)
    
    # Validate TMF mediator command and capture policy request details
    logger.info("Validating TMF mediator command for policy access")
    tmfmediator_command_set_policy_access_topic_validated(context)
    
    # Get account ID for database validation
    logger.info("Retrieving ucas_account_id for database validation")
    ucas_account_id = get_ucas_account_id_from_context(context)
    if not ucas_account_id:
        raise ValueError("Could not find ucas_account_id in initial order or account created events in context")
    
    logger.info(f"Using ucas_account_id for database validation: {ucas_account_id}")

    # Capture expected policy values from context
    expected_policy = {
        'enabled': True,
        'geo_locations': context.unity_account.policies.geo_locations if hasattr(context.unity_account, 'policies') and hasattr(context.unity_account.policies, 'geo_locations') else None,
        'ips': context.unity_account.policies.ips if hasattr(context.unity_account, 'policies') and hasattr(context.unity_account.policies, 'ips') else None,
        'default_action': context.unity_account.policies.defaultPolicyAction if hasattr(context.unity_account, 'policies') and hasattr(context.unity_account.policies, 'defaultPolicyAction') else None
    }
    logger.info(f"Expected policy configuration:\n{str(expected_policy)}")

    # Validate policy records in database
    logger.info("Starting database validation for policy records")
    with database.open_database('automation-fw', 'rcStubAccessPolicy') as db:
        # Query the database for policy records
        query = {"accountId": ucas_account_id}
        logger.info(f"Querying rcStubAccessPolicy collection with filter: {query}")
        policy_records = db.get_documents('accountId', ucas_account_id)
        logger.info(f"Found {len(policy_records)} policy records for accountId {ucas_account_id}")
        logger.info(f"Complete policy records from database:\n{str(policy_records)}")

        if not policy_records:
            raise ValueError(f"No policy records found for accountId {ucas_account_id}")

        # Validate all required requestTypes exist
        request_types = [record.get('requestType') for record in policy_records]
        logger.info(f"Found request types in records: {request_types}")
        required_types = {'Create Policy', 'Add Rules', 'Enable Policy'}
        missing_types = required_types - set(request_types)
        if missing_types:
            raise ValueError(f"Missing required request types: {missing_types}")

        # Get all records by type
        create_policy = next((record for record in policy_records if record.get('requestType') == 'Create Policy'), None)
        add_rules = next((record for record in policy_records if record.get('requestType') == 'Add Rules'), None)
        enable_policy = next((record for record in policy_records if record.get('requestType') == 'Enable Policy'), None)

        # Store policy ID from create policy record
        context.policy_id = create_policy.get('policyId')
        logger.info(f"Policy ID from Create Policy record: {context.policy_id}")

        # Validate all records have same policy ID and account ID
        for record in policy_records:
            if record.get('policyId') != context.policy_id:
                raise ValueError(f"Policy ID mismatch in {record.get('requestType')} record. "
                               f"Expected: {context.policy_id}, Got: {record.get('policyId')}")
            if record.get('accountId') != ucas_account_id:
                raise ValueError(f"Account ID mismatch in {record.get('requestType')} record. "
                               f"Expected: {ucas_account_id}, Got: {record.get('accountId')}")
        logger.info("All records have matching policy ID and account ID")

        # Validate Add Rules record against expected values
        rules = add_rules.get('records', [])
        logger.info(f"Found {len(rules)} rules in Add Rules record")
        if not rules and (expected_policy['geo_locations'] or expected_policy['ips']):
            raise ValueError(f"No rules found in Add Rules record for accountId {ucas_account_id}")

        # Validate rule actions match expected action
        if expected_policy['default_action']:
            for rule in rules:
                rule_action = rule.get('action', '').upper()
                expected_action = expected_policy['default_action'].upper()
                if rule_action != expected_action:
                    raise ValueError(f"Rule action mismatch. Expected: {expected_action}, Got: {rule_action}")
            logger.info(f"All rules have correct action: {expected_policy['default_action'].upper()}")

        # Validate rules based on policy type
        if expected_policy['geo_locations']:
            logger.info("Validating geo location rules")
            geo_rules = [rule for rule in rules if rule.get('countryIsoCode')]
            logger.info(f"Found {len(geo_rules)} geo location rules: {str(geo_rules)}")
            if not geo_rules:
                raise ValueError("No country ISO codes found in rules")
            # Validate each expected geo location is present
            for geo_location in expected_policy['geo_locations']:
                if not any(rule.get('countryIsoCode') == geo_location for rule in geo_rules):
                    raise ValueError(f"Missing geo location rule for country: {geo_location}")

        if expected_policy['ips']:
            logger.info("Validating IP rules")
            ip_rules = [rule for rule in rules if rule.get('ipRange')]
            logger.info(f"Found {len(ip_rules)} IP rules: {str(ip_rules)}")
            if not ip_rules:
                raise ValueError("No IP ranges found in rules")
            # Validate each expected IP range is present
            for ip_range in expected_policy['ips']:
                if not any(rule.get('ipRange') == ip_range for rule in ip_rules):
                    raise ValueError(f"Missing IP range rule: {ip_range}")

        # Validate Enable Policy record
        if not enable_policy.get('active'):
            raise ValueError("Policy is not enabled")
        logger.info("Policy is enabled")

        # Validate default action is opposite of expected action
        if expected_policy['default_action']:
            db_default_action = enable_policy.get('defaultAction', '').upper()
            expected_default_action = 'DENY' if expected_policy['default_action'].upper() == 'ALLOW' else 'ALLOW'
            logger.info(f"Validating default action - Expected opposite of {expected_policy['default_action'].upper()}: {expected_default_action}, Got: {db_default_action}")
            if db_default_action != expected_default_action:
                raise ValueError(f"Default action mismatch. Expected opposite action: {expected_default_action}, Got: {db_default_action}")
            logger.info("Default action validation successful - opposite action confirmed")

    # Validate RingCentral event
    logger.info("Validating RingCentral event for policy access set")
    ringcentral_event_policy_access_set_topic_validated(context, error_type)
    logger.info("Tenant policy service characteristic validation completed successfully")


@then("service order is completed for geo restriction")
def service_order_is_completed_for_geo_restriction(context):
    kafkaHandler.get_messages(context, KafkaTopics.tmfmediator_update_serviceorder.name)
    TMFHandler.validate_service_order_final_state(context, 'completed')


@given(
    "'{quantity}' '{policy_type}' is provided in Tenant policy service characteristic with default policy '{action}'")
@given("'{quantity}' '{policy_type}' is provided in Tenant policy service characteristic")
def quantity_policy_provided_in_tenant_policy_service_characteristic(context, quantity: int = None,
                                                                     policy_type: str = None, action: str = None):
    if context.unity_account.policies is None:
        policies = Policies(enabled=True, defaultPolicyAction=action)
    else:
        policies = context.unity_account.policies
    match policy_type:
        case 'geoLocations':
            geo_locations = Policies.get_country_codes(quantity)
            policies.geo_locations = geo_locations
        case 'ips':
            ips = Policies.generate_ip_addresses(quantity)
            policies.ips = ips

    context.unity_account.policies = policies
    context.payload = UnityAccountPayloadGenerator(unity_account=context.unity_account,
                                                   action=Action.add
                                                   ).to_dict()


@given("policies field '{field}' is set to '{value}'")
def field_set_to_value(context, field, value):
    create_or_update_key(context.payload, f'$..{field}', value)


@given("'{field}' policies are requested but not provided")
def policies_requested_but_not_provided(context, field):
    field_set_to_value(context, f'$..{field}', '')


@given("enabled value is set to '{enabled_value}' and '{field}' is provided")
def enabled_value_and_field_provided(context, enabled_value, field):
    quantity_policy_provided_in_tenant_policy_service_characteristic(context, 1, field)
    field_set_to_value(context, '$..enabled', strtobool(enabled_value))


@then("policies are not sent to RingCentral")
def policies_not_sent_to_ringcentral(context):
    get_messages(context, KafkaTopics.tmfgateway_process_serviceorder.name)
    flowHandler.account_is_created(context)
    processed_crf_number(context)
    database.validate_operation_not_exists(context.service_order_id, 'SET_POLICY_ACCESS')


@given("account is updated to fail on '{error_type}'")
def account_updated_to_fail_on_failure_endpoint_in_rc(context, error_type):
    quantity_policy_provided_in_tenant_policy_service_characteristic(context, 1, 'geoLocations')
    prefix_mapping = {
        'failed_create_policy': stub_accounts.rc.geo_failed_create_policy_prefix,
        'failed_add_rule': stub_accounts.rc.geo_failed_add_rule_prefix,
        'failed_enable_policy': stub_accounts.rc.geo_failed_enable_policy_prefix
    }
    geo_op_co_customer_id = prefix_mapping.get(error_type) + read_xmldata.gen_opco(marketplace='TMF')
    context.unity_account.op_co_customer_id = context.op_co_customer_id = geo_op_co_customer_id
    create_or_update_key(context.payload, 'externalReference[0].id', geo_op_co_customer_id)


@then("geo restriction operation is suspended for '{error_type}'")
def geo_operation_suspended(context, error_type):
    tenant_policy_service_characteristic_sent_to_ringcentral(context, error_type)


def tmfmediator_command_set_policy_access_topic_validated(context):
    """
    Validates the TMF mediator command to set policy access.
    This step verifies:
    1. Message is received in the correct topic
    2. Message contains the expected policy access request data
    
    Args:
        context: Behave context object containing test data
    """
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.tmfmediator_command_set_policy_access.name)
    KafkaTopicValidator(context).tmfmediator_command_set_policy_access()


def ringcentral_event_policy_access_set_topic_validated(context, error_type: str = None):
    """
    Validates the RingCentral event for policy access set.
    This step verifies:
    1. Message is received in the correct topic
    2. Message contains the expected policy access response data
    
    Args:
        context: Behave context object containing test data
        error_type: Optional error type to validate error response
    """
    context.consumer_payload = consumer_data.get_messages(context,
                                                          KafkaTopics.ringcentral_event_policy_access_set.name)
    KafkaTopicValidator(context).ringcentral_event_policy_access_set(error_type)


@given("no_policy is provided in Tenant policy service characteristic with default policy '{action}'")
def quantity_policy_provided_in_tenant_policy_service_characteristic(context, action: str = None):
    if context.unity_account.policies is None:
        policies = Policies(enabled=True, defaultPolicyAction=action)
    else:
        policies = context.unity_account.policies

    context.unity_account.policies = policies
    context.payload = UnityAccountPayloadGenerator(unity_account=context.unity_account,
                                                   action=Action.add
                                                   ).to_dict()


def get_ucas_account_id_from_context(context):
    """Helper function to get ucas_account_id from context consistently."""
    ucas_account_id = None
    
    # Try to get from ringcentral_event_initialorder_created
    initial_order_payload = consumer_data.get_messages(context, KafkaTopics.ringcentral_event_initialorder_created.name)
    if initial_order_payload:
        if isinstance(initial_order_payload, dict):
            if 'completed_order' in initial_order_payload and 'account' in initial_order_payload['completed_order']:
                ucas_account_id = initial_order_payload['completed_order']['account'].get('ucas_account_id')
                logger.info(f"Found ucas_account_id in ringcentral_event_initialorder_created: {ucas_account_id}")
        elif isinstance(initial_order_payload, list):
            for msg in initial_order_payload:
                if isinstance(msg, dict) and 'completed_order' in msg and 'account' in msg['completed_order']:
                    ucas_account_id = msg['completed_order']['account'].get('ucas_account_id')
                    logger.info(f"Found ucas_account_id in ringcentral_event_initialorder_created: {ucas_account_id}")
                    break

    # If not found, try to get from ordermanagement_event_account_created
    if not ucas_account_id:
        account_created_payload = consumer_data.get_messages(context, KafkaTopics.ordermanagement_event_account_created.name)
        if account_created_payload:
            if isinstance(account_created_payload, dict):
                if 'account' in account_created_payload:
                    ucas_account_id = account_created_payload['account'].get('ucas_account_id')
                    logger.info(f"Found ucas_account_id in ordermanagement_event_account_created: {ucas_account_id}")
            elif isinstance(account_created_payload, list):
                for msg in account_created_payload:
                    if isinstance(msg, dict) and 'account' in msg:
                        ucas_account_id = msg['account'].get('ucas_account_id')
                        logger.info(f"Found ucas_account_id in ordermanagement_event_account_created: {ucas_account_id}")
                        break

    return ucas_account_id
