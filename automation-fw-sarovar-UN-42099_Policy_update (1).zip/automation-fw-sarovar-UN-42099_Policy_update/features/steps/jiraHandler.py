import logging

from behave import then

from classes.jira_helper import transition_jira_story_to_status_done
from features.steps.TMFHandler import retrieve_and_validate


@then("status of JIRA tickets created is changed to Done")
def change_jira_status_to_done(context):
    for ticket_key in context.created_jira_ticket_keys:
        logging.info(f"handling ticket with key {ticket_key}")
        transition_jira_story_to_status_done(ticket_key)


@then("JIRA tickets has been created successfully")
def validate_jira_ticket_creation_success(context):
    retrieve_and_validate(context, 'tmfmediator_create_jiraticket')
    retrieve_and_validate(context, 'jiraticketmediator_respond_jiraticket')
    change_jira_status_to_done(context)
