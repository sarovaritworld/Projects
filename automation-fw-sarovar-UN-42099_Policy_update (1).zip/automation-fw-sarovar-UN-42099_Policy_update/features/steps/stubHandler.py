import json
import logging
import os
import time

from behave import *

from classes.common import config
from common_python import api_requests
from classes import read_xmldata, data_files, common, database, polling
from features import environment
from classes.delay import Delay

KAFKA_DATACENTER_NAME = os.environ.get("KAFKA_DATACENTER_NAME")
KAFKA_VERSION = os.environ.get("KAFKA_VERSION")
company_name = read_xmldata.readxml("company_name", "test_inputdata", "appdirectinput")
ENVIRONMENT = os.environ.get("ENVIRONMENT_NAME")
MAX_NUM_LIMIT = read_xmldata.readxml("MAX_NUM_LIMIT", "test_inputdata", "num_prov")

# Then user creates Change 'Live Reports' addon License request 'Full Stack' product with 'Standard' level edition with license '7'
@when(
    "user creates Change '{addons_type}' addon License request '{product_type}' product with '{edition_type}' level edition with license '{num_of_lic}'")
def create_addons_change_license_request_product(context, addons_type, product_type, edition_type, num_of_lic):
    context.new_license = num_of_lic
    subscriptionId_uuid = read_xmldata.gen_uuid()
    context.addons_type = addons_type
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_addonorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION

    # read_xmldata.update_xml("change_event_type", "addon license")
    addonpayload = read_xmldata.read_jsonfile("AddonChangeLicense")
    context.company_name = company_name

    ###################update the JSON######################
    if addons_type == "Additional Phone number":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ALN_38"
        context.skuID = "LC_ALN_38"
    elif addons_type == "Additional Phone number - Toll free":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ATN_39"
        context.skuID = "LC_ATN_39"
    elif addons_type == "Live Reports":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.skuID = "LC_LR_398"
    elif addons_type == "Limited Extension":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-BAS_178"
        context.skuID = "LC_DL-BAS_178"
    elif addons_type == "Hot Desking" and product_type == "Voice Only":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.skuID = "LC_LR_398"
    elif addons_type == "Hot Desking" and product_type == "Full Stack":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-HDSK_177"
        context.skuID = "LC_DL-HDSK_177"
    else:
        assert 1 == 0, " Invalid Addon Type. Please Try with valid addon type"

    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")

    ##############update the common values in JSON object#########################
    addonpayload["creator"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    addonpayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    addonpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                      "test_inputdata",
                                                                                      "appdirectinput")
    addonpayload["payload"]["account"]["parentAccountIdentifier"] = context.RC_ID
    # read_xmldata.readxml("RC_ID", "test_inputdata", "appdirectinput")
    addonpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    addonpayload["payload"]["order"]["items"][0]["quantity"] = num_of_lic

    # context.RC_ID = read_xmldata.readxml("RC_ID", "test_inputdata", "appdirectinput")

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("AddonChangeLicense", addonpayload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                          Given send get request '{ordertype}' to webhook ingester                       
                                                          """.format(ordertype="changeaddonlicense"))
    print(context.getresponse)


@given(
    "user creates '{iteration}' time Change '{addons_type}' addon License request '{product_type}' product with '{edition_type}' level edition with license '{num_of_lic}'")
@when(
    "user creates '{iteration}' time Change '{addons_type}' addon License request '{product_type}' product with '{edition_type}' level edition with license '{num_of_lic}'")
def create_time_change_license_request_product(context, iteration, addons_type, product_type, edition_type, num_of_lic):
    context.new_license = num_of_lic
    subscriptionId_uuid = read_xmldata.gen_uuid()
    context.addons_type = addons_type
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_addonorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION

    # read_xmldata.update_xml("change_event_type", "addon license")
    addonpayload = read_xmldata.read_jsonfile("AddonChangeLicense")
    context.company_name = company_name

    ###################update the JSON######################
    if addons_type == "Additional Phone number":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ALN_38"
        context.skuID = "LC_ALN_38"
    elif addons_type == "Additional Phone number - Toll free":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ATN_39"
        context.skuID = "LC_ATN_39"
    elif addons_type == "Live Reports":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.skuID = "LC_LR_398"
    elif addons_type == "Limited Extension":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-BAS_178"
        context.skuID = "LC_DL-BAS_178"
    elif addons_type == "Hot Desking" and product_type == "Voice Only":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.skuID = "LC_LR_398"
    elif addons_type == "Hot Desking" and product_type == "Full Stack":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-HDSK_177"
        context.skuID = "LC_DL-HDSK_177"
    else:
        assert 1 == 0, " Invalid Addon Type. Please Try with valid addon type"

    ##########updating Stub API@@@@@@@@
    getlistofLicAPI = read_xmldata.read_jsonfile("list_of_license")
    response_body = "{\"licenses\":[{\"quantity\":" + context.new_license1 + ",\"skuId\":\"" + context.skuID + "\",\"assigned\":true}]}"
    print("customise resp Body>>>>>>>>>>", response_body)
    getlistofLicAPI[0]["response"]["body"] = response_body
    url = read_xmldata.readxml("stubby4j_URL", "test_inputdata", 'appdirectinput')

    header = {
        'Content-Type': 'application/json'}
    print("URL>>>>>", url)
    print("BODY>>>>>", json.dumps(getlistofLicAPI, indent=3))
    context.postresponse = api_requests.put(url, data=json.dumps(getlistofLicAPI), headers=header)
    print("update RC APi response- puchase Addons ", context.postresponse)
    print("")

    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")

    ##############update the common values in JSON object#########################
    addonpayload["creator"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    addonpayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    addonpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                      "test_inputdata",
                                                                                      "appdirectinput")
    addonpayload["payload"]["account"]["parentAccountIdentifier"] = context.RC_ID
    # read_xmldata.readxml("RC_ID", "test_inputdata", "appdirectinput")
    addonpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    addonpayload["payload"]["order"]["items"][0]["quantity"] = num_of_lic

    # context.RC_ID = read_xmldata.readxml("RC_ID", "test_inputdata", "appdirectinput")

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("AddonChangeLicense", addonpayload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                          Given send get request '{ordertype}' to webhook ingester                       
                                                          """.format(ordertype="changeaddonlicense"))
    print(context.getresponse)


# And user creates Change addon License request 'Full Stack' product with 'Premium' level edition with 'SKU ID' as 'blank'
# Then user creates Change 'Live Reports' addon License request 'Full Stack' product with 'Standard' level edition with 'SKU ID' as 'blank'
@when(
    "user creates Change '{addons_type}' addon License request '{product_type}' product with '{edition_type}' level edition with '{field_type}' as '{value_type}'")
def create_addons_change_license_request_product_with_conditions(context, addons_type, product_type, edition_type, field_type, value_type):
    subscriptionId_uuid = read_xmldata.gen_uuid()
    context.addons_type = addons_type
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_addonorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION

    # read_xmldata.update_xml("change_event_type", "addon license")
    addonpayload = read_xmldata.read_jsonfile("AddonChangeLicense")
    context.company_name = company_name

    ###################update the JSON######################
    if addons_type == "Additional Phone number":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ALN_38"
        context.skuID = "LC_ALN_38"
    elif addons_type == "Additional Phone number - Toll free":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ATN_39"
        context.skuID = "LC_ATN_39"
    elif addons_type == "Live Reports":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.skuID = "LC_LR_398"
    elif addons_type == "Limited Extension":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-BAS_178"
        context.skuID = "LC_DL-BAS_178"
    elif addons_type == "Hot Desking" and product_type == "Voice Only":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.skuID = "LC_LR_398"
    elif addons_type == "Hot Desking" and product_type == "Full Stack":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-HDSK_177"
        context.skuID = "LC_DL-HDSK_177"
    else:
        assert 1 == 0, " Invalid Addon Type. Please Try with valid addon type"

    ##########updating Stub API@@@@@@@@
    getlistofLicAPI = read_xmldata.read_jsonfile("list_of_license")
    response_body = "{\"licenses\":[{\"quantity\":5,\"skuId\":\"" + context.skuID + "\",\"assigned\":true}]}"
    print("customise resp Body>>>>>>>>>>", response_body)
    getlistofLicAPI[0]["response"]["body"] = response_body
    url = read_xmldata.readxml("stubby4j_URL", "test_inputdata", 'appdirectinput')
    header = {
        'Content-Type': 'application/json'}
    print("URL>>>>>", url)
    print("BODY>>>>>", json.dumps(getlistofLicAPI, indent=3))
    context.postresponse = api_requests.put(url, data=json.dumps(getlistofLicAPI), headers=header)
    print("update RC APi response- puchase Addons ", context.postresponse)
    print("")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")

    ##############update the common values in JSON object#########################
    addonpayload["creator"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    addonpayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    addonpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                      "test_inputdata",
                                                                                      "appdirectinput")
    addonpayload["payload"]["account"]["parentAccountIdentifier"] = read_xmldata.readxml("RingCentral_ID",
                                                                                         "test_inputdata",
                                                                                         "appdirectinput")
    addonpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    addonpayload["payload"]["order"]["items"][0]["quantity"] = "6"
    context.new_license = "6"
    context.quantity = "6"

    # context.RC_ID = read_xmldata.readxml("RC_ID", "test_inputdata", "appdirectinput")
    # Update json for error ######
    if field_type == "SKU ID" and value_type == "blank":
        addonpayload["payload"]["order"]["editionCode"] = ""
    elif field_type == "Quantity" and value_type == "blank":
        addonpayload["payload"]["order"]["items"][0]["quantity"] = ""
        context.new_license = ""
        context.quantity = ""
    elif field_type == "Account ID" and value_type == "blank":
        addonpayload["payload"]["account"]["parentAccountIdentifier"] = ""
    elif field_type == "SKU ID" and value_type == "invalid":
        addonpayload["payload"]["order"]["editionCode"] = "#jer@$"
    elif field_type == "Quantity" and value_type == "invalid":
        addonpayload["payload"]["order"]["items"][0]["quantity"] = "2.55"
        context.new_license = "2.55"
        context.quantity = "2.55"
    else:
        assert 1 == 0, "#################Condition mismatch######################"

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("AddonChangeLicense", addonpayload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                          Given send get request '{ordertype}' to webhook ingester                       
                                                          """.format(ordertype="changeaddonlicense"))
    print(context.getresponse)


@when("user places an order to add device add-on from AppDirect by providing '{field_type}' as '{value_type}'")
def order_add_device_addon_from_appdirect(context, field_type, value_type):
    read_xmldata.generatedatainitialorder()
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    Addon_Device_payload = read_xmldata.read_jsonfile("Addon_Device")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    read_xmldata.update_xml("product_type", "addon device")
    ##############update the common values in JSON object#########################
    Addon_Device_payload["creator"]["email"] = email_id  # Need to check
    Addon_Device_payload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    # context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata", "appdirectinput")
    Addon_Device_payload["payload"]["company"]["uuid"] = context.company_uuid
    Addon_Device_payload["payload"]["company"]["name"] = company_name
    Addon_Device_payload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                              "test_inputdata",
                                                                                              "appdirectinput")
    Addon_Device_payload["payload"]["configuration"]["parentSubscriptionId"] = context.subscriptionId_uuid
    Addon_Device_payload["payload"]["account"]["accountIdentifier"] = context.RC_ID
    Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = context.accountLocationID
    Addon_Device_payload["payload"]["company"]["email"] = email_id
    Addon_Device_payload["payload"]["company"]["phoneNumber"] = contact_number  # Need to check
    Addon_Device_payload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    Addon_Device_payload["payload"]["order"]["items"][0]["quantity"] = '1'
    Addon_Device_payload["payload"]["order"]["editionCode"] = "LC_HD_522"

    if field_type == 'all Mandatory field' and value_type == "blank":
        Addon_Device_payload["payload"]["order"]["items"][0]["quantity"] = ""
        Addon_Device_payload["payload"]["order"]["editionCode"] = ""
        Addon_Device_payload["payload"]["configuration"]["subscriptionId"] = ""
        Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = ""
        Addon_Device_payload["payload"]["account"]["accountIdentifier"] = ""

    elif field_type == 'parentAccountIdentifier' and value_type == "Invalid":
        Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = "999988887777"

    elif field_type == 'accountIdentifier' and value_type == "Invalid":
        Addon_Device_payload["payload"]["account"]["accountIdentifier"] = "9999999999"

    elif field_type == 'parentAccountIdentifier' and value_type == "blank":
        Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = ""

    elif field_type == 'accountIdentifier' and value_type == "blank":
        Addon_Device_payload["payload"]["account"]["accountIdentifier"] = ""

    elif field_type == 'Event_Token' and value_type == "blank":
        Addon_Device_payload["payload"]["configuration"]["subscriptionId"] = ""

    elif field_type == 'Quantity' and value_type == "blank":
        Addon_Device_payload["payload"]["order"]["items"][0]["quantity"] = ""

    elif field_type == 'SKU_ID' and value_type == "blank":
        Addon_Device_payload["payload"]["order"]["editionCode"] = ""

    else:
        assert 1 == 0, "Scripts not available for this type of field"

    read_xmldata.write_jsonfile("Addon_Device", Addon_Device_payload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="addon_device"))
    print(context.getresponse)
    print(" ")


# Given user sends a payload for IP device from AppDirect to Middleware
@given("user sends a payload for IP device from AppDirect to Middleware")
def send_payload_for_ip_device_from_appdirect_mw(context):
    context.company_uuid = read_xmldata.gen_uuid()
    context.subscriptionId_uuid = read_xmldata.readxml("Master_SubscriptionId", "test_inputdata", "appdirectinput")
    context.RC_ID = read_xmldata.readxml("Master_RC_ID", "test_inputdata", "appdirectinput")
    context.accountLocationID = read_xmldata.readxml("AccountLocationID", "test_inputdata", "appdirectinput")
    context.execute_steps(u"""
                       When user places an order to add '1' add-on from AppDirect with 'same' SKUID                       
                                                       """.format())


@when("user places an order to add '{value}' add-on from AppDirect with '{SKU_type}' SKUID")
def order_add_value_add_on_from_appdirect_with_skuid(context, value, SKU_type):
    read_xmldata.generatedatainitialorder()
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    Addon_Device_payload = read_xmldata.read_jsonfile("Addon_Device")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    read_xmldata.update_xml("product_type", "addon device")
    ##############update the common values in JSON object#########################
    Addon_Device_payload["creator"]["email"] = email_id  # Need to check
    Addon_Device_payload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    # context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata", "appdirectinput")
    Addon_Device_payload["payload"]["company"]["uuid"] = context.company_uuid
    Addon_Device_payload["payload"]["company"]["name"] = company_name
    Addon_Device_payload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                              "test_inputdata",
                                                                                              "appdirectinput")
    Addon_Device_payload["payload"]["configuration"]["parentSubscriptionId"] = context.subscriptionId_uuid
    Addon_Device_payload["payload"]["account"]["accountIdentifier"] = context.RC_ID
    Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = context.accountLocationID
    Addon_Device_payload["payload"]["company"]["email"] = email_id
    Addon_Device_payload["payload"]["company"]["phoneNumber"] = contact_number  # Need to check
    Addon_Device_payload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    Addon_Device_payload["payload"]["order"]["items"][0]["quantity"] = value

    if SKU_type == 'same':
        Addon_Device_payload["payload"]["order"]["editionCode"] = "LC_HD_522"
    elif SKU_type == 'different':
        Addon_Device_payload["payload"]["order"]["editionCode"] = "LC_HD_523"
    else:
        assert 1 == 0, "Invalid SKU ID Type."

    read_xmldata.write_jsonfile("Addon_Device", Addon_Device_payload)
    time.sleep(Delay.medium)
    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="addon_device"))
    print(context.getresponse)
    print(" ")


##############IMP#
@when(
    "user places an order to add '{value}' add-on from AppDirect with '{SKU_type}' SKUID for '{device_type}' master device")
def order_add_value_add_on_from_appdirect_with_skuid_master(context, value, SKU_type, device_type):
    read_xmldata.generatedatainitialorder()
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    Addon_Device_payload = read_xmldata.read_jsonfile("Addon_Device")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    read_xmldata.update_xml("product_type", "addon device")
    ##############update the common values in JSON object#########################
    Addon_Device_payload["creator"]["email"] = email_id  # Need to check
    Addon_Device_payload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    # context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata", "appdirectinput")
    Addon_Device_payload["payload"]["company"]["uuid"] = context.company_uuid
    Addon_Device_payload["payload"]["company"]["name"] = company_name
    Addon_Device_payload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                              "test_inputdata",
                                                                                              "appdirectinput")
    Addon_Device_payload["payload"]["configuration"]["parentSubscriptionId"] = context.subscriptionId_uuid
    Addon_Device_payload["payload"]["account"]["accountIdentifier"] = context.RC_ID
    Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = context.accountLocationID
    Addon_Device_payload["payload"]["company"]["email"] = email_id
    Addon_Device_payload["payload"]["company"]["phoneNumber"] = contact_number  # Need to check
    Addon_Device_payload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    Addon_Device_payload["payload"]["order"]["items"][0]["quantity"] = value

    if SKU_type == 'same':
        Addon_Device_payload["payload"]["order"]["editionCode"] = "LC_HD_522"
    elif SKU_type == 'different':
        Addon_Device_payload["payload"]["order"]["editionCode"] = "LC_HD_523"
    else:
        assert 1 == 0, "Invalid SKU ID Type."
    if device_type == 'First':
        Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = context.First_MW_location_id
        Addon_Device_payload["payload"]["configuration"]["parentSubscriptionId"] = context.First_subscriptionId_uuid
    elif device_type == 'Second':
        Addon_Device_payload["payload"]["account"]["parentAccountIdentifier"] = context.Second_MW_location_id
        Addon_Device_payload["payload"]["configuration"]["parentSubscriptionId"] = context.Second_subscriptionId_uuid
    else:
        assert 1 == 0, "Invalid Device Type."
    read_xmldata.write_jsonfile("Addon_Device", Addon_Device_payload)
    time.sleep(Delay.medium)
    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="addon_device"))
    print(context.getresponse)
    print(" ")


################################################################################################################
@given("user places an order to purchase a master device from AppDirect with new Company UUID")
def order_master_device_purchase_from_appdirect_with_new_uuid(context):
    read_xmldata.generatedatainitialorder()
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    master_device_payload = read_xmldata.read_jsonfile("Master_Device")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    read_xmldata.update_xml("product_type", "master device")
    ##############update the common values in JSON object#########################
    master_device_payload["creator"]["email"] = email_id
    master_device_payload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    context.company_uuid = read_xmldata.gen_uuid()
    print("New Company UUID is = ", context.company_uuid)
    print("")
    company_name = "Test_Automation"
    master_device_payload["payload"]["company"]["uuid"] = context.company_uuid
    master_device_payload["payload"]["company"]["name"] = company_name
    context.subscriptionId_uuid = read_xmldata.readxml("subscriptionId_uuid", "test_inputdata", "appdirectinput")
    master_device_payload["payload"]["configuration"]["subscriptionId"] = context.subscriptionId_uuid
    master_device_payload["payload"]["company"]["email"] = email_id
    master_device_payload["payload"]["company"]["phoneNumber"] = contact_number
    master_device_payload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    master_device_payload["payload"]["order"]["items"][0]["quantity"] = 1
    print("Master Device payload = {}".format(json.dumps(master_device_payload, indent=3)))
    read_xmldata.write_jsonfile("Master_Device", master_device_payload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="master_device"))
    print(context.getresponse)
    print(" ")


# Given user sends a payload for a master device from AppDirect to Middleware
@given("user sends a payload for a master device from AppDirect to Middleware")
def send_payload_for_master_device_from_appdirect_mw(context):
    context.company_uuid = read_xmldata.gen_uuid()
    context.execute_steps(u"""
                       When user places an order to purchase a master device from AppDirect                       
                                                       """.format())


# When user places an order to purchase a master device from AppDirect
@when("user places an order to purchase a master device from AppDirect")
def order_purchase_master_device_from_appdirect(context):
    read_xmldata.generatedatainitialorder()
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    master_device_payload = read_xmldata.read_jsonfile("Master_Device")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    read_xmldata.update_xml("product_type", "master device")
    ##############update the common values in JSON object#########################
    master_device_payload["creator"]["email"] = email_id
    master_device_payload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    # context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata", "appdirectinput")
    master_device_payload["payload"]["company"]["uuid"] = context.company_uuid
    master_device_payload["payload"]["company"]["name"] = company_name
    context.subscriptionId_uuid = read_xmldata.readxml("subscriptionId_uuid", "test_inputdata", "appdirectinput")
    master_device_payload["payload"]["configuration"]["subscriptionId"] = context.subscriptionId_uuid
    master_device_payload["payload"]["company"]["email"] = email_id
    master_device_payload["payload"]["company"]["phoneNumber"] = contact_number
    master_device_payload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    master_device_payload["payload"]["order"]["items"][0]["quantity"] = 1
    print("Master Device payload = {}".format(json.dumps(master_device_payload, indent=3)))
    read_xmldata.write_jsonfile("Master_Device", master_device_payload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="master_device"))
    print(context.getresponse)
    print(" ")


# When user places an order to purchase a master device from AppDirect with different address
@when("user places an order to purchase a master device from AppDirect with different address")
def order_purchase_master_device_from_appdirect_with_alternate_address(context):
    read_xmldata.generatedatainitialorder()
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    master_device_payload = read_xmldata.read_jsonfile("Master_Device")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    read_xmldata.update_xml("product_type", "master device")
    ##############update the common values in JSON object#########################
    master_device_payload["creator"]["email"] = email_id
    master_device_payload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    # context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata", "appdirectinput")
    master_device_payload["payload"]["company"]["uuid"] = context.company_uuid
    master_device_payload["payload"]["company"]["name"] = company_name
    context.subscriptionId_uuid = read_xmldata.readxml("subscriptionId_uuid", "test_inputdata", "appdirectinput")
    master_device_payload["payload"]["configuration"]["subscriptionId"] = context.subscriptionId_uuid
    master_device_payload["payload"]["company"]["email"] = email_id
    master_device_payload["payload"]["company"]["phoneNumber"] = contact_number
    master_device_payload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    master_device_payload["payload"]["order"]["items"][0]["quantity"] = 1

    context.postcode = "W5 3SS"
    context.address1 = "7 Oak Road"
    context.address2 = "7 Oak Road"
    context.city = "London"
    master_device_payload["payload"]["configuration"]["MainLocationZIP"] = context.postcode
    master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = context.address1
    master_device_payload["payload"]["configuration"]["MainLocationStreetAddress2"] = context.address2
    master_device_payload["payload"]["configuration"]["MainLocationCity"] = context.city

    print("Master Device payload = {}".format(json.dumps(master_device_payload, indent=3)))
    read_xmldata.write_jsonfile("Master_Device", master_device_payload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="master_device"))
    print(context.getresponse)
    print(" ")
    time.sleep(Delay.long)
    ######Updating default value in Json ######
    master_device_payload = read_xmldata.read_jsonfile("Master_Device")
    master_device_payload["payload"]["configuration"]["MainLocationZIP"] = "W5 5TH"
    master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = "1,Oak Street"
    master_device_payload["payload"]["configuration"]["MainLocationStreetAddress2"] = "1,Oak Street"
    read_xmldata.write_jsonfile("Master_Device", master_device_payload)


# When user places an order to purchase a master device from AppDirect without providing 'Company_UUID' field
@when("user places an order to purchase a master device from AppDirect without providing '{field_type}' field")
def order_purchase_master_device_from_appdirect_without_field(context, field_type):
    read_xmldata.generatedatainitialorder()
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    master_device_payload = read_xmldata.read_jsonfile("Master_Device")
    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    read_xmldata.update_xml("product_type", "master device")
    ##############update the common values in JSON object#########################
    master_device_payload["creator"]["email"] = email_id
    master_device_payload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata", "appdirectinput")
    master_device_payload["payload"]["company"]["uuid"] = context.company_uuid
    master_device_payload["payload"]["company"]["name"] = company_name
    context.subscriptionId_uuid = read_xmldata.readxml("subscriptionId_uuid", "test_inputdata", "appdirectinput")
    master_device_payload["payload"]["configuration"]["subscriptionId"] = context.subscriptionId_uuid
    master_device_payload["payload"]["company"]["email"] = email_id
    master_device_payload["payload"]["company"]["phoneNumber"] = contact_number
    master_device_payload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    master_device_payload["payload"]["order"]["items"][0]["quantity"] = 1

    ####################Update JSON for ERROR#########################################
    if "all" in field_type:
        master_device_payload["payload"]["configuration"]["MainLocationZIP"] = ""
        master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = ""

        master_device_payload["payload"]["configuration"]["MainLocationCity"] = ""
        master_device_payload["payload"]["company"]["uuid"] = ""
        master_device_payload["payload"]["configuration"]["subscriptionId"] = ""
    elif "Company_UUID" in field_type:
        master_device_payload["payload"]["company"]["uuid"] = ""

    elif "Address_line_1" in field_type:
        master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = ""
        master_device_payload["payload"]["configuration"]["MainLocationZIP"] = "W5 5TH"
        master_device_payload["payload"]["configuration"]["MainLocationCity"] = "London"

    elif "Postcode" in field_type:
        master_device_payload["payload"]["configuration"]["MainLocationCity"] = "London"
        master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = "1,Oak Street"
        master_device_payload["payload"]["configuration"]["MainLocationZIP"] = ""

    elif "City" in field_type:
        master_device_payload["payload"]["configuration"]["MainLocationZIP"] = "W5 5TH"
        master_device_payload["payload"]["configuration"]["MainLocationCity"] = ""
        master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = "1,Oak Street"

    elif "Event_Token" in field_type:
        master_device_payload["payload"]["configuration"]["subscriptionId"] = ""
    else:
        assert 1 == 0, "We are unable to Update json for this field"

    print("Master Device payload = {}".format(json.dumps(master_device_payload, indent=3)))
    read_xmldata.write_jsonfile("Master_Device", master_device_payload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="master_device"))
    print(context.getresponse)
    print(" ")


# Given user purchases 'Full Stack' product with 'Standard' level edition with license '5'
@given("user purchases '{product_type}' product with '{edition_type}' level edition with license '{value}'")
def purchase_product_with_edition_and_license(context, product_type, edition_type, value):
    read_xmldata.generatedatainitialorder()
    context.initial_license = value
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
    context.product_type = product_type.replace(" ", "_").upper() + "_" + edition_type.upper()
    context.currency = "GBP"
    context.country_code = Fullstackpayload["payload"]["company"]["country"]
    context.opco_details_name = Fullstackpayload["marketplace"]["partner"]

    context.city = common.get_field(Fullstackpayload, "payload.configuration.MainLocationCity")
    context.postcode = common.get_field(Fullstackpayload, "payload.configuration.MainLocationZIP")

    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    context.op_co_customer_id = opco_crm_customer_id

    ##############update the common values in JSON object#########################
    Fullstackpayload["creator"]["email"] = email_id
    Fullstackpayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata",
                                                "appdirectinput")
    Fullstackpayload["payload"]["company"]["uuid"] = context.company_uuid
    Fullstackpayload["payload"]["company"]["name"] = company_name
    Fullstackpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                          "test_inputdata",
                                                                                          "appdirectinput")
    Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = email_id
    Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = contact_number
    Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = opco_crm_customer_id
    Fullstackpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    Fullstackpayload["payload"]["order"]["items"][0]["quantity"] = value

    ###################update the JSON######################
    if "Full Stack" in product_type and "Entry" in edition_type:
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
    elif "Full Stack" in product_type and "Standard" in edition_type:
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
    elif "Full Stack" in product_type and "Premium" in edition_type:
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
    elif product_type == "Voice Only" and "Standard" in edition_type:
        context.edition_type = "1125"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"
    elif product_type == "Voice Only" and "Premium" in edition_type:
        context.edition_type = "1119"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="initialorder"))
    print(context.getresponse)
    print(" ")


# Given user places purchase addon order with 'Full Stack' with Standard level edition with 5 Additional Phone number as add-ons
# Given user places purchase addon order with 'Full Stack' with Standard level edition with 5 Additional Phone number as add-ons
@given(
    "user places purchase addon order with '{product_name}' with Standard level edition with 5 Additional Phone number as add-ons")
@when(
    "user places purchase addon order with '{product_name}' with Standard level edition with 5 Additional Phone number as add-ons")
def purchase_addon_order_with_product_and_five_phone_numbers(context, product_name):
    context.RC_ID = read_xmldata.readxml("RingCentral_ID", "test_inputdata", "appdirectinput")
    context.execute_steps(u"""
                    Given user places purchase addon order with '{product_type}' with 'Standard' level edition with '5' 'Additional Phone number' as add-ons
                    """.format(product_type=product_name))


# When user places purchase addon order with 'Full Stack' with 'Standard' level edition with '5' 'Live Reports' as add-ons
# And user places purchase addon order with 'Full Stack' with 'Premium' level edition with '5' 'Live Reports' as add-ons
# And user places purchase addon order with 'Full Stack'  with 'Standard' level edition with '5' 'Additional local number' as add-ons
# And user places purchase addon order with 'Full Stack'  with 'Standard' level edition with '5' 'Additional local number' as add-ons
@given(
    "user places purchase addon order with '{product_type}' with '{edition_type}' level edition with '{number_of_lic}' '{addons_type}' as add-ons")
@when(
    "user places purchase addon order with '{product_type}' with '{edition_type}' level edition with '{number_of_lic}' '{addons_type}' as add-ons")
def purchase_addon_order_with_product_and_defined_addons(context, product_type, edition_type, number_of_lic, addons_type):
    subscriptionId_uuid = read_xmldata.gen_uuid()
    context.addons_type = addons_type
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_addonorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION

    addonpayload = read_xmldata.read_jsonfile("AdditionalNumbers")
    context.company_name = company_name
    addonpayload["payload"]["order"]["items"][0]["quantity"] = number_of_lic
    context.quantity = number_of_lic
    context.initial_license = number_of_lic

    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")

    ###################update the JSON######################
    if addons_type == "Additional Phone number":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ALN_38"
        context.addon_skuID = "LC_ALN_38"
    elif addons_type == "Additional Phone number - Toll free":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ATN_39"
        context.addon_skuID = "LC_ATN_39"
    elif addons_type == "Live Reports":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.addon_skuID = "LC_LR_398"
        opco_crm_customer_id = "88572436598"
        if environment.ENVIRONMENT == "Unity-Middleware-DEV":
            context.RC_ID = "990177813"
    elif addons_type == "Limited Extension":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-BAS_178"
        context.addon_skuID = "LC_DL-BAS_178"
    elif addons_type == "Hot Desking" and product_type == "Voice Only":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.addon_skuID = "LC_LR_398"
    elif addons_type == "Hot Desking" and product_type == "Full Stack":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-HDSK_177"
        context.addon_skuID = "LC_DL-HDSK_177"
    else:
        assert 1 == 0, " Invalid Addon Type. Please Try with valid addon type"
    context.skuID = context.addon_skuID
    read_xmldata.update_xml("sku_id_type", context.addon_skuID)
    print("############################################# SKU_ID Updated in xml file#########################")

    ##############update the common values in JSON object#########################
    addonpayload["creator"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    addonpayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    addonpayload["payload"]["company"]["uuid"] = read_xmldata.readxml("company_uuid", "test_inputdata",
                                                                      "appdirectinput")
    addonpayload["payload"]["company"]["name"] = company_name
    addonpayload["payload"]["order"]["editionCode"] = context.addon_skuID
    addonpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                      "test_inputdata",
                                                                                      "appdirectinput")
    addonpayload["payload"]["company"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    addonpayload["payload"]["company"]["phoneNumber"] = read_xmldata.readxml("appdirect_contactnumber",
                                                                             "test_inputdata", "appdirectinput")
    addonpayload["payload"]["account"]["parentAccountIdentifier"] = context.RC_ID
    addonpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("AdditionalNumbers", addonpayload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                      Given send get request '{ordertype}' to webhook ingester                       
                                                      """.format(ordertype="purchaseaddon"))
    print(context.getresponse)


# Then user creates Change addon License request 'Full Stack' product with 'Standard' level edition with license '2'
# When user creates Change License request 'Full Stack' product with 'Entry' level edition with license '15'
# And user creates Change License request 'Full Stack' product with 'Entry' level edition with license '10'
@given(
    "user creates Change License request '{product_type}' product with '{edition_type}' level edition with license '{value}'")
@when(
    "user creates Change License request '{product_type}' product with '{edition_type}' level edition with license '{value}'")
def create_change_license_request_product(context, product_type, edition_type, value):
    changeLicensepayload = read_xmldata.read_jsonfile("changeLicensepayload")

    # changeLicensepayload["payload"]["account"]["accountIdentifier"] = "130875004"

    if "Full Stack" in product_type and "Entry" in edition_type:  # 'Entry' level edition with license '10'
        context.skuID = "LC_DL-UNL_50"
        context.edition_type = "1136"
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"

    if "Full Stack" in product_type and "Standard" in edition_type:  # 'Standard' level edition with license '8'
        context.skuID = "LC_DL-UNL_50"
        context.edition_type = "1118"
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"

    if "Full Stack" in product_type and "Premium" in edition_type:  # 'Premium' level edition with license '3'
        context.skuID = "LC_DL-UNL_50"
        context.edition_type = "1124"
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"

    if product_type == "Voice Only" and "Premium" in edition_type:  # 'Voice Only' product with 'Premium' level edition with license '9'
        context.skuID = "LC_DL-UNL_50"
        context.edition_type = "1119"
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"

    if product_type == "Voice Only" and "Standard" in edition_type:  # 'Voice Only' product 'Standard' level edition with license '8'
        context.skuID = "LC_DL-UNL_50"
        context.edition_type = "1125"
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"

    ##################update values#########
    context.email = read_xmldata.gen_email()
    context.URL = config.appdirect_stub["url"]
    if not hasattr(context, 'RC_ID'):
        context.RC_ID = read_xmldata.readxml("RingCentral_ID", "test_inputdata", 'appdirectinput')

    context.mobile = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    context.op_co_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")

    changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = value
    changeLicensepayload["marketplace"]["baseUrl"] = context.URL
    changeLicensepayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    changeLicensepayload["payload"]["account"]["accountIdentifier"] = context.RC_ID
    changeLicensepayload["payload"]["configuration"]["PrimaryContactEmail"] = context.email
    changeLicensepayload["payload"]["configuration"]["PrimaryContactMobile"] = context.mobile
    changeLicensepayload["payload"]["configuration"]["OpcoCRMCustomerID"] = context.op_co_customer_id
    changeLicensepayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                              "test_inputdata",
                                                                                              "appdirectinput")

    context.new_license = value
    # context.edition_type = edition_type

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("changeLicensepayload", changeLicensepayload)
    time.sleep(Delay.medium)
    # print("context.RC_ID > ", context.RC_ID)
    print(" ")
    topic = read_xmldata.readxml("appdirect_create_changelicense", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    context.execute_steps(u"""
                       Given send get request '{ordertype}' to webhook ingester                       
                                                       """.format(ordertype="changelicense"))


# When user creates Change License request 'Full Stack' product with 'Premium' level edition with 'Account ID' as 'invalid'
# When user creates Change License request 'Full Stack' product with 'Premium' level edition with 'SKU ID' as 'blank'
@given(
    "user creates Change License request '{product_type}' product with '{edition_type}' level edition with '{validation_type}' as '{value}'")
@when(
    "user creates Change License request '{product_type}' product with '{edition_type}' level edition with '{validation_type}' as '{value}'")
def create_change_license_request_product_with_edition(context, product_type, edition_type, validation_type, value):
    RingCentral_ID = read_xmldata.readxml("RingCentral_ID", "test_inputdata", 'appdirectinput')
    changeLicensepayload = read_xmldata.read_jsonfile("changeLicensepayload")
    changeLicensepayload["payload"]["account"]["accountIdentifier"] = read_xmldata.readxml("RingCentral_ID",
                                                                                           "test_inputdata",
                                                                                           'appdirectinput')

    # changeLicensepayload["payload"]["account"]["accountIdentifier"] = "130875004"

    # SKU ID Validation
    if product_type == "Full Stack" and edition_type == "Entry" and validation_type == "SKU ID" and value == "blank":  # 'Entry' level edition with license '10'
        changeLicensepayload["payload"]["order"]["editionCode"] = "/ 1136"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "5"
        context.new_license = "5"

    elif product_type == "Full Stack" and edition_type == "Standard" and validation_type == "SKU ID" and value == "blank":  # 'Standard' level edition with license '8'
        changeLicensepayload["payload"]["order"]["editionCode"] = "/ 1118"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "3"
        context.new_license = "3"

    elif product_type == "Full Stack" and edition_type == "Premium" and validation_type == "SKU ID" and value == "blank":  # 'Premium' level edition with license '3'
        changeLicensepayload["payload"]["order"]["editionCode"] = "/ 1124"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "SKU ID" and value == "blank":  # 'Voice Only' product with 'Premium' level edition with license '9'
        changeLicensepayload["payload"]["order"]["editionCode"] = " / 1119"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "12"
        context.new_license = "12"

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "SKU ID" and value == "blank":  # 'Voice Only' product 'Standard' level edition with license '8'
        changeLicensepayload["payload"]["order"]["editionCode"] = "/ 1125"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "5"
        context.new_license = "5"

    elif product_type == "Full Stack" and edition_type == "Premium" and validation_type == "SKU ID" and value == "invalid":  # 'Full Stack' product 'Standard' level edition with license '8'
        changeLicensepayload["payload"]["order"]["editionCode"] = "bac@#$dd/ 1124"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "5"
        context.new_license = "5"
    elif product_type == "Full Stack" and edition_type == "Standard" and validation_type == "SKU ID" and value == "invalid":  # 'Full Stack' product 'Standard' level edition with license '8'
        changeLicensepayload["payload"]["order"]["editionCode"] = "bac@#$dd/ 1118"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "5"
        context.new_license = "5"
    # Quantity validation

    elif product_type == "Full Stack" and edition_type == "Entry" and validation_type == "Quantity" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = ""
        context.new_license = ""

    elif product_type == "Full Stack" and edition_type == "Standard" and validation_type == "Quantity" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = ""
        context.new_license = ""

    elif product_type == "Full Stack" and edition_type == "Premium" and validation_type == "Quantity" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = ""
        context.new_license = ""

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Quantity" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = ""

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Quantity" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = ""
        context.new_license = ""

    elif product_type == "Full Stack" and edition_type == "Entry" and validation_type == "Quantity" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "2.5"
        context.new_license = "2.5"

    elif product_type == "Full Stack" and edition_type == "Standard" and validation_type == "Quantity" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "2.5"
        context.new_license = "2.5"

    elif product_type == "Full Stack" and edition_type == "Premium" and validation_type == "Quantity" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "2.3"
        context.new_license = "2.5"

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Quantity" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "2.5"
        context.new_license = "2.5"

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Quantity" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "2.5"
        context.new_license = "2.5"

    # Account ID validation

    elif product_type == "Full Stack" and edition_type == "Entry" and validation_type == "Account ID" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = ""

    elif product_type == "Full Stack" and edition_type == "Premium" and validation_type == "Account ID" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = ""

    elif product_type == "Full Stack" and edition_type == "Standard" and validation_type == "Account ID" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = ""

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Account ID" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = ""

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Account ID" and value == "blank":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = ""

    elif product_type == "Full Stack" and edition_type == "Entry" and validation_type == "Account ID" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = "#whu2$"

    elif product_type == "Full Stack" and edition_type == "Premium" and validation_type == "Account ID" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = "#whu2$"

    elif product_type == "Full Stack" and edition_type == "Standard" and validation_type == "Account ID" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = "#whu2$"

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Account ID" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = "#whu2$"

    elif product_type == "Voice Only" and edition_type == "Premium" and validation_type == "Account ID" and value == "invalid":
        changeLicensepayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"
        changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = "6"
        context.new_license = "6"
        changeLicensepayload["payload"]["account"]["accountIdentifier"] = "#whu2$"
    else:
        assert 1 == 0, "Scripts not available for this action"
    # context.new_license = value
    context.edition_type = edition_type

    ##################update values#########

    changeLicensepayload["payload"]["order"]["items"][0]["quantity"] = context.new_license
    changeLicensepayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    changeLicensepayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    changeLicensepayload["creator"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    # changeLicensepayload["payload"]["account"]["accountIdentifier"] = read_xmldata.readxml("RC_ID",
    #                                                                                        "test_inputdata",
    #                                                                                        'appdirectinput')
    changeLicensepayload["payload"]["configuration"]["PrimaryContactEmail"] = read_xmldata.readxml("email_id",
                                                                                                   "test_inputdata",
                                                                                                   "appdirectinput")
    changeLicensepayload["payload"]["configuration"]["PrimaryContactMobile"] = read_xmldata.readxml(
        "appdirect_contactnumber", "test_inputdata", "appdirectinput")
    changeLicensepayload["payload"]["configuration"]["OpcoCRMCustomerID"] = read_xmldata.readxml(
        "appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")
    changeLicensepayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                              "test_inputdata",
                                                                                              "appdirectinput")

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("changeLicensepayload", changeLicensepayload)
    time.sleep(Delay.medium)
    # print("context.RC_ID > ", context.RC_ID)
    print(" ")
    changeLicensepayload = read_xmldata.read_jsonfile("changeLicensepayload")
    print(changeLicensepayload)
    print("")
    topic = read_xmldata.readxml("appdirect_create_changelicense", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    context.execute_steps(u"""
                       Given send get request '{ordertype}' to webhook ingester                       
                                                       """.format(ordertype="changelicense"))


# Given user places order request for 'Full Stack' product with 'Standard' level edition with license '5' by providing marketplace_event_id as duplicate
@when(
    "user places order request for '{product_type}' product with '{edition_type}' level edition with license '{value}' by providing marketplace_event_id as duplicate")
def order_request_product_by_providing_marketplace_event_id(context, product_type, edition_type, value):
    read_xmldata.generatedatainitialorder()
    context.initial_license = value
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")

    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")
    context.email = email_id
    context.mobile = contact_number
    context.op_co_customer_id = opco_crm_customer_id

    ##############update the common values in JSON object#########################
    Fullstackpayload["creator"]["email"] = email_id
    Fullstackpayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    context.company_uuid = read_xmldata.readxml("company_uuid", "test_inputdata",
                                                "appdirectinput")
    Fullstackpayload["payload"]["company"]["uuid"] = context.company_uuid
    Fullstackpayload["payload"]["company"]["name"] = company_name
    Fullstackpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                          "test_inputdata",
                                                                                          "appdirectinput")
    Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = email_id
    Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = contact_number
    Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = opco_crm_customer_id
    Fullstackpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    Fullstackpayload["payload"]["order"]["items"][0]["quantity"] = value

    ###################update the JSON######################
    if "Full Stack" in product_type and "Entry" in edition_type:
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
    elif "Full Stack" in product_type and "Standard" in edition_type:
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
    elif "Full Stack" in product_type and "Premium" in edition_type:
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
    elif product_type == "Voice Only" and "Standard" in edition_type:
        context.edition_type = "1125"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"
    elif product_type == "Voice Only" and "Premium" in edition_type:
        context.edition_type = "1119"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                   Given send get request '{ordertype}' to webhook ingester                       
                                                   """.format(ordertype="duplicate_market_Event"))
    print(context.getresponse)
    print(" ")


# Given user orders 'Full Stack' product with 'Entry' level edition with license '5' by providing "Address Line 1" as blank
@given(
    "user orders '{product_type}' product with '{edition_type}' level edition with license '{value}' by providing '{field_name}' as '{field_value}'")
@when(
    "user orders '{product_type}' product with '{edition_type}' level edition with license '{value}' by providing '{field_name}' as '{field_value}'")
def order_product_by_providing_field(context, product_type, edition_type, value, field_name, field_value):
    if field_value == "duplicate":
        read_xmldata.generate_testdata_for_duplicate_event(field_name, field_value)
    else:
        read_xmldata.generatedatainitialorder()
    context.initial_license = value
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_initialorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION
    Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")

    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    context.email = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")

    ##############update the common values in JSON object#########################
    Fullstackpayload["creator"]["email"] = context.email
    Fullstackpayload["creator"]["uuid"] = read_xmldata.readxml("company_uuid", "test_inputdata", "appdirectinput")
    Fullstackpayload["payload"]["company"]["uuid"] = read_xmldata.readxml("company_uuid", "test_inputdata",
                                                                          "appdirectinput")
    Fullstackpayload["payload"]["company"]["name"] = company_name
    Fullstackpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                          "test_inputdata",
                                                                                          "appdirectinput")
    Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = context.email
    Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = contact_number
    Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = opco_crm_customer_id
    Fullstackpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    Fullstackpayload["payload"]["order"]["items"][0]["quantity"] = value

    ###################update the JSON according to TC######################

    if "Full Stack" in product_type and "Entry" in edition_type and field_name == "Address Line 1" and field_value == "blank":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["MainLocationStreetAddress1"] = ""
    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Town/ City" and field_value == "blank":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["MainLocationCity"] = ""
    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "State / County / Region" and field_value == "blank":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["MainLocationState"] = ""
    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Postcode" and field_value == "blank":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["MainLocationZIP"] = ""
    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "OpCo CRM Customer Id" and field_value == "blank":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = ""
    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Customer Admin First Name" and field_value == "blank":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactFirstName"] = ""
    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Customer Admin Email" and field_value == "blank":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = ""
        Fullstackpayload["creator"]["email"] = ""

    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "OpCo Billing Account Number" and field_value == "blank":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["OpcoBillingReference"] = ""

    elif "Voice Only" in product_type and "Premium" in edition_type and field_name == "OpCo Billing Service Reference" and field_value == "blank":
        context.edition_type = "1119"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"
        Fullstackpayload["payload"]["configuration"]["OpcoBillingReference2"] = ""

    elif "Full Stack" in product_type and "Premium" in edition_type and field_name == "OpCo Order Reference Id" and field_value == "blank":
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        Fullstackpayload["payload"]["configuration"]["OpCoOrderReference"] = ""
    ########################## OpCo CRM Customer Id#######################################
    elif "Full Stack" in product_type and "Premium" in edition_type and field_name == "OpCo CRM Customer Id" and field_value == "Invalid":
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = "#jfadjf@384h"

    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "OpCo CRM Customer Id" and field_value == "Invalid":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = "#jfadjf@384h"

    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "OpCo CRM Customer Id" and field_value == "Invalid":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = "#jfadjf@384h"

    ##########################################################################
    elif "Full Stack" in product_type and "Premium" in edition_type and field_name == "OpCo CRM Customer Id" and field_value == "duplicate":
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = context.op_co_customer_id
    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "OpCo CRM Customer Id" and field_value == "duplicate":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = context.op_co_customer_id

    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "OpCo CRM Customer Id" and field_value == "duplicate":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = context.op_co_customer_id

    ##########################Customer Email ID###############################
    elif "Full Stack" in product_type and "Premium" in edition_type and field_name == "Customer Admin Email" and field_value == "Invalid":
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        context.email = "abcd"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = "abcd"
        Fullstackpayload["creator"]["email"] = context.email
        context.email = context.email

    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "Customer Admin Email" and field_value == "Invalid":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = "abcd"
        Fullstackpayload["creator"]["email"] = "abcd"
        context.email = "abcd"

    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Customer Admin Email" and field_value == "Invalid":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = "abcd"
        Fullstackpayload["creator"]["email"] = "abcd"
        context.email = "abcd"

    ####################################################################################
    elif "Full Stack" in product_type and "Premium" in edition_type and field_name == "Customer Admin Email" and field_value == "duplicate":
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = context.email
        Fullstackpayload["creator"]["email"] = context.email

    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "Customer Admin Email" and field_value == "duplicate":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = context.email
        Fullstackpayload["creator"]["email"] = context.email

    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Customer Admin Email" and field_value == "duplicate":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = context.email
        Fullstackpayload["creator"]["email"] = context.email

    ##########################Customer Contact Number###############################
    elif "Full Stack" in product_type and "Premium" in edition_type and field_name == "Customer Contact Number" and field_value == "Invalid":
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = "abcd"

    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "Customer Contact Number" and field_value == "Invalid":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = "abcd"


    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Customer Contact Number" and field_value == "Invalid":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = "abcd"

    ####################################################################################
    elif "Full Stack" in product_type and "Premium" in edition_type and field_name == "Customer Contact Number" and field_value == "duplicate":
        context.edition_type = "1124"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1124"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = context.mobile

    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "Customer Contact Number" and field_value == "duplicate":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = context.mobile

    elif "Full Stack" in product_type and "Entry" in edition_type and field_name == "Customer Contact Number" and field_value == "duplicate":
        context.edition_type = "1136"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1136"
        Fullstackpayload["payload"]["configuration"]["PrimaryContactMobile"] = context.mobile

    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "company EventID" and field_value == "duplicate":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["company"]["uuid"] = context.company_uuid
    elif "Full Stack" in product_type and "Standard" in edition_type and field_name == "MarketPlace_account_ID" and field_value == "duplicate":
        context.edition_type = "1118"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1118"
        Fullstackpayload["payload"]["company"]["uuid"] = context.company_uuid
    elif "Voice Only" in product_type and "Standard" in edition_type and field_name == "MarketPlace_account_ID" and field_value == "duplicate":
        context.edition_type = "1125"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1125"
        Fullstackpayload["payload"]["company"]["uuid"] = context.company_uuid
    elif "Voice Only" in product_type and "Premium" in edition_type and field_name == "MarketPlace_account_ID" and field_value == "duplicate":
        context.edition_type = "1119"
        context.skuID = "LC_DL-UNL_50"
        Fullstackpayload["payload"]["order"]["editionCode"] = "LC_DL-UNL_50 / 1119"
        Fullstackpayload["payload"]["company"]["uuid"] = context.company_uuid
    else:
        assert 1 == 0, "No Additional code for this Event"

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)
    time.sleep(Delay.medium)
    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                       Given send get request '{ordertype}' to webhook ingester                       
                                                       """.format(ordertype="initialorder"))
    print(context.getresponse)


# Then user validates 'success message' in DataFactory Stub sent from Middleware
@then("user validates '{msg_type}' in DataFactory Stub sent from Middleware")
def validate_message_in_datafactory_stub_mw(context, msg_type):
    with database.open_database('automation-fw', 'data-factory') as db:
        customer_call_document = polling.wait_until(lambda: db.get_first_document('vfid', context.op_co_customer_id), "customer document", raises=False, timeout=10)
        bucket_call_document = polling.wait_until(lambda: db.get_first_document('create_bucket_call', context.op_co_customer_id), "bucket created document", raises=False, timeout=10)

    if msg_type == 'success message':
        logging.info(f'customer_call_document: {customer_call_document}')
        logging.info(f'bucket_call_document: {bucket_call_document}')
        assert customer_call_document, 'Call to create customer from DataFactory has not been registered'
        assert customer_call_document['name'] == company_name
        assert customer_call_document['market'] == 'VFUK'
        assert customer_call_document['vfid'] == context.op_co_customer_id

        assert bucket_call_document, 'Call to create bucket from DataFactory has not been registered'
        # TODO (in RC stub and here): change key to vfid
        assert bucket_call_document['create_bucket_call'] == context.op_co_customer_id

    elif msg_type == 'incorrect message':
        assert not customer_call_document, 'Call to create customer from DataFactory is registered'
        assert not bucket_call_document, 'Call to create bucket from DataFactory is registered'

# Then user validates 'error message' for 'Change License' in Appdirect Stub sent from Middleware
# Then user validates 'error message' for 'Initial Order' in Appdirect Stub sent from Middleware
# Then user validates 'success message' for 'Initial Order' in Appdirect Stub sent from Middleware
@then("user validates '{msg_type}' for '{order_type}' in Appdirect Stub sent from Middleware")
def validate_message_in_appdirect_stub_mw(context, msg_type, order_type):
    time.sleep(Delay.too_long)
    response = read_xmldata.read_jsonfile("responder_error_payload")
    logging.info("Response from Middleware = " + str(response))

    if msg_type == 'success message' and order_type == 'Initial Order':
        logging.info(f"Response from Middleware = {str(response)}")
        assert response["success"] == True, f"True Success message is not present in Appdirect response, Actual Message {response['success']} and Expected Message True"
        assert response["accountIdentifier"] == context.RC_ID, "AccountIdentifier is not present in Appdirect response"
    elif order_type == 'master device order':
        master_device_payload = read_xmldata.read_jsonfile("Master_Device")
        if 'success message' in msg_type:
            assert response[
                       "success"] == True, "True Success message is not present in Appdirect response, Actual Message {} and Expected Message {}".format(
                response["success"], "True")
            context.accountLocationID = response["accountIdentifier"]
            assert context.MW_location_id == context.accountLocationID, "Middleware Location ID {} and Response Location ID {} are not matched".format(
                context.MW_location_id, context.accountLocationID)
        elif 'Unconfirmed Account Error' in msg_type:
            assert response[
                       "message"] == 'Customer Account does not have a complete Initial Order', "Correct Error message is not present"
            assert response["success"] == False, "False message is not present in Appdirect response"
            assert response["errorCode"] == "ACCOUNT_NOT_FOUND", "errorCode is not present in Appdirect response"

        elif 'missing City error message' in msg_type:
            assert response["message"] == 'MainLocationCity is a required field', "Correct Error message is not present"
            assert response["success"] == False, "False message is not present in Appdirect response"
            assert response["errorCode"] == "INVALID_OPERATION", "errorCode is not present in Appdirect response"

            master_device_payload["payload"]["configuration"]["MainLocationCity"] = "London"
            read_xmldata.write_jsonfile("Master_Device", master_device_payload)

        elif 'missing Address_line_1 error message' in msg_type:
            assert response[
                       "message"] == 'MainLocationStreetAddress1 is a required field', "Correct Error message is not present"
            assert response["success"] == False, "False message is not present in Appdirect response"
            assert response["errorCode"] == "INVALID_OPERATION", "errorCode is not present in Appdirect response"

            master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = "1,Oak Street"
            read_xmldata.write_jsonfile("Master_Device", master_device_payload)

        elif 'missing all field error message' in msg_type:
            assert response["message"] == 'Company UUID is a required field', "Correct Error message is not present"
            assert response["success"] == False, "False message is not present in Appdirect response"
            assert response["errorCode"] == "INVALID_OPERATION", "errorCode is not present in Appdirect response"

            master_device_payload["payload"]["configuration"]["MainLocationStreetAddress1"] = "1,Oak Street"
            master_device_payload["payload"]["configuration"]["MainLocationZIP"] = "W5 5TH"
            master_device_payload["payload"]["configuration"]["MainLocationCity"] = "London"
            read_xmldata.write_jsonfile("Master_Device", master_device_payload)

        elif 'missing Postcode error message' in msg_type:
            assert response["message"] == 'MainLocationZIP is a required field', "Correct Error message is not present"
            assert response["success"] == False, "False message is not present in Appdirect response"
            assert response["errorCode"] == "INVALID_OPERATION", "errorCode is not present in Appdirect response"

            master_device_payload["payload"]["configuration"]["MainLocationZIP"] = "W5 5TH"
            read_xmldata.write_jsonfile("Master_Device", master_device_payload)

        elif 'missing Company_UUID error message' in msg_type:
            assert response["message"] == 'Company UUID is a required field', "Correct Error message is not present"
            assert response["success"] == False, "False message is not present in Appdirect response"
            assert response["errorCode"] == "INVALID_OPERATION", "errorCode is not present in Appdirect response"

        elif 'missing Event_Token error message' in msg_type:
            assert response[
                       "message"] == 'Customer Account does not have a complete Initial Order', "Correct Error message is not present"
            assert response["success"] == False, "False message is not present in Appdirect response"
            assert response["errorCode"] == "ACCOUNT_NOT_FOUND", "errorCode is not present in Appdirect response"
        else:
            assert 1 == 0, "No such validation"
    elif 'success message' in msg_type and 'IP Device complete order' in order_type:
        assert response[
                   "success"] == True, "True Success message is not present in Appdirect response, Actual Message {} and Expected Message {}".format(
            response["success"], "True")
    elif 'error message' in msg_type and 'IP Device complete order' in order_type:
        assert response["success"] == False, "False Success message is not present in Appdirect response"
    elif 'error message' in msg_type and 'Initial Order' in order_type:
        assert response["success"] == False, "False message is not present in Appdirect response"
        assert response["errorCode"] == "UNKNOWN_ERROR", "errorCode message is not present in Appdirect response"
        assert response["message"] == " (errorCode: )", "error message is not present in Appdirect response"
    elif 'error message' in msg_type and 'Change License' in order_type:
        assert response["success"] == False, "False message is not present in Appdirect response"
        assert response["errorCode"] == "UNKNOWN_ERROR", "errorCode is not present in Appdirect response"
        assert response[
                   "message"] == "Not Found", "Proper error Message is not present in Appdirect response"
    elif 'JWT Error message' in msg_type and 'Change License' in order_type:
        assert response["success"] == False, "False Message is not present in appdirect response"
        assert response["errorCode"] == "UNKNOWN_ERROR", " ERROR IS NOT MATCHED"
        assert response[
                   "message"] == "JwtToken is not present in token from RingCentral API", "Error message is not matched"
    elif 'success message' in msg_type and 'Change License' in order_type:
        assert response["success"] == True, "True message is not present in appdirect response"
    elif 'invalid error' in msg_type and 'Initial Order' in order_type:

        error_code = read_xmldata.readxml("Unknown_error_code", "test_inputdata", "appdirectinput")
        assert response[
                   "success"] == False, "False message is not matched in Appdirect response Actual response :{} and Expected response :{} ".format(
            response["success"], "False")
        assert response["errorCode"] == error_code, "errorCode message is not matched in Appdirect response Actual " \
                                                    "response :{} and Expected response :{} ".format(
            response["errorCode"], error_code)
        assert response["message"] == context.RC_error_message, "error message is not matched in Appdirect response " \
                                                                "Actual response :{} and Expected response :{} " \
                                                                "".format(response["message"], context.RC_error_message)


    elif 'duplicate_account_error_message' in msg_type and 'Initial Order' in order_type:
        duplicate_account_error_message = read_xmldata.readxml(msg_type, "test_inputdata", "appdirectinput")
        duplicate_account_error_message = duplicate_account_error_message.replace('|',
                                                                                  str(context.marketplaceAccountID))
        # duplicate_account_error_code = read_xmldata.readxml("duplicate_account_error_code", "test_inputdata", "appdirectinput")
        assert response["success"] == False, "False message is not present in Appdirect response"
        assert response["errorCode"] == "UNKNOWN_ERROR", "errorCode does not match in Appdirect response"
        assert response[
                   "message"] == duplicate_account_error_message, "error message does not match in Appdirect response"
    elif 'previous_error_message' in msg_type and 'Initial Order' in order_type:
        previous_account_error_message = read_xmldata.readxml(msg_type, "test_inputdata", "appdirectinput")
        previous_account_error_code = read_xmldata.readxml("Unknown_error_code", "test_inputdata",
                                                           "appdirectinput")
        assert response["success"] == False, "False message is not present in Appdirect response"
        assert response[
                   "errorCode"] == previous_account_error_code, "errorCode message is not present in Appdirect response"
        assert response[
                   "message"] == previous_account_error_message, "error message is not present in Appdirect response"


    else:
        assert 1 == 0, "We are not validating this fields"


# Then user validates error message 'msg' from Middleware
@then("user validates error message '{error_msg}' from Middleware")
def validate_error_message_mw(context, error_msg):
    time.sleep(Delay.medium)
    response = read_xmldata.read_jsonfile("responder_error_payload")
    if "OpcoBillingReference is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["OpcoBillingReference"] = "OPCO2222"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "OpcoBillingReference2 is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["OpcoBillingReference2"] = "OPCO3333"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "OpCoOrderReference is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["OpCoOrderReference"] = "OPCO5555"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "MainLocationStreetAddress1 is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["MainLocationStreetAddress1"] = "1,Oak Street"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "MainLocationCity is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["MainLocationCity"] = "London"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "MainLocationState is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["MainLocationState"] = "London"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "MainLocationZIP is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["MainLocationZIP"] = "W5 5TH"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "OpcoCRMCustomerID is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["OpcoCRMCustomerID"] = "1234567898"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "PrimaryContactFirstName is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["PrimaryContactFirstName"] = "Something"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "PrimaryContactEmail is a required field" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)
        Fullstackpayload = read_xmldata.read_jsonfile("FullStackOrderEventResponse")
        Fullstackpayload["payload"]["configuration"]["PrimaryContactEmail"] = "Automation@vodafone.com"
        read_xmldata.write_jsonfile("FullStackOrderEventResponse", Fullstackpayload)

    elif "Unsupported operation" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)

    elif "Quantity cannot be less than 1 (provided value 0)" in error_msg:
        assert error_msg == response["message"], "Error Message: {} is not present in AppDirect Stub response".format(
            response)

    else:
        assert 1 == 0, "condition did not match {}".format(error_msg)


# Given send get request '{ordertype}' to webhook ingester
@given("send get request '{ordertype}' to webhook ingester")
def send_get_request_to_webhook_ingester(context, ordertype):
    global marketplace_eventID_initialorder
    global marketplace_eventID_changelicense
    global marketplace_eventID_purchaseaddon
    marketplace_eventID_initialorder = read_xmldata.gen_uuid()
    read_xmldata.update_xml("marketplace_eventID_initialorder", marketplace_eventID_initialorder)
    marketplace_eventID_changelicense = read_xmldata.gen_uuid()
    read_xmldata.update_xml("marketplace_eventID_changelicense", marketplace_eventID_changelicense)
    marketplace_eventID_purchaseaddon = read_xmldata.gen_uuid()
    read_xmldata.update_xml("marketplace_eventID_purchaseaddon", marketplace_eventID_purchaseaddon)

    context.getrequestURL = read_xmldata.readxml("getrequestURL", "test_inputdata", "appdirectinput")

    if ordertype == "initialorder":
        read_xmldata.update_xml("product_type", "")
        marketplace_eventID_initialorder = read_xmldata.readxml("marketplace_eventID_initialorder", "test_inputdata",
                                                                "appdirectinput")
        context.marketplaceEventID = marketplace_eventID_initialorder
        paramvalue = {'eventUrl': config.appdirect_stub["url"] + '/appdirect/' + marketplace_eventID_initialorder,
                      'applicationUuid': 'VOICE_ONLY'}
    if ordertype == "master_device":
        marketplace_eventID_initialorder = read_xmldata.readxml("marketplace_eventID_initialorder", "test_inputdata",
                                                                "appdirectinput")
        context.marketplaceEventID = marketplace_eventID_initialorder
        paramvalue = {'eventUrl': config.appdirect_stub["url"] + '/appdirect/' + marketplace_eventID_initialorder,
                      'applicationUuid': 'IP_DEVICES'}
    if ordertype == "addon_device":
        marketplace_eventID_initialorder = read_xmldata.readxml("marketplace_eventID_initialorder", "test_inputdata",
                                                                "appdirectinput")
        context.marketplaceEventID = marketplace_eventID_initialorder
        paramvalue = {'eventUrl': config.appdirect_stub["url"] + '/appdirect/' + marketplace_eventID_initialorder,
                      'applicationUuid': 'ADDON_DEVICES'}
    if ordertype == "changelicense":
        marketplace_eventID_changelicense = read_xmldata.readxml("marketplace_eventID_changelicense", "test_inputdata",
                                                                 "appdirectinput")
        context.marketplaceEventID = marketplace_eventID_changelicense
        paramvalue = {
            'eventUrl': config.appdirect_stub["url"] + '/appdirect/change_license_event2/' + marketplace_eventID_changelicense,
            'applicationUuid': 'VOICE_ONLY'}

    if ordertype == "purchaseaddon":
        marketplace_eventID_purchaseaddon = read_xmldata.readxml("marketplace_eventID_purchaseaddon", "test_inputdata",
                                                                 "appdirectinput")
        context.marketplaceEventID = marketplace_eventID_purchaseaddon
        paramvalue = {'eventUrl': config.appdirect_stub["url"] + '/purchaseaddon/' + marketplace_eventID_purchaseaddon,
                      'applicationUuid': 'VOICE_ONLY'}
    if ordertype == "changeaddonlicense":
        marketplace_eventID_changelicense = read_xmldata.readxml("marketplace_eventID_changelicense", "test_inputdata",
                                                                 "appdirectinput")
        context.marketplaceEventID = marketplace_eventID_changelicense
        paramvalue = {'eventUrl': config.appdirect_stub["url"] + '/changeaddonlic/' + marketplace_eventID_changelicense,
                      'applicationUuid': 'VOICE_ONLY'}

    if ordertype == "duplicate_market_Event":
        read_xmldata.update_xml("product_type", "")
        marketplace_eventID_initialorder = context.marketplaceEventID
        # context.marketplaceEventID = marketplace_eventID_initialorder
        paramvalue = {'eventUrl': config.appdirect_stub["url"] + '/appdirect/' + marketplace_eventID_initialorder,
                      'applicationUuid': 'VOICE_ONLY'}
    print("API Get Request URL: {}".format(context.getrequestURL))
    print("API Get Request Param: {}".format(paramvalue))
    print("")
    context.getresponse = api_requests.get(
        context.getrequestURL, params=paramvalue, token=api_requests.AuthType.VALID)


# And user places the purchase addon order with 'Full Stack' with 'Premium' level edition with 'Hot Desking' as add-ons by providing 'ucas_account_id' with 'duplicate' value
@when(
    "user places the purchase addon order with '{product_type}' with '{edition_type}' level edition with '{addons_type}' as add-ons by providing '{field_type}' with '{value_type}' value")
def order_purchase_addon_with_product_by_providing_field(context, product_type, edition_type, addons_type, field_type, value_type):
    # context.initial_license = value
    subscriptionId_uuid = read_xmldata.gen_uuid()
    context.addons_type = addons_type
    context.edition_type = edition_type
    topic = read_xmldata.readxml("appdirect_create_addonorder", "test_inputdata", "ringCentralAPI")
    context.topic = KAFKA_DATACENTER_NAME + topic + KAFKA_VERSION

    addonpayload = read_xmldata.read_jsonfile("AdditionalNumbers")

    ###################update the JSON######################
    if addons_type == "Additional local number":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ALN_38"
        context.skuID = "LC_ALN_38"
    elif addons_type == "Additional number - toll free":
        addonpayload["payload"]["order"]["editionCode"] = "LC_ATN_39"
        context.skuID = "LC_ATN_39"
    elif addons_type == "Live Reports":
        addonpayload["payload"]["order"]["editionCode"] = "LC_LR_398"
        context.skuID = "LC_LR_398"
    elif addons_type == "Limited Extension":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-BAS_178"
        context.skuID = "LC_DL-BAS_178"
    elif addons_type == "Hot Desking":
        addonpayload["payload"]["order"]["editionCode"] = "LC_DL-HDSK_177"
        context.skuID = "LC_DL-HDSK_177"
    else:
        assert 1 == 0, "We are not validation this Addons type:> {}".format(addons_type)
    # context.skuID = context.addon_skuID
    read_xmldata.update_xml("sku_id_type", context.skuID)
    print("############################################# SKU_ID Updated in xml file#########################")


    ####################read data from XML file@@@@@@@@@@@@@@@@@@
    email_id = read_xmldata.readxml("email_id", "test_inputdata", 'appdirectinput')
    contact_number = read_xmldata.readxml("appdirect_contactnumber", "test_inputdata", "appdirectinput")
    opco_crm_customer_id = read_xmldata.readxml("appdirect_opco_crm_customer_id", "test_inputdata", "appdirectinput")

    ##############update the common values in JSON object#########################
    if value_type == "duplicate":
        addonpayload["payload"]["account"]["parentAccountIdentifier"] = context.RC_ID
        # addonpayload["payload"]["account"]["parentAccountIdentifier"] = "132051004"
    if value_type == "blank":
        addonpayload["payload"]["account"]["parentAccountIdentifier"] = " "

    addonpayload["creator"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    addonpayload["creator"]["uuid"] = read_xmldata.readxml("uuid", "test_inputdata", "appdirectinput")
    addonpayload["payload"]["company"]["uuid"] = read_xmldata.readxml("company_uuid", "test_inputdata",
                                                                      "appdirectinput")
    addonpayload["payload"]["company"]["name"] = company_name
    addonpayload["payload"]["configuration"]["subscriptionId"] = read_xmldata.readxml("subscriptionId_uuid",
                                                                                      "test_inputdata",
                                                                                      "appdirectinput")
    addonpayload["payload"]["company"]["email"] = read_xmldata.readxml("email_id", "test_inputdata", "appdirectinput")
    addonpayload["payload"]["company"]["phoneNumber"] = read_xmldata.readxml("appdirect_contactnumber",
                                                                             "test_inputdata", "appdirectinput")

    addonpayload["marketplace"]["baseUrl"] = config.appdirect_stub["url"]
    # addonpayload["payload"]["order"]["items"][0]["quantity"] = value

    #####################update the JSON file###################
    read_xmldata.write_jsonfile("AdditionalNumbers", addonpayload)
    time.sleep(Delay.medium)

    #####################seding GET request to Webhook Ingester########################
    # Given send get request '{ordertype}' to webhook ingester
    context.execute_steps(u"""
                      Given send get request '{ordertype}' to webhook ingester                       
                                                      """.format(ordertype="purchaseaddon"))
    print(context.getresponse)


# And user updates total number of licenses in Ringcentral Stub
@then(u"user updates total number of licenses in Ringcentral Stub")
def update_rc_stub_total_licenses_number(context):
    print("##########waiting for the Quantity to be updated in xml-RCStubhandler ************")
    print(" ")
    read_xmldata.update_xml("quantity", context.new_license)
    print("############################################# Quantity Updated in xml file#########################")
    print("Quantity in StubHandler = ", context.new_license)
    print("")


# Then user retrieves endpoint notification status from stub#
@then("user retrieves endpoint notification status from stub")
def retrieve_stub_endpoint_notification_status(context):
    timeout = data_files.read_config("common.yml", "timeouts.stub_timeout")
    context.get_response = data_files.read("OperationStatusEndNotification", timeout=timeout)
