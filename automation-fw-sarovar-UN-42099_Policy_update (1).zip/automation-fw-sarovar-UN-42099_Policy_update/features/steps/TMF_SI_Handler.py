"""
TMF Service Inventory
"""
import logging
from datetime import datetime, timedelta
from urllib.parse import urlparse, parse_qs

from behave import *

from classes import read_xmldata, common, asserts, account, database, polling, crf
from classes.api.requests import ringcentral_gateway
from classes.api.requests import tmf_service_inventory
from classes.api.validations.api_response_validation import TMFServiceInventoryValidationSet
from classes.utils import to_json
from models.tmf_svc_inventory_gw_api import Service
from models.utils.validator import validate_model

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


@given("user wants to retrieve  Service order list by following filter data for '{response_code}'")
@given("user wants to retrieve  Service order list by following filter data")
def retrieve_payload_list_by_filter_data(context, response_code=None):
    param_object = {}
    for row in context.table:
        if 'Date' in row['field'] and response_code == None:
            n_days_ago = int(row['value'])
            n_days_ago_date = (datetime.now() - timedelta(days=n_days_ago)).strftime("%Y-%m-%d")
            param_object.update({row['field']: n_days_ago_date})
        elif row['value'] == '__NULL__':
            param_object.update({row['field']: ''})
        else:
            param_object.update({row['field']: row['value']})

    context.param = param_object


@given("an account created with RC with '{rc_account_type}'")
@given("an account created with RC with '{rc_account_type}' and product '{product_type}'")
def validate_rc_account_creation(context, rc_account_type: str, product_type: str = 'FULL_STACK_STANDARD'):
    if id := ringcentral_gateway.td_ringcentral_id.get(rc_account_type):
        logger.info(f"Selecting account type vfid={rc_account_type} and rcid={id}")
        context.op_co_customer_id = rc_account_type if rc_account_type != "CRF_TIMEOUT_ACCOUNT" else id
    elif rc_account_type == "saved_in_db":
        context.op_co_customer_id = ringcentral_gateway.VFID_SAVE_DB_PREFIX + read_xmldata.gen_RCID()
        account.create_new_account(context, product_type=product_type, market_code=context.market_code,
                                   confirmation_status='unconfirmed')
    else:
        raise NotImplementedError(f"{rc_account_type=}")


@when("request parameters are prepared as '{invalid_parameter}'")
def set_service_request_parameters(context, invalid_parameter: str) -> None:
    """Parameters for TMF Service Inventory API.

    Common for both endpoints: service and services
    """
    params = {
        "market": context.market_code,
        "vodafoneAccountId": getattr(context, "op_co_customer_id", None),
        "serviceType": "ucc.unity.tenant",
    }

    match invalid_parameter:
        case "empty_market":
            params["market"] = ""
        case "another_market":
            params["market"] = "VFDE" if params["market"] == "VFUK" else "VFUK"
        case "non_existent_account":
            params["market"] = "VFUK"
            params["vodafoneAccountId"] = "12345678901234566546513"
        case "empty_vodafone_id":
            params["vodafoneAccountId"] = ""
        case "wrong_service_type":
            params["serviceType"] = "ucc.unity.numbers"
        case "empty_service_type":
            params["serviceType"] = ""
        case "missing_market":
            params.pop("market")
        case "missing_vodafone_id":
            params.pop("vodafoneAccountId")
        case "missing_service_type":
            params.pop("serviceType")
        case "extra_unknown_parameter":
            params["an_extra_parameter"] = "1234"
        case "valid":
            pass  # no invalid parameter
        case _:
            raise NotImplementedError(f"{invalid_parameter=}")

    context.request_params = params


@when("client requests information for his account")
def request_account_information(context) -> None:
    """Send request for all services."""
    if "request_params" not in context:
        set_service_request_parameters(context, "valid")

    client = tmf_service_inventory.Client(token=context.access_token)
    context.response = client.get_services(**context.request_params)


@when("client requests information for '{service_type}' service")
def request_service_information(context, service_type: str) -> None:
    """Send request for one service."""
    match service_type:
        case "existing":
            service_id = context.response.json()[0]["id"]
        case "non_existent_account":
            service_id = "unity-tenant-VFUK-12345"  # valid ID format
        case "id_wrong_market":
            # NB: Market is the 3rd part (when splitting ID with '-')
            service_id_parts = context.response.json()[0]["id"].split("-", maxsplit=3)
            wrong_market = "VFDE" if context.request_params["market"] == "VFUK" else "VFUK"
            service_id_parts[2] = wrong_market
            service_id = "-".join(service_id_parts)
        case "id_invalid_market":
            # NB: to pass TMF SI ID format check, market must be 3 or 4 characters
            service_id_parts = context.response.json()[0]["id"].split("-", maxsplit=3)
            service_id_parts[2] = "VFXX"
            service_id = "-".join(service_id_parts)
        case "id_invalid_format":
            # NB: No '-' in ID will ensure TMF SI format check will fail
            service_id = "12345678901234566546513"
        case _:
            raise NotImplementedError(f"{service_type=}")

    client = tmf_service_inventory.Client(token=context.access_token)
    context.response_service = client.get_service(id=service_id)
    context.request_service_id = service_id


@then("the returned account information is '{expected_result}'")
def validate_retrieved_account_information(context, expected_result: str) -> None:
    """Verification of response for multiple services."""

    if expected_result == "correct":
        expected_num_services = 1
        expected_status = 200
    elif expected_result == "empty":
        expected_num_services = 0
        expected_status = 200
    else:
        expected_num_services = None
        expected_status = int(expected_result)

    asserts.equals(context.response.status_code, expected_status, "TMF service inventory response")
    response_data: list | dict = context.response.json()
    logger.info(f"TMF service inventory response: {context.response.status_code}\n{to_json(response_data)}")

    if expected_status == 200:
        assert isinstance(response_data, list), "Response should be a list (of services)"
        asserts.equals(len(response_data), expected_num_services, "Number of services returned")
        
        # Schema validation
        for service_data in response_data:
            validate_model(service_data, Service)

    validation_set = TMFServiceInventoryValidationSet(context).endpoint_services(expected_status, response_data)
    common.validate_message(response_data, validation_set)


@then("the returned service information is '{expected_status:d}'")
def validate_retrieved_service_information(context, expected_status: int) -> None:
    """Verification of response for one service."""

    asserts.equals(context.response_service.status_code, expected_status, "TMF service response")
    response_data: dict = context.response_service.json()
    logger.info(f"TMF service inventory response: {context.response.status_code}\n{to_json(response_data)}")
    if expected_status == 200:
        # Schema validation
        validate_model(response_data, Service)

    validation_set = TMFServiceInventoryValidationSet(context).endpoint_service(expected_status, response_data)
    common.validate_message(response_data, validation_set)


@then('TMF SI request is audited in DB')
def audit_tmf_si_request_db(context):
    logging.info(f'op_co_customer_id: {context.op_co_customer_id=}')
    doc = None
    with database.open_database('tmf-svc-inventory-gw-api', 'http_audits') as db:
        document = polling.wait_until(lambda: db.collection.find({"requestUrl": {"$regex": context.op_co_customer_id}}),
                                      'TMF SI request',)

        logging.info(f'TMF SI audit document from database: {document[0]}')
        doc = (document[0])
    audit_url = doc['requestUrl']
    expected_params = context.request_params
    query_str = urlparse(audit_url).query
    logging.info(f'{query_str=}')
    actual_query_params = {
        key: val[0]
        for key, val in parse_qs(query_str).items()}
    common.validate_message(actual_query_params, expected_params)


@then("the returned account has '{expected}' info")
def validate_cac_info(context, expected):
    response_data: list | dict = context.response.json()
    logger.info(f"TMF service inventory response: {context.response.status_code}\n{to_json(response_data)}")

    characteristic_names = [c["name"] for c in response_data[0]["serviceCharacteristic"]]
    if expected == "no_cac":
        assert "CAC" not in characteristic_names
    else:
        assert "CAC" in characteristic_names
        cac_info_index = characteristic_names.index("CAC")
        cac_info_response = response_data[0]["serviceCharacteristic"][cac_info_index]
        validate_presence_of_cac_info(cac_info_response)


def validate_presence_of_cac_info(cac_info_response):
    expected_cac_info_properties = crf.get_cac_info_properties()
    # Extra property "@type" is added by TMF Service Inventory while mapping the cac info with account details
    expected_cac_info_properties.append("@type")
    actual_cac_info_properties = list(cac_info_response["value"].keys())
    for key in expected_cac_info_properties:
        asserts.in_list(key, actual_cac_info_properties, f"CAC info property = {key}")
