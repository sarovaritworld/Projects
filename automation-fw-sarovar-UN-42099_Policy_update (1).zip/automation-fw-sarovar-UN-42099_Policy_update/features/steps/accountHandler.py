import logging
from typing import Any

from behave import *

from classes import common, payload, account, read_xmldata
from features.steps import MSOCHandler, TMFHandler, numbersHandler, flowHandler, CeaseMSOCHandler
from classes.common import create_or_update_key

CURRENT_MODULE = common.get_module_name(__file__)
logger = logging.getLogger(CURRENT_MODULE)


# Given account for 'FULL_STACK_STANDARD' in 'VFDE' market is 'confirmed'
# Given account for 'FULL_STACK_STANDARD' in 'VFDE' market is 'unconfirmed'
@given("account for '{product_type}' in '{market_code}' market is '{confirmation_status}'")
def create_account_prerequisite(context, product_type, market_code, confirmation_status):
    context.market_code = market_code
    context.confirmation_status = confirmation_status
    if confirmation_status in ['confirmed', 'unconfirmed']:
        vodafone_id = None
        if common.config.is_dev_env:
            search_filter = {
                'environment': common.config.ENVIRONMENT,
                'market_code': market_code,
                'confirmation_status': confirmation_status,
                'category': 'UNITY'
            }
            vodafone_id = account.get_reusable_account_number(search_filter)
        account.create_account_if_doesnt_exist(context, vodafone_id, product_type, market_code, confirmation_status)
    elif confirmation_status == 'not_confirmed_by_RingCentral':
        payload.prepare_account_payload(context, 'add', product_type, market_code)
        context.payload['externalReference'][0]['id'] = account.generate_account_fail_confirmation()
        context.op_co_customer_id = context.payload['externalReference'][0]['id']
        context.execute_steps(f"""
            When customer sends an order to Middleware
            And RingCentral fails to 'confirm_account'
            """)
    if hasattr(context, 'payload'):
        delattr(context, 'payload')


@given('new account is requested')
def new_account_requested(context):
    context.execute_steps("""
        Given user has a Create Account payload for topic 'ordermanagement_event_account_created'
        When payload is sent to Kafka Topic 'ordermanagement_event_account_created'
    """)


@given("account is created for '{vodafone_id}' and '{market_code}' if account does not exist")
def account_created_if_not_exist(context, vodafone_id, market_code):
    account.create_account_if_doesnt_exist(context, vodafone_id, market_code=market_code)


@given("account has been onboarded")
def save_op_co_customer_id(context):
    create_account_prerequisite(context, 'FULL_STACK_STANDARD', 'VFUK', 'confirmed')


@given("Unity account to be failed in RC confirmation updated in the payload")
def update_account_value(context):
    context.op_co_customer_id = account.generate_account_fail_confirmation()
    create_or_update_key(context.payload, '$.externalReference.[0].id', context.op_co_customer_id)
    context.negative_event_type = 'confirm_account'


@given("a '{category}' account is created and '{quantity}' '{pool_type}' numbers added to it")
def create_account_and_add_numbers(context: Any, category: str, quantity, pool_type):
    category = category.upper()
    context.category = category
    match category:
        case "MSOC":
            CeaseMSOCHandler.msoc_customer_has_been_created_with_billing_info_and_add_numbers_in_resource_type(context, quantity, context.market_code)
        case "UNITY":
            TMFHandler.order_account_for_product(context, 'add', 'FULL_STACK_STANDARD', 'VFUK')
            numbersHandler.create_payload_for_numbers_with_conditions(context, 'add', quantity, 'numbers', pool_type)
            flowHandler.customer_sends_an_order_to_middleware(context)
            numbersHandler.validate_pool_number_mw(context, 'added to')
            TMFHandler.send_patch_request_tmf_service_order_gw(context, 'get_service_order_by_id')
            TMFHandler.validate_final_state(context, 'completed')
        case _:
            raise NotImplementedError(f"Please implement create account for {category=}")


@given("a '{category}' account is created")
def create_account(context: Any, category: str, market: str = "VFUK"):
    category = category.upper()
    context.category = category
    match category:
        case "MSOC":
            MSOCHandler.process_msoc_create_account_for_market(context, market)
        case "UNITY":
            create_account_prerequisite(context, 'FULL_STACK_STANDARD', 'VFUK', 'confirmed')
        case _:
            raise NotImplementedError(f"Please implement create account for {category=}")


@given("a '{category}' account is created with same account number")
def create_account_with_same_account_number(context: Any, category: str, market: str = "VFUK"):
    if not hasattr(context, "op_co_customer_id"):
        raise NotImplementedError("This step requires op_co_customer_id in context, a pre-created account")
    context.category = category
    CeaseMSOCHandler.msoc_customer_has_been_created_with_billing_info_without_adding_numbers(context, market)
